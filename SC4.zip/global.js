// [QASHVRA BOT] - global.js - Master Global Configuration & Initialization
require('dotenv').config();
const config = require('./config.json');
const Logger = require('./utils/logger');
const FileChecker = require('./utils/fileChecker');
const unicodeLoader = require('./utils/unicodeLoader');
const mongoose = require('mongoose');
const path = require('path');

class Global {
    constructor() {
        this.baseDir = __dirname;
        this.config = config;
        this.botToken = process.env.BOT_TOKEN || config.bot.token;
        this.botUsername = process.env.BOT_USERNAME || config.bot.username;
        this.ownerId = parseInt(process.env.OWNER_ID || config.owner.id);
        this.ownerUsername = process.env.OWNER_USERNAME || config.owner.username;
        this.mongodbUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/qashvra_bot';
        this.brandName = process.env.BRAND_NAME || config.brand.name;
        this.isProduction = process.env.NODE_ENV === 'production';
        
        // Global statistics (start from 0)
        this.globalStats = {
            activeSenders: { current: 0, max: 1984 },
            totalUsers: 0,
            totalFix: 0,
            totalSuccess: 0,
            winRateGlobal: 0
        };
        
        // Runtime tracking
        this.startTime = new Date();
        this.totalFilesLoaded = 0;
        this.maxFiles = 50; // Will be updated by FileChecker
    }

    async initialize() {
        try {
            // Step 1: Check files
            Logger.info('Initializing QASHVRA Global System...', 'Global');
            const fileChecker = new FileChecker(this.baseDir);
            const checkResult = fileChecker.checkAllFiles();
            
            if (!checkResult.isComplete) {
                Logger.warn(`Found ${checkResult.missing.length} missing files!`, 'Global');
                fileChecker.displaySummary();
                Logger.info('Continuing with available files...', 'Global');
            }
            
            this.maxFiles = checkResult.total;
            this.totalFilesLoaded = checkResult.loaded;
            
            // Step 2: Show startup loading
            await unicodeLoader.showStartupLoading();
            
            // Step 3: Connect to MongoDB
            await this.connectDatabase();
            
            // Step 4: Initialize global statistics from DB
            await this.initGlobalStatistics();
            
            // Step 5: Display bot start banner
            Logger.botStart(this.botUsername, this.totalFilesLoaded, this.maxFiles);
            
            return true;
        } catch (error) {
            Logger.error(`Failed to initialize: ${error.message}`, 'Global');
            process.exit(1);
        }
    }

    async connectDatabase() {
        try {
            await mongoose.connect(this.mongodbUri);
            Logger.success('Connected to MongoDB successfully', 'Database');
        } catch (error) {
            Logger.error(`MongoDB connection failed: ${error.message}`, 'Database');
            throw error;
        }
    }

    async initGlobalStatistics() {
        try {
            const StatisticsModel = require('./models/statisticsModel');
            let stats = await StatisticsModel.findOne({ type: 'global' });
            
            if (!stats) {
                // Start from 0 if no statistics exist
                stats = await StatisticsModel.create({
                    type: 'global',
                    ...this.globalStats,
                    startFromZero: true
                });
                Logger.info('Global statistics initialized from 0', 'Global');
            } else {
                // Load existing statistics
                this.globalStats = {
                    activeSenders: stats.activeSenders,
                    totalUsers: stats.totalUsers,
                    totalFix: stats.totalFix,
                    totalSuccess: stats.totalSuccess,
                    winRateGlobal: stats.winRateGlobal
                };
                Logger.info('Global statistics loaded from database', 'Global');
            }
        } catch (error) {
            Logger.warn('Using default statistics (start from 0)', 'Global');
        }
    }

    async getGlobalStatistics() {
        try {
            const StatisticsModel = require('./models/statisticsModel');
            const stats = await StatisticsModel.findOne({ type: 'global' });
            return stats || this.globalStats;
        } catch (error) {
            return this.globalStats;
        }
    }

    getRuntime() {
        const now = new Date();
        const diff = now - this.startTime;
        const hours = Math.floor(diff / 3600000);
        const minutes = Math.floor((diff % 3600000) / 60000);
        const seconds = Math.floor((diff % 60000) / 1000);
        return `${hours}h ${minutes}m ${seconds}s`;
    }

    getStartDate() {
        const moment = require('moment-timezone');
        return moment(this.startTime).tz('Asia/Jakarta').format('dddd, DD MMMM YYYY HH:mm:ss');
    }

    isOwner(userId) {
        return userId === this.ownerId;
    }
}

// Create singleton instance
const globalInstance = new Global();

module.exports = globalInstance;
// END OF FILE - global.js