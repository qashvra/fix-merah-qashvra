// [QASHVRA BOT] - ecosystem.config.js - PM2 Process Manager Configuration
module.exports = {
    apps: [
        {
            name: 'qashvra-bot',
            script: 'index.js',
            cwd: __dirname,
            node_args: '--max-old-space-size=2048',
            
            // Process settings
            instances: 1,
            exec_mode: 'fork',
            autorestart: true,
            watch: false,
            max_memory_restart: '1G',
            
            // Environment
            env: {
                NODE_ENV: 'production',
                TZ: 'Asia/Jakarta'
            },
            env_development: {
                NODE_ENV: 'development',
                TZ: 'Asia/Jakarta'
            },
            
            // Logging
            error_file: './logs/pm2_error.log',
            out_file: './logs/pm2_output.log',
            log_file: './logs/pm2_combined.log',
            merge_logs: true,
            log_date_format: 'YYYY-MM-DD HH:mm:ss',
            
            // Cron restart (every day at 3 AM)
            cron_restart: '0 3 * * *',
            
            // Graceful shutdown
            kill_timeout: 10000,
            listen_timeout: 5000,
            
            // Restart delay
            restart_delay: 5000,
            max_restarts: 10,
            
            // Custom metrics
            instance_var: 'INSTANCE_ID'
        }
    ]
};
// END OF FILE - ecosystem.config.js