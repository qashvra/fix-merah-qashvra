// [QASHVRA BOT] - middleware/authMiddleware.js - Authentication & User Registration
const UserModel = require('../models/userModel');
const StatisticsModel = require('../models/statisticsModel');
const globalInstance = require('../global');
const Logger = require('../utils/logger');

async function authMiddleware(ctx, next) {
    // Skip if no message or callback query
    if (!ctx.from) return next();
    
    const userId = ctx.from.id;
    const username = ctx.from.username || '';
    const firstName = ctx.from.first_name || '';
    const lastName = ctx.from.last_name || '';
    
    try {
        // Check if user exists, if not create new one
        let user = await UserModel.findOne({ userId });
        
        if (!user) {
            // New user registration
            user = await UserModel.findOrCreate(userId, {
                username,
                firstName,
                lastName
            });
            
            Logger.info(`New user registered: ${userId} (@${username})`, 'AuthMiddleware');
            
            // Increment global user count
            await StatisticsModel.findOneAndUpdate(
                { type: 'global' },
                { $inc: { totalUsers: 1 } },
                { upsert: true }
            );
            
            // Update global stats
            const stats = await StatisticsModel.findOne({ type: 'global' });
            if (stats) {
                globalInstance.globalStats.totalUsers = stats.totalUsers;
            }
        } else {
            // Update user info if changed
            let updated = false;
            if (user.username !== username) {
                user.username = username;
                updated = true;
            }
            if (user.firstName !== firstName) {
                user.firstName = firstName;
                updated = true;
            }
            if (user.lastName !== lastName) {
                user.lastName = lastName;
                updated = true;
            }
            if (updated) {
                await user.save();
            }
        }
        
        // Check if user is banned
        if (user.isBanned) {
            await ctx.reply(
                `🚫 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜𝗕𝗟𝗢𝗞𝗜𝗥\n\n` +
                `Anda telah diblokir dari menggunakan bot ini.\n\n` +
                `📋 Alasan: ${user.banReason || 'Pelanggaran aturan'}\n\n` +
                `Hubungi @${globalInstance.ownerUsername} untuk banding.`
            );
            return;
        }
        
        // Check premium expiry
        if (user.status !== 'FREE' && user.status !== 'OWNER') {
            const isPremiumActive = user.isPremiumActive();
            if (!isPremiumActive && user.status !== 'OWNER') {
                user.status = 'FREE';
                user.limits.dailyFix = 2;
                user.limits.massSend = 1;
                user.smtp.type = 'none';
                await user.save();
                Logger.info(`Premium expired for user ${userId}`, 'AuthMiddleware');
            }
        }
        
        // Check and reset daily limit
        user.checkAndResetDailyLimit();
        
        // Update last activity
        user.lastActivity = new Date();
        await user.save();
        
        // Attach user to context
        ctx.state.user = user;
        
        // Check if owner
        ctx.state.isOwner = globalInstance.isOwner(userId);
        if (ctx.state.isOwner && user.status !== 'OWNER') {
            user.status = 'OWNER';
            await user.save();
        }
        
    } catch (error) {
        Logger.error(`Auth error: ${error.message}`, 'AuthMiddleware', '31');
        // Continue anyway
        ctx.state.user = { userId, status: 'FREE', statistics: { totalFix: 0, berhasil: 0, gagal: 0, winRate: 0 } };
        ctx.state.isOwner = globalInstance.isOwner(userId);
    }
    
    return next();
}

module.exports = authMiddleware;
// END OF FILE - middleware/authMiddleware.js