// [QASHVRA BOT] - middleware/verificationMiddleware.js - Channel/Group Verification
const globalInstance = require('../global');
const Logger = require('../utils/logger');

async function verificationMiddleware(ctx, next) {
    // Skip for owner
    if (ctx.state?.isOwner) return next();
    
    // Skip for certain commands
    if (ctx.message?.text?.startsWith('/start')) {
        // Will be handled in start handler
        return next();
    }
    
    // Skip if no user state
    if (!ctx.state?.user) return next();
    
    const user = ctx.state.user;
    
    // If already verified, skip
    if (user.isVerified) return next();
    
    // Check verification settings
    const verification = globalInstance.config.verification;
    if (!verification.enabled) {
        user.isVerified = true;
        await user.save();
        return next();
    }
    
    try {
        const requiredChannels = verification.requiredChannels || [];
        const requiredGroups = verification.requiredGroups || [];
        const allRequired = [...requiredChannels, ...requiredGroups];
        
        if (allRequired.length === 0) {
            user.isVerified = true;
            await user.save();
            return next();
        }
        
        // Check membership for each required channel/group
        let allJoined = true;
        const notJoined = [];
        
        for (const entity of allRequired) {
            try {
                const chatId = entity.id.startsWith('@') ? entity.id : `@${entity.id}`;
                const member = await ctx.telegram.getChatMember(chatId, user.userId);
                
                const validStatuses = ['member', 'administrator', 'creator'];
                if (!validStatuses.includes(member.status)) {
                    allJoined = false;
                    notJoined.push(entity);
                }
            } catch (error) {
                Logger.warn(`Cannot check membership for ${entity.id}: ${error.message}`, 'Verification');
                // Skip if can't check (bot not in channel)
            }
        }
        
        if (allJoined) {
            // User has joined all required channels/groups
            user.isVerified = true;
            await user.save();
            Logger.info(`User ${user.userId} verified successfully`, 'Verification');
            return next();
        } else {
            // User hasn't joined all required entities
            const buttons = [];
            
            for (const entity of notJoined) {
                buttons.push([{
                    text: `📢 Join ${entity.name}`,
                    url: entity.link
                }]);
            }
            
            buttons.push([{
                text: '✅ Sudah Join? Cek Ulang',
                callback_data: 'verify_check'
            }]);
            
            await ctx.reply(
                `⚠️ 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜𝗧𝗢𝗟𝗔𝗞!\n\n` +
                `Anda harus bergabung ke channel dan grup resmi QASHVRA terlebih dahulu untuk menggunakan bot ini.\n\n` +
                `📋 Channel/Grup yang wajib diikuti:\n` +
                notJoined.map(e => `└ ${e.name}`).join('\n') + `\n\n` +
                `Setelah join, klik tombol "Cek Ulang" di bawah.`,
                {
                    reply_markup: {
                        inline_keyboard: buttons
                    }
                }
            );
            return;
        }
        
    } catch (error) {
        Logger.error(`Verification error: ${error.message}`, 'VerificationMiddleware');
        return next(); // Continue on error
    }
}

module.exports = verificationMiddleware;
// END OF FILE - middleware/verificationMiddleware.js