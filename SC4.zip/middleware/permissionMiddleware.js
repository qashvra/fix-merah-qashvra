// [QASHVRA BOT] - middleware/permissionMiddleware.js - Permission & Limit Checker
const UserModel = require('../models/userModel');
const globalInstance = require('../global');
const Logger = require('../utils/logger');

async function permissionMiddleware(ctx, next) {
    // Skip if no user state
    if (!ctx.state?.user) return next();
    
    const user = ctx.state.user;
    const userId = user.userId;
    
    // Owner has unlimited access
    if (ctx.state.isOwner || user.status === 'OWNER') {
        ctx.state.permission = {
            level: 'OWNER',
            unlimited: true,
            canFix: true,
            dailyLimit: Infinity,
            massSendLimit: Infinity,
            concurrentFixes: Infinity,
            smtpType: 'premium'
        };
        return next();
    }
    
    // Set permission based on user status
    const statusConfig = globalInstance.config.userStatus[user.status] || globalInstance.config.userStatus.FREE;
    
    ctx.state.permission = {
        level: user.status,
        unlimited: false,
        canFix: true,
        dailyLimit: statusConfig.dailyLimit,
        massSendLimit: statusConfig.massSendLimit,
        concurrentFixes: statusConfig.concurrentFixes || 1,
        smtpType: statusConfig.smtpType,
        priority: statusConfig.priority
    };
    
    // Check daily limit
    if (user.limits.usedToday >= statusConfig.dailyLimit && statusConfig.dailyLimit !== 999999) {
        ctx.state.permission.canFix = false;
        ctx.state.permission.limitReached = true;
    }
    
    // Check if user has SMTP configured (for FREE users)
    if (user.status === 'FREE' && (!user.smtp || !user.smtp.isActive)) {
        ctx.state.permission.hasSMTP = false;
    } else {
        ctx.state.permission.hasSMTP = true;
    }
    
    return next();
}

module.exports = permissionMiddleware;
// END OF FILE - middleware/permissionMiddleware.js