// [QASHVRA BOT] - services/smtpService.js - SMTP Email Service with Rolling System
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
const globalInstance = require('../global');
const Logger = require('../utils/logger');
const Formatter = require('../utils/formatter');

class SMTPService {
    constructor() {
        this.freePoolPath = path.join(__dirname, '..', 'data', 'free_smtp_pool.json');
        this.userMappingPath = path.join(__dirname, '..', 'data', 'user_smtp_mapping.json');
        this.currentIndex = 0;
        this.transporters = new Map();
        this.failedSMTPs = new Set();
    }

    // ============ LOAD SMTP POOL ============
    loadFreePool() {
        try {
            if (!fs.existsSync(this.freePoolPath)) {
                return { pool: [], stats: { totalSMTP: 0, activeSMTP: 0 } };
            }
            const data = fs.readFileSync(this.freePoolPath, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            Logger.error(`Load free pool error: ${error.message}`, 'SMTPService');
            return { pool: [], stats: { totalSMTP: 0, activeSMTP: 0 } };
        }
    }

    saveFreePool(poolData) {
        try {
            fs.writeFileSync(this.freePoolPath, JSON.stringify(poolData, null, 2), 'utf8');
        } catch (error) {
            Logger.error(`Save free pool error: ${error.message}`, 'SMTPService');
        }
    }

    loadUserMapping() {
        try {
            if (!fs.existsSync(this.userMappingPath)) {
                return { mappings: {}, stats: { totalMappings: 0 } };
            }
            const data = fs.readFileSync(this.userMappingPath, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            Logger.error(`Load user mapping error: ${error.message}`, 'SMTPService');
            return { mappings: {}, stats: { totalMappings: 0 } };
        }
    }

    saveUserMapping(mappingData) {
        try {
            fs.writeFileSync(this.userMappingPath, JSON.stringify(mappingData, null, 2), 'utf8');
        } catch (error) {
            Logger.error(`Save user mapping error: ${error.message}`, 'SMTPService');
        }
    }

    // ============ ADD USER SMTP ============
    async addUserSMTP(userId, email, appPassword) {
        try {
            // Validate SMTP first
            const isValid = await this.validateSMTP(email, appPassword);
            if (!isValid) {
                return { success: false, error: 'SMTP tidak valid. Periksa email dan App Password Gmail Anda.' };
            }

            // Load pools
            const poolData = this.loadFreePool();
            const mappingData = this.loadUserMapping();

            // Check if already exists
            const existingIndex = poolData.pool.findIndex(s => s.email === email);
            if (existingIndex >= 0) {
                // Update existing
                poolData.pool[existingIndex].appPassword = appPassword;
                poolData.pool[existingIndex].isActive = true;
                poolData.pool[existingIndex].errorCount = 0;
            } else {
                // Add new SMTP to pool
                poolData.pool.push({
                    id: `SMTP-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
                    email,
                    appPassword,
                    userId,
                    isActive: true,
                    errorCount: 0,
                    totalSent: 0,
                    totalSuccess: 0,
                    lastUsed: null,
                    addedAt: new Date().toISOString()
                });
            }

            // Update stats
            poolData.stats.totalSMTP = poolData.pool.length;
            poolData.stats.activeSMTP = poolData.pool.filter(s => s.isActive).length;

            // Update mapping
            if (!mappingData.mappings[userId]) {
                mappingData.mappings[userId] = [];
            }
            if (!mappingData.mappings[userId].includes(email)) {
                mappingData.mappings[userId].push(email);
            }
            mappingData.stats.totalMappings = Object.keys(mappingData.mappings).length;

            // Save
            this.saveFreePool(poolData);
            this.saveUserMapping(mappingData);

            Logger.success(`SMTP added for user ${userId}: ${email}`, 'SMTPService');

            return { success: true, message: 'SMTP berhasil ditambahkan!' };
        } catch (error) {
            Logger.error(`Add SMTP error: ${error.message}`, 'SMTPService');
            return { success: false, error: error.message };
        }
    }

    // ============ VALIDATE SMTP ============
    async validateSMTP(email, appPassword) {
        try {
            const transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                    user: email,
                    pass: appPassword
                },
                tls: {
                    rejectUnauthorized: false
                }
            });

            await transporter.verify();
            transporter.close();
            return true;
        } catch (error) {
            Logger.warn(`SMTP validation failed for ${email}: ${error.message}`, 'SMTPService');
            return false;
        }
    }

    // ============ GET SMTP FOR USER ============
    getSMTPForUser(user) {
        try {
            // Premium users use premium pool
            if (user.status === 'VIP' || user.status === 'VVIP' || user.status === 'OWNER') {
                return this.getPremiumSMTP();
            }

            // FREE users use their own SMTP from pool (rolling)
            return this.getRollingSMTP(user.userId);
        } catch (error) {
            Logger.error(`Get SMTP for user error: ${error.message}`, 'SMTPService');
            return null;
        }
    }

    // ============ PREMIUM SMTP ============
    getPremiumSMTP() {
        const premiumPool = globalInstance.config.smtp.premiumPool || [];
        if (premiumPool.length === 0) {
            Logger.warn('Premium SMTP pool is empty', 'SMTPService');
            return null;
        }
        // Random premium SMTP
        const randomIndex = Math.floor(Math.random() * premiumPool.length);
        return premiumPool[randomIndex];
    }

    // ============ ROLLING SMTP FOR FREE USERS ============
    getRollingSMTP(userId) {
        const poolData = this.loadFreePool();
        const mappingData = this.loadUserMapping();

        // Get user's SMTP list
        const userEmails = mappingData.mappings[userId] || [];
        if (userEmails.length === 0) {
            return null;
        }

        // Filter active SMTPs for this user
        const userSMTPs = poolData.pool.filter(
            s => userEmails.includes(s.email) && s.isActive && !this.failedSMTPs.has(s.id)
        );

        if (userSMTPs.length === 0) {
            // Reset failed SMTPs if all are failed
            this.failedSMTPs.clear();
            return poolData.pool.find(s => userEmails.includes(s.email) && s.isActive) || null;
        }

        // Rolling selection
        const smtp = userSMTPs[this.currentIndex % userSMTPs.length];
        this.currentIndex = (this.currentIndex + 1) % userSMTPs.length;

        return smtp;
    }

    // ============ SEND BANDING EMAIL ============
    async sendBandingEmail(user, phoneNumber) {
        try {
            const smtp = this.getSMTPForUser(user);
            if (!smtp) {
                return { success: false, error: 'Tidak ada SMTP tersedia', smtpUsed: 'none' };
            }

            // Get email template from config
            const template = globalInstance.config.templates.bandingEmail;
            const username = user.firstName || user.username || 'User';

            const mailOptions = {
                from: smtp.email,
                to: template.to,
                subject: template.subject.replace('{NOMOR}', phoneNumber),
                text: template.body
                    .replace('{NOMOR}', phoneNumber)
                    .replace('{USERNAME}', username)
            };

            // Create transporter
            const transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                    user: smtp.email,
                    pass: smtp.appPassword
                },
                tls: {
                    rejectUnauthorized: false
                }
            });

            // Send email
            const info = await transporter.sendMail(mailOptions);
            transporter.close();

            // Update SMTP stats
            smtp.totalSent = (smtp.totalSent || 0) + 1;
            smtp.totalSuccess = (smtp.totalSuccess || 0) + 1;
            smtp.lastUsed = new Date().toISOString();
            smtp.errorCount = 0;

            // Save updated stats
            this.updateSMTPStats(smtp);

            Logger.success(`Email sent for ${phoneNumber} using ${smtp.email}`, 'SMTPService');

            return {
                success: true,
                messageId: info.messageId,
                smtpUsed: smtp.email,
                phone: phoneNumber
            };

        } catch (error) {
            Logger.error(`Send banding error: ${error.message}`, 'SMTPService');

            // Mark SMTP as failed if error count exceeds max
            const smtp = this.getSMTPForUser(user);
            if (smtp) {
                smtp.errorCount = (smtp.errorCount || 0) + 1;
                const maxRetry = globalInstance.config.smtp.maxRetryPerSMTP || 3;

                if (smtp.errorCount >= maxRetry) {
                    smtp.isActive = false;
                    this.failedSMTPs.add(smtp.id);
                    Logger.warn(`SMTP ${smtp.email} disabled after ${maxRetry} retries`, 'SMTPService');
                }

                this.updateSMTPStats(smtp);
            }

            return {
                success: false,
                error: error.message,
                smtpUsed: smtp?.email || 'unknown',
                phone: phoneNumber
            };
        }
    }

    // ============ UPDATE SMTP STATS IN POOL ============
    updateSMTPStats(smtp) {
        try {
            const poolData = this.loadFreePool();
            const index = poolData.pool.findIndex(s => s.id === smtp.id || s.email === smtp.email);

            if (index >= 0) {
                poolData.pool[index] = { ...poolData.pool[index], ...smtp };
                this.saveFreePool(poolData);
            }
        } catch (error) {
            Logger.error(`Update SMTP stats error: ${error.message}`, 'SMTPService');
        }
    }

    // ============ SEND MASS EMAIL (BULK) ============
    async sendMassBanding(user, phoneNumbers) {
        const results = [];

        for (const phone of phoneNumbers) {
            const result = await this.sendBandingEmail(user, phone);
            results.push(result);

            // Delay between sends
            const interval = globalInstance.config.smtp.rollingInterval || 3000;
            await new Promise(resolve => setTimeout(resolve, interval));
        }

        return results;
    }

    // ============ GET SMTP STATS ============
    getSMTPStats() {
        const poolData = this.loadFreePool();
        return {
            total: poolData.pool.length,
            active: poolData.pool.filter(s => s.isActive).length,
            failed: poolData.pool.filter(s => !s.isActive).length,
            totalSent: poolData.pool.reduce((sum, s) => sum + (s.totalSent || 0), 0),
            totalSuccess: poolData.pool.reduce((sum, s) => sum + (s.totalSuccess || 0), 0)
        };
    }

    // ============ CLEANUP FAILED SMTPs ============
    cleanupFailedSMTPs() {
        this.failedSMTPs.clear();
        Logger.info('Failed SMTPs cache cleared', 'SMTPService');
    }
}

module.exports = new SMTPService();
// END OF FILE - services/smtpService.js