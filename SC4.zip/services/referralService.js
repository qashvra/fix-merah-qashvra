// [QASHVRA BOT] - services/referralService.js - Referral System Service
const UserModel = require('../models/userModel');
const globalInstance = require('../global');
const Logger = require('../utils/logger');
const Formatter = require('../utils/formatter');

class ReferralService {
    
    async processReferral(newUserId, referrerId) {
        try {
            // Validate referrer
            if (!referrerId || referrerId === newUserId) {
                return { success: false, error: 'Invalid referral' };
            }

            const referrer = await UserModel.findOne({ userId: referrerId });
            if (!referrer) {
                return { success: false, error: 'Referrer not found' };
            }

            // Check if already referred
            const newUser = await UserModel.findOne({ userId: newUserId });
            if (newUser?.referral?.referredBy) {
                return { success: false, error: 'Already referred by someone else' };
            }

            // Check if already in invited list
            if (referrer.referral.invitedUsers.includes(newUserId)) {
                return { success: false, error: 'Already invited this user' };
            }

            // Update referrer
            const coinsPerReferral = globalInstance.config.referral.coinsPerReferral || 5;
            referrer.referral.totalInvited += 1;
            referrer.referral.coins += coinsPerReferral;
            referrer.referral.invitedUsers.push(newUserId);
            await referrer.save();

            // Update new user
            if (newUser) {
                newUser.referral.referredBy = referrerId;
                await newUser.save();
            }

            Logger.success(`Referral: ${newUserId} referred by ${referrerId} (+${coinsPerReferral} coins)`, 'ReferralService');

            // Notify referrer
            try {
                const bot = globalInstance.bot;
                if (bot) {
                    await bot.telegram.sendMessage(
                        referrerId,
                        `🎉 𝗥𝗘𝗙𝗘𝗥𝗥𝗔𝗟 𝗕𝗔𝗥𝗨!\n\n` +
                        `👤 User baru telah join menggunakan link Anda!\n` +
                        `🪙 +${coinsPerReferral} Koin ditambahkan\n\n` +
                        `📊 Total Koin: ${referrer.referral.coins}\n` +
                        `👥 Total Diundang: ${referrer.referral.totalInvited} Orang`
                    );
                }
            } catch (e) {
                Logger.warn(`Failed to notify referrer ${referrerId}`, 'ReferralService');
            }

            return {
                success: true,
                coinsEarned: coinsPerReferral,
                totalCoins: referrer.referral.coins
            };

        } catch (error) {
            Logger.error(`Process referral error: ${error.message}`, 'ReferralService');
            return { success: false, error: error.message };
        }
    }

    async redeemCoins(userId, days) {
        try {
            const user = await UserModel.findOne({ userId });
            if (!user) {
                return { success: false, error: 'User not found' };
            }

            const redeemDays = globalInstance.config.referral.redeemDays || {};
            const requiredCoins = redeemDays[days.toString()];

            if (!requiredCoins) {
                return { success: false, error: 'Invalid redemption option' };
            }

            if (user.referral.coins < requiredCoins) {
                return {
                    success: false,
                    error: 'Insufficient coins',
                    required: requiredCoins,
                    current: user.referral.coins
                };
            }

            // Deduct coins
            user.referral.coins -= requiredCoins;

            // Calculate expiry
            const expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + days);

            // Upgrade user
            user.status = 'VIP';
            user.premiumExpiry = expiryDate;
            user.limits.dailyFix = 999999;
            user.limits.massSend = 5;
            user.smtp.type = 'premium';

            await user.save();

            Logger.success(`User ${userId} redeemed ${days} days VIP with ${requiredCoins} coins`, 'ReferralService');

            return {
                success: true,
                coinsUsed: requiredCoins,
                remainingCoins: user.referral.coins,
                days,
                expiryDate
            };

        } catch (error) {
            Logger.error(`Redeem coins error: ${error.message}`, 'ReferralService');
            return { success: false, error: error.message };
        }
    }

    async getReferralStats(userId) {
        try {
            const user = await UserModel.findOne({ userId });
            if (!user) {
                return { totalInvited: 0, coins: 0, referralLink: '' };
            }

            const botUsername = globalInstance.botUsername;
            const referralLink = `https://t.me/${botUsername}?start=${userId}`;

            return {
                totalInvited: user.referral.totalInvited || 0,
                coins: user.referral.coins || 0,
                referralLink,
                referredBy: user.referral.referredBy || null,
                invitedUsers: user.referral.invitedUsers || []
            };
        } catch (error) {
            Logger.error(`Get referral stats error: ${error.message}`, 'ReferralService');
            return { totalInvited: 0, coins: 0, referralLink: '' };
        }
    }

    async getTopReferrers(limit = 10) {
        try {
            return await UserModel.find({
                'referral.totalInvited': { $gt: 0 }
            })
            .sort({ 'referral.totalInvited': -1 })
            .limit(limit)
            .select('userId username firstName referral');
        } catch (error) {
            Logger.error(`Get top referrers error: ${error.message}`, 'ReferralService');
            return [];
        }
    }

    async addCoins(userId, amount) {
        try {
            const user = await UserModel.findOneAndUpdate(
                { userId },
                { $inc: { 'referral.coins': amount } },
                { new: true }
            );

            if (user) {
                Logger.info(`Added ${amount} coins to user ${userId}`, 'ReferralService');
                return { success: true, totalCoins: user.referral.coins };
            }

            return { success: false, error: 'User not found' };
        } catch (error) {
            Logger.error(`Add coins error: ${error.message}`, 'ReferralService');
            return { success: false, error: error.message };
        }
    }
}

module.exports = new ReferralService();
// END OF FILE - services/referralService.js