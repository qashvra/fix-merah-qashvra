// [QASHVRA BOT] - services/statisticsService.js - Statistics Management Service
const StatisticsModel = require('../models/statisticsModel');
const globalInstance = require('../global');
const Logger = require('../utils/logger');

class StatisticsService {
    
    async updateGlobalStats(successCount = 0, failedCount = 0) {
        try {
            const totalFix = successCount + failedCount;
            
            // Update global statistics in database
            const update = {
                $inc: {
                    totalFix: totalFix,
                    totalSuccess: successCount,
                    totalFailed: failedCount
                }
            };
            
            let stats = await StatisticsModel.findOneAndUpdate(
                { type: 'global' },
                update,
                { upsert: true, new: true }
            );
            
            // Recalculate win rate
            if (stats.totalFix > 0) {
                stats.winRate = parseFloat(((stats.totalSuccess / stats.totalFix) * 100).toFixed(1));
                await stats.save();
            }
            
            // Update global instance
            globalInstance.globalStats.totalFix = stats.totalFix;
            globalInstance.globalStats.totalSuccess = stats.totalSuccess;
            globalInstance.globalStats.winRateGlobal = stats.winRate;
            
            Logger.info(`Global stats updated: +${totalFix} fix (${successCount} success, ${failedCount} failed)`, 'StatisticsService');
            
            return stats;
        } catch (error) {
            Logger.error(`Update global stats error: ${error.message}`, 'StatisticsService');
            return null;
        }
    }
    
    async updateUserStats(userId, successCount = 0, failedCount = 0) {
        try {
            const totalFix = successCount + failedCount;
            
            let stats = await StatisticsModel.findOneAndUpdate(
                { type: 'user', userId },
                {
                    $inc: {
                        totalFix: totalFix,
                        totalSuccess: successCount,
                        totalFailed: failedCount
                    },
                    $push: {
                        history: {
                            action: 'fix_merah',
                            timestamp: new Date(),
                            success: successCount > 0,
                            details: { successCount, failedCount }
                        }
                    }
                },
                { upsert: true, new: true }
            );
            
            // Recalculate win rate
            if (stats.totalFix > 0) {
                stats.winRate = parseFloat(((stats.totalSuccess / stats.totalFix) * 100).toFixed(1));
                await stats.save();
            }
            
            return stats;
        } catch (error) {
            Logger.error(`Update user stats error: ${error.message}`, 'StatisticsService');
            return null;
        }
    }
    
    async updateCountryStats(countryCode, successCount = 0, failedCount = 0) {
        try {
            const totalFix = successCount + failedCount;
            
            let stats = await StatisticsModel.findOneAndUpdate(
                { type: 'country', countryCode },
                {
                    $inc: {
                        totalFix: totalFix,
                        totalSuccess: successCount,
                        totalFailed: failedCount
                    }
                },
                { upsert: true, new: true }
            );
            
            if (stats.totalFix > 0) {
                stats.winRate = parseFloat(((stats.totalSuccess / stats.totalFix) * 100).toFixed(1));
                await stats.save();
            }
            
            return stats;
        } catch (error) {
            Logger.error(`Update country stats error: ${error.message}`, 'StatisticsService');
            return null;
        }
    }
    
    async getLeaderboard(limit = 10) {
        try {
            return await StatisticsModel.getLeaderboard(limit);
        } catch (error) {
            Logger.error(`Get leaderboard error: ${error.message}`, 'StatisticsService');
            return [];
        }
    }
    
    async getGlobalStats() {
        try {
            let stats = await StatisticsModel.findOne({ type: 'global' });
            
            if (!stats) {
                // Initialize from zero
                stats = await StatisticsModel.create({
                    type: 'global',
                    totalFix: 0,
                    totalSuccess: 0,
                    totalFailed: 0,
                    winRate: 0.0,
                    startFromZero: true
                });
            }
            
            return stats;
        } catch (error) {
            Logger.error(`Get global stats error: ${error.message}`, 'StatisticsService');
            return {
                totalFix: 0,
                totalSuccess: 0,
                totalFailed: 0,
                winRate: 0.0,
                totalUsers: 0,
                activeSenders: { current: 0, max: 1984 }
            };
        }
    }
    
    async resetDailyStats() {
        try {
            // Reset daily counters but keep totals
            const users = await StatisticsModel.find({ type: 'user' });
            
            for (const user of users) {
                user.history = user.history.filter(h => {
                    const today = new Date();
                    return h.timestamp.toDateString() === today.toDateString();
                });
                await user.save();
            }
            
            Logger.info('Daily stats reset completed', 'StatisticsService');
        } catch (error) {
            Logger.error(`Reset daily stats error: ${error.message}`, 'StatisticsService');
        }
    }
}

module.exports = new StatisticsService();
// END OF FILE - services/statisticsService.js