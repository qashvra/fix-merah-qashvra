// [QASHVRA BOT] - services/userService.js - User Management Service
const UserModel = require('../models/userModel');
const databaseService = require('./databaseService');
const globalInstance = require('../global');
const Logger = require('../utils/logger');

class UserService {
    
    async getUser(userId) {
        try {
            return await UserModel.findOne({ userId });
        } catch (error) {
            Logger.error(`Get user error: ${error.message}`, 'UserService');
            return null;
        }
    }
    
    async createUser(userData) {
        try {
            return await UserModel.findOrCreate(userData.userId, userData);
        } catch (error) {
            Logger.error(`Create user error: ${error.message}`, 'UserService');
            return null;
        }
    }
    
    async updateUserStatus(userId, status, expiryDays = 0) {
        try {
            const update = { status };
            
            if (expiryDays > 0) {
                const expiryDate = new Date();
                expiryDate.setDate(expiryDate.getDate() + expiryDays);
                update.premiumExpiry = expiryDate;
            }
            
            if (status === 'VIP' || status === 'VVIP') {
                update['limits.dailyFix'] = 999999;
                update['limits.massSend'] = status === 'VVIP' ? 25 : 5;
                update['smtp.type'] = 'premium';
            } else if (status === 'FREE') {
                update['limits.dailyFix'] = 2;
                update['limits.massSend'] = 1;
                update['smtp.type'] = 'none';
                update.premiumExpiry = null;
            }
            
            return await UserModel.findOneAndUpdate(
                { userId },
                update,
                { new: true }
            );
        } catch (error) {
            Logger.error(`Update user status error: ${error.message}`, 'UserService');
            return null;
        }
    }
    
    async banUser(userId, reason = '') {
        try {
            return await UserModel.findOneAndUpdate(
                { userId },
                {
                    isBanned: true,
                    banReason: reason
                },
                { new: true }
            );
        } catch (error) {
            Logger.error(`Ban user error: ${error.message}`, 'UserService');
            return null;
        }
    }
    
    async unbanUser(userId) {
        try {
            return await UserModel.findOneAndUpdate(
                { userId },
                {
                    isBanned: false,
                    banReason: ''
                },
                { new: true }
            );
        } catch (error) {
            Logger.error(`Unban user error: ${error.message}`, 'UserService');
            return null;
        }
    }
    
    async getAllUsers(page = 1, limit = 50) {
        try {
            const skip = (page - 1) * limit;
            const users = await UserModel.find()
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(limit)
                .select('userId username firstName status premiumExpiry statistics referral');
            
            const total = await UserModel.countDocuments();
            
            return {
                users,
                total,
                page,
                totalPages: Math.ceil(total / limit)
            };
        } catch (error) {
            Logger.error(`Get all users error: ${error.message}`, 'UserService');
            return { users: [], total: 0, page: 1, totalPages: 0 };
        }
    }
    
    async getUsersByStatus(status) {
        try {
            return await UserModel.find({ status });
        } catch (error) {
            Logger.error(`Get users by status error: ${error.message}`, 'UserService');
            return [];
        }
    }
    
    async getPremiumUsers() {
        try {
            return await UserModel.find({
                status: { $in: ['VIP', 'VVIP'] },
                premiumExpiry: { $gt: new Date() }
            });
        } catch (error) {
            Logger.error(`Get premium users error: ${error.message}`, 'UserService');
            return [];
        }
    }
    
    async getExpiredPremiumUsers() {
        try {
            return await UserModel.find({
                status: { $in: ['VIP', 'VVIP'] },
                premiumExpiry: { $lt: new Date() }
            });
        } catch (error) {
            Logger.error(`Get expired premium users error: ${error.message}`, 'UserService');
            return [];
        }
    }
    
    async checkAndExpirePremiums() {
        try {
            const expired = await this.getExpiredPremiumUsers();
            
            for (const user of expired) {
                await this.updateUserStatus(user.userId, 'FREE');
                Logger.info(`Premium expired for user ${user.userId}`, 'UserService');
            }
            
            return expired.length;
        } catch (error) {
            Logger.error(`Check expire premiums error: ${error.message}`, 'UserService');
            return 0;
        }
    }
    
    async getUserStats() {
        try {
            const total = await UserModel.countDocuments();
            const free = await UserModel.countDocuments({ status: 'FREE' });
            const vip = await UserModel.countDocuments({ status: 'VIP' });
            const vvip = await UserModel.countDocuments({ status: 'VVIP' });
            const banned = await UserModel.countDocuments({ isBanned: true });
            
            return { total, free, vip, vvip, banned };
        } catch (error) {
            Logger.error(`Get user stats error: ${error.message}`, 'UserService');
            return { total: 0, free: 0, vip: 0, vvip: 0, banned: 0 };
        }
    }
}

module.exports = new UserService();
// END OF FILE - services/userService.js