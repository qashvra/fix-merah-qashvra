// [QASHVRA BOT] - services/databaseService.js - MongoDB Connection & Operations
const mongoose = require('mongoose');
const globalInstance = require('../global');
const Logger = require('../utils/logger');

class DatabaseService {
    constructor() {
        this.isConnected = false;
    }
    
    async connect() {
        try {
            await mongoose.connect(globalInstance.mongodbUri, {
                maxPoolSize: 10,
                serverSelectionTimeoutMS: 5000,
                socketTimeoutMS: 45000,
            });
            
            this.isConnected = true;
            Logger.success('MongoDB connected successfully', 'DatabaseService');
            
            // Handle connection events
            mongoose.connection.on('error', (err) => {
                Logger.error(`MongoDB connection error: ${err.message}`, 'DatabaseService');
                this.isConnected = false;
            });
            
            mongoose.connection.on('disconnected', () => {
                Logger.warn('MongoDB disconnected', 'DatabaseService');
                this.isConnected = false;
            });
            
            mongoose.connection.on('reconnected', () => {
                Logger.info('MongoDB reconnected', 'DatabaseService');
                this.isConnected = true;
            });
            
        } catch (error) {
            Logger.error(`MongoDB connection failed: ${error.message}`, 'DatabaseService');
            throw error;
        }
    }
    
    async disconnect() {
        try {
            await mongoose.disconnect();
            this.isConnected = false;
            Logger.info('MongoDB disconnected gracefully', 'DatabaseService');
        } catch (error) {
            Logger.error(`MongoDB disconnect error: ${error.message}`, 'DatabaseService');
        }
    }
    
    async findOne(collection, query) {
        try {
            return await mongoose.model(collection).findOne(query);
        } catch (error) {
            Logger.error(`Find one error: ${error.message}`, 'DatabaseService');
            return null;
        }
    }
    
    async find(collection, query = {}, options = {}) {
        try {
            return await mongoose.model(collection).find(query, null, options);
        } catch (error) {
            Logger.error(`Find error: ${error.message}`, 'DatabaseService');
            return [];
        }
    }
    
    async create(collection, data) {
        try {
            return await mongoose.model(collection).create(data);
        } catch (error) {
            Logger.error(`Create error: ${error.message}`, 'DatabaseService');
            throw error;
        }
    }
    
    async updateOne(collection, query, update, options = {}) {
        try {
            return await mongoose.model(collection).updateOne(query, update, options);
        } catch (error) {
            Logger.error(`Update error: ${error.message}`, 'DatabaseService');
            throw error;
        }
    }
    
    async findOneAndUpdate(collection, query, update, options = { new: true }) {
        try {
            return await mongoose.model(collection).findOneAndUpdate(query, update, options);
        } catch (error) {
            Logger.error(`FindOneAndUpdate error: ${error.message}`, 'DatabaseService');
            throw error;
        }
    }
    
    async deleteOne(collection, query) {
        try {
            return await mongoose.model(collection).deleteOne(query);
        } catch (error) {
            Logger.error(`Delete error: ${error.message}`, 'DatabaseService');
            throw error;
        }
    }
    
    async countDocuments(collection, query = {}) {
        try {
            return await mongoose.model(collection).countDocuments(query);
        } catch (error) {
            Logger.error(`Count error: ${error.message}`, 'DatabaseService');
            return 0;
        }
    }
    
    async aggregate(collection, pipeline) {
        try {
            return await mongoose.model(collection).aggregate(pipeline);
        } catch (error) {
            Logger.error(`Aggregate error: ${error.message}`, 'DatabaseService');
            return [];
        }
    }
}

module.exports = new DatabaseService();
// END OF FILE - services/databaseService.js