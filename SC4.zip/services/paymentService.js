// [QASHVRA BOT] - services/paymentService.js - Payment Gateway Integration
const axios = require('axios');
const crypto = require('crypto');
const globalInstance = require('../global');
const Logger = require('../utils/logger');
const databaseService = require('./databaseService');
const UserModel = require('../models/userModel');
const Formatter = require('../utils/formatter');

class PaymentService {
    constructor() {
        this.gateway = globalInstance.config.payment.gateway || 'qris';
        this.tripayConfig = globalInstance.config.payment.tripay;
        this.midtransConfig = globalInstance.config.payment.midtrans;
        this.tokopayConfig = globalInstance.config.payment.tokopay;
    }

    // ============ GENERATE QRIS PAYMENT ============
    async generateQRISPayment({ orderId, amount, type, days, userId }) {
        try {
            // Modify QRIS base string with amount
            const qrisBase = globalInstance.config.payment.qrisBaseString;
            
            // Generate QR code image URL
            const qrData = encodeURIComponent(
                `${qrisBase}|ORDER:${orderId}|AMOUNT:${amount}`
            );
            const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${qrData}`;

            return {
                success: true,
                orderId,
                amount,
                qrImageUrl,
                paymentMethod: 'QRIS'
            };
        } catch (error) {
            Logger.error(`Generate QRIS error: ${error.message}`, 'PaymentService');
            return { success: false, error: error.message };
        }
    }

    // ============ CREATE PAYMENT RECORD ============
    async createPaymentRecord(paymentData) {
        try {
            const PaymentModel = require('../models/paymentModel');
            
            const payment = await PaymentModel.create({
                orderId: paymentData.orderId,
                userId: paymentData.userId,
                type: paymentData.type,
                days: paymentData.days,
                amount: paymentData.amount,
                paymentMethod: paymentData.paymentMethod || 'QRIS',
                status: 'pending',
                gateway: this.gateway,
                metadata: paymentData.metadata || {}
            });

            Logger.info(`Payment record created: ${paymentData.orderId}`, 'PaymentService');
            return payment;
        } catch (error) {
            Logger.error(`Create payment error: ${error.message}`, 'PaymentService');
            return null;
        }
    }

    // ============ GET PAYMENT BY ORDER ID ============
    async getPaymentByOrderId(orderId) {
        try {
            const PaymentModel = require('../models/paymentModel');
            return await PaymentModel.findOne({ orderId });
        } catch (error) {
            Logger.error(`Get payment error: ${error.message}`, 'PaymentService');
            return null;
        }
    }

    // ============ UPDATE PAYMENT STATUS ============
    async updatePaymentStatus(orderId, status, metadata = {}) {
        try {
            const PaymentModel = require('../models/paymentModel');
            
            const update = {
                status,
                updatedAt: new Date(),
                ...metadata
            };

            if (status === 'paid') {
                update.paidAt = new Date();
            }

            const payment = await PaymentModel.findOneAndUpdate(
                { orderId },
                update,
                { new: true }
            );

            // If paid, upgrade user
            if (status === 'paid' && payment) {
                await this.upgradeUserAfterPayment(payment);
            }

            return payment;
        } catch (error) {
            Logger.error(`Update payment status error: ${error.message}`, 'PaymentService');
            return null;
        }
    }

    // ============ UPGRADE USER AFTER PAYMENT ============
    async upgradeUserAfterPayment(payment) {
        try {
            const expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + payment.days);

            const updatedUser = await UserModel.findOneAndUpdate(
                { userId: payment.userId },
                {
                    status: payment.type,
                    premiumExpiry: expiryDate,
                    'limits.dailyFix': 999999,
                    'limits.massSend': payment.type === 'VVIP' ? 25 : 5,
                    'smtp.type': 'premium',
                    $push: {
                        paymentHistory: {
                            orderId: payment.orderId,
                            package: `${payment.type} ${payment.days} Hari`,
                            amount: payment.amount,
                            status: 'paid',
                            paymentMethod: payment.paymentMethod,
                            timestamp: new Date()
                        }
                    }
                },
                { new: true }
            );

            Logger.success(`User ${payment.userId} upgraded to ${payment.type} after payment`, 'PaymentService');
            
            // Notify user
            try {
                await globalInstance.bot?.telegram?.sendMessage(
                    payment.userId,
                    `✅ 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 𝗧𝗘𝗥𝗞𝗢𝗡𝗙𝗜𝗥𝗠𝗔𝗦𝗜!\n\n` +
                    `🔖 Order ID: ${payment.orderId}\n` +
                    `📦 Paket: ${payment.type} ${payment.days} Hari\n` +
                    `📅 Expired: ${Formatter.formatDate(expiryDate)}\n` +
                    `👑 Status: ${payment.type} User\n\n` +
                    `🎉 Selamat menikmati fitur premium QASHVRA!`
                );
            } catch (e) {
                Logger.warn(`Failed to notify user ${payment.userId}`, 'PaymentService');
            }

            return updatedUser;
        } catch (error) {
            Logger.error(`Upgrade user error: ${error.message}`, 'PaymentService');
            return null;
        }
    }

    // ============ VERIFY PAYMENT ============
    async verifyPayment(orderId) {
        try {
            const payment = await this.getPaymentByOrderId(orderId);
            if (!payment) {
                return { verified: false, status: 'not_found' };
            }

            if (payment.status === 'paid') {
                return { verified: true, status: 'paid' };
            }

            // Check with payment gateway based on type
            switch (this.gateway) {
                case 'tripay':
                    return await this.verifyTripayPayment(orderId);
                case 'midtrans':
                    return await this.verifyMidtransPayment(orderId);
                case 'tokopay':
                    return await this.verifyTokopayPayment(orderId);
                case 'qris':
                default:
                    return await this.verifyQRISPayment(orderId);
            }
        } catch (error) {
            Logger.error(`Verify payment error: ${error.message}`, 'PaymentService');
            return { verified: false, status: 'error', error: error.message };
        }
    }

    // ============ VERIFY QRIS PAYMENT (Manual Check) ============
    async verifyQRISPayment(orderId) {
        // For QRIS, payment verification is manual or via webhook
        // This is a placeholder - in production, integrate with payment gateway API
        const payment = await this.getPaymentByOrderId(orderId);
        
        if (payment && payment.status === 'paid') {
            return { verified: true, status: 'paid' };
        }

        return { verified: false, status: 'pending' };
    }

    // ============ TRIPAY INTEGRATION ============
    async verifyTripayPayment(orderId) {
        try {
            if (!this.tripayConfig.apiKey) {
                return { verified: false, status: 'not_configured' };
            }

            const response = await axios.get(
                `https://tripay.co.id/api/transaction/detail?reference=${orderId}`,
                {
                    headers: {
                        'Authorization': `Bearer ${this.tripayConfig.apiKey}`
                    }
                }
            );

            const data = response.data;
            if (data.success && data.data.status === 'PAID') {
                return { verified: true, status: 'paid', gatewayData: data.data };
            }

            return { verified: false, status: data.data?.status || 'pending' };
        } catch (error) {
            Logger.error(`Tripay verify error: ${error.message}`, 'PaymentService');
            return { verified: false, status: 'error' };
        }
    }

    // ============ MIDTRANS INTEGRATION ============
    async verifyMidtransPayment(orderId) {
        try {
            if (!this.midtransConfig.serverKey) {
                return { verified: false, status: 'not_configured' };
            }

            const auth = Buffer.from(this.midtransConfig.serverKey + ':').toString('base64');
            
            const response = await axios.get(
                `https://api.midtrans.com/v2/${orderId}/status`,
                {
                    headers: {
                        'Authorization': `Basic ${auth}`
                    }
                }
            );

            const data = response.data;
            if (data.transaction_status === 'settlement' || data.transaction_status === 'capture') {
                return { verified: true, status: 'paid', gatewayData: data };
            }

            return { verified: false, status: data.transaction_status || 'pending' };
        } catch (error) {
            Logger.error(`Midtrans verify error: ${error.message}`, 'PaymentService');
            return { verified: false, status: 'error' };
        }
    }

    // ============ TOKOPAY INTEGRATION ============
    async verifyTokopayPayment(orderId) {
        try {
            if (!this.tokopayConfig.apiKey) {
                return { verified: false, status: 'not_configured' };
            }

            const response = await axios.get(
                `https://api.tokopay.id/v1/transaction/${orderId}`,
                {
                    headers: {
                        'Authorization': `Bearer ${this.tokopayConfig.apiKey}`,
                        'Merchant-ID': this.tokopayConfig.merchantId
                    }
                }
            );

            const data = response.data;
            if (data.status === 'success' || data.status === 'paid') {
                return { verified: true, status: 'paid', gatewayData: data };
            }

            return { verified: false, status: data.status || 'pending' };
        } catch (error) {
            Logger.error(`Tokopay verify error: ${error.message}`, 'PaymentService');
            return { verified: false, status: 'error' };
        }
    }

    // ============ CHECK PAYMENT STATUS ============
    async checkPaymentStatus(orderId) {
        const result = await this.verifyPayment(orderId);
        return {
            status: result.status,
            verified: result.verified,
            orderId
        };
    }

    // ============ GET PAYMENT STATS ============
    async getPaymentStats() {
        try {
            const PaymentModel = require('../models/paymentModel');
            
            const total = await PaymentModel.countDocuments();
            const paid = await PaymentModel.countDocuments({ status: 'paid' });
            const pending = await PaymentModel.countDocuments({ status: 'pending' });
            const failed = await PaymentModel.countDocuments({ status: 'failed' });
            
            const revenue = await PaymentModel.aggregate([
                { $match: { status: 'paid' } },
                { $group: { _id: null, total: { $sum: '$amount' } } }
            ]);

            return {
                total,
                paid,
                pending,
                failed,
                totalRevenue: revenue[0]?.total || 0
            };
        } catch (error) {
            Logger.error(`Get payment stats error: ${error.message}`, 'PaymentService');
            return { total: 0, paid: 0, pending: 0, failed: 0, totalRevenue: 0 };
        }
    }

    // ============ SET PAYMENT GATEWAY ============
    setGateway(gateway) {
        const validGateways = ['qris', 'tripay', 'midtrans', 'tokopay'];
        if (validGateways.includes(gateway)) {
            this.gateway = gateway;
            globalInstance.config.payment.gateway = gateway;
            Logger.info(`Payment gateway changed to: ${gateway}`, 'PaymentService');
            return { success: true, gateway };
        }
        return { success: false, error: 'Invalid gateway' };
    }

    // ============ UPDATE GATEWAY CONFIG ============
    updateGatewayConfig(gateway, config) {
        try {
            switch (gateway) {
                case 'tripay':
                    globalInstance.config.payment.tripay = { ...globalInstance.config.payment.tripay, ...config };
                    this.tripayConfig = globalInstance.config.payment.tripay;
                    break;
                case 'midtrans':
                    globalInstance.config.payment.midtrans = { ...globalInstance.config.payment.midtrans, ...config };
                    this.midtransConfig = globalInstance.config.payment.midtrans;
                    break;
                case 'tokopay':
                    globalInstance.config.payment.tokopay = { ...globalInstance.config.payment.tokopay, ...config };
                    this.tokopayConfig = globalInstance.config.payment.tokopay;
                    break;
                default:
                    return { success: false, error: 'Unknown gateway' };
            }

            Logger.success(`Gateway ${gateway} config updated`, 'PaymentService');
            return { success: true };
        } catch (error) {
            Logger.error(`Update gateway config error: ${error.message}`, 'PaymentService');
            return { success: false, error: error.message };
        }
    }
}

module.exports = new PaymentService();
// END OF FILE - services/paymentService.js