// [QASHVRA BOT] - models/userModel.js - MongoDB User Schema
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    userId: {
        type: Number,
        required: true,
        unique: true
    },
    username: {
        type: String,
        default: ''
    },
    firstName: {
        type: String,
        default: ''
    },
    lastName: {
        type: String,
        default: ''
    },
    status: {
        type: String,
        enum: ['FREE', 'VIP', 'VVIP', 'OWNER'],
        default: 'FREE'
    },
    isVerified: {
        type: Boolean,
        default: false
    },
    joinedAt: {
        type: Date,
        default: Date.now
    },
    premiumExpiry: {
        type: Date,
        default: null
    },
    statistics: {
        totalFix: { type: Number, default: 0 },
        berhasil: { type: Number, default: 0 },
        gagal: { type: Number, default: 0 },
        winRate: { type: Number, default: 0.0 }
    },
    limits: {
        dailyFix: { type: Number, default: 2 },
        usedToday: { type: Number, default: 0 },
        lastReset: { type: Date, default: Date.now },
        massSend: { type: Number, default: 1 },
        concurrentFixes: { type: Number, default: 1 }
    },
    referral: {
        referredBy: { type: Number, default: null },
        referralCode: { type: String, unique: true },
        totalInvited: { type: Number, default: 0 },
        coins: { type: Number, default: 0 },
        invitedUsers: [Number]
    },
    smtp: {
        type: {
            type: String,
            enum: ['self', 'premium', 'none'],
            default: 'none'
        },
        email: { type: String, default: '' },
        appPassword: { type: String, default: '' },
        isActive: { type: Boolean, default: false },
        lastUsed: { type: Date, default: null },
        errorCount: { type: Number, default: 0 }
    },
    paymentHistory: [{
        orderId: String,
        package: String,
        amount: Number,
        status: String,
        paymentMethod: String,
        timestamp: { type: Date, default: Date.now }
    }],
    fixHistory: [{
        phoneNumber: String,
        status: String,
        emailTemplate: String,
        smtpUsed: String,
        timestamp: { type: Date, default: Date.now }
    }],
    lastActivity: {
        type: Date,
        default: Date.now
    },
    isBanned: {
        type: Boolean,
        default: false
    },
    banReason: {
        type: String,
        default: ''
    }
}, {
    timestamps: true
});

// Pre-save middleware to update win rate
userSchema.pre('save', function(next) {
    if (this.statistics.totalFix > 0) {
        this.statistics.winRate = parseFloat(
            ((this.statistics.berhasil / this.statistics.totalFix) * 100).toFixed(1)
        );
    }
    next();
});

// Method to check if premium is active
userSchema.methods.isPremiumActive = function() {
    if (!this.premiumExpiry) return false;
    return new Date() < this.premiumExpiry;
};

// Method to reset daily limits if needed
userSchema.methods.checkAndResetDailyLimit = function() {
    const now = new Date();
    const lastReset = this.limits.lastReset;
    
    if (now.getDate() !== lastReset.getDate() || 
        now.getMonth() !== lastReset.getMonth() || 
        now.getFullYear() !== lastReset.getFullYear()) {
        this.limits.usedToday = 0;
        this.limits.lastReset = now;
        return true;
    }
    return false;
};

// Static method to find or create user
userSchema.statics.findOrCreate = async function(userId, userData = {}) {
    let user = await this.findOne({ userId });
    
    if (!user) {
        // Generate unique referral code
        const referralCode = 'QASH' + userId.toString().slice(-6) + Math.random().toString(36).substring(2, 5).toUpperCase();
        
        user = await this.create({
            userId,
            username: userData.username || '',
            firstName: userData.firstName || '',
            lastName: userData.lastName || '',
            referral: {
                referralCode
            },
            statistics: {
                totalFix: 0,
                berhasil: 0,
                gagal: 0,
                winRate: 0.0
            },
            limits: {
                dailyFix: 2,
                usedToday: 0,
                lastReset: new Date()
            }
        });
    }
    
    return user;
};

const UserModel = mongoose.model('User', userSchema);

module.exports = UserModel;
// END OF FILE - models/userModel.js