// [QASHVRA BOT] - models/statisticsModel.js - MongoDB Statistics Schema
const mongoose = require('mongoose');

const statisticsSchema = new mongoose.Schema({
    type: {
        type: String,
        enum: ['global', 'user', 'country'],
        required: true
    },
    userId: {
        type: Number,
        required: function() { return this.type === 'user'; }
    },
    countryCode: {
        type: String,
        required: function() { return this.type === 'country'; }
    },
    totalFix: {
        type: Number,
        default: 0
    },
    totalSuccess: {
        type: Number,
        default: 0
    },
    totalFailed: {
        type: Number,
        default: 0
    },
    winRate: {
        type: Number,
        default: 0.0
    },
    activeSenders: {
        current: { type: Number, default: 0 },
        max: { type: Number, default: 1984 }
    },
    totalUsers: {
        type: Number,
        default: 0
    },
    startFromZero: {
        type: Boolean,
        default: true
    },
    lastUpdated: {
        type: Date,
        default: Date.now
    },
    history: [{
        action: String,
        timestamp: {
            type: Date,
            default: Date.now
        },
        success: Boolean,
        details: mongoose.Schema.Types.Mixed
    }]
}, {
    timestamps: true
});

// Update win rate before save
statisticsSchema.pre('save', function(next) {
    if (this.totalFix > 0) {
        this.winRate = parseFloat(((this.totalSuccess / this.totalFix) * 100).toFixed(1));
    } else {
        this.winRate = 0.0;
    }
    this.lastUpdated = new Date();
    next();
});

// Static method to increment statistics
statisticsSchema.statics.incrementStats = async function(type, identifier, isSuccess) {
    const query = type === 'user' 
        ? { type, userId: identifier }
        : type === 'country'
        ? { type, countryCode: identifier }
        : { type: 'global' };
    
    const update = {
        $inc: {
            totalFix: 1,
            totalSuccess: isSuccess ? 1 : 0,
            totalFailed: isSuccess ? 0 : 1
        },
        $push: {
            history: {
                action: 'fix_merah',
                timestamp: new Date(),
                success: isSuccess
            }
        }
    };
    
    return this.findOneAndUpdate(query, update, { upsert: true, new: true });
};

// Static method to get leaderboard
statisticsSchema.statics.getLeaderboard = async function(limit = 10) {
    return this.find({ type: 'user' })
        .sort({ totalFix: -1 })
        .limit(limit)
        .select('userId totalFix totalSuccess winRate');
};

const StatisticsModel = mongoose.model('Statistics', statisticsSchema);

module.exports = StatisticsModel;
// END OF FILE - models/statisticsModel.js