// [QASHVRA BOT] - models/paymentModel.js - MongoDB Payment Schema
const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema({
    orderId: {
        type: String,
        required: true,
        unique: true,
        index: true
    },
    userId: {
        type: Number,
        required: true,
        index: true
    },
    type: {
        type: String,
        enum: ['VIP', 'VVIP', 'FIX'],
        required: true
    },
    days: {
        type: Number,
        required: true
    },
    amount: {
        type: Number,
        required: true
    },
    paymentMethod: {
        type: String,
        enum: ['QRIS', 'TRIPAY', 'MIDTRANS', 'TOKOPAY', 'MANUAL'],
        default: 'QRIS'
    },
    status: {
        type: String,
        enum: ['pending', 'paid', 'failed', 'expired', 'cancelled'],
        default: 'pending',
        index: true
    },
    gateway: {
        type: String,
        enum: ['qris', 'tripay', 'midtrans', 'tokopay'],
        default: 'qris'
    },
    gatewayResponse: {
        type: mongoose.Schema.Types.Mixed,
        default: {}
    },
    metadata: {
        type: mongoose.Schema.Types.Mixed,
        default: {}
    },
    paidAt: {
        type: Date,
        default: null
    },
    expiredAt: {
        type: Date,
        default: function() {
            // Expire after 24 hours
            const date = new Date();
            date.setHours(date.getHours() + 24);
            return date;
        }
    },
    cancelledAt: {
        type: Date,
        default: null
    },
    notes: {
        type: String,
        default: ''
    }
}, {
    timestamps: true
});

// Index for faster queries
paymentSchema.index({ userId: 1, status: 1 });
paymentSchema.index({ status: 1, createdAt: -1 });

// Method to check if payment is expired
paymentSchema.methods.isExpired = function() {
    if (this.status === 'paid') return false;
    return new Date() > this.expiredAt;
};

// Pre-save middleware
paymentSchema.pre('save', function(next) {
    if (this.isModified('status') && this.status === 'paid' && !this.paidAt) {
        this.paidAt = new Date();
    }
    next();
});

// Static method to get revenue stats
paymentSchema.statics.getRevenueStats = async function(period = 'all') {
    const matchStage = { status: 'paid' };
    
    if (period === 'today') {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        matchStage.paidAt = { $gte: today };
    } else if (period === 'week') {
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        matchStage.paidAt = { $gte: weekAgo };
    } else if (period === 'month') {
        const monthAgo = new Date();
        monthAgo.setMonth(monthAgo.getMonth() - 1);
        matchStage.paidAt = { $gte: monthAgo };
    }
    
    const result = await this.aggregate([
        { $match: matchStage },
        {
            $group: {
                _id: null,
                totalRevenue: { $sum: '$amount' },
                totalTransactions: { $sum: 1 },
                averageAmount: { $avg: '$amount' }
            }
        }
    ]);
    
    return result[0] || { totalRevenue: 0, totalTransactions: 0, averageAmount: 0 };
};

// Static method to clean expired payments
paymentSchema.statics.cleanExpiredPayments = async function() {
    const result = await this.updateMany(
        {
            status: 'pending',
            expiredAt: { $lt: new Date() }
        },
        {
            status: 'expired'
        }
    );
    
    return result.modifiedCount;
};

const PaymentModel = mongoose.model('Payment', paymentSchema);

module.exports = PaymentModel;
// END OF FILE - models/paymentModel.js