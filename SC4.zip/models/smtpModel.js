// [QASHVRA BOT] - models/smtpModel.js - MongoDB SMTP Schema (For Premium SMTP)
const mongoose = require('mongoose');

const smtpSchema = new mongoose.Schema({
    smtpId: {
        type: String,
        required: true,
        unique: true
    },
    email: {
        type: String,
        required: true
    },
    appPassword: {
        type: String,
        required: true,
        select: false // Hide by default in queries
    },
    type: {
        type: String,
        enum: ['premium', 'owner', 'backup'],
        default: 'premium'
    },
    isActive: {
        type: Boolean,
        default: true
    },
    maxDailySend: {
        type: Number,
        default: 500
    },
    dailySent: {
        type: Number,
        default: 0
    },
    totalSent: {
        type: Number,
        default: 0
    },
    totalSuccess: {
        type: Number,
        default: 0
    },
    totalFailed: {
        type: Number,
        default: 0
    },
    errorCount: {
        type: Number,
        default: 0
    },
    maxErrorRetry: {
        type: Number,
        default: 3
    },
    lastUsed: {
        type: Date,
        default: null
    },
    lastError: {
        type: String,
        default: ''
    },
    lastReset: {
        type: Date,
        default: Date.now
    },
    addedBy: {
        type: Number,
        default: null
    },
    notes: {
        type: String,
        default: ''
    }
}, {
    timestamps: true
});

// Check if SMTP can still send today
smtpSchema.methods.canSend = function() {
    // Reset daily counter if new day
    const now = new Date();
    const lastReset = this.lastReset;
    
    if (now.getDate() !== lastReset.getDate() || 
        now.getMonth() !== lastReset.getMonth() || 
        now.getFullYear() !== lastReset.getFullYear()) {
        this.dailySent = 0;
        this.lastReset = now;
    }
    
    return this.isActive && 
           this.dailySent < this.maxDailySend && 
           this.errorCount < this.maxErrorRetry;
};

// Increment sent count
smtpSchema.methods.incrementSent = function(success = true) {
    this.dailySent += 1;
    this.totalSent += 1;
    
    if (success) {
        this.totalSuccess += 1;
        this.errorCount = 0; // Reset error count on success
    } else {
        this.totalFailed += 1;
        this.errorCount += 1;
        
        // Disable if too many errors
        if (this.errorCount >= this.maxErrorRetry) {
            this.isActive = false;
        }
    }
    
    this.lastUsed = new Date();
};

// Reset daily counter
smtpSchema.methods.resetDaily = function() {
    this.dailySent = 0;
    this.lastReset = new Date();
};

// Static method to get available SMTP
smtpSchema.statics.getAvailableSMTP = async function(type = 'premium') {
    const smtpList = await this.find({ 
        type, 
        isActive: true,
        $expr: { $lt: ['$dailySent', '$maxDailySend'] },
        $expr: { $lt: ['$errorCount', '$maxErrorRetry'] }
    });
    
    return smtpList;
};

// Static method to get next SMTP (rolling)
smtpSchema.statics.getNextSMTP = async function(type = 'premium') {
    const available = await this.getAvailableSMTP(type);
    
    if (available.length === 0) {
        // Try to reset daily counters
        await this.updateMany(
            { type, isActive: true },
            { dailySent: 0, lastReset: new Date() }
        );
        return this.findOne({ type, isActive: true });
    }
    
    // Get SMTP with least usage today
    available.sort((a, b) => a.dailySent - b.dailySent);
    return available[0];
};

// Static method to get stats
smtpSchema.statics.getStats = async function() {
    const stats = await this.aggregate([
        {
            $group: {
                _id: '$type',
                total: { $sum: 1 },
                active: { 
                    $sum: { $cond: ['$isActive', 1, 0] } 
                },
                totalSent: { $sum: '$totalSent' },
                totalSuccess: { $sum: '$totalSuccess' },
                totalFailed: { $sum: '$totalFailed' }
            }
        }
    ]);
    
    return stats;
};

const SMTPModel = mongoose.model('SMTP', smtpSchema);

module.exports = SMTPModel;
// END OF FILE - models/smtpModel.js