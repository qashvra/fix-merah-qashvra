// [QASHVRA BOT] - utils/formatter.js - Text & Data Formatter Utility
class Formatter {
    static maskUsername(username) {
        if (!username) return 'Unknown';
        if (username.length <= 3) return username;
        return username.substring(0, 2) + '*'.repeat(username.length - 4) + username.substring(username.length - 2);
    }

    static maskPhoneNumber(phone) {
        if (!phone) return 'Unknown';
        const clean = phone.replace(/[^0-9]/g, '');
        if (clean.length < 8) return phone;
        return clean.substring(0, 5) + '****' + clean.substring(clean.length - 4);
    }

    static formatNumber(num) {
        if (!num && num !== 0) return '0';
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }

    static generateOrderId(type, userId, days) {
        const random = Math.floor(Math.random() * 90000) + 10000;
        return `QASHVRA-${type}-${userId}-${days}-${random}`;
    }

    static formatCurrency(amount) {
        return `Rp ${this.formatNumber(amount)}`;
    }

    static formatDate(date) {
        const moment = require('moment-timezone');
        return moment(date).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss');
    }

    static formatWinRate(success, total) {
        if (total === 0) return '0.0%';
        return ((success / total) * 100).toFixed(1) + '%';
    }

    static getStatusEmoji(status) {
        const statusEmojis = {
            'FREE': '👤',
            'VIP': '⭐',
            'VVIP': '💎',
            'OWNER': '👑'
        };
        return statusEmojis[status] || '👤';
    }

    static getStatusBadge(status) {
        const badges = {
            'FREE': '👤 𝗙𝗥𝗘𝗘 𝗨𝗦𝗘𝗥',
            'VIP': '⭐ 𝗩𝗜𝗣 𝗨𝗦𝗘𝗥',
            'VVIP': '💎 𝗩𝗩𝗜𝗣 𝗨𝗦𝗘𝗥',
            'OWNER': '👑 𝗢𝗪𝗡𝗘𝗥'
        };
        return badges[status] || badges.FREE;
    }

    static truncateText(text, maxLength = 50) {
        if (!text) return '';
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength) + '...';
    }
}

module.exports = Formatter;
// END OF FILE - utils/formatter.js