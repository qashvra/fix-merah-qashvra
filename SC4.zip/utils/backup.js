// [QASHVRA BOT] - utils/backup.js - Database & Config Backup Utility
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const Logger = require('./logger');

class Backup {
    
    static async createBackup() {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupDir = path.join(__dirname, '..', 'backups', `backup-${timestamp}`);
        
        try {
            // Create backup directory
            if (!fs.existsSync(backupDir)) {
                fs.mkdirSync(backupDir, { recursive: true });
            }
            
            Logger.info(`Creating backup: ${backupDir}`, 'Backup');
            
            // Backup config
            await this.backupFile('config.json', backupDir);
            
            // Backup data files
            await this.backupFile('data/free_smtp_pool.json', backupDir);
            await this.backupFile('data/user_smtp_mapping.json', backupDir);
            
            // Backup MongoDB (if local)
            await this.backupMongoDB(backupDir);
            
            // Create backup info
            const info = {
                timestamp: new Date().toISOString(),
                files: fs.readdirSync(backupDir),
                version: require('../package.json').version
            };
            fs.writeFileSync(
                path.join(backupDir, 'backup-info.json'),
                JSON.stringify(info, null, 2)
            );
            
            Logger.success(`Backup completed: ${backupDir}`, 'Backup');
            
            // Clean old backups (keep last 7)
            await this.cleanOldBackups(7);
            
            return { success: true, path: backupDir };
            
        } catch (error) {
            Logger.error(`Backup error: ${error.message}`, 'Backup');
            return { success: false, error: error.message };
        }
    }

    static async backupFile(filePath, backupDir) {
        const fullPath = path.join(__dirname, '..', filePath);
        
        if (fs.existsSync(fullPath)) {
            const destPath = path.join(backupDir, path.basename(filePath));
            fs.copyFileSync(fullPath, destPath);
            Logger.info(`Backed up: ${filePath}`, 'Backup');
        }
    }

    static async backupMongoDB(backupDir) {
        try {
            const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/qashvra_bot';
            
            if (mongoUri.includes('localhost')) {
                const dbName = mongoUri.split('/').pop();
                const command = `mongodump --db=${dbName} --out=${backupDir}/mongodb`;
                
                exec(command, (error, stdout, stderr) => {
                    if (error) {
                        Logger.warn(`MongoDB backup skipped: ${error.message}`, 'Backup');
                    } else {
                        Logger.info('MongoDB backup completed', 'Backup');
                    }
                });
            } else {
                Logger.info('Remote MongoDB - skipping local backup', 'Backup');
            }
        } catch (error) {
            Logger.warn(`MongoDB backup error: ${error.message}`, 'Backup');
        }
    }

    static async cleanOldBackups(keepCount = 7) {
        const backupsDir = path.join(__dirname, '..', 'backups');
        
        if (!fs.existsSync(backupsDir)) return;
        
        const backups = fs.readdirSync(backupsDir)
            .filter(f => f.startsWith('backup-'))
            .sort()
            .reverse();
        
        // Remove old backups
        for (let i = keepCount; i < backups.length; i++) {
            const backupPath = path.join(backupsDir, backups[i]);
            fs.rmSync(backupPath, { recursive: true, force: true });
            Logger.info(`Removed old backup: ${backups[i]}`, 'Backup');
        }
    }

    static async restoreBackup(backupName) {
        const backupPath = path.join(__dirname, '..', 'backups', backupName);
        
        if (!fs.existsSync(backupPath)) {
            return { success: false, error: 'Backup not found' };
        }
        
        try {
            // Restore config
            const configBackup = path.join(backupPath, 'config.json');
            if (fs.existsSync(configBackup)) {
                fs.copyFileSync(configBackup, path.join(__dirname, '..', 'config.json'));
            }
            
            // Restore data files
            const smtpBackup = path.join(backupPath, 'free_smtp_pool.json');
            if (fs.existsSync(smtpBackup)) {
                fs.copyFileSync(smtpBackup, path.join(__dirname, '..', 'data', 'free_smtp_pool.json'));
            }
            
            const mappingBackup = path.join(backupPath, 'user_smtp_mapping.json');
            if (fs.existsSync(mappingBackup)) {
                fs.copyFileSync(mappingBackup, path.join(__dirname, '..', 'data', 'user_smtp_mapping.json'));
            }
            
            Logger.success(`Backup restored: ${backupName}`, 'Backup');
            return { success: true };
            
        } catch (error) {
            Logger.error(`Restore error: ${error.message}`, 'Backup');
            return { success: false, error: error.message };
        }
    }
}

module.exports = Backup;
// END OF FILE - utils/backup.js