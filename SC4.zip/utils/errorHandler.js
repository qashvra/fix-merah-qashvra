// [QASHVRA BOT] - utils/errorHandler.js - Global Error Handler Utility
const Logger = require('./logger');

class ErrorHandler {
    static handle(error, ctx = null, source = 'Unknown') {
        const errorMessage = error.message || 'Unknown error';
        const stackLine = error.stack?.split('\n')[1]?.trim() || '';
        
        Logger.error(`${errorMessage}`, source, stackLine);

        // Notify owner if critical
        if (ctx && errorMessage.includes('FATAL')) {
            try {
                const globalInstance = require('../global');
                ctx.telegram.sendMessage(
                    globalInstance.ownerId,
                    `🚨 𝗖𝗥𝗜𝗧𝗜𝗖𝗔𝗟 𝗘𝗥𝗥𝗢𝗥\n\n` +
                    `📋 Source: ${source}\n` +
                    `❌ Error: ${errorMessage}\n` +
                    `📍 Stack: ${stackLine}\n` +
                    `🕐 Time: ${new Date().toISOString()}`
                ).catch(() => {});
            } catch (e) {}
        }

        // Return user-friendly message
        if (ctx) {
            return ctx.reply(
                `❌ 𝗧𝗲𝗿𝗷𝗮𝗱𝗶 𝗞𝗲𝘀𝗮𝗹𝗮𝗵𝗮𝗻\n\n` +
                `Silakan coba lagi nanti.\n` +
                `Jika berlanjut, hubungi admin.`
            ).catch(() => {});
        }
    }

    static async safeExecute(fn, errorMessage = 'Operation failed') {
        try {
            return await fn();
        } catch (error) {
            Logger.error(`${errorMessage}: ${error.message}`, 'SafeExecute');
            return null;
        }
    }

    static wrapAsync(fn) {
        return async (...args) => {
            try {
                return await fn(...args);
            } catch (error) {
                ErrorHandler.handle(error, args[0], fn.name || 'Anonymous');
                return null;
            }
        };
    }
}

module.exports = ErrorHandler;
// END OF FILE - utils/errorHandler.js