// [QASHVRA BOT] - utils/validator.js - Input Validation Utility
class Validator {
    
    static isValidPhone(phone) {
        const cleaned = phone.replace(/[^0-9+]/g, '');
        return /^\+?[0-9]{7,15}$/.test(cleaned);
    }

    static isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    static isValidGmail(email) {
        return this.isValidEmail(email) && email.toLowerCase().endsWith('@gmail.com');
    }

    static isValidUserId(id) {
        const num = parseInt(id);
        return !isNaN(num) && num > 0;
    }

    static isValidAmount(amount, min = 1, max = 999999999) {
        const num = parseInt(amount);
        return !isNaN(num) && num >= min && num <= max;
    }

    static isValidDays(days, allowedDays = [1, 3, 7, 30, 90]) {
        const num = parseInt(days);
        return !isNaN(num) && allowedDays.includes(num);
    }

    static isValidOrderId(orderId) {
        return /^QASHVRA-\w+-\d+-\d+-\d+$/.test(orderId);
    }

    static isValidSMTPFormat(text) {
        const lines = text.split('\n').filter(l => l.trim());
        if (lines.length < 2) return false;
        
        const email = lines[0].trim();
        const password = lines.slice(1).join(' ').trim();
        
        return this.isValidGmail(email) && password.length >= 4;
    }

    static sanitizeText(text, maxLength = 1000) {
        if (!text) return '';
        return text
            .replace(/[<>]/g, '') // Remove HTML tags
            .substring(0, maxLength)
            .trim();
    }

    static parsePhoneList(text) {
        if (!text) return [];
        
        const lines = text.split(/[\n,]+/);
        const phones = [];
        
        for (const line of lines) {
            const cleaned = line.trim().replace(/[^0-9+]/g, '');
            if (this.isValidPhone(cleaned)) {
                phones.push(cleaned);
            }
        }
        
        return [...new Set(phones)]; // Remove duplicates
    }

    static validatePrice(price, minPrice = 100, maxPrice = 100000000) {
        const num = parseInt(price);
        return !isNaN(num) && num >= minPrice && num <= maxPrice;
    }

    static validateGatewayConfig(gateway, config) {
        const required = {
            tripay: ['apiKey', 'privateKey', 'merchantCode'],
            midtrans: ['serverKey', 'clientKey'],
            tokopay: ['apiKey', 'merchantId']
        };

        const requiredFields = required[gateway];
        if (!requiredFields) return { valid: false, error: 'Invalid gateway' };

        for (const field of requiredFields) {
            if (!config[field]) {
                return { valid: false, error: `Missing required field: ${field}` };
            }
        }

        return { valid: true };
    }

    static validateReferralConfig(config) {
        const errors = [];
        
        if (!config.coinsPerReferral || config.coinsPerReferral < 1) {
            errors.push('coinsPerReferral must be >= 1');
        }
        if (!config.minimumRedeemCoins || config.minimumRedeemCoins < 10) {
            errors.push('minimumRedeemCoins must be >= 10');
        }
        
        return {
            valid: errors.length === 0,
            errors
        };
    }
}

module.exports = Validator;
// END OF FILE - utils/validator.js