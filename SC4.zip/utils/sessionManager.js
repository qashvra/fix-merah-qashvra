// [QASHVRA BOT] - utils/sessionManager.js - User Session Management
class SessionManager {
    constructor() {
        this.sessions = new Map();
        this.sessionTimeout = 30 * 60 * 1000; // 30 minutes
    }

    getSession(userId) {
        if (!this.sessions.has(userId)) {
            this.sessions.set(userId, {
                userId,
                data: {},
                createdAt: new Date(),
                lastActivity: new Date()
            });
        }

        const session = this.sessions.get(userId);
        session.lastActivity = new Date();

        return session;
    }

    setSessionData(userId, key, value) {
        const session = this.getSession(userId);
        session.data[key] = value;
    }

    getSessionData(userId, key) {
        const session = this.getSession(userId);
        return session.data[key];
    }

    deleteSession(userId) {
        this.sessions.delete(userId);
    }

    clearSessionData(userId) {
        if (this.sessions.has(userId)) {
            this.sessions.get(userId).data = {};
        }
    }

    isSessionActive(userId) {
        if (!this.sessions.has(userId)) return false;
        
        const session = this.sessions.get(userId);
        const now = new Date();
        const diff = now - session.lastActivity;

        if (diff > this.sessionTimeout) {
            this.deleteSession(userId);
            return false;
        }

        return true;
    }

    getAllActiveSessions() {
        const active = [];
        const now = new Date();

        for (const [userId, session] of this.sessions) {
            if (now - session.lastActivity < this.sessionTimeout) {
                active.push({ userId, lastActivity: session.lastActivity });
            }
        }

        return active;
    }

    getActiveSessionCount() {
        return this.getAllActiveSessions().length;
    }

    cleanupExpiredSessions() {
        const now = new Date();
        let cleaned = 0;

        for (const [userId, session] of this.sessions) {
            if (now - session.lastActivity > this.sessionTimeout) {
                this.sessions.delete(userId);
                cleaned++;
            }
        }

        return cleaned;
    }

    // Auto cleanup every hour
    startAutoCleanup() {
        setInterval(() => {
            const cleaned = this.cleanupExpiredSessions();
            if (cleaned > 0) {
                // Logger.info(`Cleaned ${cleaned} expired sessions`, 'SessionManager');
            }
        }, 60 * 60 * 1000); // Every hour
    }
}

module.exports = new SessionManager();
// END OF FILE - utils/sessionManager.js