// [QASHVRA BOT] - utils/constants.js - Application Constants
module.exports = {
    // Bot Info
    BOT_NAME: 'QASHVRA Fix Merah Pro',
    BOT_VERSION: '1.0.0',
    BRAND_NAME: 'QASHVRA',
    
    // User Status
    STATUS: {
        FREE: 'FREE',
        VIP: 'VIP',
        VVIP: 'VVIP',
        OWNER: 'OWNER'
    },
    
    // Payment Status
    PAYMENT_STATUS: {
        PENDING: 'pending',
        PAID: 'paid',
        FAILED: 'failed',
        EXPIRED: 'expired',
        CANCELLED: 'cancelled'
    },
    
    // SMTP Types
    SMTP_TYPE: {
        SELF: 'self',
        PREMIUM: 'premium',
        NONE: 'none'
    },
    
    // Fix Status
    FIX_STATUS: {
        SUCCESS: 'success',
        FAILED: 'failed',
        PENDING: 'pending'
    },
    
    // Gateway Types
    GATEWAY: {
        QRIS: 'qris',
        TRIPAY: 'tripay',
        MIDTRANS: 'midtrans',
        TOKOPAY: 'tokopay'
    },
    
    // Limits
    LIMITS: {
        FREE_DAILY: 2,
        FREE_MASS_SEND: 1,
        VIP_MASS_SEND: 5,
        VVIP_MASS_SEND: 25,
        UNLIMITED: 999999
    },
    
    // Referral
    REFERRAL: {
        COINS_PER_REFERRAL: 5,
        MIN_REDEEM_COINS: 100,
        REDEEM_OPTIONS: {
            1: 100,
            3: 250,
            7: 500
        }
    },
    
    // SMTP
    SMTP: {
        MAX_RETRY: 3,
        TIMEOUT: 30000,
        ROLLING_INTERVAL: 3000
    },
    
    // Session
    SESSION: {
        TIMEOUT: 30 * 60 * 1000 // 30 minutes
    },
    
    // Payment
    PAYMENT: {
        EXPIRY_HOURS: 24,
        MIN_AMOUNT: 100,
        MAX_AMOUNT: 100000000
    },
    
    // Emoji Map
    EMOJI: {
        SUCCESS: '✅',
        FAILED: '❌',
        WARNING: '⚠️',
        INFO: 'ℹ️',
        LOADING: '⏳',
        PREMIUM: '👑',
        VIP: '⭐',
        VVIP: '💎',
        FREE: '👤',
        COINS: '🪙',
        FIX: '🛠️',
        PAYMENT: '💳',
        REFERRAL: '🧧',
        HISTORY: '📜',
        STATS: '📊',
        GLOBAL: '🌍',
        SMTP: '📧',
        BROADCAST: '📢',
        SETTINGS: '⚙️',
        BACK: '🔙',
        REFRESH: '🔄',
        SEARCH: '🔍',
        BAN: '🚫',
        UNBAN: '✅',
        ADD: '➕',
        REMOVE: '➖',
        EDIT: '✏️',
        SAVE: '💾',
        DELETE: '🗑️',
        CLOSE: '❌',
        NEXT: '▶️',
        PREV: '◀️',
        TOP: '🔝',
        RANK: '🏆',
        USER: '👤',
        ID: '🆔',
        DATE: '📅',
        TIME: '🕐',
        PHONE: '📱',
        EMAIL: '📧',
        PASSWORD: '🔑',
        LINK: '🔗',
        COPY: '📋',
        SHARE: '📤',
        CHECK: '✔️',
        CROSS: '✖️',
        STAR: '🌟',
        FIRE: '🔥',
        NEW: '🆕',
        HOT: '🔥',
        COOL: '😎',
        PARTY: '🎉',
        GIFT: '🎁',
        MONEY: '💰',
        BANK: '🏦',
        CREDIT_CARD: '💳'
    },
    
    // Country Flags for Leaderboard
    COUNTRY_FLAGS: {
        'Lainnya': '🏳️',
        'Venezuela': '🇻🇪',
        'Rusia': '🇷🇺',
        'Indonesia': '🇮🇩',
        'Arab Saudi': '🇸🇦',
        'Zimbabwe': '🇿🇼',
        'Pakistan': '🇵🇰',
        'Pantai Gading': '🇨🇮',
        'Togo': '🇹🇬',
        'Malaysia': '🇲🇾'
    },
    
    // Leaderboard Medals
    MEDALS: ['🥇', '🥈', '🥉'],
    
    // Timezone
    TIMEZONE: 'Asia/Jakarta',
    
    // File Paths
    PATHS: {
        DATA: './data',
        LOGS: './logs',
        ASSETS: './assets',
        BACKUPS: './backups',
        CONFIG: './config.json',
        ENV: './.env',
        SMTP_POOL: './data/free_smtp_pool.json',
        SMTP_MAPPING: './data/user_smtp_mapping.json'
    }
};
// END OF FILE - utils/constants.js