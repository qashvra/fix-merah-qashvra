// [QASHVRA BOT] - utils/dailyReset.js - Daily Reset Cron Job
const cron = require('node-cron');
const UserModel = require('../models/userModel');
const PaymentModel = require('../models/paymentModel');
const smtpService = require('../services/smtpService');
const userService = require('../services/userService');
const Logger = require('./logger');

class DailyReset {
    
    static startScheduler() {
        Logger.info('Daily reset scheduler initialized', 'DailyReset');
        
        // Reset daily limits every midnight
        cron.schedule('0 0 * * *', async () => {
            Logger.info('Running daily reset...', 'DailyReset');
            await this.resetDailyLimits();
            await this.checkExpiredPremiums();
            await this.cleanExpiredPayments();
            await this.resetSMTPCounters();
            Logger.success('Daily reset completed', 'DailyReset');
        }, {
            timezone: 'Asia/Jakarta'
        });
        
        // Cleanup every hour
        cron.schedule('0 * * * *', async () => {
            await this.cleanupOldData();
        }, {
            timezone: 'Asia/Jakarta'
        });
        
        // SMTP pool check every 30 minutes
        cron.schedule('*/30 * * * *', async () => {
            await this.checkSMTPPool();
        }, {
            timezone: 'Asia/Jakarta'
        });
    }

    static async resetDailyLimits() {
        try {
            const result = await UserModel.updateMany(
                { status: 'FREE' },
                {
                    $set: {
                        'limits.usedToday': 0,
                        'limits.lastReset': new Date()
                    }
                }
            );
            
            Logger.info(`Daily limits reset for ${result.modifiedCount} users`, 'DailyReset');
        } catch (error) {
            Logger.error(`Reset daily limits error: ${error.message}`, 'DailyReset');
        }
    }

    static async checkExpiredPremiums() {
        try {
            const count = await userService.checkAndExpirePremiums();
            if (count > 0) {
                Logger.info(`${count} premium users expired`, 'DailyReset');
            }
        } catch (error) {
            Logger.error(`Check expired premiums error: ${error.message}`, 'DailyReset');
        }
    }

    static async cleanExpiredPayments() {
        try {
            const cleaned = await PaymentModel.cleanExpiredPayments();
            if (cleaned > 0) {
                Logger.info(`${cleaned} expired payments cleaned`, 'DailyReset');
            }
        } catch (error) {
            Logger.error(`Clean payments error: ${error.message}`, 'DailyReset');
        }
    }

    static async resetSMTPCounters() {
        try {
            smtpService.cleanupFailedSMTPs();
            Logger.info('SMTP counters reset', 'DailyReset');
        } catch (error) {
            Logger.error(`Reset SMTP error: ${error.message}`, 'DailyReset');
        }
    }

    static async cleanupOldData() {
        try {
            // Clean old sessions (handled by SessionManager)
            const sessionManager = require('./sessionManager');
            sessionManager.cleanupExpiredSessions();
            
            // Clean old payment history (older than 90 days)
            const ninetyDaysAgo = new Date();
            ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
            
            // Optionally archive old fix history
            // await UserModel.updateMany({}, {
            //     $pull: {
            //         fixHistory: {
            //             timestamp: { $lt: ninetyDaysAgo }
            //         }
            //     }
            // });
            
        } catch (error) {
            Logger.error(`Cleanup error: ${error.message}`, 'DailyReset');
        }
    }

    static async checkSMTPPool() {
        try {
            const poolData = smtpService.loadFreePool();
            const failedSMTPs = poolData.pool.filter(s => !s.isActive);
            
            if (failedSMTPs.length > poolData.pool.length * 0.5) {
                Logger.warn(`More than 50% SMTPs are inactive (${failedSMTPs.length}/${poolData.pool.length})`, 'DailyReset');
                
                // Notify owner
                try {
                    const globalInstance = require('../global');
                    const bot = globalInstance.bot;
                    if (bot) {
                        await bot.telegram.sendMessage(
                            globalInstance.ownerId,
                            `⚠️ 𝗦𝗠𝗧𝗣 𝗣𝗢𝗢𝗟 𝗪𝗔𝗥𝗡𝗜𝗡𝗚\n\n` +
                            `❌ ${failedSMTPs.length}/${poolData.pool.length} SMTPs tidak aktif!\n\n` +
                            `Cek panel owner untuk detail.`
                        );
                    }
                } catch (e) {}
            }
        } catch (error) {
            Logger.error(`SMTP pool check error: ${error.message}`, 'DailyReset');
        }
    }
}

module.exports = DailyReset;
// END OF FILE - utils/dailyReset.js