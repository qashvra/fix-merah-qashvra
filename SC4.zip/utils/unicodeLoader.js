// [QASHVRA BOT] - utils/unicodeLoader.js - Unicode Loading Animation System
const Logger = require('./logger');

class UnicodeLoader {
    constructor() {
        this.frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
        this.specialLoaders = {
            processing: ['[⏳]', '[⌛]', '[🔄]'],
            success: ['[✅]', '[🎉]', '[✔️]'],
            failed: ['[❌]', '[💥]', '[⚠️]'],
            payment: ['[💳]', '[💰]', '[💵]'],
            sending: ['[📤]', '[📧]', '[✉️]'],
            checking: ['[🔍]', '[👀]', '[🔎]']
        };
    }

    async showLoading(ctx, messageId, action, duration = 3000) {
        let frameIndex = 0;
        const loaderType = this.specialLoaders[action] || this.specialLoaders.processing;
        
        const interval = setInterval(async () => {
            try {
                const frame = this.frames[frameIndex % this.frames.length];
                const emoji = loaderType[Math.floor(frameIndex / 3) % loaderType.length];
                
                const loadingTexts = {
                    processing: `${frame} ${emoji} 𝗠𝗲𝗺𝗽𝗿𝗼𝘀𝗲𝘀...`,
                    success: `${emoji} 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹!`,
                    failed: `${emoji} 𝗚𝗮𝗴𝗮𝗹!`,
                    payment: `${frame} ${emoji} 𝗠𝗲𝗺𝗲𝗿𝗶𝗸𝘀𝗮 𝗣𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻...`,
                    sending: `${frame} ${emoji} 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗣𝗲𝘀𝗮𝗻...`,
                    checking: `${frame} ${emoji} 𝗠𝗲𝗺𝗲𝗿𝗶𝗸𝘀𝗮...`
                };
                
                const text = loadingTexts[action] || loadingTexts.processing;
                
                await ctx.telegram.editMessageText(
                    ctx.chat.id,
                    messageId,
                    null,
                    text
                ).catch(() => {});
                
                frameIndex++;
            } catch (error) {
                clearInterval(interval);
            }
        }, 500);
        
        return new Promise(resolve => {
            setTimeout(() => {
                clearInterval(interval);
                resolve();
            }, duration);
        });
    }

    async showStartupLoading() {
        const phases = [
            { text: '⠋ 𝗜𝗻𝗶𝘁𝗶𝗮𝗹𝗶𝘇𝗶𝗻𝗴 𝗤𝗔𝗦𝗛𝗩𝗥𝗔 𝗦𝘆𝘀𝘁𝗲𝗺...', delay: 500 },
            { text: '⠙ 𝗖𝗼𝗻𝗻𝗲𝗰𝘁𝗶𝗻𝗴 𝘁𝗼 𝗠𝗼𝗻𝗴𝗼𝗗𝗕...', delay: 800 },
            { text: '⠹ 𝗟𝗼𝗮𝗱𝗶𝗻𝗴 𝗺𝗼𝗱𝘂𝗹𝗲𝘀...', delay: 600 },
            { text: '⠸ 𝗖𝗵𝗲𝗰𝗸𝗶𝗻𝗴 𝗰𝗼𝗻𝗳𝗶𝗴𝘂𝗿𝗮𝘁𝗶𝗼𝗻...', delay: 700 },
            { text: '⠼ 𝗦𝗲𝘁𝘁𝗶𝗻𝗴 𝘂𝗽 𝗵𝗮𝗻𝗱𝗹𝗲𝗿𝘀...', delay: 500 },
            { text: '⠴ 𝗩𝗲𝗿𝗶𝗳𝘆𝗶𝗻𝗴 𝗽𝗲𝗿𝗺𝗶𝘀𝘀𝗶𝗼𝗻𝘀...', delay: 600 },
            { text: '⠦ 𝗦𝘆𝗻𝗰𝗵𝗿𝗼𝗻𝗶𝘇𝗶𝗻𝗴 𝗱𝗮𝘁𝗮...', delay: 500 },
            { text: '✅ 𝗤𝗔𝗦𝗛𝗩𝗥𝗔 𝗕𝗼𝘁 𝗥𝗲𝗮𝗱𝘆!', delay: 300 }
        ];
        
        for (const phase of phases) {
            console.log(`  ${phase.text}`);
            await new Promise(resolve => setTimeout(resolve, phase.delay));
        }
    }
}

module.exports = new UnicodeLoader();
// END OF FILE - utils/unicodeLoader.js