// [QASHVRA BOT] - utils/fileChecker.js - Auto detect missing files
const fs = require('fs');
const path = require('path');
const Logger = require('./logger');

class FileChecker {
    constructor(baseDir) {
        this.baseDir = baseDir;
        this.requiredFiles = [
            // Core files
            'index.js',
            'package.json',
            '.env',
            'config.json',
            'global.js',
            
            // Utils
            'utils/logger.js',
            'utils/fileChecker.js',
            'utils/unicodeLoader.js',
            'utils/formatter.js',
            
            // Handlers
            'handlers/startHandler.js',
            'handlers/menuHandler.js',
            'handlers/fixMerahHandler.js',
            'handlers/vipHandler.js',
            'handlers/referralHandler.js',
            'handlers/historyHandler.js',
            'handlers/leaderboardHandler.js',
            'handlers/paymentHandler.js',
            'handlers/ownerPanel.js',
            
            // Services
            'services/databaseService.js',
            'services/userService.js',
            'services/smtpService.js',
            'services/paymentService.js',
            'services/statisticsService.js',
            'services/referralService.js',
            
            // Models
            'models/userModel.js',
            'models/paymentModel.js',
            'models/smtpModel.js',
            'models/statisticsModel.js',
            
            // Middleware
            'middleware/authMiddleware.js',
            'middleware/verificationMiddleware.js',
            'middleware/permissionMiddleware.js',
            
            // Data
            'data/free_smtp_pool.json',
            'data/user_smtp_mapping.json'
        ];
        
        this.loadedFiles = [];
        this.missingFiles = [];
    }

    checkAllFiles() {
        Logger.info('Memeriksa kelengkapan file...', 'FileChecker');
        
        this.requiredFiles.forEach((file, index) => {
            const filePath = path.join(this.baseDir, file);
            const fileNumber = index + 1;
            const totalFiles = this.requiredFiles.length;
            
            if (fs.existsSync(filePath)) {
                this.loadedFiles.push(file);
                Logger.fileLoaded(file, fileNumber, totalFiles);
            } else {
                this.missingFiles.push(file);
                Logger.error(`FILE MISSING: ${file}`, 'FileChecker');
            }
        });
        
        return {
            loaded: this.loadedFiles.length,
            total: this.requiredFiles.length,
            missing: this.missingFiles,
            isComplete: this.missingFiles.length === 0
        };
    }

    getLoadedCount() {
        return this.loadedFiles.length;
    }

    getTotalCount() {
        return this.requiredFiles.length;
    }

    getMissingFiles() {
        return this.missingFiles;
    }

    displaySummary() {
        const loaded = this.loadedFiles.length;
        const total = this.requiredFiles.length;
        const missing = this.missingFiles.length;
        
        console.log('\n' + '='.repeat(50));
        console.log(`  📊 FILE CHECKER SUMMARY`);
        console.log(`  ✅ Loaded  : ${loaded}/${total} files`);
        console.log(`  ❌ Missing : ${missing} files`);
        
        if (this.missingFiles.length > 0) {
            console.log(`\n  ⚠️  MISSING FILES DETECTED:`);
            this.missingFiles.forEach(file => {
                console.log(`     └ ❌ ${file}`);
            });
            console.log(`\n  🔧 Silakan generate file yang kurang!`);
        } else {
            console.log(`  🎉 All files are complete!`);
        }
        console.log('='.repeat(50) + '\n');
    }
}

module.exports = FileChecker;
// END OF FILE - utils/fileChecker.js