// [QASHVRA BOT] - utils/logger.js - Professional Console Logger System
const chalk = require('chalk');
const moment = require('moment-timezone');

class Logger {
    static getTimestamp() {
        return moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');
    }

    static info(message, file = 'SYSTEM') {
        console.log(
            chalk.cyan(`[${this.getTimestamp()}]`) +
            chalk.white(` [INFO] `) +
            chalk.green(`${file}`) +
            chalk.white(` → ${message}`)
        );
    }

    static error(message, file = 'SYSTEM', line = '') {
        console.log(
            chalk.red(`[${this.getTimestamp()}]`) +
            chalk.white(` [ERROR] `) +
            chalk.yellow(`${file}${line ? ':' + line : ''}`) +
            chalk.red(` → ${message}`)
        );
    }

    static warn(message, file = 'SYSTEM') {
        console.log(
            chalk.yellow(`[${this.getTimestamp()}]`) +
            chalk.white(` [WARN] `) +
            chalk.magenta(`${file}`) +
            chalk.yellow(` → ${message}`)
        );
    }

    static debug(message, file = 'SYSTEM') {
        console.log(
            chalk.gray(`[${this.getTimestamp()}]`) +
            chalk.white(` [DEBUG] `) +
            chalk.blue(`${file}`) +
            chalk.gray(` → ${message}`)
        );
    }

    static success(message, file = 'SYSTEM') {
        console.log(
            chalk.green(`[${this.getTimestamp()}]`) +
            chalk.white(` [SUCCESS] `) +
            chalk.green(`${file}`) +
            chalk.white(` → ${message}`)
        );
    }

    static botStart(botName, filesLoaded, totalFiles) {
        console.log('\n' + '='.repeat(50));
        console.log(chalk.red.bold(`  🔴 QASHVRA FIX MERAH BOT PRO`));
        console.log(chalk.white(`  🤖 Bot Name    : ${botName}`));
        console.log(chalk.white(`  📅 Start Date  : ${moment().tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')}`));
        console.log(chalk.white(`  ⏰ Start Time  : ${this.getTimestamp()}`));
        console.log(chalk.white(`  📂 Files Loaded: ${filesLoaded}/${totalFiles}`));
        console.log('='.repeat(50) + '\n');
    }

    static fileLoaded(fileName, fileNumber, totalFiles) {
        console.log(
            chalk.green(`  [${this.getTimestamp()}]`) +
            chalk.white(` [FILE] `) +
            chalk.cyan(`${fileNumber}/${totalFiles}`) +
            chalk.white(` → Loaded: ${fileName}`)
        );
    }
}

module.exports = Logger;
// END OF FILE - utils/logger.js