// [QASHVRA BOT] - handlers/startHandler.js - Start Command Handler
const globalInstance = require('../global');
const UserModel = require('../models/userModel');
const StatisticsModel = require('../models/statisticsModel');
const Formatter = require('../utils/formatter');
const Logger = require('../utils/logger');
const fs = require('fs');
const path = require('path');

class StartHandler {
    async handleStart(ctx) {
        const userId = ctx.from.id;
        const user = ctx.state.user;
        
        try {
            Logger.info(`User ${userId} started the bot`, 'StartHandler');
            
            // Check verification first
            const verification = globalInstance.config.verification;
            if (verification.enabled && !user.isVerified && !ctx.state.isOwner) {
                await this.handleVerification(ctx);
                return;
            }
            
            // Check if user came from referral link
            if (ctx.startPayload) {
                await this.handleReferralStart(ctx, ctx.startPayload);
            }
            
            // Send start image
            const startImage = globalInstance.config.bot.startImage;
            if (fs.existsSync(path.resolve(startImage))) {
                await ctx.replyWithPhoto(
                    { source: path.resolve(startImage) },
                    { caption: '🔴 QASHVRA FIX MERAH PRO' }
                );
            }
            
            // Send secondary image
            const secondaryImage = globalInstance.config.bot.secondaryImage;
            if (fs.existsSync(path.resolve(secondaryImage))) {
                await ctx.replyWithPhoto({ source: path.resolve(secondaryImage) });
            }
            
            // Send start audio
            const startAudio = globalInstance.config.bot.startAudio;
            if (fs.existsSync(path.resolve(startAudio))) {
                await ctx.replyWithAudio({ source: path.resolve(startAudio) });
            }
            
            // Wait a moment
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Send main menu
            await this.showMainMenu(ctx, user);
            
        } catch (error) {
            Logger.error(`Start handler error: ${error.message}`, 'StartHandler', '22');
            await ctx.reply('❌ Terjadi kesalahan. Silakan coba /start kembali.');
        }
    }
    
    async handleVerification(ctx) {
        const verification = globalInstance.config.verification;
        const requiredChannels = verification.requiredChannels || [];
        const requiredGroups = verification.requiredGroups || [];
        const allRequired = [...requiredChannels, ...requiredGroups];
        
        const buttons = [];
        
        for (const entity of allRequired) {
            buttons.push([{
                text: `📢 Join ${entity.name}`,
                url: entity.link
            }]);
        }
        
        buttons.push([{
            text: '✅ Sudah Join? Cek Ulang',
            callback_data: 'verify_check'
        }]);
        
        await ctx.reply(
            `🔴 𝗤𝗔𝗦𝗛𝗩𝗥𝗔 𝗙𝗜𝗫 𝗠𝗘𝗥𝗔𝗛 𝗣𝗥𝗢\n\n` +
            `⚠️ 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜𝗧𝗢𝗟𝗔𝗞!\n\n` +
            `Anda harus bergabung ke channel dan grup resmi QASHVRA terlebih dahulu untuk menggunakan bot ini.\n\n` +
            `📋 Channel/Grup yang wajib diikuti:\n` +
            allRequired.map(e => `├ ${e.name}`).join('\n') + `\n\n` +
            `Setelah join, klik tombol "Cek Ulang" di bawah.`,
            {
                reply_markup: {
                    inline_keyboard: buttons
                }
            }
        );
    }
    
    async handleReferralStart(ctx, payload) {
        try {
            const referrerId = parseInt(payload);
            if (referrerId && referrerId !== ctx.from.id) {
                const referrer = await UserModel.findOne({ userId: referrerId });
                
                if (referrer && !referrer.referral.invitedUsers.includes(ctx.from.id)) {
                    // Add referral bonus
                    referrer.referral.totalInvited += 1;
                    referrer.referral.coins += globalInstance.config.referral.coinsPerReferral || 5;
                    referrer.referral.invitedUsers.push(ctx.from.id);
                    await referrer.save();
                    
                    // Set referred by for new user
                    const user = ctx.state.user;
                    user.referral.referredBy = referrerId;
                    await user.save();
                    
                    Logger.info(`Referral: ${ctx.from.id} referred by ${referrerId}`, 'StartHandler');
                    
                    // Notify referrer
                    try {
                        await ctx.telegram.sendMessage(
                            referrerId,
                            `🎉 𝗥𝗘𝗙𝗘𝗥𝗥𝗔𝗟 𝗕𝗔𝗥𝗨!\n\n` +
                            `👤 User baru telah join menggunakan link Anda!\n` +
                            `🪙 +${globalInstance.config.referral.coinsPerReferral || 5} Koin ditambahkan\n\n` +
                            `Total koin: ${referrer.referral.coins} Koin`
                        );
                    } catch (e) {
                        // Referrer might have blocked the bot
                    }
                }
            }
        } catch (error) {
            Logger.warn(`Referral handling error: ${error.message}`, 'StartHandler');
        }
    }
    
    async showMainMenu(ctx, user) {
        // Get global statistics (realtime from DB)
        const globalStats = await globalInstance.getGlobalStatistics();
        
        // Update user statistics display
        const stats = user.statistics || { totalFix: 0, berhasil: 0, winRate: 0 };
        
        const message = 
            `🔴 WELCOME TO QASHVRA FIX MERAH PRO\n\n` +
            `👤 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗔𝗞𝗨𝗡\n` +
            `├ 👤 Nama: ${Formatter.maskUsername(user.firstName || user.username)}\n` +
            `├ 🆔 Akun ID: ${user.userId}\n` +
            `├ 👑 Status: ${Formatter.getStatusBadge(user.status)}\n` +
            `├ ⏰ Runtime: ${globalInstance.getRuntime()}\n` +
            `└ 📅 Hari: ${globalInstance.getStartDate().split(' ')[0]}\n\n` +
            `📊 𝗦𝗧𝗔𝗧𝗜𝗦𝗧𝗜𝗞 𝗣𝗥𝗜𝗕𝗔𝗗𝗜\n` +
            `├ 🛠️ Total Fix: ${Formatter.formatNumber(stats.totalFix || 0)}\n` +
            `├ 🎯 Berhasil: ${Formatter.formatNumber(stats.berhasil || 0)}\n` +
            `└ 📈 Win Rate: ${Formatter.formatWinRate(stats.berhasil || 0, stats.totalFix || 0)}\n\n` +
            `🌍 𝗦𝗧𝗔𝗧𝗜𝗦𝗧𝗜𝗞 𝗚𝗟𝗢𝗕𝗔𝗟 𝗤𝗔𝗦𝗛𝗩𝗥𝗔\n` +
            `├ 📧 Sender Aktif: ${globalStats.activeSenders?.current || 0}/${globalStats.activeSenders?.max || 1984}\n` +
            `├ 👥 Pengguna: ${Formatter.formatNumber(globalStats.totalUsers || 0)}\n` +
            `├ 🛠️ Total Fix: ${Formatter.formatNumber(globalStats.totalFix || 0)}\n` +
            `└ 📈 Win Rate Global: ${Formatter.formatWinRate(globalStats.totalSuccess || 0, globalStats.totalFix || 0)}`;
        
        // Main menu keyboard
        const keyboard = {
            reply_markup: {
                keyboard: [
                    [
                        { text: '🛠️ Fix Merah' },
                        { text: '👑 VIP / VVIP' }
                    ],
                    [
                        { text: '🧧 Referral' },
                        { text: '📜 Riwayat' }
                    ],
                    [
                        { text: '🏆 Top Global' },
                        { text: '💬 Testimoni' }
                    ]
                ],
                resize_keyboard: true,
                persistent: true
            }
        };
        
        await ctx.reply(message, keyboard);
    }
}

module.exports = new StartHandler();
// END OF FILE - handlers/startHandler.js