// [QASHVRA BOT] - handlers/notificationHandler.js - User Notification System
const globalInstance = require('../global');
const UserModel = require('../models/userModel');
const Logger = require('../utils/logger');

class NotificationHandler {
    
    // Send to single user
    static async sendToUser(userId, message, options = {}) {
        try {
            await globalInstance.bot?.telegram?.sendMessage(userId, message, options);
            return true;
        } catch (error) {
            Logger.warn(`Failed to notify user ${userId}: ${error.message}`, 'NotificationHandler');
            return false;
        }
    }

    // Notify premium expiry soon
    static async notifyExpiringPremiums() {
        try {
            const threeDaysFromNow = new Date();
            threeDaysFromNow.setDate(threeDaysFromNow.getDate() + 3);
            
            const oneDayFromNow = new Date();
            oneDayFromNow.setDate(oneDayFromNow.getDate() + 1);

            const expiringUsers = await UserModel.find({
                status: { $in: ['VIP', 'VVIP'] },
                premiumExpiry: {
                    $gte: new Date(),
                    $lte: threeDaysFromNow
                }
            });

            for (const user of expiringUsers) {
                const daysLeft = Math.ceil(
                    (user.premiumExpiry - new Date()) / (1000 * 60 * 60 * 24)
                );

                const message = 
                    `⚠️ 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗔𝗞𝗔𝗡 𝗕𝗘𝗥𝗔𝗞𝗛𝗜𝗥\n\n` +
                    `Status ${user.status} Anda akan berakhir dalam ${daysLeft} hari.\n` +
                    `📅 Expired: ${user.premiumExpiry.toLocaleDateString('id-ID')}\n\n` +
                    `🔄 Perpanjang sekarang untuk tetap menikmati fitur premium!\n` +
                    `Klik 👑 VIP / VVIP di menu utama.`;

                await this.sendToUser(user.userId, message);
            }

            Logger.info(`Sent expiry notifications to ${expiringUsers.length} users`, 'NotificationHandler');
        } catch (error) {
            Logger.error(`Expiry notification error: ${error.message}`, 'NotificationHandler');
        }
    }

    // Notify new VIP user
    static async notifyNewPremium(userId, type, days, expiryDate) {
        const message = 
            `🎉 𝗦𝗘𝗟𝗔𝗠𝗔𝗧!\n\n` +
            `Anda sekarang adalah ${type} User QASHVRA!\n\n` +
            `📅 Durasi: ${days} Hari\n` +
            `📆 Expired: ${expiryDate.toLocaleDateString('id-ID')}\n\n` +
            `✨ 𝗙𝗶𝘁𝘂𝗿 𝗣𝗿𝗲𝗺𝗶𝘂𝗺:\n` +
            `├ 📊 Limit: ∞ Unlimited\n` +
            `├ 📦 Mass Send: ${type === 'VVIP' ? '25' : '5'} Nomor\n` +
            `├ 📧 SMTP: Premium QASHVRA\n` +
            `└ 🚀 Prioritas: ${type === 'VVIP' ? 'Paling Utama' : 'Prioritas'}\n\n` +
            `Selamat menggunakan QASHVRA Fix Merah Bot!`;

        await this.sendToUser(userId, message);
    }

    // Notify payment success
    static async notifyPaymentSuccess(userId, orderId, packageName, amount) {
        const Formatter = require('../utils/formatter');
        
        const message = 
            `✅ 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟\n\n` +
            `🔖 Order ID: ${orderId}\n` +
            `📦 Paket: ${packageName}\n` +
            `💰 Total: ${Formatter.formatCurrency(amount)}\n\n` +
            `Terima kasih telah berlangganan QASHVRA!`;

        await this.sendToUser(userId, message);
    }

    // Notify referral bonus
    static async notifyReferralBonus(userId, coinsEarned, totalCoins) {
        const message = 
            `🎉 𝗥𝗘𝗙𝗘𝗥𝗥𝗔𝗟 𝗕𝗔𝗥𝗨!\n\n` +
            `🪙 +${coinsEarned} Koin ditambahkan\n` +
            `💰 Total Koin: ${totalCoins}\n\n` +
            `Ajak lebih banyak teman untuk kumpulkan koin!`;

        await this.sendToUser(userId, message);
    }

    // Notify ban/unban
    static async notifyBanStatus(userId, isBanned, reason = '') {
        if (isBanned) {
            const message = 
                `🚫 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜𝗕𝗟𝗢𝗞𝗜𝗥\n\n` +
                `Akun Anda telah diblokir.\n` +
                `📋 Alasan: ${reason || 'Pelanggaran aturan'}\n\n` +
                `Hubungi @${globalInstance.ownerUsername} untuk banding.`;
            
            await this.sendToUser(userId, message);
        } else {
            const message = 
                `✅ 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜𝗣𝗨𝗟𝗜𝗛𝗞𝗔𝗡\n\n` +
                `Akun Anda telah dipulihkan.\n` +
                `Silakan gunakan bot kembali.`;
            
            await this.sendToUser(userId, message);
        }
    }

    // Broadcast to all users
    static async broadcastToAll(message, excludeBanned = true) {
        try {
            const filter = excludeBanned ? { isBanned: false } : {};
            const users = await UserModel.find(filter).select('userId');
            
            let sent = 0;
            let failed = 0;

            for (const user of users) {
                const success = await this.sendToUser(
                    user.userId,
                    `📢 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧 𝗤𝗔𝗦𝗛𝗩𝗥𝗔\n\n${message}`
                );
                
                if (success) sent++;
                else failed++;
                
                // Delay to avoid rate limiting
                await new Promise(resolve => setTimeout(resolve, 50));
            }

            Logger.info(`Broadcast: ${sent} sent, ${failed} failed`, 'NotificationHandler');
            return { sent, failed };
            
        } catch (error) {
            Logger.error(`Broadcast error: ${error.message}`, 'NotificationHandler');
            return { sent: 0, failed: 0 };
        }
    }

    // Send daily stats to owner
    static async sendDailyStatsToOwner() {
        try {
            const userService = require('../services/userService');
            const paymentService = require('../services/paymentService');
            const statisticsService = require('../services/statisticsService');
            const smtpService = require('../services/smtpService');

            const userStats = await userService.getUserStats();
            const paymentStats = await paymentService.getPaymentStats();
            const globalStats = await statisticsService.getGlobalStats();
            const smtpStats = smtpService.getSMTPStats();

            const message = 
                `📊 𝗗𝗔𝗜𝗟𝗬 𝗥𝗘𝗣𝗢𝗥𝗧\n\n` +
                `📅 ${new Date().toLocaleDateString('id-ID')}\n\n` +
                `👥 Users: ${userStats.total} (${userStats.free} FREE, ${userStats.vip} VIP, ${userStats.vvip} VVIP)\n` +
                `🛠️ Fix Today: ${globalStats.totalFix}\n` +
                `💰 Revenue: Rp ${paymentStats.totalRevenue.toLocaleString('id-ID')}\n` +
                `📧 SMTP Active: ${smtpStats.active}/${smtpStats.total}\n\n` +
                `🤖 QASHVRA Fix Merah Bot`;

            await this.sendToUser(globalInstance.ownerId, message);
            
        } catch (error) {
            Logger.error(`Daily stats error: ${error.message}`, 'NotificationHandler');
        }
    }
}

module.exports = NotificationHandler;
// END OF FILE - handlers/notificationHandler.js