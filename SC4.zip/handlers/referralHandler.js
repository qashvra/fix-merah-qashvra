// [QASHVRA BOT] - handlers/referralHandler.js - Referral Redemption Handler
const globalInstance = require('../global');
const UserModel = require('../models/userModel');
const Formatter = require('../utils/formatter');
const Logger = require('../utils/logger');

class ReferralHandler {
    
    async handleRedeemCoins(ctx) {
        try {
            const callbackData = ctx.callbackQuery.data;
            const match = callbackData.match(/^redeem_(\d+)$/);
            
            if (!match) {
                await ctx.answerCbQuery('❌ Invalid redemption');
                return;
            }
            
            const days = parseInt(match[1]);
            const user = ctx.state.user;
            
            // Get redeem requirements
            const redeemDays = globalInstance.config.referral.redeemDays || {};
            const requiredCoins = redeemDays[days.toString()];
            
            if (!requiredCoins) {
                await ctx.answerCbQuery('❌ Opsi redeem tidak tersedia');
                return;
            }
            
            const userCoins = user.referral?.coins || 0;
            
            // Check if user has enough coins
            if (userCoins < requiredCoins) {
                await ctx.answerCbQuery(`❌ Koin tidak cukup! Butuh ${requiredCoins} koin.`);
                await ctx.reply(
                    `⚠️ 𝗞𝗢𝗜𝗡 𝗧𝗜𝗗𝗔𝗞 𝗖𝗨𝗞𝗨𝗣!\n\n` +
                    `🪙 Koin Anda: ${userCoins}\n` +
                    `🎯 Dibutuhkan: ${requiredCoins} Koin\n` +
                    `❌ Kurang: ${requiredCoins - userCoins} Koin\n\n` +
                    `Ajak lebih banyak teman menggunakan link referral Anda!`
                );
                return;
            }
            
            // Deduct coins
            user.referral.coins -= requiredCoins;
            
            // Calculate expiry
            const expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + days);
            
            // Upgrade user
            user.status = 'VIP';
            user.premiumExpiry = expiryDate;
            user.limits.dailyFix = 999999;
            user.limits.massSend = 5;
            
            await user.save();
            
            const successMessage = 
                `🎉 𝗥𝗘𝗗𝗘𝗠𝗣𝗧𝗜𝗢𝗡 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟!\n\n` +
                `📦 Paket: VIP ${days} Hari\n` +
                `🪙 Koin Digunakan: ${requiredCoins}\n` +
                `🪙 Sisa Koin: ${user.referral.coins}\n` +
                `📅 Expired: ${Formatter.formatDate(expiryDate)}\n` +
                `👑 Status: ${Formatter.getStatusBadge('VIP')}\n\n` +
                `Selamat menikmati fitur VIP QASHVRA!`;
            
            await ctx.reply(successMessage);
            await ctx.answerCbQuery('✅ Redeem berhasil!');
            
            Logger.success(`User ${user.userId} redeemed ${days} days VIP with ${requiredCoins} coins`, 'ReferralHandler');
            
        } catch (error) {
            Logger.error(`Redeem error: ${error.message}`, 'ReferralHandler', '39');
            await ctx.answerCbQuery('❌ Terjadi kesalahan');
        }
    }
}

module.exports = new ReferralHandler();
// END OF FILE - handlers/referralHandler.js