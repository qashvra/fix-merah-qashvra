// [QASHVRA BOT] - handlers/menuHandler.js - Menu Navigation Handler
const globalInstance = require('../global');
const UserModel = require('../models/userModel');
const StatisticsModel = require('../models/statisticsModel');
const Formatter = require('../utils/formatter');
const Logger = require('../utils/logger');
const fs = require('fs');
const path = require('path');

class MenuHandler {
    
    // ============ FIX MERAH MENU ============
    async handleFixMerahMenu(ctx) {
        try {
            const user = ctx.state.user;
            const permission = ctx.state.permission;
            
            // Check if can fix
            if (!permission.canFix) {
                await ctx.reply(
                    `⚠️ 𝗟𝗜𝗠𝗜𝗧 𝗛𝗔𝗥𝗜𝗔𝗡 𝗧𝗘𝗥𝗖𝗔𝗣𝗔𝗜\n\n` +
                    `Anda telah mencapai batas harian ${permission.dailyLimit}x Fix Merah.\n\n` +
                    `👑 Upgrade ke VIP/VVIP untuk unlimited fix!\n` +
                    `Klik menu 👑 VIP / VVIP untuk informasi lebih lanjut.`
                );
                return;
            }
            
            // Check SMTP for FREE users
            if (user.status === 'FREE' && !permission.hasSMTP) {
                await ctx.reply(
                    `⚠️ 𝗦𝗠𝗧𝗣 𝗕𝗘𝗟𝗨𝗠 𝗗𝗜𝗔𝗧𝗨𝗥\n\n` +
                    `Anda harus menambahkan SMTP Gmail terlebih dahulu.\n\n` +
                    `📧 Cara menambahkan SMTP:\n` +
                    `Kirimkan email dan App Password Gmail Anda dengan format:\n\n` +
                    `📧 email@gmail.com\n` +
                    `🔑 app-password-anda\n\n` +
                    `⚠️ Tutorial bikin App Password Gmail:\n` +
                    `https://support.google.com/accounts/answer/185833`
                );
                return;
            }
            
            const message = 
                `🛠️ 𝗠𝗘𝗡𝗨 𝗜𝗡𝗣𝗨𝗧 𝗙𝗜𝗫 𝗠𝗘𝗥𝗔𝗛\n\n` +
                `📌 𝗚𝘂𝗻𝗮𝗸𝗮𝗻 𝗳𝗶𝘁𝘂𝗿 𝗶𝗻𝗶 𝗷𝗶𝗸𝗮:\n` +
                `🔸 Nomor terkena login tidak tersedia\n` +
                `🔸 Nomer harus sudah terdaftar di WA\n` +
                `🔸 Login berubah menjadi SMS\n` +
                `🔸 Verifikasi gagal terus menerus\n\n` +
                `├ 👑 Status: ${Formatter.getStatusBadge(user.status)}\n` +
                `├ 📊 Limit Harian: ${permission.dailyLimit === Infinity ? '∞ Unlimited' : permission.dailyLimit + ' Kali'}\n` +
                `├ 📧 Sender Aktif: ${globalInstance.globalStats.activeSenders?.current || 0}/${globalInstance.globalStats.activeSenders?.max || 1984}\n` +
                `└ 📦 Slot Terpakai: ${user.limits.usedToday}/${permission.dailyLimit === Infinity ? '∞' : permission.dailyLimit} (Sisa: ${permission.dailyLimit === Infinity ? '∞' : permission.dailyLimit - user.limits.usedToday})\n\n` +
                `📥 Kirim nomor telepon (1 nomor per baris). Contoh:\n` +
                `+62812345678910`;
            
            // Try to send with photo
            const fixImage = './assets/fix_merah.jpg';
            if (fs.existsSync(path.resolve(fixImage))) {
                await ctx.replyWithPhoto(
                    { source: path.resolve(fixImage) },
                    { caption: message }
                );
            } else {
                await ctx.reply(message);
            }
            
            // Set session for phone input
            ctx.session = ctx.session || {};
            ctx.session.waitingForPhone = true;
            
        } catch (error) {
            Logger.error(`Fix Merah menu error: ${error.message}`, 'MenuHandler', '46');
            await ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
        }
    }
    
    // ============ VIP/VVIP MENU ============
    async handleVipMenu(ctx) {
        try {
            const user = ctx.state.user;
            const isPremium = user.status === 'VIP' || user.status === 'VVIP';
            const expiryDate = user.premiumExpiry ? Formatter.formatDate(user.premiumExpiry) : 'N/A';
            
            let message = 
                `👑 𝗔𝗞𝗦𝗘𝗦 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 (𝗩𝗜𝗣 & 𝗩𝗩𝗜𝗣)\n` +
                `├ 👑 Status: ${Formatter.getStatusBadge(user.status)}\n`;
            
            if (isPremium) {
                message += `├ 📅 Expired: ${expiryDate}\n` +
                           `└ ✅ Status: Aktif\n\n`;
            } else {
                message += `└ ❌ Belum ada langganan aktif\n\n`;
            }
            
            message += 
                `✨ 𝗠𝗔𝗡𝗙𝗔𝗔𝗧 𝗩𝗜𝗣 𝗣𝗥𝗘𝗠𝗜𝗨𝗠:\n` +
                `├ 📊 Limit Harian: ∞ Unlimited\n` +
                `├ 📦 Kirim Massal: 5 Nomor Sekaligus\n` +
                `└ 🚀 Masuk antrean prioritas\n\n` +
                `🌟 𝗠𝗔𝗡𝗙𝗔𝗔𝗧 𝗩𝗩𝗜𝗣 (𝗦𝗨𝗣𝗘𝗥 𝗣𝗥𝗢):\n` +
                `├ 📊 Limit Harian: ∞ Unlimited\n` +
                `├ 📦 Kirim Massal: 25 Nomor Sekaligus\n` +
                `└ ⚡ Bypass! Antrean paling diutamakan`;
            
            // VIP pricing buttons
            const inlineKeyboard = {
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '⭐ VIP 1 Hari - Rp 1.007', callback_data: 'vip_VIP_1' },
                            { text: '⭐ VIP 7 Hari - Rp 5.007', callback_data: 'vip_VIP_7' }
                        ],
                        [
                            { text: '⭐ VIP 30 Hari - Rp 15.007', callback_data: 'vip_VIP_30' },
                            { text: '⭐ VIP 90 Hari - Rp 35.007', callback_data: 'vip_VIP_90' }
                        ],
                        [
                            { text: '💎 VVIP 1 Hari - Rp 2.007', callback_data: 'vip_VVIP_1' },
                            { text: '💎 VVIP 7 Hari - Rp 10.007', callback_data: 'vip_VVIP_7' }
                        ],
                        [
                            { text: '💎 VVIP 30 Hari - Rp 25.007', callback_data: 'vip_VVIP_30' },
                            { text: '💎 VVIP 90 Hari - Rp 50.007', callback_data: 'vip_VVIP_90' }
                        ],
                        [
                            { text: '🔙 Kembali', callback_data: 'menu_main' }
                        ]
                    ]
                }
            };
            
            // Try to send with photo
            const vipImage = './assets/vip_premium.jpg';
            if (fs.existsSync(path.resolve(vipImage))) {
                await ctx.replyWithPhoto(
                    { source: path.resolve(vipImage) },
                    { caption: message, ...inlineKeyboard }
                );
            } else {
                await ctx.reply(message, inlineKeyboard);
            }
            
        } catch (error) {
            Logger.error(`VIP menu error: ${error.message}`, 'MenuHandler', '92');
            await ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
        }
    }
    
    // ============ REFERRAL MENU ============
    async handleReferralMenu(ctx) {
        try {
            const user = ctx.state.user;
            const botUsername = globalInstance.botUsername;
            const referralLink = `https://t.me/${botUsername}?start=${user.userId}`;
            
            const message = 
                `🧧 𝗠𝗘𝗡𝗨 𝗥𝗘𝗙𝗘𝗥𝗥𝗔𝗟\n\n` +
                `📌 Cara Kerja:\n\n` +
                `1. Share link referral ke teman\n` +
                `2. Tempel link referral ke bio Anda\n` +
                `3. Teman klik link dan gunakan bot\n` +
                `4. Dapat +${globalInstance.config.referral.coinsPerReferral || 5} Koin per user valid\n` +
                `5. Kumpulkan koin untuk beli VIP Gratis!\n\n` +
                `🔗 𝗟𝗶𝗻𝗸 𝗥𝗲𝗳𝗲𝗿𝗿𝗮𝗹 𝗔𝗻𝗱𝗮:\n` +
                `${referralLink}\n\n` +
                `📊 Statistik User:\n` +
                `├ 👥 Total Diundang: ${user.referral?.totalInvited || 0} Orang\n` +
                `└ 🪙 Total Koin: ${user.referral?.coins || 0}/${globalInstance.config.referral.minimumRedeemCoins || 100} Koin`;
            
            const redeemOptions = globalInstance.config.referral.redeemDays || {};
            const inlineKeyboard = {
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: `🎁 Redeem 1 Hari (${redeemOptions['1'] || 100} Koin)`, callback_data: 'redeem_1' },
                            { text: `🎁 Redeem 3 Hari (${redeemOptions['3'] || 250} Koin)`, callback_data: 'redeem_3' }
                        ],
                        [
                            { text: `🎁 Redeem 7 Hari (${redeemOptions['7'] || 500} Koin)`, callback_data: 'redeem_7' }
                        ],
                        [
                            { text: '📤 Share Link', switch_inline_query: referralLink }
                        ],
                        [
                            { text: '🔙 Kembali', callback_data: 'menu_main' }
                        ]
                    ]
                }
            };
            
            const refImage = './assets/referral.jpg';
            if (fs.existsSync(path.resolve(refImage))) {
                await ctx.replyWithPhoto(
                    { source: path.resolve(refImage) },
                    { caption: message, ...inlineKeyboard }
                );
            } else {
                await ctx.reply(message, inlineKeyboard);
            }
            
        } catch (error) {
            Logger.error(`Referral menu error: ${error.message}`, 'MenuHandler', '124');
            await ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
        }
    }
    
    // ============ HISTORY MENU ============
    async handleHistoryMenu(ctx) {
        try {
            const user = ctx.state.user;
            const history = user.fixHistory || [];
            const last10 = history.slice(-10).reverse();
            
            let message = `📜 𝗥𝗜𝗪𝗔𝗬𝗔𝗧 𝗙𝗜𝗫 𝗠𝗘𝗥𝗔𝗛 (𝟭𝟬 𝗧𝗘𝗥𝗔𝗞𝗛𝗜𝗥)\n\n`;
            
            if (last10.length === 0) {
                message += `Belum ada riwayat.\n\nGunakan fitur Fix Merah terlebih dahulu!`;
            } else {
                last10.forEach((item, index) => {
                    const statusEmoji = item.status === 'success' ? '✅' : '❌';
                    const date = Formatter.formatDate(item.timestamp);
                    message += `${index + 1}. ${statusEmoji} ${Formatter.maskPhoneNumber(item.phoneNumber)}\n`;
                    message += `   ├ Status: ${item.status === 'success' ? 'Sukses' : 'Gagal'}\n`;
                    message += `   └ 📅 ${date}\n\n`;
                });
            }
            
            await ctx.reply(message);
            
        } catch (error) {
            Logger.error(`History menu error: ${error.message}`, 'MenuHandler', '152');
            await ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
        }
    }
    
    // ============ LEADERBOARD MENU ============
    async handleLeaderboardMenu(ctx) {
        try {
            const leaderboard = globalInstance.config.leaderboard;
            
            let message = `🏆 𝗧𝗢𝗣 𝟭𝟬 𝗟𝗘𝗔𝗗𝗘𝗥𝗕𝗢𝗔𝗥𝗗\n\n`;
            message += `Top 10 user FixMerah terbanyak:\n\n`;
            
            const medals = ['🥇', '🥈', '🥉'];
            leaderboard.topUsers.forEach((user, index) => {
                const medal = medals[index] || `${index + 1}.`;
                message += `${medal} ${user.name}\n`;
                message += `🔍 ${Formatter.formatNumber(user.fix)}x FixMerah\n\n`;
            });
            
            message += `\n━━━━━━━━━━━━━━━━\n\n`;
            message += `🏆 𝗧𝗢𝗣 𝟭𝟬 𝗡𝗘𝗚𝗔𝗥𝗔\n\n`;
            message += `Top 10 negara terbanyak:\n\n`;
            
            leaderboard.topCountries.forEach((country, index) => {
                const medal = medals[index] || `${index + 1}.`;
                message += `${medal} ${country.flag} ${country.name}\n`;
                message += `🔍 ${Formatter.formatNumber(country.fix)}x FixMerah\n\n`;
            });
            
            await ctx.reply(message);
            
        } catch (error) {
            Logger.error(`Leaderboard error: ${error.message}`, 'MenuHandler', '178');
            await ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
        }
    }
    
    // ============ TESTIMONI MENU ============
    async handleTestimoniMenu(ctx) {
        try {
            const message = 
                `💬 𝗧𝗘𝗦𝗧𝗜𝗠𝗢𝗡𝗜 𝗙𝗜𝗫 𝗠𝗘𝗥𝗔𝗛\n\n` +
                `Testimoni akan otomatis dikirim ke channel ketika Fix Merah Anda berhasil diproses oleh WhatsApp.\n\n` +
                `🔴 Format Testimoni:\n` +
                `🆔 ID Banding: QASHVRA-xxxx\n` +
                `📱 Nomor: +62xxxx\n` +
                `📌 Status: ✅ SUKSES\n\n` +
                `🤖 Powered by QASHVRA Fix Merah Bot`;
            
            await ctx.reply(message);
            
        } catch (error) {
            Logger.error(`Testimoni error: ${error.message}`, 'MenuHandler', '195');
            await ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
        }
    }
}

module.exports = new MenuHandler();
// END OF FILE - handlers/menuHandler.js