// [QASHVRA BOT] - handlers/premiumHandler.js - Premium Feature Management
const UserModel = require('../models/userModel');
const globalInstance = require('../global');
const Formatter = require('../utils/formatter');
const notificationHandler = require('./notificationHandler');
const Logger = require('../utils/logger');

class PremiumHandler {
    
    // Check if user has premium access
    static async checkPremiumAccess(userId) {
        try {
            const user = await UserModel.findOne({ userId });
            if (!user) return { hasAccess: false, reason: 'User not found' };
            
            // Owner always has access
            if (user.status === 'OWNER' || userId === globalInstance.ownerId) {
                return { hasAccess: true, type: 'OWNER', unlimited: true };
            }
            
            // Check premium status
            if (user.status === 'VIP' || user.status === 'VVIP') {
                const isActive = user.isPremiumActive();
                
                if (!isActive) {
                    // Downgrade user
                    user.status = 'FREE';
                    user.limits.dailyFix = 2;
                    user.limits.massSend = 1;
                    user.premiumExpiry = null;
                    user.smtp.type = 'none';
                    await user.save();
                    
                    Logger.info(`Premium expired for user ${userId}`, 'PremiumHandler');
                    return { hasAccess: false, reason: 'Premium expired', type: 'FREE' };
                }
                
                return {
                    hasAccess: true,
                    type: user.status,
                    expiry: user.premiumExpiry,
                    massSendLimit: user.status === 'VVIP' ? 25 : 5,
                    unlimited: true
                };
            }
            
            return { hasAccess: false, reason: 'Not premium', type: 'FREE' };
            
        } catch (error) {
            Logger.error(`Check premium error: ${error.message}`, 'PremiumHandler');
            return { hasAccess: false, reason: 'Error checking premium' };
        }
    }
    
    // Grant premium to user
    static async grantPremium(userId, type, days) {
        try {
            if (!['VIP', 'VVIP'].includes(type)) {
                return { success: false, error: 'Invalid premium type' };
            }
            
            const user = await UserModel.findOne({ userId });
            if (!user) {
                return { success: false, error: 'User not found' };
            }
            
            // Calculate expiry
            const expiryDate = user.premiumExpiry && user.premiumExpiry > new Date()
                ? new Date(user.premiumExpiry.getTime() + days * 24 * 60 * 60 * 1000)
                : new Date(Date.now() + days * 24 * 60 * 60 * 1000);
            
            // Update user
            user.status = type;
            user.premiumExpiry = expiryDate;
            user.limits.dailyFix = 999999;
            user.limits.massSend = type === 'VVIP' ? 25 : 5;
            user.smtp.type = 'premium';
            
            await user.save();
            
            // Notify user
            await notificationHandler.notifyNewPremium(userId, type, days, expiryDate);
            
            Logger.success(`Premium granted: User ${userId} -> ${type} for ${days} days`, 'PremiumHandler');
            
            return {
                success: true,
                type,
                days,
                expiry: expiryDate,
                message: `${type} access granted for ${days} days`
            };
            
        } catch (error) {
            Logger.error(`Grant premium error: ${error.message}`, 'PremiumHandler');
            return { success: false, error: error.message };
        }
    }
    
    // Revoke premium from user
    static async revokePremium(userId) {
        try {
            const user = await UserModel.findOneAndUpdate(
                { userId, status: { $in: ['VIP', 'VVIP'] } },
                {
                    status: 'FREE',
                    premiumExpiry: null,
                    'limits.dailyFix': 2,
                    'limits.massSend': 1,
                    'smtp.type': 'none'
                },
                { new: true }
            );
            
            if (user) {
                Logger.info(`Premium revoked for user ${userId}`, 'PremiumHandler');
                return { success: true, message: 'Premium access revoked' };
            }
            
            return { success: false, error: 'User not found or not premium' };
            
        } catch (error) {
            Logger.error(`Revoke premium error: ${error.message}`, 'PremiumHandler');
            return { success: false, error: error.message };
        }
    }
    
    // Extend premium duration
    static async extendPremium(userId, additionalDays) {
        try {
            const user = await UserModel.findOne({ userId });
            if (!user) {
                return { success: false, error: 'User not found' };
            }
            
            if (user.status !== 'VIP' && user.status !== 'VVIP') {
                return { success: false, error: 'User is not premium' };
            }
            
            const currentExpiry = user.premiumExpiry || new Date();
            const newExpiry = new Date(currentExpiry.getTime() + additionalDays * 24 * 60 * 60 * 1000);
            
            user.premiumExpiry = newExpiry;
            await user.save();
            
            Logger.info(`Premium extended for user ${userId} by ${additionalDays} days`, 'PremiumHandler');
            
            return {
                success: true,
                newExpiry,
                message: `Premium extended by ${additionalDays} days. New expiry: ${Formatter.formatDate(newExpiry)}`
            };
            
        } catch (error) {
            Logger.error(`Extend premium error: ${error.message}`, 'PremiumHandler');
            return { success: false, error: error.message };
        }
    }
    
    // Get premium stats
    static async getPremiumStats() {
        try {
            const totalPremium = await UserModel.countDocuments({
                status: { $in: ['VIP', 'VVIP'] },
                premiumExpiry: { $gt: new Date() }
            });
            
            const vipCount = await UserModel.countDocuments({
                status: 'VIP',
                premiumExpiry: { $gt: new Date() }
            });
            
            const vvipCount = await UserModel.countDocuments({
                status: 'VVIP',
                premiumExpiry: { $gt: new Date() }
            });
            
            const expiringSoon = await UserModel.countDocuments({
                status: { $in: ['VIP', 'VVIP'] },
                premiumExpiry: {
                    $gt: new Date(),
                    $lt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000)
                }
            });
            
            return {
                totalPremium,
                vipCount,
                vvipCount,
                expiringSoon
            };
            
        } catch (error) {
            Logger.error(`Get premium stats error: ${error.message}`, 'PremiumHandler');
            return { totalPremium: 0, vipCount: 0, vvipCount: 0, expiringSoon: 0 };
        }
    }
}

module.exports = PremiumHandler;
// END OF FILE - handlers/premiumHandler.js