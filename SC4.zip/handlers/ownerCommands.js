// [QASHVRA BOT] - handlers/ownerCommands.js - Owner Text Commands Handler
const globalInstance = require('../global');
const UserModel = require('../models/userModel');
const userService = require('../services/userService');
const smtpService = require('../services/smtpService');
const statisticsService = require('../services/statisticsService');
const paymentService = require('../services/paymentService');
const Formatter = require('../utils/formatter');
const Logger = require('../utils/logger');

class OwnerCommands {
    
    async handleOwnerCommand(ctx) {
        if (!ctx.state.isOwner) return;
        
        const text = ctx.message?.text || '';
        const args = text.split(' ');

        try {
            switch (true) {
                // /addvip userId days
                case text.startsWith('/addvip'):
                    await this.handleAddVIP(ctx, args, 'VIP');
                    break;

                // /addvvip userId days
                case text.startsWith('/addvvip'):
                    await this.handleAddVIP(ctx, args, 'VVIP');
                    break;

                // /ban userId reason
                case text.startsWith('/ban'):
                    await this.handleBanUser(ctx, args);
                    break;

                // /unban userId
                case text.startsWith('/unban'):
                    await this.handleUnbanUser(ctx, args);
                    break;

                // /userinfo userId
                case text.startsWith('/userinfo'):
                    await this.handleUserInfo(ctx, args);
                    break;

                // /broadcast message
                case text.startsWith('/broadcast'):
                    await this.handleBroadcast(ctx, text);
                    break;

                // /stats
                case text === '/stats':
                    await this.handleStats(ctx);
                    break;

                // /resetdaily
                case text === '/resetdaily':
                    await this.handleResetDaily(ctx);
                    break;

                // /expiredcheck
                case text === '/expiredcheck':
                    await this.handleExpiredCheck(ctx);
                    break;

                // /cleanpayments
                case text === '/cleanpayments':
                    await this.handleCleanPayments(ctx);
                    break;

                // /restartbot
                case text === '/restartbot':
                    await this.handleRestart(ctx);
                    break;

                // /addcoins userId amount
                case text.startsWith('/addcoins'):
                    await this.handleAddCoins(ctx, args);
                    break;
            }
        } catch (error) {
            Logger.error(`Owner command error: ${error.message}`, 'OwnerCommands');
            await ctx.reply(`❌ Error: ${error.message}`);
        }
    }

    async handleAddVIP(ctx, args, type) {
        if (args.length < 3) {
            await ctx.reply(`Format: /add${type.toLowerCase()} [userId] [days]\nContoh: /add${type.toLowerCase()} 123456789 30`);
            return;
        }

        const userId = parseInt(args[1]);
        const days = parseInt(args[2]);

        if (isNaN(userId) || isNaN(days)) {
            await ctx.reply('❌ User ID dan Days harus berupa angka!');
            return;
        }

        const result = await userService.updateUserStatus(userId, type, days);

        if (result) {
            await ctx.reply(
                `✅ 𝗨𝗦𝗘𝗥 𝗨𝗣𝗚𝗥𝗔𝗗𝗘𝗗!\n\n` +
                `👤 User: ${userId}\n` +
                `👑 Status: ${type}\n` +
                `📅 Durasi: ${days} Hari\n` +
                `📆 Expired: ${Formatter.formatDate(result.premiumExpiry)}`
            );

            // Notify user
            try {
                await ctx.telegram.sendMessage(
                    userId,
                    `🎉 𝗦𝗘𝗟𝗔𝗠𝗔𝗧!\n\n` +
                    `Anda telah diupgrade menjadi ${type} User!\n` +
                    `📅 Durasi: ${days} Hari\n` +
                    `📆 Expired: ${Formatter.formatDate(result.premiumExpiry)}\n\n` +
                    `Nikmati semua fitur premium QASHVRA!`
                );
            } catch (e) {
                Logger.warn(`Failed to notify user ${userId}`, 'OwnerCommands');
            }
        } else {
            await ctx.reply('❌ Gagal upgrade user. User tidak ditemukan.');
        }
    }

    async handleBanUser(ctx, args) {
        if (args.length < 2) {
            await ctx.reply('Format: /ban [userId] [alasan]\nContoh: /ban 123456789 Spam');
            return;
        }

        const userId = parseInt(args[1]);
        const reason = args.slice(2).join(' ') || 'Pelanggaran aturan';

        if (isNaN(userId)) {
            await ctx.reply('❌ User ID harus berupa angka!');
            return;
        }

        const result = await userService.banUser(userId, reason);

        if (result) {
            await ctx.reply(
                `🚫 𝗨𝗦𝗘𝗥 𝗕𝗔𝗡𝗡𝗘𝗗!\n\n` +
                `👤 User: ${userId}\n` +
                `📋 Alasan: ${reason}`
            );

            // Notify user
            try {
                await ctx.telegram.sendMessage(
                    userId,
                    `🚫 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜𝗕𝗟𝗢𝗞𝗜𝗥\n\n` +
                    `Anda telah diblokir dari bot.\n` +
                    `📋 Alasan: ${reason}\n\n` +
                    `Hubungi @${globalInstance.ownerUsername} untuk banding.`
                );
            } catch (e) {}
        } else {
            await ctx.reply('❌ User tidak ditemukan.');
        }
    }

    async handleUnbanUser(ctx, args) {
        if (args.length < 2) {
            await ctx.reply('Format: /unban [userId]');
            return;
        }

        const userId = parseInt(args[1]);

        if (isNaN(userId)) {
            await ctx.reply('❌ User ID harus berupa angka!');
            return;
        }

        const result = await userService.unbanUser(userId);

        if (result) {
            await ctx.reply(`✅ User ${userId} telah di-unban!`);

            try {
                await ctx.telegram.sendMessage(
                    userId,
                    `✅ 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜𝗣𝗨𝗟𝗜𝗛𝗞𝗔𝗡\n\n` +
                    `Akun Anda telah dipulihkan. Silakan gunakan bot kembali.`
                );
            } catch (e) {}
        } else {
            await ctx.reply('❌ User tidak ditemukan.');
        }
    }

    async handleUserInfo(ctx, args) {
        if (args.length < 2) {
            await ctx.reply('Format: /userinfo [userId]');
            return;
        }

        const userId = parseInt(args[1]);

        if (isNaN(userId)) {
            await ctx.reply('❌ User ID harus berupa angka!');
            return;
        }

        const user = await UserModel.findOne({ userId });

        if (!user) {
            await ctx.reply('❌ User tidak ditemukan.');
            return;
        }

        const message = 
            `👤 𝗨𝗦𝗘𝗥 𝗜𝗡𝗙𝗢\n\n` +
            `├ ID: ${user.userId}\n` +
            `├ Nama: ${user.firstName} ${user.lastName}\n` +
            `├ Username: @${user.username}\n` +
            `├ Status: ${user.status}\n` +
            `├ Verified: ${user.isVerified ? '✅' : '❌'}\n` +
            `├ Banned: ${user.isBanned ? '🚫' : '✅'}\n` +
            `├ Premium: ${user.premiumExpiry ? Formatter.formatDate(user.premiumExpiry) : 'N/A'}\n` +
            `├ Total Fix: ${Formatter.formatNumber(user.statistics.totalFix)}\n` +
            `├ Berhasil: ${Formatter.formatNumber(user.statistics.berhasil)}\n` +
            `├ Win Rate: ${Formatter.formatWinRate(user.statistics.berhasil, user.statistics.totalFix)}\n` +
            `├ Koin: ${user.referral?.coins || 0}\n` +
            `├ Invited: ${user.referral?.totalInvited || 0}\n` +
            `├ SMTP: ${user.smtp?.email || 'None'}\n` +
            `├ Registered: ${Formatter.formatDate(user.createdAt)}\n` +
            `└ Last Active: ${Formatter.formatDate(user.lastActivity)}`;

        await ctx.reply(message);
    }

    async handleBroadcast(ctx, text) {
        const message = text.replace('/broadcast', '').trim();

        if (!message) {
            await ctx.reply('Format: /broadcast [pesan]\nContoh: /broadcast 🔔 Update tersedia!');
            return;
        }

        await ctx.reply(`⏳ Memulai broadcast ke semua user...`);

        const allUsers = await UserModel.find({ isBanned: false }).select('userId');
        let sent = 0;
        let failed = 0;

        for (const user of allUsers) {
            try {
                await ctx.telegram.sendMessage(user.userId, `📢 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧 𝗤𝗔𝗦𝗛𝗩𝗥𝗔\n\n${message}`);
                sent++;
            } catch (e) {
                failed++;
            }
            // Delay to avoid flood
            await new Promise(resolve => setTimeout(resolve, 50));
        }

        await ctx.reply(
            `✅ 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧 𝗦𝗘𝗟𝗘𝗦𝗔𝗜!\n\n` +
            `├ Terkirim: ${sent}\n` +
            `└ Gagal: ${failed}`
        );
    }

    async handleStats(ctx) {
        const userStats = await userService.getUserStats();
        const paymentStats = await paymentService.getPaymentStats();
        const globalStats = await statisticsService.getGlobalStats();
        const smtpStats = smtpService.getSMTPStats();

        const message = 
            `📊 𝗕𝗢𝗧 𝗦𝗧𝗔𝗧𝗜𝗦𝗧𝗜𝗖𝗦\n\n` +
            `👥 𝗨𝘀𝗲𝗿𝘀: ${Formatter.formatNumber(userStats.total)}\n` +
            `├ Free: ${Formatter.formatNumber(userStats.free)}\n` +
            `├ VIP: ${Formatter.formatNumber(userStats.vip)}\n` +
            `├ VVIP: ${Formatter.formatNumber(userStats.vvip)}\n` +
            `└ Banned: ${Formatter.formatNumber(userStats.banned)}\n\n` +
            `🛠️ 𝗙𝗶𝘅: ${Formatter.formatNumber(globalStats.totalFix)}\n` +
            `├ Success: ${Formatter.formatNumber(globalStats.totalSuccess)}\n` +
            `└ Failed: ${Formatter.formatNumber(globalStats.totalFailed)}\n\n` +
            `💰 𝗥𝗲𝘃𝗲𝗻𝘂𝗲: ${Formatter.formatCurrency(paymentStats.totalRevenue)}\n` +
            `├ Paid: ${paymentStats.paid}\n` +
            `└ Pending: ${paymentStats.pending}\n\n` +
            `📧 𝗦𝗠𝗧𝗣: ${smtpStats.total}\n` +
            `├ Active: ${smtpStats.active}\n` +
            `└ Failed: ${smtpStats.failed}\n\n` +
            `⏰ Runtime: ${globalInstance.getRuntime()}`;

        await ctx.reply(message);
    }

    async handleResetDaily(ctx) {
        await UserModel.updateMany({}, {
            'limits.usedToday': 0,
            'limits.lastReset': new Date()
        });

        await ctx.reply('✅ Daily limits reset untuk semua user!');
    }

    async handleExpiredCheck(ctx) {
        const count = await userService.checkAndExpirePremiums();
        await ctx.reply(`✅ Expired check selesai! ${count} user di-downgrade ke FREE.`);
    }

    async handleCleanPayments(ctx) {
        const PaymentModel = require('../models/paymentModel');
        const cleaned = await PaymentModel.cleanExpiredPayments();
        await ctx.reply(`✅ ${cleaned} expired payments dibersihkan!`);
    }

    async handleRestart(ctx) {
        await ctx.reply('🔄 Restarting bot...');
        process.exit(0);
    }

    async handleAddCoins(ctx, args) {
        if (args.length < 3) {
            await ctx.reply('Format: /addcoins [userId] [amount]');
            return;
        }

        const userId = parseInt(args[1]);
        const amount = parseInt(args[2]);

        if (isNaN(userId) || isNaN(amount)) {
            await ctx.reply('❌ User ID dan Amount harus angka!');
            return;
        }

        const user = await UserModel.findOneAndUpdate(
            { userId },
            { $inc: { 'referral.coins': amount } },
            { new: true }
        );

        if (user) {
            await ctx.reply(`✅ ${amount} Koin ditambahkan ke User ${userId}!\nTotal: ${user.referral.coins} Koin`);
        } else {
            await ctx.reply('❌ User tidak ditemukan.');
        }
    }
}

module.exports = new OwnerCommands();
// END OF FILE - handlers/ownerCommands.js