// [QASHVRA BOT] - handlers/fixMerahHandler.js - Fix Merah Phone Processing
const UserModel = require('../models/userModel');
const StatisticsModel = require('../models/statisticsModel');
const globalInstance = require('../global');
const Formatter = require('../utils/formatter');
const Logger = require('../utils/logger');
const unicodeLoader = require('../utils/unicodeLoader');
const smtpService = require('../services/smtpService');
const statisticsService = require('../services/statisticsService');

class FixMerahHandler {
    
    async handlePhoneInput(ctx) {
        // Only process if waiting for phone input
        if (!ctx.session?.waitingForPhone) return;
        
        const user = ctx.state.user;
        const permission = ctx.state.permission;
        const text = ctx.message?.text;
        
        // Check if user cancelled
        if (text === '❌ Cancel' || text === '/cancel') {
            ctx.session.waitingForPhone = false;
            await ctx.reply('✅ Operasi Fix Merah dibatalkan.');
            return;
        }
        
        // Parse phone numbers
        const phoneNumbers = this.parsePhoneNumbers(text);
        
        if (phoneNumbers.length === 0) {
            await ctx.reply(
                `⚠️ 𝗙𝗼𝗿𝗺𝗮𝘁 𝗡𝗼𝗺𝗼𝗿 𝗧𝗶𝗱𝗮𝗸 𝗩𝗮𝗹𝗶𝗱!\n\n` +
                `Kirim nomor telepon dengan format yang benar.\n\n` +
                `Contoh:\n` +
                `+62812345678910\n\n` +
                `Atau kirim ❌ Cancel untuk membatalkan.`
            );
            return;
        }
        
        // Check mass send limit
        const massLimit = permission.massSendLimit || 1;
        if (phoneNumbers.length > massLimit) {
            await ctx.reply(
                `⚠️ 𝗕𝗮𝘁𝗮𝘀 𝗠𝗮𝘀𝘀𝗮𝗹!\n\n` +
                `Status ${user.status} hanya bisa mengirim maksimal ${massLimit} nomor sekaligus.\n` +
                `Anda mengirim ${phoneNumbers.length} nomor.\n\n` +
                `👑 Upgrade ke VIP/VVIP untuk kapasitas lebih besar!`
            );
            return;
        }
        
        // Check daily limit
        if (!permission.canFix) {
            await ctx.reply('⚠️ Batas harian Anda telah tercapai. Upgrade ke VIP/VVIP!');
            return;
        }
        
        // Start processing
        const loadingMsg = await ctx.reply(`⠋ ⏳ 𝗠𝗲𝗺𝗽𝗿𝗼𝘀𝗲𝘀 ${phoneNumbers.length} 𝗻𝗼𝗺𝗼𝗿...`);
        
        try {
            let successCount = 0;
            let failedCount = 0;
            const results = [];
            
            for (const phone of phoneNumbers) {
                try {
                    // Send banding email via SMTP
                    const result = await smtpService.sendBandingEmail(user, phone);
                    
                    results.push({
                        phone,
                        status: result.success ? 'success' : 'failed',
                        details: result
                    });
                    
                    if (result.success) {
                        successCount++;
                    } else {
                        failedCount++;
                    }
                    
                    // Add to user history
                    user.fixHistory.push({
                        phoneNumber: phone,
                        status: result.success ? 'success' : 'failed',
                        emailTemplate: 'banding',
                        smtpUsed: result.smtpUsed || 'unknown',
                        timestamp: new Date()
                    });
                    
                } catch (error) {
                    failedCount++;
                    results.push({
                        phone,
                        status: 'failed',
                        details: { error: error.message }
                    });
                    
                    user.fixHistory.push({
                        phoneNumber: phone,
                        status: 'failed',
                        emailTemplate: 'banding',
                        smtpUsed: 'error',
                        timestamp: new Date()
                    });
                }
            }
            
            // Update user statistics
            user.statistics.totalFix += phoneNumbers.length;
            user.statistics.berhasil += successCount;
            user.statistics.gagal += failedCount;
            user.limits.usedToday += phoneNumbers.length;
            await user.save();
            
            // Update global statistics
            await statisticsService.updateGlobalStats(successCount, failedCount);
            
            // Send results
            let resultMessage = 
                `🔴 𝗛𝗔𝗦𝗜𝗟 𝗙𝗜𝗫 𝗠𝗘𝗥𝗔𝗛\n\n` +
                `📊 Total: ${phoneNumbers.length} Nomor\n` +
                `✅ Berhasil: ${successCount}\n` +
                `❌ Gagal: ${failedCount}\n\n`;
            
            results.forEach((r, i) => {
                const emoji = r.status === 'success' ? '✅' : '❌';
                resultMessage += `${i + 1}. ${emoji} ${Formatter.maskPhoneNumber(r.phone)}\n`;
            });
            
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                null,
                resultMessage
            );
            
            // If any success, send testimoni notification
            if (successCount > 0) {
                const successPhones = results.filter(r => r.status === 'success');
                for (const s of successPhones) {
                    await this.sendTestimoni(ctx, s.phone);
                }
            }
            
            // Reset waiting state
            ctx.session.waitingForPhone = false;
            
        } catch (error) {
            Logger.error(`Fix Merah processing error: ${error.message}`, 'FixMerahHandler', '99');
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                null,
                `❌ 𝗚𝗔𝗚𝗔𝗟 𝗠𝗘𝗠𝗣𝗥𝗢𝗦𝗘𝗦!\n\nError: ${error.message}`
            );
        }
    }
    
    parsePhoneNumbers(text) {
        if (!text) return [];
        
        // Split by newline or comma
        const lines = text.split(/[\n,]+/);
        const phones = [];
        
        const phoneRegex = /^\+?[0-9]{7,15}$/;
        
        for (const line of lines) {
            const cleaned = line.trim().replace(/[^0-9+]/g, '');
            if (phoneRegex.test(cleaned)) {
                phones.push(cleaned);
            }
        }
        
        return phones;
    }
    
    async sendTestimoni(ctx, phone) {
        try {
            const orderId = Formatter.generateOrderId('FIX', ctx.from.id, 1);
            
            const message = 
                `🔴 𝗣𝗥𝗢𝗦𝗘𝗦 𝗙𝗜𝗫 𝗠𝗘𝗥𝗔𝗛 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 🔴\n\n` +
                `🆔 ID Banding: ${orderId}\n` +
                `📱 Nomor: ${Formatter.maskPhoneNumber(phone)}\n` +
                `📌 Status: ✅ SUKSES\n\n` +
                `🤖 Powered by QASHVRA Fix Merah Bot`;
            
            // Send to testimoni channel (configured by owner)
            // const testimoniChannel = globalInstance.config.verification.requiredChannels[0]?.id;
            // if (testimoniChannel) {
            //     await ctx.telegram.sendMessage(testimoniChannel, message);
            // }
            
            // Also send to user
            await ctx.reply(message);
            
        } catch (error) {
            Logger.warn(`Failed to send testimoni: ${error.message}`, 'FixMerahHandler');
        }
    }
}

module.exports = new FixMerahHandler();
// END OF FILE - handlers/fixMerahHandler.js