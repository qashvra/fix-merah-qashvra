// [QASHVRA BOT] - handlers/errorHandler.js - Bot Error Handler with User Feedback
const globalInstance = require('../global');
const Logger = require('../utils/logger');
const ErrorHandler = require('../utils/errorHandler');

class BotErrorHandler {
    
    static async handleBotError(error, ctx) {
        // Log error
        Logger.error(
            `Bot Error: ${error.message}`,
            'BotErrorHandler',
            error.stack?.split('\n')[1]?.trim() || ''
        );

        // Determine error type and response
        let userMessage = '❌ Terjadi kesalahan. Silakan coba lagi.';
        let notifyOwner = false;

        // Telegram API errors
        if (error.code === 403) {
            // Bot blocked by user
            Logger.info(`User blocked bot: ${ctx?.from?.id}`, 'BotErrorHandler');
            return; // Don't reply
        }
        
        if (error.code === 400) {
            if (error.description?.includes('message is not modified')) {
                return; // Ignore not modified errors
            }
            userMessage = '⚠️ Permintaan tidak valid. Silakan coba lagi.';
        }
        
        if (error.code === 429) {
            // Rate limited
            const retryAfter = error.parameters?.retry_after || 30;
            Logger.warn(`Rate limited. Retry after ${retryAfter}s`, 'BotErrorHandler');
            userMessage = `⏳ Terlalu banyak permintaan. Silakan tunggu ${retryAfter} detik.`;
            
            await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
        }

        // Database errors
        if (error.name === 'MongoError' || error.name === 'MongooseError') {
            userMessage = '🗄️ Database error. Silakan coba lagi nanti.';
            notifyOwner = true;
        }

        // Network errors
        if (error.code === 'ECONNREFUSED' || error.code === 'ETIMEDOUT') {
            userMessage = '🌐 Koneksi bermasalah. Silakan coba lagi.';
            notifyOwner = true;
        }

        // Payment errors
        if (error.message?.includes('payment') || error.message?.includes('Payment')) {
            userMessage = '💳 Pembayaran gagal diproses. Silakan coba lagi.';
        }

        // SMTP errors
        if (error.message?.includes('SMTP') || error.message?.includes('smtp')) {
            userMessage = '📧 Gagal mengirim email. SMTP mungkin bermasalah.';
        }

        // Notify owner for critical errors
        if (notifyOwner) {
            try {
                await ctx?.telegram?.sendMessage(
                    globalInstance.ownerId,
                    `🚨 𝗖𝗥𝗜𝗧𝗜𝗖𝗔𝗟 𝗘𝗥𝗥𝗢𝗥\n\n` +
                    `❌ Error: ${error.message}\n` +
                    `📍 Code: ${error.code || 'N/A'}\n` +
                    `👤 User: ${ctx?.from?.id || 'Unknown'}\n` +
                    `🕐 Time: ${new Date().toISOString()}`
                );
            } catch (e) {}
        }

        // Reply to user
        if (ctx && ctx.chat) {
            try {
                await ctx.reply(userMessage).catch(() => {});
            } catch (e) {
                Logger.error(`Failed to send error message to user: ${e.message}`, 'BotErrorHandler');
            }
        }
    }

    static setupGlobalHandlers(bot) {
        // Handle uncaught errors
        bot.catch(async (err, ctx) => {
            await BotErrorHandler.handleBotError(err, ctx);
        });

        // Handle process errors
        process.on('uncaughtException', (error) => {
            Logger.error(`Uncaught Exception: ${error.message}`, 'Process', error.stack?.split('\n')[1]);
        });

        process.on('unhandledRejection', (reason, promise) => {
            Logger.error(`Unhandled Rejection: ${reason}`, 'Process');
        });

        // Handle SIGTERM/SIGINT
        const gracefulShutdown = async (signal) => {
            Logger.warn(`Received ${signal}. Shutting down gracefully...`, 'Process');
            
            try {
                // Stop bot
                await bot.stop(signal);
                
                // Close database connections
                const mongoose = require('mongoose');
                await mongoose.disconnect();
                
                Logger.info('Shutdown complete', 'Process');
                process.exit(0);
            } catch (error) {
                Logger.error(`Shutdown error: ${error.message}`, 'Process');
                process.exit(1);
            }
        };

        process.on('SIGINT', () => gracefulShutdown('SIGINT'));
        process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    }
}

module.exports = BotErrorHandler;
// END OF FILE - handlers/errorHandler.js