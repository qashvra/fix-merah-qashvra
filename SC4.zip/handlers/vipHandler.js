// [QASHVRA BOT] - handlers/vipHandler.js - VIP/VVIP Purchase Handler
const globalInstance = require('../global');
const UserModel = require('../models/userModel');
const Formatter = require('../utils/formatter');
const Logger = require('../utils/logger');
const paymentService = require('../services/paymentService');

class VipHandler {
    
    async handleVipSelection(ctx) {
        try {
            const callbackData = ctx.callbackQuery.data;
            const match = callbackData.match(/^vip_(\w+)_(\d+)$/);
            
            if (!match) {
                await ctx.answerCbQuery('❌ Invalid selection');
                return;
            }
            
            const type = match[1]; // VIP or VVIP
            const days = parseInt(match[2]);
            const user = ctx.state.user;
            
            // Get pricing
            const pricing = globalInstance.config.pricing[type]?.[days.toString()];
            if (!pricing) {
                await ctx.answerCbQuery('❌ Package tidak tersedia');
                return;
            }
            
            const amount = pricing.price;
            const orderId = Formatter.generateOrderId(type, user.userId, days);
            
            // Generate QRIS payment
            const paymentResult = await paymentService.generateQRISPayment({
                orderId,
                amount,
                type,
                days,
                userId: user.userId,
                username: user.username
            });
            
            if (!paymentResult.success) {
                await ctx.answerCbQuery('❌ Gagal generate pembayaran');
                await ctx.reply(`❌ Gagal generate pembayaran: ${paymentResult.error}`);
                return;
            }
            
            // Create payment record in database
            await paymentService.createPaymentRecord({
                orderId,
                userId: user.userId,
                type,
                days,
                amount,
                paymentMethod: 'QRIS',
                status: 'pending'
            });
            
            // Show invoice with QR code
            const invoiceMessage = 
                `💳 𝗜𝗡𝗩𝗢𝗜𝗖𝗘\n\n` +
                `🔖 Order ID: ${orderId}\n` +
                `📦 Paket: ${type} ${days} Hari\n` +
                `💰 Total: ${Formatter.formatCurrency(amount)}\n\n` +
                `⚠️ Klik 𝗦𝗨𝗗𝗔𝗛 𝗕𝗔𝗬𝗔𝗥 jika sudah transfer!`;
            
            const inlineKeyboard = {
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '💵 SUDAH BAYAR', callback_data: `pay_confirm_${orderId}` }
                        ],
                        [
                            { text: '❌ Batalkan', callback_data: 'menu_vip' }
                        ]
                    ]
                }
            };
            
            // Try to send with QR code image
            if (paymentResult.qrImageUrl) {
                await ctx.replyWithPhoto(
                    paymentResult.qrImageUrl,
                    { caption: invoiceMessage, ...inlineKeyboard }
                );
            } else {
                await ctx.reply(invoiceMessage, inlineKeyboard);
            }
            
            await ctx.answerCbQuery('✅ Invoice berhasil dibuat!');
            
        } catch (error) {
            Logger.error(`VIP selection error: ${error.message}`, 'VipHandler', '31');
            await ctx.answerCbQuery('❌ Terjadi kesalahan');
        }
    }
    
    async handlePaymentCheck(ctx) {
        try {
            const callbackData = ctx.callbackQuery.data;
            const match = callbackData.match(/^payment_check_(.+)$/);
            
            if (!match) {
                await ctx.answerCbQuery('❌ Invalid');
                return;
            }
            
            const orderId = match[1];
            const user = ctx.state.user;
            
            await ctx.answerCbQuery('⏳ Memeriksa pembayaran...');
            
            // Check payment status
            const paymentStatus = await paymentService.checkPaymentStatus(orderId);
            
            if (paymentStatus.status === 'paid') {
                // Activate premium
                const payment = await paymentService.getPaymentByOrderId(orderId);
                
                if (!payment) {
                    await ctx.reply('❌ Data pembayaran tidak ditemukan.');
                    return;
                }
                
                const days = payment.days;
                const type = payment.type;
                
                // Calculate expiry
                const expiryDate = new Date();
                expiryDate.setDate(expiryDate.getDate() + days);
                
                // Update user
                const updatedUser = await UserModel.findOneAndUpdate(
                    { userId: user.userId },
                    {
                        status: type,
                        premiumExpiry: expiryDate,
                        'limits.dailyFix': 999999,
                        'limits.massSend': type === 'VVIP' ? 25 : 5,
                        $push: {
                            paymentHistory: {
                                orderId,
                                package: `${type} ${days} Hari`,
                                amount: payment.amount,
                                status: 'paid',
                                paymentMethod: 'QRIS',
                                timestamp: new Date()
                            }
                        }
                    },
                    { new: true }
                );
                
                // Update payment record
                await paymentService.updatePaymentStatus(orderId, 'paid');
                
                const successMessage = 
                    `✅ 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟!\n\n` +
                    `🔖 Order ID: ${orderId}\n` +
                    `📦 Paket: ${type} ${days} Hari\n` +
                    `📅 Expired: ${Formatter.formatDate(expiryDate)}\n` +
                    `👑 Status: ${Formatter.getStatusBadge(type)}\n\n` +
                    `🎉 Selamat! Anda sekarang adalah ${type} User!\n` +
                    `Nikmati semua fitur premium QASHVRA Fix Merah!`;
                
                await ctx.reply(successMessage);
                
                Logger.success(`User ${user.userId} upgraded to ${type} for ${days} days`, 'VipHandler');
                
            } else if (paymentStatus.status === 'pending') {
                await ctx.reply(
                    `⏳ 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 𝗕𝗘𝗟𝗨𝗠 𝗗𝗜𝗧𝗘𝗥𝗜𝗠𝗔\n\n` +
                    `Kami belum menerima pembayaran untuk Order ID: ${orderId}\n\n` +
                    `Silakan lakukan pembayaran terlebih dahulu, lalu klik tombol SUDAH BAYAR kembali.\n\n` +
                    `Jika sudah transfer, tunggu beberapa saat dan coba lagi.`
                );
            } else {
                await ctx.reply(
                    `❌ 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 𝗚𝗔𝗚𝗔𝗟\n\n` +
                    `Status: ${paymentStatus.status}\n\n` +
                    `Silakan coba lagi atau hubungi admin @${globalInstance.ownerUsername}`
                );
            }
            
        } catch (error) {
            Logger.error(`Payment check error: ${error.message}`, 'VipHandler', '98');
            await ctx.reply('❌ Terjadi kesalahan saat memeriksa pembayaran.');
        }
    }
}

module.exports = new VipHandler();
// END OF FILE - handlers/vipHandler.js