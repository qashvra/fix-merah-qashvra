// [QASHVRA BOT] - handlers/paymentHandler.js - Payment Confirmation Handler
const globalInstance = require('../global');
const paymentService = require('../services/paymentService');
const Logger = require('../utils/logger');
const unicodeLoader = require('../utils/unicodeLoader');

class PaymentHandler {
    
    async handlePaymentConfirmation(ctx) {
        try {
            const callbackData = ctx.callbackQuery.data;
            const match = callbackData.match(/^pay_confirm_(.+)$/);
            
            if (!match) {
                await ctx.answerCbQuery('❌ Invalid');
                return;
            }
            
            const orderId = match[1];
            const messageId = ctx.callbackQuery.message.message_id;
            
            await ctx.answerCbQuery('⏳ Memeriksa pembayaran...');
            
            // Show loading animation
            await unicodeLoader.showLoading(ctx, messageId, 'payment', 3000);
            
            // Check payment via payment gateway
            const paymentStatus = await paymentService.verifyPayment(orderId);
            
            if (paymentStatus.verified) {
                // Payment confirmed
                await paymentService.updatePaymentStatus(orderId, 'paid');
                
                // Get payment details
                const payment = await paymentService.getPaymentByOrderId(orderId);
                
                if (payment) {
                    // Call VIP handler logic to upgrade user
                    const vipHandler = require('./vipHandler');
                    // Upgrade happens in payment service
                    
                    const successMessage = 
                        `✅ 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 𝗧𝗘𝗥𝗞𝗢𝗡𝗙𝗜𝗥𝗠𝗔𝗦𝗜!\n\n` +
                        `🔖 Order ID: ${orderId}\n` +
                        `📦 Paket: ${payment.type} ${payment.days} Hari\n` +
                        `💰 Total: Rp ${payment.amount.toLocaleString('id-ID')}\n` +
                        `📌 Status: LUNAS\n\n` +
                        `🎉 Akun Anda telah diupgrade!\n` +
                        `Silakan cek status di menu utama.`;
                    
                    await ctx.telegram.editMessageText(
                        ctx.chat.id,
                        messageId,
                        null,
                        successMessage
                    );
                    
                    Logger.success(`Payment confirmed for order ${orderId}`, 'PaymentHandler');
                }
                
            } else {
                // Payment not found
                const failMessage = 
                    `❌ 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 𝗕𝗘𝗟𝗨𝗠 𝗗𝗜𝗧𝗘𝗥𝗜𝗠𝗔\n\n` +
                    `🔖 Order ID: ${orderId}\n\n` +
                    `Kami belum menerima pembayaran Anda.\n\n` +
                    `📌 Pastikan:\n` +
                    `├ Nominal transfer sesuai\n` +
                    `├ Transfer ke rekening yang benar\n` +
                    `└ Tunggu 1-5 menit setelah transfer\n\n` +
                    `Klik tombol SUDAH BAYAR untuk cek ulang.`;
                
                await ctx.telegram.editMessageText(
                    ctx.chat.id,
                    messageId,
                    null,
                    failMessage,
                    {
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '💵 CEK LAGI', callback_data: `pay_confirm_${orderId}` }],
                                [{ text: '📞 Hubungi Admin', url: `https://t.me/${globalInstance.ownerUsername}` }]
                            ]
                        }
                    }
                );
            }
            
        } catch (error) {
            Logger.error(`Payment confirmation error: ${error.message}`, 'PaymentHandler', '63');
            await ctx.reply('❌ Terjadi kesalahan saat verifikasi pembayaran.');
        }
    }
}

module.exports = new PaymentHandler();
// END OF FILE - handlers/paymentHandler.js