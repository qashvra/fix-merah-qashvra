// [QASHVRA BOT] - handlers/ownerPanel.js - Owner Control Panel Handler
const globalInstance = require('../global');
const UserModel = require('../models/userModel');
const PaymentModel = require('../models/paymentModel');
const StatisticsModel = require('../models/statisticsModel');
const userService = require('../services/userService');
const paymentService = require('../services/paymentService');
const smtpService = require('../services/smtpService');
const statisticsService = require('../services/statisticsService');
const Formatter = require('../utils/formatter');
const Logger = require('../utils/logger');
const fs = require('fs');
const path = require('path');

class OwnerPanel {
    
    async handleOwnerPanel(ctx) {
        // Only owner can access
        if (!ctx.state.isOwner) {
            await ctx.reply('⛔ 𝗔𝗞𝗦𝗘𝗦 𝗗𝗜𝗧𝗢𝗟𝗔𝗞!\n\nHanya owner yang dapat mengakses panel ini.');
            return;
        }

        const message = 
            `👑 𝗤𝗔𝗦𝗛𝗩𝗥𝗔 𝗢𝗪𝗡𝗘𝗥 𝗣𝗔𝗡𝗘𝗟\n\n` +
            `🕐 Runtime: ${globalInstance.getRuntime()}\n` +
            `📅 Started: ${globalInstance.getStartDate()}\n` +
            `📂 Files: ${globalInstance.totalFilesLoaded}/${globalInstance.maxFiles}\n\n` +
            `𝗣𝗶𝗹𝗶𝗵 𝗠𝗲𝗻𝘂:`;

        const inlineKeyboard = {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '📊 Statistics', callback_data: 'owner_stats' },
                        { text: '👥 Users', callback_data: 'owner_users' }
                    ],
                    [
                        { text: '💰 Payments', callback_data: 'owner_payments' },
                        { text: '📧 SMTP', callback_data: 'owner_smtp' }
                    ],
                    [
                        { text: '⚙️ Config', callback_data: 'owner_config' },
                        { text: '🔧 Settings', callback_data: 'owner_settings' }
                    ],
                    [
                        { text: '📢 Broadcast', callback_data: 'owner_broadcast' },
                        { text: '🔄 Maintenance', callback_data: 'owner_maintenance' }
                    ],
                    [
                        { text: '❌ Close Panel', callback_data: 'owner_close' }
                    ]
                ]
            }
        };

        await ctx.reply(message, inlineKeyboard);
    }

    async handleOwnerActions(ctx) {
        if (!ctx.state.isOwner) {
            await ctx.answerCbQuery('⛔ Access Denied');
            return;
        }

        const action = ctx.callbackQuery.data;

        try {
            switch (action) {
                case 'owner_stats':
                    await this.showStatistics(ctx);
                    break;
                case 'owner_users':
                    await this.showUsers(ctx);
                    break;
                case 'owner_payments':
                    await this.showPayments(ctx);
                    break;
                case 'owner_smtp':
                    await this.showSMTP(ctx);
                    break;
                case 'owner_config':
                    await this.showConfig(ctx);
                    break;
                case 'owner_settings':
                    await this.showSettings(ctx);
                    break;
                case 'owner_broadcast':
                    await this.showBroadcast(ctx);
                    break;
                case 'owner_maintenance':
                    await this.showMaintenance(ctx);
                    break;
                case 'owner_close':
                    await ctx.deleteMessage(ctx.callbackQuery.message.message_id);
                    break;
                default:
                    await ctx.answerCbQuery('Unknown action');
            }
        } catch (error) {
            Logger.error(`Owner action error: ${error.message}`, 'OwnerPanel');
            await ctx.answerCbQuery('❌ Error occurred');
        }
    }

    async showStatistics(ctx) {
        const paymentStats = await paymentService.getPaymentStats();
        const userStats = await userService.getUserStats();
        const smtpStats = smtpService.getSMTPStats();
        const globalStats = await statisticsService.getGlobalStats();

        const message = 
            `📊 𝗦𝗧𝗔𝗧𝗜𝗦𝗧𝗜𝗖𝗦 𝗣𝗔𝗡𝗘𝗟\n\n` +
            `👥 𝗨𝗦𝗘𝗥𝗦\n` +
            `├ Total: ${Formatter.formatNumber(userStats.total)}\n` +
            `├ Free: ${Formatter.formatNumber(userStats.free)}\n` +
            `├ VIP: ${Formatter.formatNumber(userStats.vip)}\n` +
            `├ VVIP: ${Formatter.formatNumber(userStats.vvip)}\n` +
            `└ Banned: ${Formatter.formatNumber(userStats.banned)}\n\n` +
            `🛠️ 𝗙𝗜𝗫 𝗠𝗘𝗥𝗔𝗛\n` +
            `├ Total: ${Formatter.formatNumber(globalStats.totalFix)}\n` +
            `├ Success: ${Formatter.formatNumber(globalStats.totalSuccess)}\n` +
            `├ Failed: ${Formatter.formatNumber(globalStats.totalFailed)}\n` +
            `└ Win Rate: ${Formatter.formatWinRate(globalStats.totalSuccess, globalStats.totalFix)}\n\n` +
            `💰 𝗣𝗔𝗬𝗠𝗘𝗡𝗧𝗦\n` +
            `├ Total: ${Formatter.formatNumber(paymentStats.total)}\n` +
            `├ Paid: ${Formatter.formatNumber(paymentStats.paid)}\n` +
            `├ Pending: ${Formatter.formatNumber(paymentStats.pending)}\n` +
            `├ Revenue: ${Formatter.formatCurrency(paymentStats.totalRevenue)}\n` +
            `└ Failed: ${Formatter.formatNumber(paymentStats.failed)}\n\n` +
            `📧 𝗦𝗠𝗧𝗣\n` +
            `├ Total: ${smtpStats.total}\n` +
            `├ Active: ${smtpStats.active}\n` +
            `└ Failed: ${smtpStats.failed}`;

        await ctx.editMessageText(message, {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔄 Refresh', callback_data: 'owner_stats' }],
                    [{ text: '🔙 Back to Panel', callback_data: 'owner_back' }]
                ]
            }
        });
    }

    async showUsers(ctx) {
        const { users, total, page, totalPages } = await userService.getAllUsers(1, 5);

        let message = `👥 𝗨𝗦𝗘𝗥 𝗠𝗔𝗡𝗔𝗚𝗘𝗠𝗘𝗡𝗧\n\n`;
        message += `Total: ${total} Users | Page: ${page}/${totalPages}\n\n`;

        users.forEach((user, i) => {
            message += `${i + 1}. ${Formatter.getStatusBadge(user.status)} ${Formatter.maskUsername(user.firstName || user.username)}\n`;
            message += `   ├ ID: ${user.userId}\n`;
            message += `   ├ Status: ${user.status}\n`;
            message += `   └ Fix: ${user.statistics?.totalFix || 0}x\n\n`;
        });

        await ctx.editMessageText(message, {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '◀️ Prev', callback_data: 'owner_users_prev' },
                        { text: 'Next ▶️', callback_data: 'owner_users_next' }
                    ],
                    [{ text: '🔍 Search User', callback_data: 'owner_user_search' }],
                    [{ text: '🔙 Back to Panel', callback_data: 'owner_back' }]
                ]
            }
        });
    }

    async showPayments(ctx) {
        const paymentStats = await paymentService.getPaymentStats();
        const recentPayments = await PaymentModel.find({ status: 'paid' })
            .sort({ paidAt: -1 })
            .limit(5);

        let message = `💰 𝗣𝗔𝗬𝗠𝗘𝗡𝗧 𝗣𝗔𝗡𝗘𝗟\n\n`;
        message += `📊 𝗦𝘂𝗺𝗺𝗮𝗿𝘆:\n`;
        message += `├ Total Revenue: ${Formatter.formatCurrency(paymentStats.totalRevenue)}\n`;
        message += `├ Total Paid: ${paymentStats.paid}\n`;
        message += `└ Total Pending: ${paymentStats.pending}\n\n`;
        message += `📋 𝗥𝗲𝗰𝗲𝗻𝘁 𝗣𝗮𝘆𝗺𝗲𝗻𝘁𝘀:\n`;

        recentPayments.forEach((p, i) => {
            message += `${i + 1}. ${p.orderId}\n`;
            message += `   ├ User: ${p.userId}\n`;
            message += `   ├ Package: ${p.type} ${p.days} Hari\n`;
            message += `   ├ Amount: ${Formatter.formatCurrency(p.amount)}\n`;
            message += `   └ Date: ${Formatter.formatDate(p.paidAt)}\n\n`;
        });

        await ctx.editMessageText(message, {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔄 Refresh', callback_data: 'owner_payments' }],
                    [{ text: '🔙 Back to Panel', callback_data: 'owner_back' }]
                ]
            }
        });
    }

    async showSMTP(ctx) {
        const smtpStats = smtpService.getSMTPStats();
        const poolData = smtpService.loadFreePool();
        const recentSMTPs = poolData.pool.slice(-5);

        let message = `📧 𝗦𝗠𝗧𝗣 𝗣𝗔𝗡𝗘𝗟\n\n`;
        message += `📊 𝗦𝘁𝗮𝘁𝘀:\n`;
        message += `├ Total: ${smtpStats.total}\n`;
        message += `├ Active: ${smtpStats.active}\n`;
        message += `├ Total Sent: ${Formatter.formatNumber(smtpStats.totalSent)}\n`;
        message += `└ Total Success: ${Formatter.formatNumber(smtpStats.totalSuccess)}\n\n`;
        message += `📋 𝗥𝗲𝗰𝗲𝗻𝘁 𝗦𝗠𝗧𝗣𝘀:\n`;

        recentSMTPs.forEach((s, i) => {
            message += `${i + 1}. ${s.email}\n`;
            message += `   ├ Active: ${s.isActive ? '✅' : '❌'}\n`;
            message += `   ├ Sent: ${Formatter.formatNumber(s.totalSent || 0)}\n`;
            message += `   └ Success: ${Formatter.formatNumber(s.totalSuccess || 0)}\n\n`;
        });

        await ctx.editMessageText(message, {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '➕ Add Premium SMTP', callback_data: 'owner_smtp_add' },
                        { text: '🔄 Refresh Pool', callback_data: 'owner_smtp_refresh' }
                    ],
                    [{ text: '🔙 Back to Panel', callback_data: 'owner_back' }]
                ]
            }
        });
    }

    async showConfig(ctx) {
        const config = globalInstance.config;

        let message = `⚙️ 𝗖𝗢𝗡𝗙𝗜𝗚 𝗣𝗔𝗡𝗘𝗟\n\n`;
        message += `🔧 𝗖𝘂𝗿𝗿𝗲𝗻𝘁 𝗖𝗼𝗻𝗳𝗶𝗴:\n`;
        message += `├ Gateway: ${config.payment.gateway}\n`;
        message += `├ Verification: ${config.verification.enabled ? '✅ ON' : '❌ OFF'}\n`;
        message += `├ Referral Coins: ${config.referral.coinsPerReferral}\n`;
        message += `├ Min Redeem: ${config.referral.minimumRedeemCoins}\n`;
        message += `└ Rolling Interval: ${config.smtp.rollingInterval}ms\n`;

        await ctx.editMessageText(message, {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '💳 Payment Gateway', callback_data: 'owner_config_gateway' },
                        { text: '👥 Referral', callback_data: 'owner_config_referral' }
                    ],
                    [
                        { text: '📧 SMTP Settings', callback_data: 'owner_config_smtp' },
                        { text: '✅ Verification', callback_data: 'owner_config_verify' }
                    ],
                    [{ text: '🔙 Back to Panel', callback_data: 'owner_back' }]
                ]
            }
        });
    }

    async showSettings(ctx) {
        let message = `🔧 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦 𝗣𝗔𝗡𝗘𝗟\n\n`;
        message += `𝗔𝘃𝗮𝗶𝗹𝗮𝗯𝗹𝗲 𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀:\n\n`;
        message += `📧 𝗦𝗠𝗧𝗣\n`;
        message += `├ /addpremiumsmtp email pass - Add premium SMTP\n`;
        message += `├ /listsmtp - List all SMTPs\n`;
        message += `└ /removesmtp email - Remove SMTP\n\n`;
        message += `👥 𝗨𝗦𝗘𝗥\n`;
        message += `├ /addvip userId days - Add VIP to user\n`;
        message += `├ /addvvip userId days - Add VVIP to user\n`;
        message += `├ /ban userId reason - Ban user\n`;
        message += `├ /unban userId - Unban user\n`;
        message += `└ /userinfo userId - User details\n\n`;
        message += `📢 𝗢𝗧𝗛𝗘𝗥\n`;
        message += `├ /broadcast text - Send to all users\n`;
        message += `├ /stats - Show statistics\n`;
        message += `├ /resetdaily - Reset all daily limits\n`;
        message += `└ /maintenance on/off - Toggle maintenance`;

        await ctx.editMessageText(message, {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔙 Back to Panel', callback_data: 'owner_back' }]
                ]
            }
        });
    }

    async showBroadcast(ctx) {
        await ctx.editMessageText(
            `📢 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧 𝗣𝗔𝗡𝗘𝗟\n\n` +
            `Gunakan command:\n` +
            `/broadcast [pesan Anda]\n\n` +
            `Contoh:\n` +
            `/broadcast 🔔 Update bot tersedia! Cek menu utama.`,
            {
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔙 Back to Panel', callback_data: 'owner_back' }]
                    ]
                }
            }
        );
    }

    async showMaintenance(ctx) {
        let message = `🔄 𝗠𝗔𝗜𝗡𝗧𝗘𝗡𝗔𝗡𝗖𝗘 𝗣𝗔𝗡𝗘𝗟\n\n`;
        message += `Available commands:\n\n`;
        message += `├ /maintenance on - Turn ON\n`;
        message += `├ /maintenance off - Turn OFF\n`;
        message += `├ /expiredcheck - Check expired premium\n`;
        message += `├ /cleanpayments - Clean expired payments\n`;
        message += `├ /resetdaily - Reset daily limits\n`;
        message += `└ /restartbot - Restart bot`;

        await ctx.editMessageText(message, {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔙 Back to Panel', callback_data: 'owner_back' }]
                ]
            }
        });
    }
}

module.exports = new OwnerPanel();
// END OF FILE - handlers/ownerPanel.js