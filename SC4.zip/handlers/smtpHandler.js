// [QASHVRA BOT] - handlers/smtpHandler.js - SMTP Management Handler for Users
const smtpService = require('../services/smtpService');
const globalInstance = require('../global');
const Logger = require('../utils/logger');

class SMTPHandler {
    
    async handleSMTPCommand(ctx) {
        const user = ctx.state.user;
        const text = ctx.message?.text || '';
        const args = text.split(' ');

        // Command: /addsmtp email@gmail.com app-password
        if (text.startsWith('/addsmtp') || text.startsWith('📧 Add SMTP')) {
            await this.handleAddSMTP(ctx);
            return;
        }

        // Command: /mysmtp or show SMTP status
        if (text.startsWith('/mysmtp') || text.startsWith('📋 My SMTP')) {
            await this.handleMySMTP(ctx);
            return;
        }

        // Check if user is sending SMTP credentials
        if (ctx.session?.waitingForSMTP) {
            await this.processSMTPInput(ctx);
            return;
        }
    }

    async handleAddSMTP(ctx) {
        const user = ctx.state.user;

        // Premium users don't need to add SMTP
        if (user.status === 'VIP' || user.status === 'VVIP') {
            await ctx.reply(
                `✅ Anda adalah ${user.status} User!\n\n` +
                `Anda sudah menggunakan SMTP premium QASHVRA.\n` +
                `Tidak perlu menambahkan SMTP pribadi.`
            );
            return;
        }

        // Show instructions
        await ctx.reply(
            `📧 𝗧𝗔𝗠𝗕𝗔𝗛 𝗦𝗠𝗧𝗣 𝗚𝗠𝗔𝗜𝗟\n\n` +
            `Untuk menggunakan Fitur Fix Merah, Anda perlu menambahkan SMTP Gmail.\n\n` +
            `📌 𝗖𝗮𝗿𝗮 𝗠𝗲𝗻𝗱𝗮𝗽𝗮𝘁𝗸𝗮𝗻 𝗔𝗽𝗽 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱:\n` +
            `1. Buka https://myaccount.google.com/apppasswords\n` +
            `2. Login dengan akun Gmail Anda\n` +
            `3. Buat App Password baru\n` +
            `4. Copy password yang muncul\n\n` +
            `📤 𝗞𝗶𝗿𝗶𝗺𝗸𝗮𝗻 𝗱𝗲𝗻𝗴𝗮𝗻 𝗳𝗼𝗿𝗺𝗮𝘁:\n\n` +
            `📧 email@gmail.com\n` +
            `🔑 app-password-anda\n\n` +
            `Contoh:\n` +
            `qashvra@gmail.com\n` +
            `abcd efgh ijkl mnop\n\n` +
            `⚠️ Kirim dengan format yang tepat!\n` +
            `Ketik /cancel untuk membatalkan.`
        );

        // Set waiting state
        ctx.session = ctx.session || {};
        ctx.session.waitingForSMTP = true;
    }

    async processSMTPInput(ctx) {
        const text = ctx.message?.text;

        if (text === '/cancel' || text === '❌ Cancel') {
            ctx.session.waitingForSMTP = false;
            await ctx.reply('✅ Penambahan SMTP dibatalkan.');
            return;
        }

        // Parse email and password
        const lines = text.split('\n').filter(l => l.trim());
        
        if (lines.length < 2) {
            await ctx.reply(
                `⚠️ 𝗙𝗼𝗿𝗺𝗮𝘁 𝗧𝗶𝗱𝗮𝗸 𝗩𝗮𝗹𝗶𝗱!\n\n` +
                `Kirim dengan format:\n` +
                `Baris 1: email@gmail.com\n` +
                `Baris 2: app-password\n\n` +
                `Ketik /cancel untuk membatalkan.`
            );
            return;
        }

        const email = lines[0].trim().toLowerCase();
        const appPassword = lines.slice(1).join(' ').trim();

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            await ctx.reply('⚠️ Format email tidak valid!');
            return;
        }

        // Validate Gmail
        if (!email.endsWith('@gmail.com')) {
            await ctx.reply('⚠️ Hanya Gmail yang didukung! Gunakan @gmail.com');
            return;
        }

        // Show processing
        const loadingMsg = await ctx.reply('⏳ Memvalidasi SMTP Anda...');

        // Add SMTP
        const result = await smtpService.addUserSMTP(ctx.from.id, email, appPassword);

        if (result.success) {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                null,
                `✅ 𝗦𝗠𝗧𝗣 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗗𝗜𝗧𝗔𝗠𝗕𝗔𝗛𝗞𝗔𝗡!\n\n` +
                `📧 Email: ${email}\n` +
                `🔐 Status: Aktif\n\n` +
                `Sekarang Anda bisa menggunakan Fitur Fix Merah!`
            );

            // Update user SMTP status
            const user = ctx.state.user;
            user.smtp = {
                type: 'self',
                email,
                appPassword,
                isActive: true,
                lastUsed: null,
                errorCount: 0
            };
            await user.save();

        } else {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                null,
                `❌ 𝗚𝗔𝗚𝗔𝗟 𝗠𝗘𝗡𝗔𝗠𝗕𝗔𝗛𝗞𝗔𝗡 𝗦𝗠𝗧𝗣\n\n` +
                `Error: ${result.error}\n\n` +
                `Pastikan:\n` +
                `├ Email Gmail valid\n` +
                `├ App Password benar\n` +
                `├ 2FA/2-Step Verification aktif\n` +
                `└ Buka https://myaccount.google.com/apppasswords`
            );
        }

        ctx.session.waitingForSMTP = false;
    }

    async handleMySMTP(ctx) {
        const user = ctx.state.user;
        const mappingData = smtpService.loadUserMapping();
        const userEmails = mappingData.mappings[user.userId] || [];

        let message = `📋 𝗦𝗠𝗧𝗣 𝗔𝗡𝗗𝗔\n\n`;

        if (user.status === 'VIP' || user.status === 'VVIP') {
            message += 
                `✅ Status: ${user.status} User\n` +
                `📧 Tipe: SMTP Premium QASHVRA\n` +
                `🔐 Status: Aktif\n\n` +
                `Anda menggunakan SMTP premium dari QASHVRA.\n` +
                `Tidak perlu konfigurasi tambahan.`;
        } else if (userEmails.length > 0) {
            message += `📧 Email Terdaftar:\n`;
            const poolData = smtpService.loadFreePool();
            
            userEmails.forEach((email, i) => {
                const smtp = poolData.pool.find(s => s.email === email);
                const isActive = smtp?.isActive ? '✅' : '❌';
                message += `${i + 1}. ${isActive} ${email}\n`;
            });
        } else {
            message += `❌ Belum ada SMTP terdaftar.\n\nKirim /addsmtp untuk menambahkan.`;
        }

        await ctx.reply(message);
    }

    async handleOwnerSMTPCommands(ctx) {
        if (!ctx.state.isOwner) return;

        const text = ctx.message?.text || '';
        const args = text.split(' ');

        // /addpremiumsmtp email pass
        if (text.startsWith('/addpremiumsmtp')) {
            if (args.length < 3) {
                await ctx.reply('Format: /addpremiumsmtp email@gmail.com app-password');
                return;
            }

            const email = args[1];
            const appPassword = args.slice(2).join(' ');

            const premiumPool = globalInstance.config.smtp.premiumPool || [];
            premiumPool.push({ email, appPassword });
            globalInstance.config.smtp.premiumPool = premiumPool;

            await ctx.reply(`✅ Premium SMTP ditambahkan: ${email}`);
            Logger.info(`Owner added premium SMTP: ${email}`, 'SMTPHandler');
        }

        // /listsmtp
        if (text.startsWith('/listsmtp')) {
            const smtpStats = smtpService.getSMTPStats();
            const premiumPool = globalInstance.config.smtp.premiumPool || [];
            const poolData = smtpService.loadFreePool();

            let message = `📧 𝗦𝗠𝗧𝗣 𝗟𝗜𝗦𝗧\n\n`;
            message += `Premium SMTP: ${premiumPool.length}\n`;
            premiumPool.forEach((s, i) => {
                message += `${i + 1}. ${s.email}\n`;
            });
            message += `\nFree SMTP Pool: ${poolData.pool.length}\n`;
            poolData.pool.slice(0, 10).forEach((s, i) => {
                message += `${i + 1}. ${s.email} [${s.isActive ? '✅' : '❌'}]\n`;
            });

            await ctx.reply(message);
        }

        // /removesmtp email
        if (text.startsWith('/removesmtp')) {
            if (args.length < 2) {
                await ctx.reply('Format: /removesmtp email@gmail.com');
                return;
            }

            const email = args[1];
            const premiumPool = globalInstance.config.smtp.premiumPool || [];
            const index = premiumPool.findIndex(s => s.email === email);

            if (index >= 0) {
                premiumPool.splice(index, 1);
                globalInstance.config.smtp.premiumPool = premiumPool;
                await ctx.reply(`✅ Premium SMTP dihapus: ${email}`);
            } else {
                await ctx.reply(`❌ SMTP tidak ditemukan: ${email}`);
            }
        }
    }
}

module.exports = new SMTPHandler();
// END OF FILE - handlers/smtpHandler.js