// [QASHVRA BOT] - handlers/callbackHandler.js - General Callback Query Handler
const globalInstance = require('../global');
const Logger = require('../utils/logger');
const startHandler = require('./startHandler');
const menuHandler = require('./menuHandler');

class CallbackHandler {
    
    async handleCallback(ctx) {
        const callbackData = ctx.callbackQuery?.data;
        const user = ctx.state.user;

        if (!callbackData) return;

        try {
            switch (callbackData) {
                // Verification check
                case 'verify_check':
                    await this.handleVerifyCheck(ctx);
                    break;

                // Back to main menu
                case 'menu_main':
                    await ctx.deleteMessage(ctx.callbackQuery.message.message_id);
                    await startHandler.showMainMenu(ctx, user);
                    await ctx.answerCbQuery('✅ Kembali ke menu utama');
                    break;

                // Back to VIP menu
                case 'menu_vip':
                    await ctx.deleteMessage(ctx.callbackQuery.message.message_id);
                    await menuHandler.handleVipMenu(ctx);
                    await ctx.answerCbQuery('✅ Kembali ke menu VIP');
                    break;

                // Back to owner panel
                case 'owner_back':
                    await ctx.deleteMessage(ctx.callbackQuery.message.message_id);
                    const ownerPanel = require('./ownerPanel');
                    await ownerPanel.handleOwnerPanel(ctx);
                    await ctx.answerCbQuery('✅ Kembali ke panel');
                    break;

                default:
                    // Check if it's a payment or VIP action
                    if (callbackData.startsWith('vip_') || 
                        callbackData.startsWith('pay_') || 
                        callbackData.startsWith('redeem_') ||
                        callbackData.startsWith('owner_')) {
                        // These are handled by their respective handlers
                        return;
                    }
                    
                    Logger.warn(`Unhandled callback: ${callbackData}`, 'CallbackHandler');
                    await ctx.answerCbQuery('⚠️ Menu tidak tersedia');
            }
        } catch (error) {
            Logger.error(`Callback error: ${error.message}`, 'CallbackHandler');
            await ctx.answerCbQuery('❌ Terjadi kesalahan');
        }
    }

    async handleVerifyCheck(ctx) {
        try {
            const verification = globalInstance.config.verification;
            const allRequired = [...(verification.requiredChannels || []), ...(verification.requiredGroups || [])];
            
            let allJoined = true;
            const notJoined = [];

            for (const entity of allRequired) {
                try {
                    const chatId = entity.id.startsWith('@') ? entity.id : `@${entity.id}`;
                    const member = await ctx.telegram.getChatMember(chatId, ctx.from.id);
                    
                    if (!['member', 'administrator', 'creator'].includes(member.status)) {
                        allJoined = false;
                        notJoined.push(entity);
                    }
                } catch (error) {
                    allJoined = false;
                    notJoined.push(entity);
                }
            }

            if (allJoined) {
                // User has joined all channels/groups
                const user = ctx.state.user;
                user.isVerified = true;
                await user.save();

                await ctx.answerCbQuery('✅ Verifikasi berhasil!');
                await ctx.deleteMessage(ctx.callbackQuery.message.message_id);
                await startHandler.showMainMenu(ctx, user);
                
                Logger.info(`User ${ctx.from.id} verified successfully`, 'CallbackHandler');
            } else {
                await ctx.answerCbQuery('❌ Anda belum join semua channel/grup!', { show_alert: true });
                
                // Update message with remaining channels
                const buttons = notJoined.map(entity => ([{
                    text: `📢 Join ${entity.name}`,
                    url: entity.link
                }]));
                buttons.push([{ text: '✅ Cek Ulang', callback_data: 'verify_check' }]);

                await ctx.editMessageReplyMarkup({
                    inline_keyboard: buttons
                });
            }
        } catch (error) {
            Logger.error(`Verify check error: ${error.message}`, 'CallbackHandler');
            await ctx.answerCbQuery('❌ Gagal verifikasi. Coba lagi.');
        }
    }
}

module.exports = new CallbackHandler();
// END OF FILE - handlers/callbackHandler.js