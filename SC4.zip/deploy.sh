#!/bin/bash
# [QASHVRA BOT] - deploy.sh - Deployment Script for Production

echo "🔴 QASHVRA FIX MERAH BOT - DEPLOYMENT"
echo "========================================="
echo ""

# Check Node.js version
echo "📋 Checking Node.js..."
node_version=$(node -v 2>/dev/null)
if [ $? -eq 0 ]; then
    echo "✅ Node.js $node_version"
else
    echo "❌ Node.js not found! Please install Node.js 16+"
    exit 1
fi

# Check MongoDB
echo "📋 Checking MongoDB..."
mongod --version >/dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "✅ MongoDB found"
else
    echo "⚠️ MongoDB not found locally (using remote URI)"
fi

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
npm install --production
if [ $? -eq 0 ]; then
    echo "✅ Dependencies installed"
else
    echo "❌ Failed to install dependencies"
    exit 1
fi

# Create required directories
echo ""
echo "📁 Creating directories..."
mkdir -p data logs assets temp backups
echo "✅ Directories created"

# Create default files if not exist
if [ ! -f ".env" ]; then
    echo ""
    echo "⚠️ .env file not found!"
    echo "Creating .env from template..."
    cp .env.example .env 2>/dev/null || touch .env
    echo "Please edit .env with your configuration!"
fi

if [ ! -f "data/free_smtp_pool.json" ]; then
    echo '{"_comment":"SMTP Pool for FREE Users","pool":[],"stats":{"totalSMTP":0,"activeSMTP":0}}' > data/free_smtp_pool.json
fi

if [ ! -f "data/user_smtp_mapping.json" ]; then
    echo '{"_comment":"User SMTP Mapping","mappings":{},"stats":{"totalMappings":0}}' > data/user_smtp_mapping.json
fi

# Check file completeness
echo ""
echo "📂 Checking file structure..."
node utils/fileChecker.js 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ File check complete"
else
    echo "⚠️ File checker running..."
    node -e "const fc = require('./utils/fileChecker'); const c = new fc('.'); c.checkAllFiles(); c.displaySummary();"
fi

# Run tests (if any)
echo ""
echo "🧪 Running pre-deployment checks..."
# Add any pre-deployment tests here

# Start bot
echo ""
echo "========================================="
echo "✅ Deployment ready!"
echo ""
echo "To start the bot:"
echo "  npm start          # Normal mode"
echo "  npm run dev        # Development mode"
echo ""
echo "🔴 QASHVRA FIX MERAH BOT PRO"
echo "========================================="