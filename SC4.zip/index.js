// [QASHVRA BOT] - index.js - Main Entry Point (Updated with all handlers)
const { Telegraf } = require('telegraf');
const globalInstance = require('./global');
const Logger = require('./utils/logger');
const FileChecker = require('./utils/fileChecker');
const SessionManager = require('./utils/sessionManager');
const DailyReset = require('./utils/dailyReset');
const BotErrorHandler = require('./handlers/errorHandler');
const path = require('path');

// Initialize global system
async function bootstrap() {
    try {
        // ============ INITIALIZATION ============
        Logger.info('🔴 QASHVRA FIX MERAH BOT - STARTING', 'Bootstrap');
        
        // Initialize global configuration & database
        await globalInstance.initialize();
        
        // Run file checker
        const fileChecker = new FileChecker(__dirname);
        const checkResult = fileChecker.checkAllFiles();
        fileChecker.displaySummary();
        
        // Update global file count
        globalInstance.totalFilesLoaded = checkResult.loaded;
        globalInstance.maxFiles = checkResult.total;
        
        if (!checkResult.isComplete) {
            Logger.warn(`⚠️ ${checkResult.missing.length} files missing! Generate before production.`, 'Bootstrap');
        }
        
        // ============ BOT INITIALIZATION ============
        const bot = new Telegraf(globalInstance.botToken);
        
        // Store bot instance globally
        globalInstance.bot = bot;
        
        // ============ SESSION MIDDLEWARE ============
        bot.use((ctx, next) => {
            const userId = ctx.from?.id;
            if (userId) {
                ctx.session = SessionManager.getSession(userId);
            }
            return next();
        });
        
        // ============ CORE MIDDLEWARE ============
        Logger.info('Loading middleware...', 'Bootstrap');
        
        const authMiddleware = require('./middleware/authMiddleware');
        const verificationMiddleware = require('./middleware/verificationMiddleware');
        const permissionMiddleware = require('./middleware/permissionMiddleware');
        
        bot.use(authMiddleware);
        bot.use(verificationMiddleware);
        bot.use(permissionMiddleware);
        
        // ============ HANDLERS LOADING ============
        Logger.info('Loading handlers...', 'Bootstrap');
        
        // Core handlers
        const startHandler = require('./handlers/startHandler');
        const menuHandler = require('./handlers/menuHandler');
        const callbackHandler = require('./handlers/callbackHandler');
        const fixMerahHandler = require('./handlers/fixMerahHandler');
        const vipHandler = require('./handlers/vipHandler');
        const referralHandler = require('./handlers/referralHandler');
        const paymentHandler = require('./handlers/paymentHandler');
        const ownerPanel = require('./handlers/ownerPanel');
        const ownerCommands = require('./handlers/ownerCommands');
        const smtpHandler = require('./handlers/smtpHandler');
        
        // ============ COMMAND REGISTRATION ============
        
        // Start & Main Menu
        bot.start(startHandler.handleStart.bind(startHandler));
        bot.command('start', startHandler.handleStart.bind(startHandler));
        
        // Menu Keypad Handlers
        bot.hears('🛠️ Fix Merah', menuHandler.handleFixMerahMenu.bind(menuHandler));
        bot.hears('👑 VIP / VVIP', menuHandler.handleVipMenu.bind(menuHandler));
        bot.hears('🧧 Referral', menuHandler.handleReferralMenu.bind(menuHandler));
        bot.hears('📜 Riwayat', menuHandler.handleHistoryMenu.bind(menuHandler));
        bot.hears('🏆 Top Global', menuHandler.handleLeaderboardMenu.bind(menuHandler));
        bot.hears('💬 Testimoni', menuHandler.handleTestimoniMenu.bind(menuHandler));
        
        // Fix Merah - Phone Input
        bot.on('text', fixMerahHandler.handlePhoneInput.bind(fixMerahHandler));
        
        // SMTP Commands
        bot.command('addsmtp', smtpHandler.handleSMTPCommand.bind(smtpHandler));
        bot.command('mysmtp', smtpHandler.handleSMTPCommand.bind(smtpHandler));
        bot.hears('📧 Add SMTP', smtpHandler.handleSMTPCommand.bind(smtpHandler));
        bot.hears('📋 My SMTP', smtpHandler.handleSMTPCommand.bind(smtpHandler));
        
        // Owner Commands
        bot.command('panel', ownerPanel.handleOwnerPanel.bind(ownerPanel));
        bot.command('admin', ownerPanel.handleOwnerPanel.bind(ownerPanel));
        bot.command('owner', ownerPanel.handleOwnerPanel.bind(ownerPanel));
        
        // Owner text commands
        bot.command('addvip', ownerCommands.handleOwnerCommand.bind(ownerCommands));
        bot.command('addvvip', ownerCommands.handleOwnerCommand.bind(ownerCommands));
        bot.command('ban', ownerCommands.handleOwnerCommand.bind(ownerCommands));
        bot.command('unban', ownerCommands.handleOwnerCommand.bind(ownerCommands));
        bot.command('userinfo', ownerCommands.handleOwnerCommand.bind(ownerCommands));
        bot.command('broadcast', ownerCommands.handleOwnerCommand.bind(ownerCommands));
        bot.command('stats', ownerCommands.handleOwnerCommand.bind(ownerCommands));
        bot.command('resetdaily', ownerCommands.handleOwnerCommand.bind(ownerCommands));
        bot.command('expiredcheck', ownerCommands.handleOwnerCommand.bind(ownerCommands));
        bot.command('cleanpayments', ownerCommands.handleOwnerCommand.bind(ownerCommands));
        bot.command('restartbot', ownerCommands.handleOwnerCommand.bind(ownerCommands));
        bot.command('addcoins', ownerCommands.handleOwnerCommand.bind(ownerCommands));
        
        // Owner SMTP commands
        bot.command('addpremiumsmtp', smtpHandler.handleOwnerSMTPCommands.bind(smtpHandler));
        bot.command('listsmtp', smtpHandler.handleOwnerSMTPCommands.bind(smtpHandler));
        bot.command('removesmtp', smtpHandler.handleOwnerSMTPCommands.bind(smtpHandler));
        
        // ============ CALLBACK ACTIONS ============
        
        // VIP purchase
        bot.action(/^vip_(VIP|VVIP)_(\d+)$/, vipHandler.handleVipSelection.bind(vipHandler));
        
        // Payment confirmation
        bot.action(/^pay_confirm_(.+)$/, paymentHandler.handlePaymentConfirmation.bind(paymentHandler));
        
        // Redeem coins
        bot.action(/^redeem_(\d+)$/, referralHandler.handleRedeemCoins.bind(referralHandler));
        
        // Owner panel actions
        bot.action(/^owner_(.+)$/, ownerPanel.handleOwnerActions.bind(ownerPanel));
        
        // General callback handler (verification, menu navigation, etc.)
        bot.action(/.*/, callbackHandler.handleCallback.bind(callbackHandler));
        
        // ============ ERROR HANDLER ============
        bot.catch(async (err, ctx) => {
            await BotErrorHandler.handleBotError(err, ctx);
        });
        
        // ============ GLOBAL ERROR HANDLERS ============
        BotErrorHandler.setupGlobalHandlers(bot);
        
        // ============ SCHEDULERS ============
        Logger.info('Starting schedulers...', 'Bootstrap');
        DailyReset.startScheduler();
        SessionManager.startAutoCleanup();
        
        // ============ LAUNCH BOT ============
        await bot.launch();
        
        // ============ STARTUP DISPLAY ============
        Logger.botStart(
            globalInstance.botUsername,
            globalInstance.totalFilesLoaded,
            globalInstance.maxFiles
        );
        
        Logger.success(`Bot @${globalInstance.botUsername} is running!`, 'Bootstrap');
        Logger.info(`Owner: @${globalInstance.ownerUsername} (${globalInstance.ownerId})`, 'Bootstrap');
        Logger.info(`Start Date: ${globalInstance.getStartDate()}`, 'Bootstrap');
        
        console.log('\n' + '='.repeat(50));
        console.log('  🔴 QASHVRA FIX MERAH BOT - READY');
        console.log('  📂 Files loaded: ' + globalInstance.totalFilesLoaded + '/' + globalInstance.maxFiles);
        console.log('  👑 Owner ID: ' + globalInstance.ownerId);
        console.log('  ⏰ Runtime: ' + globalInstance.getStartDate());
        console.log('  Press CTRL+C to stop');
        console.log('='.repeat(50) + '\n');
        
    } catch (error) {
        Logger.error(`Bootstrap failed: ${error.message}`, 'Bootstrap', error.stack?.split('\n')[1]);
        process.exit(1);
    }
}

// Start the bot
bootstrap();
// END OF FILE - index.js