const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const path = require('path');

class APIServer {
  constructor(bot) {
    this.bot = bot;
    this.app = express();
    this.server = http.createServer(this.app);
    this.io = null;
    this.logger = bot.logger;
  }

  async initialize() {
    try {
      this.logger.info('Initializing API Server...');

      // Security middleware
      this.app.use(helmet());
      this.app.use(cors({
        origin: process.env.DASHBOARD_URL || '*',
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        allowedHeaders: ['Content-Type', 'Authorization', 'x-api-key']
      }));

      // Compression
      this.app.use(compression());

      // Body parsing
      this.app.use(express.json({ limit: '10mb' }));
      this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));

      // Rate limiting
      const limiter = rateLimit({
        windowMs: 15 * 60 * 1000, // 15 minutes
        max: 100, // limit each IP to 100 requests per windowMs
        message: { error: 'Too many requests, please try again later.' }
      });
      this.app.use('/api/', limiter);

      // API routes
      const apiRoutes = require('./routes')(this.bot);
      this.app.use('/api', apiRoutes);

      // Serve static files (if web dashboard exists)
      const dashboardPath = path.join(__dirname, '../../dashboard/build');
      this.app.use(express.static(dashboardPath));
      
      // SPA fallback
      this.app.get('*', (req, res) => {
        if (req.path.startsWith('/api')) {
          return res.status(404).json({ error: 'API endpoint not found' });
        }
        res.sendFile(path.join(dashboardPath, 'index.html'));
      });

      // Socket.IO setup
      this.io = socketIO(this.server, {
        cors: {
          origin: '*',
          methods: ['GET', 'POST']
        },
        pingTimeout: 60000,
        pingInterval: 25000
      });

      // Socket.IO middleware for authentication
      this.io.use((socket, next) => {
        const token = socket.handshake.auth.token;
        const apiKey = socket.handshake.auth.apiKey;

        if (apiKey === process.env.API_KEY) {
          return next();
        }

        if (token) {
          try {
            const jwt = require('jsonwebtoken');
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            socket.userId = decoded.userId;
            return next();
          } catch (error) {
            return next(new Error('Authentication error'));
          }
        }

        // Allow connection without auth for public stats
        socket.isPublic = true;
        next();
      });

      // Socket.IO connection handler
      this.io.on('connection', (socket) => {
        this.logger.info(`Socket connected: ${socket.id} (${socket.isPublic ? 'public' : 'authenticated'})`);

        // Join user-specific room
        if (socket.userId) {
          socket.join(`user:${socket.userId}`);
        }

        // Join admin room
        if (!socket.isPublic) {
          socket.join('admin');
        }

        // Handle real-time stats subscription
        socket.on('subscribe:stats', () => {
          socket.join('stats');
        });

        socket.on('unsubscribe:stats', () => {
          socket.leave('stats');
        });

        // Handle queue subscription
        socket.on('subscribe:queue', () => {
          socket.join('queue');
        });

        // Handle disconnect
        socket.on('disconnect', () => {
          this.logger.info(`Socket disconnected: ${socket.id}`);
        });
      });

      // Start sending real-time updates
      this.startRealtimeUpdates();

      // Start server
      const port = process.env.PORT || 3000;
      this.server.listen(port, () => {
        this.logger.info(`API Server running on port ${port}`);
        console.log(`✅ API Server: http://localhost:${port}`);
      });

      // Attach IO to bot for use in other services
      this.bot.io = this.io;

    } catch (error) {
      this.logger.error('API Server initialization failed:', error);
      throw error;
    }
  }

  startRealtimeUpdates() {
    // Send stats every 5 seconds
    setInterval(async () => {
      try {
        const stats = await this.bot.services.statistics.getDashboardStats();
        const queueStats = this.bot.managers.queue.getStats();
        
        // Emit to stats room
        this.io.to('stats').emit('stats:update', {
          timestamp: new Date(),
          ...stats
        });

        // Emit to queue room
        this.io.to('queue').emit('queue:update', queueStats);

        // Emit to admin room
        this.io.to('admin').emit('admin:update', {
          stats,
          queue: queueStats,
          system: {
            memory: process.memoryUsage(),
            uptime: process.uptime()
          }
        });

      } catch (error) {
        this.logger.error('Realtime update error:', error);
      }
    }, 5000);
  }

  async stop() {
    this.logger.info('Stopping API Server...');
    
    if (this.io) {
      this.io.close();
    }
    
    if (this.server) {
      await new Promise((resolve) => this.server.close(resolve));
    }
    
    this.logger.info('API Server stopped');
  }
}

module.exports = APIServer;