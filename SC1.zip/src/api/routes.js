const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

module.exports = (bot) => {
  // Middleware untuk API authentication
  const apiAuth = (req, res, next) => {
    const apiKey = req.headers['x-api-key'];
    const token = req.headers['authorization'];

    // Check API key
    if (apiKey && apiKey === process.env.API_KEY) {
      return next();
    }

    // Check JWT token
    if (token) {
      try {
        const decoded = jwt.verify(token.replace('Bearer ', ''), process.env.JWT_SECRET);
        req.user = decoded;
        return next();
      } catch (error) {
        return res.status(401).json({ error: 'Invalid token' });
      }
    }

    return res.status(401).json({ error: 'Unauthorized' });
  };

  // Admin only middleware
  const adminAuth = async (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const User = bot.managers.database.models.User;
    const user = await User.findOne({ userId: req.user.userId });

    if (!user || !['owner', 'developer', 'admin'].includes(user.role)) {
      return res.status(403).json({ error: 'Admin access required' });
    }

    next();
  };

  // Health check
  router.get('/health', (req, res) => {
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: '1.0.0',
      environment: process.env.NODE_ENV
    });
  });

  // Bot status
  router.get('/status', apiAuth, (req, res) => {
    const stats = bot.services.statistics.getStats();
    
    res.json({
      bot: {
        running: bot.isRunning,
        username: process.env.BOT_USERNAME,
        uptime: bot.formatUptime()
      },
      system: {
        memory: process.memoryUsage(),
        cpu: process.cpuUsage(),
        uptime: process.uptime()
      },
      stats
    });
  });

  // Dashboard stats
  router.get('/dashboard', apiAuth, adminAuth, async (req, res) => {
    try {
      const stats = await bot.services.statistics.getDashboardStats();
      const queueStats = bot.managers.queue.getStats();
      const smtpStats = bot.services.smtp.getStats();
      
      res.json({
        success: true,
        data: {
          stats,
          queue: queueStats,
          smtp: smtpStats
        }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get all users
  router.get('/users', apiAuth, adminAuth, async (req, res) => {
    try {
      const { page = 1, limit = 20, role, search } = req.query;
      const User = bot.managers.database.models.User;
      
      const query = {};
      if (role) query.role = role;
      if (search) {
        query.$or = [
          { username: { $regex: search, $options: 'i' } },
          { fullName: { $regex: search, $options: 'i' } },
          { userId: parseInt(search) || 0 }
        ];
      }

      const users = await User.find(query)
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(parseInt(limit));

      const total = await User.countDocuments(query);

      res.json({
        success: true,
        data: {
          users,
          pagination: {
            page: parseInt(page),
            limit: parseInt(limit),
            total,
            pages: Math.ceil(total / limit)
          }
        }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get user details
  router.get('/users/:userId', apiAuth, adminAuth, async (req, res) => {
    try {
      const User = bot.managers.database.models.User;
      const user = await User.findOne({ userId: parseInt(req.params.userId) });

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      res.json({ success: true, data: user });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Update user
  router.put('/users/:userId', apiAuth, adminAuth, async (req, res) => {
    try {
      const User = bot.managers.database.models.User;
      const { role, isBanned, banReason, membershipExpiry } = req.body;

      const update = {};
      if (role) update.role = role;
      if (isBanned !== undefined) update.isBanned = isBanned;
      if (banReason) update.banReason = banReason;
      if (membershipExpiry) update.membershipExpiry = new Date(membershipExpiry);

      const user = await User.findOneAndUpdate(
        { userId: parseInt(req.params.userId) },
        update,
        { new: true }
      );

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      res.json({ success: true, data: user });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get payments
  router.get('/payments', apiAuth, adminAuth, async (req, res) => {
    try {
      const { page = 1, limit = 20, status } = req.query;
      const Payment = bot.managers.database.models.Payment;
      
      const query = {};
      if (status) query.status = status;

      const payments = await Payment.find(query)
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(parseInt(limit));

      const total = await Payment.countDocuments(query);

      res.json({
        success: true,
        data: {
          payments,
          pagination: {
            page: parseInt(page),
            limit: parseInt(limit),
            total,
            pages: Math.ceil(total / limit)
          }
        }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get SMTP configs
  router.get('/smtp', apiAuth, adminAuth, async (req, res) => {
    try {
      const SMTPConfig = bot.managers.database.models.SMTPConfig;
      const configs = await SMTPConfig.find().sort({ addedAt: -1 });

      res.json({ success: true, data: configs });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Add SMTP config
  router.post('/smtp', apiAuth, adminAuth, async (req, res) => {
    try {
      const { host, port, secure, username, password, type } = req.body;

      const SMTPConfig = bot.managers.database.models.SMTPConfig;
      const config = new SMTPConfig({
        userId: req.user.userId,
        type: type || 'owner',
        host,
        port,
        secure: secure || false,
        username,
        password: bot.services.smtp.encryptPassword(password),
        status: 'active',
        addedBy: req.user.userId
      });

      await config.save();
      await bot.services.smtp.createTransporter(config);

      res.json({ success: true, data: config });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Send broadcast
  router.post('/broadcast', apiAuth, adminAuth, async (req, res) => {
    try {
      const { message, userIds, role } = req.body;

      if (!message) {
        return res.status(400).json({ error: 'Message is required' });
      }

      const User = bot.managers.database.models.User;
      let query = {};

      if (userIds && Array.isArray(userIds)) {
        query.userId = { $in: userIds };
      } else if (role) {
        query.role = role;
      } else {
        query.role = { $ne: 'banned' };
      }

      const users = await User.find(query);
      let successCount = 0;
      let failCount = 0;

      for (const user of users) {
        try {
          await bot.bot.telegram.sendMessage(user.userId, `📢 *BROADCAST*\n\n${message}`, {
            parse_mode: 'Markdown'
          });
          successCount++;
        } catch (error) {
          failCount++;
        }
      }

      res.json({
        success: true,
        data: {
          totalUsers: users.length,
          successCount,
          failCount
        }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get queue status
  router.get('/queue', apiAuth, adminAuth, (req, res) => {
    const queueStats = bot.managers.queue.getStats();
    res.json({ success: true, data: queueStats });
  });

  // Clear queue
  router.delete('/queue', apiAuth, adminAuth, async (req, res) => {
    try {
      const count = await bot.managers.queue.clearQueue();
      res.json({ success: true, data: { cleared: count } });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get logs
  router.get('/logs', apiAuth, adminAuth, async (req, res) => {
    try {
      const { type, level, limit = 50 } = req.query;
      const Log = bot.managers.database.models.Log;
      
      const query = {};
      if (type) query.type = type;
      if (level) query.level = level;

      const logs = await Log.find(query)
        .sort({ timestamp: -1 })
        .limit(parseInt(limit));

      res.json({ success: true, data: logs });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Backup
  router.post('/backup', apiAuth, adminAuth, async (req, res) => {
    try {
      const backupFile = await bot.managers.database.backup();
      res.json({ success: true, data: { file: backupFile } });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Restore
  router.post('/restore', apiAuth, adminAuth, async (req, res) => {
    try {
      const { file } = req.body;
      
      if (!file) {
        return res.status(400).json({ error: 'Backup file name required' });
      }

      await bot.managers.database.restore(file);
      res.json({ success: true, message: 'Restore completed' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Maintenance mode
  router.post('/maintenance', apiAuth, adminAuth, async (req, res) => {
    try {
      const { enabled } = req.body;
      
      await bot.configManager.set('bot.maintenance_mode', enabled);
      
      res.json({
        success: true,
        data: { maintenance_mode: enabled }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Reload config
  router.post('/reload', apiAuth, adminAuth, async (req, res) => {
    try {
      await bot.configManager.reload();
      res.json({ success: true, message: 'Config reloaded' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get statistics
  router.get('/statistics', apiAuth, async (req, res) => {
    try {
      const stats = await bot.services.statistics.getDashboardStats();
      res.json({ success: true, data: stats });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get leaderboard
  router.get('/leaderboard/:type', apiAuth, async (req, res) => {
    try {
      const { type } = req.params;
      const { limit = 10 } = req.query;
      
      const leaderboard = await bot.services.leaderboard.formatLeaderboardMessage(
        type,
        parseInt(limit)
      );
      
      res.json({ success: true, data: leaderboard });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Generate API token
  router.post('/auth/token', apiAuth, (req, res) => {
    const { userId } = req.body;
    
    if (!userId) {
      return res.status(400).json({ error: 'User ID required' });
    }

    const token = jwt.sign(
      { userId },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({ success: true, data: { token } });
  });

  // Webhook endpoint (for payment gateway callbacks)
  router.post('/webhook/payment', async (req, res) => {
    try {
      const { orderId, status, transactionId } = req.body;

      if (status === 'paid') {
        await bot.services.payment.verifyPayment({
          orderId,
          transactionId
        });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Socket.IO stats endpoint
  router.get('/realtime', (req, res) => {
    res.json({
      socket: {
        enabled: !!bot.io,
        clients: bot.io?.engine?.clientsCount || 0
      }
    });
  });

  return router;
};