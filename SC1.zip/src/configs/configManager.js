const fs = require('fs').promises;
const path = require('path');
const EventEmitter = require('events');

class ConfigManager extends EventEmitter {
  constructor(bot) {
    super();
    this.bot = bot;
    this.logger = bot?.logger;
    this.configs = {};
    this.configPath = path.join(__dirname, '../../');
    this.watchers = new Map();
    this.isLoaded = false;
  }

  async loadConfigs() {
    try {
      this.logger?.info('Loading configurations...');

      // Load all config files
      await this.loadConfig('config.json', 'bot');
      await this.loadConfig('permissions.json', 'permissions');
      await this.loadConfig('settings.json', 'settings');
      await this.loadConfig('smtp.json', 'smtp');
      await this.loadConfig('templates.json', 'templates');

      // Load environment variables
      this.loadEnvConfig();

      this.isLoaded = true;
      this.logger?.info('Configurations loaded successfully');
      
      // Start watching for changes
      this.startWatching();

      this.emit('config:loaded', this.configs);
    } catch (error) {
      this.logger?.error('Failed to load configurations:', error);
      throw error;
    }
  }

  async loadConfig(filename, key) {
    try {
      const filePath = path.join(this.configPath, filename);
      const data = await fs.readFile(filePath, 'utf8');
      this.configs[key] = JSON.parse(data);
      this.logger?.debug(`Loaded config: ${key} from ${filename}`);
    } catch (error) {
      this.logger?.error(`Failed to load config ${filename}:`, error);
      // Set default empty config
      this.configs[key] = {};
    }
  }

  loadEnvConfig() {
    this.configs.env = {
      bot: {
        token: process.env.BOT_TOKEN,
        username: process.env.BOT_USERNAME,
        ownerId: parseInt(process.env.OWNER_ID),
        ownerUsername: process.env.OWNER_USERNAME,
        prefix: process.env.BOT_PREFIX || '/',
        timezone: process.env.BOT_TIMEZONE || 'Asia/Jakarta',
        language: process.env.BOT_LANGUAGE || 'id',
        maintenanceMode: process.env.MAINTENANCE_MODE === 'true',
        debugMode: process.env.DEBUG_MODE === 'true'
      },
      database: {
        mongodbUri: process.env.MONGODB_URI,
        redisHost: process.env.REDIS_HOST,
        redisPort: parseInt(process.env.REDIS_PORT) || 6379,
        redisPassword: process.env.REDIS_PASSWORD
      },
      security: {
        jwtSecret: process.env.JWT_SECRET,
        encryptionKey: process.env.ENCRYPTION_KEY,
        apiKey: process.env.API_KEY
      },
      channels: {
        verificationGroup: process.env.VERIFICATION_GROUP_1,
        verificationChannel: process.env.VERIFICATION_CHANNEL_1,
        testimonialChannel: process.env.TESTIMONIAL_CHANNEL,
        logChannel: process.env.LOG_CHANNEL,
        paymentChannel: process.env.PAYMENT_CHANNEL
      },
      smtp: {
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT) || 587,
        secure: process.env.SMTP_SECURE === 'true'
      }
    };
  }

  startWatching() {
    const configFiles = ['config.json', 'permissions.json', 'settings.json', 'smtp.json', 'templates.json'];
    
    for (const filename of configFiles) {
      const filePath = path.join(this.configPath, filename);
      
      // Watch for file changes
      try {
        const watcher = fs.watch(filePath, async (eventType) => {
          if (eventType === 'change') {
            const key = filename.replace('.json', '');
            this.logger?.info(`Config file changed: ${filename}`);
            
            // Reload config with small delay to ensure file write is complete
            setTimeout(async () => {
              await this.loadConfig(filename, key);
              this.emit('config:changed', { key, filename });
              
              // Notify owner about config change
              if (this.bot) {
                await this.bot.managers?.notification?.notifyOwner(
                  '🔄 Config Updated',
                  `Config file changed: ${filename}\nKey: ${key}`
                ).catch(() => {});
              }
            }, 1000);
          }
        });
        
        this.watchers.set(filename, watcher);
      } catch (error) {
        this.logger?.warn(`Cannot watch ${filename}: ${error.message}`);
      }
    }
  }

  get(key, defaultValue = null) {
    try {
      const keys = key.split('.');
      let value = this.configs;

      for (const k of keys) {
        if (value && typeof value === 'object' && k in value) {
          value = value[k];
        } else {
          return defaultValue;
        }
      }

      return value !== undefined ? value : defaultValue;
    } catch (error) {
      return defaultValue;
    }
  }

  async set(key, value) {
    try {
      const keys = key.split('.');
      const configKey = keys[0];
      
      // Update in-memory config
      let target = this.configs[configKey];
      if (!target) {
        this.configs[configKey] = {};
        target = this.configs[configKey];
      }

      // Navigate to nested key
      for (let i = 1; i < keys.length - 1; i++) {
        if (!target[keys[i]]) {
          target[keys[i]] = {};
        }
        target = target[keys[i]];
      }

      target[keys[keys.length - 1]] = value;

      // Save to file
      const filename = `${configKey}.json`;
      const filePath = path.join(this.configPath, filename);
      
      // Temporarily unwatch file
      const watcher = this.watchers.get(filename);
      if (watcher) {
        watcher.close();
      }

      await fs.writeFile(filePath, JSON.stringify(this.configs[configKey], null, 2), 'utf8');

      // Rewatch file
      this.watchers.delete(filename);
      this.startWatching();

      this.emit('config:updated', { key, value });
      
      return true;
    } catch (error) {
      this.logger?.error(`Failed to set config ${key}:`, error);
      return false;
    }
  }

  async updateConfig(section, updates) {
    try {
      const current = this.configs[section] || {};
      this.configs[section] = { ...current, ...updates };

      // Save to file
      const filename = `${section}.json`;
      const filePath = path.join(this.configPath, filename);
      
      await fs.writeFile(filePath, JSON.stringify(this.configs[section], null, 2), 'utf8');

      this.emit('config:updated', { section, updates });
      
      return true;
    } catch (error) {
      this.logger?.error(`Failed to update config ${section}:`, error);
      return false;
    }
  }

  getPermissions() {
    return this.configs.permissions || {};
  }

  getRolePermissions(role) {
    const permissions = this.configs.permissions;
    return permissions?.roles?.[role]?.permissions || [];
  }

  hasPermission(role, permission) {
    const permissions = this.getRolePermissions(role);
    return permissions.includes(permission) || permissions.includes('all');
  }

  getSettings() {
    return this.configs.settings || {};
  }

  getBotSettings() {
    return this.configs.settings?.bot_settings || {};
  }

  getVerificationGroups() {
    return this.configs.settings?.verification?.groups || [];
  }

  getMenuButtons() {
    return this.configs.settings?.bot_settings?.menu?.buttons || [];
  }

  async updateMenuButton(buttonId, updates) {
    const buttons = this.getMenuButtons();
    const index = buttons.findIndex(b => b.id === buttonId);
    
    if (index !== -1) {
      buttons[index] = { ...buttons[index], ...updates };
      await this.set('settings.bot_settings.menu.buttons', buttons);
      return true;
    }
    
    return false;
  }

  async addMenuButton(button) {
    const buttons = this.getMenuButtons();
    buttons.push(button);
    await this.set('settings.bot_settings.menu.buttons', buttons);
    return true;
  }

  async removeMenuButton(buttonId) {
    const buttons = this.getMenuButtons().filter(b => b.id !== buttonId);
    await this.set('settings.bot_settings.menu.buttons', buttons);
    return true;
  }

  getTemplateById(templateId) {
    return this.configs.templates?.templates?.[templateId] || null;
  }

  getTemplatesByCountry(country) {
    const templates = this.configs.templates?.templates || {};
    return Object.values(templates).filter(t => t.country === country || t.country === 'all');
  }

  async addTemplate(template) {
    const templates = this.configs.templates?.templates || {};
    templates[template.id] = template;
    await this.set('templates.templates', templates);
    return true;
  }

  async updateTemplate(templateId, updates) {
    const templates = this.configs.templates?.templates || {};
    
    if (templates[templateId]) {
      templates[templateId] = { ...templates[templateId], ...updates };
      await this.set('templates.templates', templates);
      return true;
    }
    
    return false;
  }

  async deleteTemplate(templateId) {
    const templates = this.configs.templates?.templates || {};
    delete templates[templateId];
    await this.set('templates.templates', templates);
    return true;
  }

  getSMTPSettings() {
    return this.configs.smtp || {};
  }

  async addSMTPConfig(userId, smtpConfig) {
    const smtp = this.configs.smtp || {};
    const pool = smtpConfig.type === 'shared' ? 'shared' : 'premium';
    
    if (!smtp.smtp_pools) smtp.smtp_pools = {};
    if (!smtp.smtp_pools[pool]) smtp.smtp_pools[pool] = [];
    
    smtp.smtp_pools[pool].push({
      ...smtpConfig,
      userId,
      addedAt: new Date().toISOString()
    });
    
    await this.set('smtp', smtp);
    return true;
  }

  async removeSMTPConfig(smtpId) {
    const smtp = this.configs.smtp || {};
    
    for (const pool of Object.keys(smtp.smtp_pools || {})) {
      smtp.smtp_pools[pool] = smtp.smtp_pools[pool].filter(
        s => s.id !== smtpId && s._id !== smtpId
      );
    }
    
    await this.set('smtp', smtp);
    return true;
  }

  getPaymentPackages() {
    return this.configs.packages || [];
  }

  async updatePackage(packageId, updates) {
    const packages = this.configs.packages || [];
    const index = packages.findIndex(p => p.packageId === packageId);
    
    if (index !== -1) {
      packages[index] = { ...packages[index], ...updates };
      await this.set('packages', packages);
      return true;
    }
    
    return false;
  }

  getAll() {
    return this.configs;
  }

  async reload() {
    await this.loadConfigs();
    this.emit('config:reloaded', this.configs);
  }

  stopWatching() {
    for (const [filename, watcher] of this.watchers) {
      watcher.close();
    }
    this.watchers.clear();
  }
}

module.exports = ConfigManager;