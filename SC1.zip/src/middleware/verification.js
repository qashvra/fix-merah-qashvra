const verificationMiddleware = (bot) => {
  return async (ctx, next) => {
    try {
      // Skip verification for owner
      const ownerId = parseInt(process.env.OWNER_ID);
      if (ctx.from.id === ownerId) {
        return next();
      }

      // Skip verification for certain commands
      const skipCommands = ['/start', '/verify', '/help'];
      if (ctx.message?.text && skipCommands.includes(ctx.message.text.split(' ')[0])) {
        return next();
      }

      // Check if verification is enabled
      const verificationEnabled = bot.configManager.get('verification.enabled');
      if (!verificationEnabled) {
        return next();
      }

      // Check if user is verified
      const User = bot.managers.database.models.User;
      const user = await User.findOne({ userId: ctx.from.id });

      if (!user || !user.isVerified) {
        // Check verification status
        const isVerified = await checkUserVerification(bot, ctx.from.id);
        
        if (!isVerified) {
          await ctx.reply(
            '⚠️ *VERIFIKASI DIPERLUKAN*\n\n' +
            'Anda harus bergabung dengan channel/group berikut untuk menggunakan bot ini:\n\n' +
            '1. @qashvra_group\n' +
            '2. @qashvra_channel\n\n' +
            'Setelah bergabung, klik tombol di bawah:',
            {
              parse_mode: 'Markdown',
              reply_markup: {
                inline_keyboard: [
                  [
                    { text: '📢 JOIN GROUP', url: 'https://t.me/qashvra_group' },
                    { text: '📢 JOIN CHANNEL', url: 'https://t.me/qashvra_channel' }
                  ],
                  [
                    { text: '✅ CEK VERIFIKASI', callback_data: 'check_verification' }
                  ]
                ]
              }
            }
          );
          return;
        }

        // User is verified, update database
        if (user) {
          user.isVerified = true;
          await user.save();
        }
      }

      return next();

    } catch (error) {
      bot.logger.error('Verification middleware error:', error);
      return next();
    }
  };
};

async function checkUserVerification(bot, userId) {
  try {
    const verificationGroups = bot.configManager.get('verification.groups') || [];
    
    for (const group of verificationGroups) {
      if (!group.required) continue;
      
      try {
        const chatId = group.id;
        
        // Check if user is member of the group/channel
        const member = await bot.bot.telegram.getChatMember(chatId, userId);
        
        const validStatuses = ['member', 'administrator', 'creator'];
        
        if (!validStatuses.includes(member.status)) {
          return false;
        }
      } catch (error) {
        // If bot can't check the group, assume user is not a member
        if (error.description?.includes('user not found') || 
            error.description?.includes('chat not found')) {
          return false;
        }
        bot.logger.warn(`Verification check failed for ${group.id}: ${error.message}`);
      }
    }
    
    return true;
    
  } catch (error) {
    bot.logger.error('Failed to check user verification:', error);
    return false;
  }
}

module.exports = { verificationMiddleware };