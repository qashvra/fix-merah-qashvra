const { authMiddleware } = require('./auth');
const { maintenanceMiddleware } = require('./maintenance');
const { verificationMiddleware } = require('./verification');
const RateLimitMiddleware = require('./rateLimit');
const SecurityManager = require('../services/security/SecurityManager');

class MiddlewareHandler {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    this.rateLimiter = new RateLimitMiddleware(bot);
    this.security = new SecurityManager(bot);
  }

  registerMiddleware() {
    this.logger.info('Registering middleware...');

    // 1. Error handler (outermost)
    this.bot.bot.use(async (ctx, next) => {
      try {
        await next();
      } catch (error) {
        this.logger.error('Unhandled error:', error);
        
        // Notify owner
        if (error.message && !error.message.includes('403')) {
          await this.bot.managers.notification.notifyOwner(
            '⚠️ Bot Error',
            `Error: ${error.message}\nUser: ${ctx.from?.id}\nAction: ${ctx.updateType}`
          );
        }

        // Reply to user
        await ctx.reply(
          '⚠️ Terjadi kesalahan internal. Tim kami telah diberitahu.',
          { parse_mode: 'Markdown' }
        ).catch(() => {});
      }
    });

    // 2. Auth middleware
    this.bot.bot.use(authMiddleware(this.bot));

    // 3. Maintenance middleware
    this.bot.bot.use(maintenanceMiddleware(this.bot));

    // 4. Rate limiting (general)
    this.bot.bot.use(this.rateLimiter.generalLimit());

    // 5. Anti-spam
    this.bot.bot.use(this.rateLimiter.antiSpam());

    // 6. Security checks
    this.bot.bot.use(async (ctx, next) => {
      await this.security.checkRequest(ctx);
      return next();
    });

    // 7. Verification middleware (for certain actions)
    this.bot.bot.use(async (ctx, next) => {
      // Only apply verification for non-start commands
      const messageText = ctx.message?.text || '';
      const callbackData = ctx.callbackQuery?.data || '';

      if (!messageText.startsWith('/start') && 
          !messageText.startsWith('/verify') &&
          callbackData !== 'check_verification') {
        return verificationMiddleware(this.bot)(ctx, next);
      }

      return next();
    });

    // 8. Request logging
    this.bot.bot.use(async (ctx, next) => {
      const start = Date.now();
      await next();
      const ms = Date.now() - start;
      
      // Log slow requests
      if (ms > 1000) {
        this.logger.warn(`Slow request: ${ms}ms - ${ctx.updateType}`);
      }
    });

    this.logger.info('Middleware registered successfully');
  }

  getRateLimiter() {
    return this.rateLimiter;
  }

  getSecurity() {
    return this.security;
  }
}

module.exports = MiddlewareHandler;