const maintenanceMiddleware = (bot) => {
  return async (ctx, next) => {
    try {
      const userId = ctx.from?.id;
      
      // Skip for owner and admins
      const privilegedRoles = ['owner', 'developer', 'partner', 'admin'];
      const User = bot.managers.database.models.User;
      const user = await User.findOne({ userId });
      
      if (user && privilegedRoles.includes(user.role)) {
        return next();
      }

      // Check maintenance mode
      const maintenanceMode = bot.configManager.get('bot.maintenance_mode');
      
      if (maintenanceMode) {
        const maintenanceMessage = bot.configManager.get('bot.maintenance_message') || 
          '🔧 *MAINTENANCE MODE*\n\n' +
          'Bot sedang dalam pemeliharaan.\n' +
          'Silakan coba lagi nanti.\n\n' +
          'Terima kasih atas pengertian Anda.';

        await ctx.reply(maintenanceMessage, {
          parse_mode: 'Markdown'
        });
        return;
      }

      return next();

    } catch (error) {
      bot.logger.error('Maintenance middleware error:', error);
      return next();
    }
  };
};

module.exports = { maintenanceMiddleware };