const { RateLimiterMemory } = require('rate-limiter-flexible');

class RateLimitMiddleware {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    
    // General rate limiter
    this.generalLimiter = new RateLimiterMemory({
      points: 30, // 30 requests
      duration: 60, // per 60 seconds
      blockDuration: 30 // block for 30 seconds if exceeded
    });

    // Fix Merah rate limiter
    this.fixLimiter = new RateLimiterMemory({
      points: 5,
      duration: 60,
      blockDuration: 120
    });

    // Payment rate limiter
    this.paymentLimiter = new RateLimiterMemory({
      points: 10,
      duration: 60,
      blockDuration: 60
    });

    // Anti-spam limiter
    this.spamLimiter = new RateLimiterMemory({
      points: 10,
      duration: 10,
      blockDuration: 300
    });

    // Track violations
    this.violations = new Map();
  }

  generalLimit() {
    return async (ctx, next) => {
      try {
        const userId = ctx.from?.id;
        
        if (!userId) {
          return next();
        }

        // Skip for owner
        if (userId === parseInt(process.env.OWNER_ID)) {
          return next();
        }

        await this.generalLimiter.consume(userId);
        return next();

      } catch (rejRes) {
        if (rejRes instanceof Error) {
          throw rejRes;
        }

        const secs = Math.round(rejRes.msBeforeNext / 1000) || 1;
        
        await ctx.reply(
          `⚠️ *RATE LIMIT*\n\n` +
          `Terlalu banyak request. Silakan tunggu ${secs} detik.`,
          { parse_mode: 'Markdown' }
        ).catch(() => {});
      }
    };
  }

  fixLimit() {
    return async (ctx, next) => {
      try {
        const userId = ctx.from?.id;
        
        if (!userId) {
          return next();
        }

        // Skip for owner
        if (userId === parseInt(process.env.OWNER_ID)) {
          return next();
        }

        await this.fixLimiter.consume(userId);
        return next();

      } catch (rejRes) {
        if (rejRes instanceof Error) {
          throw rejRes;
        }

        await ctx.reply(
          '⚠️ Terlalu banyak request fix merah. Silakan tunggu.',
          { parse_mode: 'Markdown' }
        ).catch(() => {});
      }
    };
  }

  paymentLimit() {
    return async (ctx, next) => {
      try {
        const userId = ctx.from?.id;
        
        if (!userId) {
          return next();
        }

        await this.paymentLimiter.consume(userId);
        return next();

      } catch (rejRes) {
        if (rejRes instanceof Error) {
          throw rejRes;
        }

        await ctx.reply(
          '⚠️ Terlalu banyak request payment. Silakan tunggu.',
          { parse_mode: 'Markdown' }
        ).catch(() => {});
      }
    };
  }

  antiSpam() {
    return async (ctx, next) => {
      try {
        const userId = ctx.from?.id;
        
        if (!userId) {
          return next();
        }

        // Skip for owner
        if (userId === parseInt(process.env.OWNER_ID)) {
          return next();
        }

        await this.spamLimiter.consume(userId);

        // Check for repeated messages
        const messageText = ctx.message?.text;
        if (messageText) {
          const key = `${userId}:${messageText}`;
          const count = this.violations.get(key) || 0;
          
          if (count > 5) {
            // Potential spam
            this.logger.warn(`Spam detected from user ${userId}: "${messageText}"`);
            
            await ctx.reply(
              '⚠️ *SPAM DETECTED*\n\n' +
              'Anda mengirim pesan yang sama berulang kali.\n' +
              'Akun Anda akan dibatasi sementara.',
              { parse_mode: 'Markdown' }
            ).catch(() => {});

            // Temporarily ban from fix feature
            const User = this.bot.managers.database.models.User;
            await User.findOneAndUpdate(
              { userId },
              { spamCount: (count + 1), lastSpamAt: new Date() }
            );

            return;
          }

          this.violations.set(key, count + 1);
          
          // Clear after 1 minute
          setTimeout(() => {
            this.violations.delete(key);
          }, 60000);
        }

        return next();

      } catch (rejRes) {
        if (rejRes instanceof Error) {
          throw rejRes;
        }

        await ctx.reply(
          '🚫 *ANTI SPAM*\n\n' +
          'Anda telah diblokir sementara karena spam.',
          { parse_mode: 'Markdown' }
        ).catch(() => {});
      }
    };
  }

  async checkUserViolations(userId) {
    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });

    if (user && user.spamCount > 10) {
      // Auto-ban user for spam
      user.isBanned = true;
      user.banReason = 'Auto-ban: Excessive spam';
      user.role = 'banned';
      await user.save();

      this.logger.warn(`User ${userId} auto-banned for spam`);
      return true;
    }

    return false;
  }

  getStats() {
    return {
      general: this.generalLimiter,
      fix: this.fixLimiter,
      payment: this.paymentLimiter,
      spam: this.spamLimiter,
      violations: this.violations.size
    };
  }
}

module.exports = RateLimitMiddleware;