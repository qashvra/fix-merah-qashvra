const authMiddleware = (bot) => {
  return async (ctx, next) => {
    try {
      const userId = ctx.from?.id;
      
      if (!userId) {
        return;
      }

      // Check if user exists
      const User = bot.managers.database.models.User;
      let user = await User.findOne({ userId });

      if (!user) {
        // Auto-register user
        user = new User({
          userId,
          username: ctx.from.username || `user_${userId}`,
          firstName: ctx.from.first_name || '',
          lastName: ctx.from.last_name || '',
          fullName: [ctx.from.first_name, ctx.from.last_name].filter(Boolean).join(' ') || `User ${userId}`,
          language: ctx.from.language_code || 'id',
          role: userId === parseInt(process.env.OWNER_ID) ? 'owner' : 'free',
          referralCode: generateReferralCode(userId),
          createdAt: new Date(),
          updatedAt: new Date()
        });

        await user.save();
      }

      // Update user activity
      user.lastActive = new Date();
      await user.save().catch(() => {});

      // Attach user to context
      ctx.state.user = user;

      // Check if user is banned
      if (user.isBanned || user.role === 'banned') {
        // Allow only certain commands for banned users
        const allowedCommands = ['/start', '/help'];
        const messageText = ctx.message?.text || '';
        
        if (!allowedCommands.some(cmd => messageText.startsWith(cmd))) {
          await ctx.reply(
            '🚫 *AKUN DIBANNED*\n\n' +
            `Alasan: ${user.banReason || 'Tidak ada alasan'}\n\n` +
            'Hubungi @qashvra untuk banding.',
            { parse_mode: 'Markdown' }
          );
          return;
        }
      }

      // Check membership expiry
      if (user.membershipExpiry && new Date() > user.membershipExpiry) {
        user.role = 'free';
        user.membershipExpiry = null;
        await user.save();
        
        // Notify user
        try {
          await ctx.reply(
            '⚠️ *MASA PREMIUM BERAKHIR*\n\n' +
            'Masa premium Anda telah berakhir.\n' +
            'Upgrade kembali untuk menikmati fitur premium.',
            { parse_mode: 'Markdown' }
          );
        } catch (error) {
          bot.logger.warn(`Failed to notify expired membership for ${userId}`);
        }
      }

      return next();

    } catch (error) {
      bot.logger.error('Auth middleware error:', error);
      return next();
    }
  };
};

function generateReferralCode(userId) {
  const hash = Buffer.from(userId.toString()).toString('base64').substring(0, 8);
  return `REF${hash}`;
}

module.exports = { authMiddleware };