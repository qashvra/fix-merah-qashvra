class KeyboardBuilder {
  constructor() {
    this.buttons = [];
    this.currentRow = [];
    this.maxButtonsPerRow = 2;
  }

  /**
   * Add a button to the current row
   */
  addButton(text, callbackData, style = 'default') {
    const button = this.createButton(text, callbackData, style);
    this.currentRow.push(button);
    return this;
  }

  /**
   * Add a URL button
   */
  addUrlButton(text, url) {
    this.currentRow.push({
      text,
      url
    });
    return this;
  }

  /**
   * Add a row of buttons
   */
  addRow(buttons) {
    this.buttons.push(buttons);
    return this;
  }

  /**
   * End current row and start new row
   */
  newRow() {
    if (this.currentRow.length > 0) {
      this.buttons.push([...this.currentRow]);
      this.currentRow = [];
    }
    return this;
  }

  /**
   * Build the final keyboard
   */
  build() {
    // Add any remaining buttons
    if (this.currentRow.length > 0) {
      this.buttons.push([...this.currentRow]);
      this.currentRow = [];
    }

    return {
      inline_keyboard: this.buttons
    };
  }

  /**
   * Create a button object
   */
  createButton(text, callbackData, style = 'default') {
    const styleEmojis = {
      default: '',
      primary: '✨ ',
      danger: '⚠️ ',
      success: '✅ ',
      warning: '⚡ ',
      info: 'ℹ️ ',
      premium: '💎 '
    };

    return {
      text: `${styleEmojis[style] || ''}${text}`,
      callback_data: callbackData
    };
  }

  /**
   * Build main menu keyboard
   */
  static buildMainMenu(role = 'free') {
    const builder = new KeyboardBuilder();

    builder.addRow([
      { text: '🛠️ FIX MERAH', callback_data: 'menu_fix_merah' },
      { text: '👑 VIP / VVIP', callback_data: 'menu_vip_vvip' }
    ]);

    builder.addRow([
      { text: '🎁 REFERRAL', callback_data: 'menu_referral' },
      { text: '📜 RIWAYAT', callback_data: 'menu_history' }
    ]);

    builder.addRow([
      { text: '🏆 TOP GLOBAL', callback_data: 'menu_leaderboard' },
      { text: '✅ TESTIMONI', callback_data: 'menu_testimoni' }
    ]);

    builder.addRow([
      { text: '⚙️ SETTINGS', callback_data: 'menu_settings' },
      { text: '👤 PROFILE', callback_data: 'menu_profile' }
    ]);

    // Add owner panel for privileged users
    const privilegedRoles = ['owner', 'developer', 'partner', 'admin'];
    if (privilegedRoles.includes(role)) {
      builder.addRow([
        { text: '🔧 OWNER PANEL', callback_data: 'menu_owner_panel' }
      ]);
    }

    return builder.build();
  }

  /**
   * Build Fix Merah menu
   */
  static buildFixMerahMenu() {
    const builder = new KeyboardBuilder();

    builder.addRow([
      { text: '🔄 FIX LAGI', callback_data: 'menu_fix_merah' },
      { text: '📜 RIWAYAT', callback_data: 'menu_history' }
    ]);

    builder.addRow([
      { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
    ]);

    return builder.build();
  }

  /**
   * Build VIP menu
   */
  static buildVIPMenu(packages) {
    const builder = new KeyboardBuilder();

    for (const pkg of packages) {
      builder.addRow([
        {
          text: `${pkg.name} - Rp ${pkg.price.toLocaleString('id-ID')}`,
          callback_data: `select_package_${pkg.packageId}`
        }
      ]);
    }

    builder.addRow([
      { text: '🎁 TUKAR DENGAN KOIN', callback_data: 'redeem_vip' }
    ]);

    builder.addRow([
      { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
    ]);

    return builder.build();
  }

  /**
   * Build Referral menu
   */
  static buildReferralMenu(userId) {
    const builder = new KeyboardBuilder();

    builder.addRow([
      { text: '📤 SHARE REFERRAL', switch_inline_query: `start=${userId}` },
      { text: '📊 STATISTIK', callback_data: 'referral_stats' }
    ]);

    builder.addRow([
      { text: '🎁 TUKAR VIP', callback_data: 'redeem_vip' }
    ]);

    builder.addRow([
      { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
    ]);

    return builder.build();
  }

  /**
   * Build Leaderboard menu
   */
  static buildLeaderboardMenu() {
    const builder = new KeyboardBuilder();

    builder.addRow([
      { text: '👥 TOP USERS', callback_data: 'leaderboard_users' },
      { text: '🌍 TOP COUNTRIES', callback_data: 'leaderboard_countries' }
    ]);

    builder.addRow([
      { text: '🔄 REFRESH', callback_data: 'menu_leaderboard' }
    ]);

    builder.addRow([
      { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
    ]);

    return builder.build();
  }

  /**
   * Build Settings menu
   */
  static buildSettingsMenu() {
    const builder = new KeyboardBuilder();

    builder.addRow([
      { text: '🌐 BAHASA', callback_data: 'settings_language' },
      { text: '🎨 TEMA', callback_data: 'settings_theme' }
    ]);

    builder.addRow([
      { text: '🕐 TIMEZONE', callback_data: 'settings_timezone' },
      { text: '🔔 NOTIFIKASI', callback_data: 'settings_notification' }
    ]);

    builder.addRow([
      { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
    ]);

    return builder.build();
  }

  /**
   * Build Language Selection menu
   */
  static buildLanguageMenu() {
    const builder = new KeyboardBuilder();

    builder.addRow([
      { text: '🇮🇩 INDONESIA', callback_data: 'set_language_id' },
      { text: '🇬🇧 ENGLISH', callback_data: 'set_language_en' }
    ]);

    builder.addRow([
      { text: '🇸🇦 ARABIC', callback_data: 'set_language_ar' },
      { text: '🇷🇺 RUSSIAN', callback_data: 'set_language_ru' }
    ]);

    builder.addRow([
      { text: '🔙 KEMBALI', callback_data: 'menu_settings' }
    ]);

    return builder.build();
  }

  /**
   * Build Theme Selection menu
   */
  static buildThemeMenu() {
    const builder = new KeyboardBuilder();

    builder.addRow([
      { text: '🔴 DEFAULT', callback_data: 'set_theme_default' },
      { text: '🔵 BLUE', callback_data: 'set_theme_blue' }
    ]);

    builder.addRow([
      { text: '🟢 GREEN', callback_data: 'set_theme_green' },
      { text: '⚫ DARK', callback_data: 'set_theme_dark' }
    ]);

    builder.addRow([
      { text: '🔙 KEMBALI', callback_data: 'menu_settings' }
    ]);

    return builder.build();
  }

  /**
   * Build Owner Panel menu
   */
  static buildOwnerPanel() {
    const builder = new KeyboardBuilder();

    builder.addRow([
      { text: '📊 DASHBOARD', callback_data: 'owner_dashboard' },
      { text: '📢 BROADCAST', callback_data: 'owner_broadcast' }
    ]);

    builder.addRow([
      { text: '👥 USERS', callback_data: 'owner_users' },
      { text: '📧 SMTP', callback_data: 'owner_smtp' }
    ]);

    builder.addRow([
      { text: '💰 PAYMENTS', callback_data: 'owner_payments' },
      { text: '📋 QUEUE', callback_data: 'owner_queue' }
    ]);

    builder.addRow([
      { text: '🔄 RELOAD CONFIG', callback_data: 'owner_reload' },
      { text: '🔧 MAINTENANCE', callback_data: 'owner_maintenance' }
    ]);

    builder.addRow([
      { text: '💾 BACKUP', callback_data: 'owner_backup' },
      { text: '📥 RESTORE', callback_data: 'owner_restore' }
    ]);

    builder.addRow([
      { text: '🗑️ CLEAR LOGS', callback_data: 'owner_clearlogs' },
      { text: '🧹 CLEAR QUEUE', callback_data: 'owner_clearqueue' }
    ]);

    builder.addRow([
      { text: '🔌 RESTART BOT', callback_data: 'owner_restart' },
      { text: '⚠️ EMERGENCY', callback_data: 'owner_emergency' }
    ]);

    builder.addRow([
      { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
    ]);

    return builder.build();
  }

  /**
   * Build Admin Panel menu
   */
  static buildAdminPanel() {
    const builder = new KeyboardBuilder();

    builder.addRow([
      { text: '👥 MANAGE USERS', callback_data: 'admin_users' },
      { text: '📧 SMTP MANAGER', callback_data: 'admin_smtp' }
    ]);

    builder.addRow([
      { text: '📢 BROADCAST', callback_data: 'admin_broadcast' },
      { text: '📊 STATISTICS', callback_data: 'admin_stats' }
    ]);

    builder.addRow([
      { text: '🔙 BACK', callback_data: 'menu_owner_panel' }
    ]);

    return builder.build();
  }

  /**
   * Build pagination keyboard
   */
  static buildPagination(currentPage, totalPages, callbackPrefix) {
    const builder = new KeyboardBuilder();

    const buttons = [];

    if (currentPage > 1) {
      buttons.push({
        text: '⬅️ PREV',
        callback_data: `${callbackPrefix}_${currentPage - 1}`
      });
    }

    buttons.push({
      text: `${currentPage}/${totalPages}`,
      callback_data: 'noop'
    });

    if (currentPage < totalPages) {
      buttons.push({
        text: 'NEXT ➡️',
        callback_data: `${callbackPrefix}_${currentPage + 1}`
      });
    }

    builder.addRow(buttons);

    builder.addRow([
      { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
    ]);

    return builder.build();
  }

  /**
   * Build confirmation keyboard
   */
  static buildConfirmation(confirmCallback, cancelCallback) {
    const builder = new KeyboardBuilder();

    builder.addRow([
      { text: '✅ YA', callback_data: confirmCallback },
      { text: '❌ TIDAK', callback_data: cancelCallback }
    ]);

    return builder.build();
  }

  /**
   * Build back button only
   */
  static buildBackOnly(backCallback = 'menu_main') {
    const builder = new KeyboardBuilder();

    builder.addRow([
      { text: '🔙 KEMBALI', callback_data: backCallback }
    ]);

    return builder.build();
  }

  /**
   * Build payment method selection
   */
  static buildPaymentMethods(orderId) {
    const builder = new KeyboardBuilder();

    builder.addRow([
      { text: '📱 QRIS', callback_data: `pay_qris_${orderId}` }
    ]);

    builder.addRow([
      { text: '📱 DANA', callback_data: `pay_dana_${orderId}` },
      { text: '📱 GOPAY', callback_data: `pay_gopay_${orderId}` }
    ]);

    builder.addRow([
      { text: '🏦 BANK TRANSFER', callback_data: `pay_bank_${orderId}` }
    ]);

    builder.addRow([
      { text: '❌ BATALKAN', callback_data: `cancel_payment_${orderId}` }
    ]);

    return builder.build();
  }
}

module.exports = KeyboardBuilder;