require('dotenv').config();

const { Telegraf } = require('telegraf');
const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const mongoose = require('mongoose');
const Redis = require('redis');
const { RateLimiterMemory } = require('rate-limiter-flexible');
const winston = require('winston');
const chalk = require('chalk');
const path = require('path');

// Import core modules
const DatabaseManager = require('./database/DatabaseManager');
const ConfigManager = require('./configs/ConfigManager');
const SecurityManager = require('./services/security/SecurityManager');
const QueueManager = require('./services/queue/QueueManager');
const PermissionManager = require('./services/permissions/PermissionManager');
const LoggerService = require('./services/logs/LoggerService');
const NotificationManager = require('./services/notifications/NotificationManager');

// Import services
const SMTPService = require('./services/smtp/SMTPService');
const PaymentService = require('./services/payment/PaymentService');
const QRISGenerator = require('./services/qris/QRISGenerator');
const ReferralService = require('./services/referral/ReferralService');
const StatisticsService = require('./services/statistics/StatisticsService');
const LeaderboardService = require('./services/leaderboard/LeaderboardService');

// Import handlers
const CommandHandler = require('./handlers/CommandHandler');
const CallbackHandler = require('./handlers/CallbackHandler');
const MessageHandler = require('./handlers/MessageHandler');
const MiddlewareHandler = require('./middleware/MiddlewareHandler');

// Import middleware
const { authMiddleware } = require('./middleware/auth');
const { rateLimitMiddleware } = require('./middleware/rateLimit');
const { maintenanceMiddleware } = require('./middleware/maintenance');
const { verificationMiddleware } = require('./middleware/verification');

class QashvraBot {
  constructor() {
    this.bot = null;
    this.app = null;
    this.server = null;
    this.io = null;
    this.redis = null;
    this.isRunning = false;
    this.startTime = null;
    
    this.services = {};
    this.managers = {};
    
    this.initialize();
  }

  async initialize() {
    try {
      console.log(chalk.red.bold(`
╔══════════════════════════════════════════════════════╗
║           QASHVRA FIX MERAH PRO v1.0.0              ║
║         Enterprise Telegram Bot Automation           ║
║                 Starting System...                   ║
╚══════════════════════════════════════════════════════╝
      `));

      // Initialize Logger
      this.logger = new LoggerService();
      this.logger.info('Initializing Qashvra Bot System...');

      // Initialize Config Manager
      this.configManager = new ConfigManager();
      await this.configManager.loadConfigs();

      // Connect to MongoDB
      await this.connectMongoDB();

      // Connect to Redis
      await this.connectRedis();

      // Initialize Express
      await this.initializeExpress();

      // Initialize Managers
      await this.initializeManagers();

      // Initialize Services
      await this.initializeServices();

      // Initialize Bot
      await this.initializeBot();

      // Initialize Handlers
      await this.initializeHandlers();

      // Start Auto Backup
      await this.startAutoBackup();

      // Start Health Check
      await this.startHealthCheck();

      this.startTime = Date.now();
      this.isRunning = true;

      this.logger.info('Qashvra Bot System started successfully!');
      console.log(chalk.green('✅ System is ready!'));
      
      // Notify Owner
      await this.notifyOwner('System Started', '✅ Qashvra Fix Merah Pro is now running!');

    } catch (error) {
      this.logger.error('Failed to initialize system:', error);
      console.error(chalk.red('❌ System initialization failed:'), error);
      process.exit(1);
    }
  }

  async connectMongoDB() {
    try {
      const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/qashvra_bot';
      
      await mongoose.connect(uri, {
        maxPoolSize: 10,
        serverSelectionTimeoutMS: 5000,
        socketTimeoutMS: 45000,
      });

      this.logger.info('MongoDB connected successfully');
      console.log(chalk.green('✅ MongoDB Connected'));

      mongoose.connection.on('error', (err) => {
        this.logger.error('MongoDB connection error:', err);
      });

      mongoose.connection.on('disconnected', () => {
        this.logger.warn('MongoDB disconnected');
      });

    } catch (error) {
      this.logger.error('MongoDB connection failed:', error);
      throw error;
    }
  }

  async connectRedis() {
    try {
      this.redis = Redis.createClient({
        host: process.env.REDIS_HOST || 'localhost',
        port: process.env.REDIS_PORT || 6379,
        password: process.env.REDIS_PASSWORD || undefined,
        retry_strategy: (options) => {
          if (options.error && options.error.code === 'ECONNREFUSED') {
            return new Error('Redis server refused connection');
          }
          if (options.total_retry_time > 1000 * 60 * 60) {
            return new Error('Retry time exhausted');
          }
          if (options.attempt > 10) {
            return undefined;
          }
          return Math.min(options.attempt * 100, 3000);
        }
      });

      await this.redis.connect();
      this.logger.info('Redis connected successfully');
      console.log(chalk.green('✅ Redis Connected'));

    } catch (error) {
      this.logger.error('Redis connection failed:', error);
      // Redis is optional, don't throw
      console.warn(chalk.yellow('⚠️  Redis not available, continuing without cache'));
    }
  }

  async initializeExpress() {
    try {
      this.app = express();
      this.server = http.createServer(this.app);
      
      // Security middleware
      this.app.use(helmet());
      this.app.use(cors());
      this.app.use(compression());
      this.app.use(express.json({ limit: '10mb' }));
      this.app.use(express.urlencoded({ extended: true }));

      // Health check endpoint
      this.app.get('/health', (req, res) => {
        res.json({
          status: 'healthy',
          timestamp: new Date().toISOString(),
          uptime: process.uptime(),
          bot: this.isRunning ? 'running' : 'stopped'
        });
      });

      // API Routes
      this.app.use('/api', require('./api/routes'));

      // Socket.IO
      this.io = socketIO(this.server, {
        cors: {
          origin: '*',
          methods: ['GET', 'POST']
        }
      });

      this.io.on('connection', (socket) => {
        this.logger.info(`Socket connected: ${socket.id}`);
        
        socket.on('disconnect', () => {
          this.logger.info(`Socket disconnected: ${socket.id}`);
        });
      });

      const port = process.env.PORT || 3000;
      this.server.listen(port, () => {
        this.logger.info(`Express server running on port ${port}`);
        console.log(chalk.green(`✅ Server running on port ${port}`));
      });

    } catch (error) {
      this.logger.error('Express initialization failed:', error);
      throw error;
    }
  }

  async initializeManagers() {
    this.logger.info('Initializing managers...');

    this.managers.database = new DatabaseManager(this);
    this.managers.permission = new PermissionManager(this);
    this.managers.queue = new QueueManager(this);
    this.managers.notification = new NotificationManager(this);
    this.managers.security = new SecurityManager(this);

    await this.managers.queue.initialize();
    await this.managers.permission.initialize();

    this.logger.info('Managers initialized successfully');
  }

  async initializeServices() {
    this.logger.info('Initializing services...');

    this.services.smtp = new SMTPService(this);
    this.services.payment = new PaymentService(this);
    this.services.qris = new QRISGenerator(this);
    this.services.referral = new ReferralService(this);
    this.services.statistics = new StatisticsService(this);
    this.services.leaderboard = new LeaderboardService(this);

    // Initialize all services
    for (const [name, service] of Object.entries(this.services)) {
      if (service.initialize) {
        await service.initialize();
        this.logger.info(`Service ${name} initialized`);
      }
    }

    this.logger.info('Services initialized successfully');
  }

  async initializeBot() {
    try {
      const token = process.env.BOT_TOKEN;
      
      if (!token || token === 'example') {
        throw new Error('Invalid BOT_TOKEN. Please set your bot token in .env file');
      }

      this.bot = new Telegraf(token, {
        telegram: {
          apiRoot: 'https://api.telegram.org',
          timeout: 30000,
          limit: 30
        }
      });

      // Bot middleware
      this.bot.use(async (ctx, next) => {
        try {
          await next();
        } catch (error) {
          this.logger.error('Bot middleware error:', error);
          await ctx.reply('⚠️ An error occurred. Please try again.').catch(() => {});
        }
      });

      this.logger.info('Bot initialized successfully');
      console.log(chalk.green(`✅ Bot @${process.env.BOT_USERNAME} initialized`));

    } catch (error) {
      this.logger.error('Bot initialization failed:', error);
      throw error;
    }
  }

  async initializeHandlers() {
    this.logger.info('Initializing handlers...');

    // Initialize middleware
    const middlewareHandler = new MiddlewareHandler(this);
    middlewareHandler.registerMiddleware();

    // Initialize command handlers
    const commandHandler = new CommandHandler(this);
    commandHandler.registerCommands();

    // Initialize callback handlers
    const callbackHandler = new CallbackHandler(this);
    callbackHandler.registerCallbacks();

    // Initialize message handlers
    const messageHandler = new MessageHandler(this);
    messageHandler.registerHandlers();

    this.logger.info('Handlers initialized successfully');
  }

  async startAutoBackup() {
    const interval = this.configManager.get('backup.interval') || 86400000;
    
    setInterval(async () => {
      try {
        this.logger.info('Starting auto backup...');
        await this.managers.database.backup();
        this.logger.info('Auto backup completed');
      } catch (error) {
        this.logger.error('Auto backup failed:', error);
      }
    }, interval);
  }

  async startHealthCheck() {
    setInterval(async () => {
      try {
        const health = {
          mongodb: mongoose.connection.readyState === 1,
          redis: this.redis ? await this.redis.ping().then(() => true).catch(() => false) : false,
          bot: this.isRunning,
          uptime: process.uptime(),
          memory: process.memoryUsage(),
          timestamp: new Date().toISOString()
        };

        // Emit health status via Socket.IO
        if (this.io) {
          this.io.emit('health', health);
        }

        // Log if any service is unhealthy
        for (const [service, status] of Object.entries(health)) {
          if (status === false) {
            this.logger.warn(`Service ${service} is unhealthy!`);
            await this.notifyOwner('Service Alert', `⚠️ ${service} is down!`);
          }
        }

      } catch (error) {
        this.logger.error('Health check failed:', error);
      }
    }, 30000);
  }

  async notifyOwner(title, message) {
    try {
      const ownerId = process.env.OWNER_ID;
      if (ownerId && this.bot) {
        await this.bot.telegram.sendMessage(
          ownerId,
          `🔔 ${title}\n\n${message}`,
          { parse_mode: 'HTML' }
        );
      }
    } catch (error) {
      this.logger.error('Failed to notify owner:', error);
    }
  }

  async start() {
    if (this.isRunning) {
      this.logger.warn('Bot is already running');
      return;
    }

    try {
      await this.bot.launch();
      this.isRunning = true;
      this.logger.info('Bot launched successfully');
      console.log(chalk.green.bold('🚀 Bot is running!'));
    } catch (error) {
      this.logger.error('Failed to launch bot:', error);
      throw error;
    }
  }

  async stop() {
    this.logger.info('Stopping bot...');
    
    try {
      if (this.bot) {
        await this.bot.stop();
      }
      
      this.isRunning = false;
      
      // Close connections
      await mongoose.disconnect();
      
      if (this.redis) {
        await this.redis.quit();
      }
      
      this.logger.info('Bot stopped successfully');
      process.exit(0);
      
    } catch (error) {
      this.logger.error('Failed to stop bot:', error);
      process.exit(1);
    }
  }

  getUptime() {
    if (!this.startTime) return 0;
    return Date.now() - this.startTime;
  }

  formatUptime() {
    const uptime = this.getUptime();
    const seconds = Math.floor(uptime / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    return `${days}d ${hours % 24}h ${minutes % 60}m ${seconds % 60}s`;
  }
}

// Create and start the bot
const qashvraBot = new QashvraBot();

// Handle process termination
process.on('SIGINT', async () => {
  console.log(chalk.yellow('\n⚠️  Shutting down...'));
  await qashvraBot.stop();
});

process.on('SIGTERM', async () => {
  console.log(chalk.yellow('\n⚠️  Shutting down...'));
  await qashvraBot.stop();
});

process.on('uncaughtException', (error) => {
  console.error(chalk.red('❌ Uncaught Exception:'), error);
  if (qashvraBot.logger) {
    qashvraBot.logger.error('Uncaught Exception:', error);
  }
});

process.on('unhandledRejection', (reason, promise) => {
  console.error(chalk.red('❌ Unhandled Rejection:'), reason);
  if (qashvraBot.logger) {
    qashvraBot.logger.error('Unhandled Rejection:', reason);
  }
});

// Start the bot
qashvraBot.start().catch((error) => {
  console.error(chalk.red('❌ Failed to start bot:'), error);
  process.exit(1);
});

module.exports = QashvraBot;