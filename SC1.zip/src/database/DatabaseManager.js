const mongoose = require('mongoose');
const fs = require('fs').promises;
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

class DatabaseManager {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    this.models = {};
    this.backupPath = path.join(__dirname, '../../backups');
  }

  async initialize() {
    this.logger.info('Initializing Database Manager...');
    
    try {
      // Register all models
      await this.registerModels();
      
      // Create indexes
      await this.createIndexes();
      
      // Ensure backup directory exists
      await fs.mkdir(this.backupPath, { recursive: true });
      
      this.logger.info('Database Manager initialized successfully');
    } catch (error) {
      this.logger.error('Database Manager initialization failed:', error);
      throw error;
    }
  }

  async registerModels() {
    // User Model
    const userSchema = new mongoose.Schema({
      userId: { type: Number, required: true, unique: true },
      username: String,
      firstName: String,
      lastName: String,
      fullName: String,
      language: { type: String, default: 'id' },
      timezone: { type: String, default: 'Asia/Jakarta' },
      theme: { type: String, default: 'default' },
      role: { 
        type: String, 
        enum: ['owner', 'developer', 'partner', 'admin', 'moderator', 'reseller', 'vvip', 'vip', 'free', 'banned'],
        default: 'free'
      },
      membershipExpiry: Date,
      coins: { type: Number, default: 0 },
      totalFix: { type: Number, default: 0 },
      successFix: { type: Number, default: 0 },
      failedFix: { type: Number, default: 0 },
      dailyFixCount: { type: Number, default: 0 },
      lastFixDate: Date,
      isVerified: { type: Boolean, default: false },
      isBanned: { type: Boolean, default: false },
      banReason: String,
      referralCode: String,
      referredBy: Number,
      referralCount: { type: Number, default: 0 },
      smtpConfigs: [{ type: mongoose.Schema.Types.ObjectId, ref: 'SMTPConfig' }],
      createdAt: { type: Date, default: Date.now },
      updatedAt: { type: Date, default: Date.now }
    });

    userSchema.index({ userId: 1 });
    userSchema.index({ role: 1 });
    userSchema.index({ referralCode: 1 });
    userSchema.index({ 'membershipExpiry': 1 }, { expireAfterSeconds: 0 });

    this.models.User = mongoose.model('User', userSchema);

    // Fix History Model
    const fixHistorySchema = new mongoose.Schema({
      userId: { type: Number, required: true },
      phoneNumber: { type: String, required: true },
      bandingId: { type: String, required: true, unique: true },
      status: { 
        type: String, 
        enum: ['pending', 'processing', 'success', 'failed', 'cancelled'],
        default: 'pending'
      },
      smtpUsed: String,
      templateUsed: String,
      attemptCount: { type: Number, default: 1 },
      maxAttempts: { type: Number, default: 3 },
      errorMessage: String,
      processingTime: Number,
      queuePosition: Number,
      priority: { type: Number, default: 4 },
      createdAt: { type: Date, default: Date.now },
      updatedAt: { type: Date, default: Date.now },
      completedAt: Date
    });

    fixHistorySchema.index({ userId: 1, createdAt: -1 });
    fixHistorySchema.index({ bandingId: 1 });
    fixHistorySchema.index({ status: 1 });
    fixHistorySchema.index({ createdAt: -1 });

    this.models.FixHistory = mongoose.model('FixHistory', fixHistorySchema);

    // SMTP Config Model
    const smtpConfigSchema = new mongoose.Schema({
      userId: { type: Number, required: true },
      type: { type: String, enum: ['owner', 'premium', 'shared', 'custom'], default: 'shared' },
      host: { type: String, required: true },
      port: { type: Number, required: true },
      secure: { type: Boolean, default: false },
      username: { type: String, required: true },
      password: { type: String, required: true },
      status: { type: String, enum: ['active', 'failed', 'cooldown', 'disabled'], default: 'active' },
      maxConnections: { type: Number, default: 5 },
      maxMessagesPerHour: { type: Number, default: 100 },
      rateDelta: { type: Number, default: 1000 },
      rateLimit: { type: Number, default: 5 },
      totalSent: { type: Number, default: 0 },
      totalFailed: { type: Number, default: 0 },
      errorMessage: String,
      lastUsed: Date,
      lastCheck: Date,
      cooldownUntil: Date,
      addedBy: { type: Number, required: true },
      addedAt: { type: Date, default: Date.now },
      updatedAt: { type: Date, default: Date.now }
    });

    smtpConfigSchema.index({ userId: 1 });
    smtpConfigSchema.index({ status: 1 });
    smtpConfigSchema.index({ type: 1 });

    this.models.SMTPConfig = mongoose.model('SMTPConfig', smtpConfigSchema);

    // Payment Model
    const paymentSchema = new mongoose.Schema({
      orderId: { type: String, required: true, unique: true },
      userId: { type: Number, required: true },
      packageId: { type: String, required: true },
      packageName: String,
      amount: { type: Number, required: true },
      status: { 
        type: String, 
        enum: ['pending', 'paid', 'expired', 'failed', 'cancelled', 'refunded'],
        default: 'pending'
      },
      paymentMethod: { type: String, default: 'qris' },
      qrisString: String,
      transactionId: String,
      paymentProof: String,
      expiryTime: { type: Date, required: true },
      paidAt: Date,
      verifiedBy: Number,
      notes: String,
      createdAt: { type: Date, default: Date.now },
      updatedAt: { type: Date, default: Date.now }
    });

    paymentSchema.index({ orderId: 1 });
    paymentSchema.index({ userId: 1, createdAt: -1 });
    paymentSchema.index({ status: 1 });
    paymentSchema.index({ expiryTime: 1 }, { expireAfterSeconds: 0 });

    this.models.Payment = mongoose.model('Payment', paymentSchema);

    // Referral Model
    const referralSchema = new mongoose.Schema({
      referrerId: { type: Number, required: true },
      referredId: { type: Number, required: true, unique: true },
      status: { 
        type: String, 
        enum: ['pending', 'active', 'expired'],
        default: 'active'
      },
      coinsEarned: { type: Number, default: 0 },
      level: { type: Number, default: 1 },
      createdAt: { type: Date, default: Date.now }
    });

    referralSchema.index({ referrerId: 1 });
    referralSchema.index({ referredId: 1 });

    this.models.Referral = mongoose.model('Referral', referralSchema);

    // Statistics Model
    const statisticsSchema = new mongoose.Schema({
      date: { type: String, required: true },
      totalUsers: { type: Number, default: 0 },
      newUsers: { type: Number, default: 0 },
      activeUsers: { type: Number, default: 0 },
      totalFix: { type: Number, default: 0 },
      successFix: { type: Number, default: 0 },
      failedFix: { type: Number, default: 0 },
      totalPayments: { type: Number, default: 0 },
      totalRevenue: { type: Number, default: 0 },
      activeSMTP: { type: Number, default: 0 },
      queueSize: { type: Number, default: 0 },
      topCountries: [{
        country: String,
        count: Number
      }],
      hourlyStats: [{
        hour: Number,
        fixes: Number,
        success: Number
      }],
      createdAt: { type: Date, default: Date.now },
      updatedAt: { type: Date, default: Date.now }
    });

    statisticsSchema.index({ date: 1 }, { unique: true });

    this.models.Statistics = mongoose.model('Statistics', statisticsSchema);

    // Log Model
    const logSchema = new mongoose.Schema({
      type: { 
        type: String, 
        enum: ['payment', 'smtp', 'security', 'admin', 'queue', 'error', 'system'],
        required: true
      },
      level: { 
        type: String, 
        enum: ['info', 'warn', 'error', 'debug'],
        default: 'info'
      },
      userId: Number,
      message: { type: String, required: true },
      metadata: mongoose.Schema.Types.Mixed,
      timestamp: { type: Date, default: Date.now }
    });

    logSchema.index({ type: 1, timestamp: -1 });
    logSchema.index({ level: 1 });
    logSchema.index({ timestamp: 1 }, { expireAfterSeconds: 2592000 }); // 30 days TTL

    this.models.Log = mongoose.model('Log', logSchema);

    // Package Model
    const packageSchema = new mongoose.Schema({
      packageId: { type: String, required: true, unique: true },
      name: { type: String, required: true },
      type: { type: String, enum: ['vip', 'vvip', 'custom'], required: true },
      duration: { type: Number, required: true }, // in days
      price: { type: Number, required: true },
      originalPrice: Number,
      discount: { type: Number, default: 0 },
      features: [String],
      isActive: { type: Boolean, default: true },
      isPromo: { type: Boolean, default: false },
      promoEndDate: Date,
      sortOrder: { type: Number, default: 0 },
      createdAt: { type: Date, default: Date.now },
      updatedAt: { type: Date, default: Date.now }
    });

    packageSchema.index({ type: 1, isActive: 1 });
    packageSchema.index({ sortOrder: 1 });

    this.models.Package = mongoose.model('Package', packageSchema);

    // Template Model
    const templateSchema = new mongoose.Schema({
      templateId: { type: String, required: true, unique: true },
      name: { type: String, required: true },
      country: { type: String, default: 'all' },
      category: { type: String, default: 'general' },
      subject: { type: String, required: true },
      body: { type: String, required: true },
      cooldown: { type: Number, default: 0 },
      priority: { type: Number, default: 1 },
      isActive: { type: Boolean, default: true },
      successRate: { type: Number, default: 0 },
      usageCount: { type: Number, default: 0 },
      createdBy: Number,
      createdAt: { type: Date, default: Date.now },
      updatedAt: { type: Date, default: Date.now }
    });

    templateSchema.index({ country: 1, isActive: 1 });
    templateSchema.index({ category: 1 });

    this.models.Template = mongoose.model('Template', templateSchema);

    // Queue Model
    const queueSchema = new mongoose.Schema({
      userId: { type: Number, required: true },
      phoneNumber: { type: String, required: true },
      bandingId: { type: String, required: true, unique: true },
      priority: { type: Number, default: 4 },
      status: {
        type: String,
        enum: ['queued', 'processing', 'completed', 'failed'],
        default: 'queued'
      },
      attempts: { type: Number, default: 0 },
      maxAttempts: { type: Number, default: 3 },
      position: Number,
      startedAt: Date,
      completedAt: Date,
      errorMessage: String,
      createdAt: { type: Date, default: Date.now }
    });

    queueSchema.index({ priority: 1, createdAt: 1 });
    queueSchema.index({ status: 1 });
    queueSchema.index({ userId: 1 });

    this.models.Queue = mongoose.model('Queue', queueSchema);

    // Notification Model
    const notificationSchema = new mongoose.Schema({
      userId: { type: Number, required: true },
      type: {
        type: String,
        enum: ['payment', 'fix', 'system', 'promo', 'referral'],
        required: true
      },
      title: { type: String, required: true },
      message: { type: String, required: true },
      isRead: { type: Boolean, default: false },
      metadata: mongoose.Schema.Types.Mixed,
      createdAt: { type: Date, default: Date.now }
    });

    notificationSchema.index({ userId: 1, isRead: 1, createdAt: -1 });

    this.models.Notification = mongoose.model('Notification', notificationSchema);

    this.logger.info('All models registered successfully');
  }

  async createIndexes() {
    try {
      for (const [name, model] of Object.entries(this.models)) {
        await model.createIndexes();
      }
      this.logger.info('Database indexes created successfully');
    } catch (error) {
      this.logger.error('Failed to create indexes:', error);
    }
  }

  async backup() {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupDir = path.join(this.backupPath, `backup-${timestamp}`);
      
      await fs.mkdir(backupDir, { recursive: true });

      // Backup MongoDB
      const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/qashvra_bot';
      const mongoCommand = `mongodump --uri="${mongoUri}" --out="${backupDir}/mongodb"`;
      
      await execPromise(mongoCommand);
      
      // Backup configs
      const configsDir = path.join(backupDir, 'configs');
      await fs.mkdir(configsDir, { recursive: true });
      
      const configFiles = ['config.json', 'permissions.json', 'settings.json', 'smtp.json', 'templates.json', '.env'];
      
      for (const file of configFiles) {
        const sourcePath = path.join(__dirname, '../../', file);
        const destPath = path.join(configsDir, file);
        
        try {
          await fs.copyFile(sourcePath, destPath);
        } catch (err) {
          this.logger.warn(`Could not backup ${file}: ${err.message}`);
        }
      }
      
      // Compress backup
      const tarCommand = `tar -czf "${backupDir}.tar.gz" -C "${this.backupPath}" "backup-${timestamp}"`;
      await execPromise(tarCommand);
      
      // Clean up uncompressed directory
      await fs.rm(backupDir, { recursive: true, force: true });
      
      // Clean old backups
      await this.cleanOldBackups();
      
      this.logger.info(`Backup completed: backup-${timestamp}.tar.gz`);
      
      return `backup-${timestamp}.tar.gz`;
      
    } catch (error) {
      this.logger.error('Backup failed:', error);
      throw error;
    }
  }

  async restore(backupFile) {
    try {
      const backupPath = path.join(this.backupPath, backupFile);
      
      // Extract backup
      const extractDir = path.join(this.backupPath, 'restore-temp');
      await execPromise(`tar -xzf "${backupPath}" -C "${this.backupPath}"`);
      
      // Restore MongoDB
      const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/qashvra_bot';
      const restoreDir = path.join(this.backupPath, backupFile.replace('.tar.gz', ''), 'mongodb');
      
      await execPromise(`mongorestore --uri="${mongoUri}" --drop "${restoreDir}"`);
      
      // Clean up
      await fs.rm(path.join(this.backupPath, backupFile.replace('.tar.gz', '')), { recursive: true, force: true });
      
      this.logger.info(`Restore completed from ${backupFile}`);
      
      return true;
      
    } catch (error) {
      this.logger.error('Restore failed:', error);
      throw error;
    }
  }

  async cleanOldBackups() {
    try {
      const files = await fs.readdir(this.backupPath);
      const retentionDays = this.bot.configManager?.get('backup.retention_days') || 30;
      const cutoffDate = new Date(Date.now() - retentionDays * 24 * 60 * 60 * 1000);
      
      for (const file of files) {
        if (file.endsWith('.tar.gz')) {
          const filePath = path.join(this.backupPath, file);
          const stats = await fs.stat(filePath);
          
          if (stats.mtime < cutoffDate) {
            await fs.unlink(filePath);
            this.logger.info(`Deleted old backup: ${file}`);
          }
        }
      }
    } catch (error) {
      this.logger.error('Failed to clean old backups:', error);
    }
  }

  async getStats() {
    try {
      const stats = {};
      
      for (const [name, model] of Object.entries(this.models)) {
        stats[name] = await model.countDocuments();
      }
      
      stats.mongodb = {
        connected: mongoose.connection.readyState === 1,
        host: mongoose.connection.host,
        name: mongoose.connection.name
      };
      
      return stats;
      
    } catch (error) {
      this.logger.error('Failed to get database stats:', error);
      return null;
    }
  }
}

module.exports = DatabaseManager;