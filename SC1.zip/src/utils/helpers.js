const crypto = require('crypto');
const moment = require('moment-timezone');

class Helpers {
  /**
   * Generate unique ID
   */
  static generateId(prefix = '', length = 16) {
    const timestamp = Date.now().toString(36);
    const random = crypto.randomBytes(length / 2).toString('hex');
    return `${prefix}${timestamp}${random}`.substring(0, length + prefix.length);
  }

  /**
   * Generate banding ID for Fix Merah
   */
  static generateBandingId(userId, phoneNumber) {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    const userHash = crypto.createHash('md5').update(userId.toString()).digest('hex').substring(0, 4).toUpperCase();
    return `MADS-${timestamp}${userHash}${random}`;
  }

  /**
   * Generate order ID for payment
   */
  static generateOrderId(userId, packageId) {
    const timestamp = Date.now().toString(36);
    const random = Math.floor(Math.random() * 100000).toString(36);
    return `QASHVRA-${packageId.toUpperCase()}-${userId}-${timestamp}-${random}`;
  }

  /**
   * Generate referral code
   */
  static generateReferralCode(userId) {
    const hash = crypto.createHash('sha256')
      .update(userId.toString())
      .digest('hex')
      .substring(0, 8)
      .toUpperCase();
    return `REF${hash}`;
  }

  /**
   * Mask phone number for privacy
   */
  static maskPhoneNumber(phoneNumber, visibleStart = 4, visibleEnd = 4) {
    if (!phoneNumber || phoneNumber.length < (visibleStart + visibleEnd)) {
      return phoneNumber || 'N/A';
    }
    
    const start = phoneNumber.substring(0, visibleStart);
    const end = phoneNumber.substring(phoneNumber.length - visibleEnd);
    const masked = '*'.repeat(Math.min(phoneNumber.length - visibleStart - visibleEnd, 8));
    
    return `${start}${masked}${end}`;
  }

  /**
   * Mask username for privacy
   */
  static maskUsername(username) {
    if (!username || username.length <= 2) return username || 'Anonymous';
    return username.substring(0, 2) + '***' + username.substring(username.length - 2);
  }

  /**
   * Mask name for leaderboard
   */
  static maskName(name) {
    if (!name || name.length <= 3) return name || 'Anonymous';
    const visible = Math.min(2, Math.floor(name.length / 3));
    return name.substring(0, visible) + '*'.repeat(name.length - visible * 2) + name.substring(name.length - visible);
  }

  /**
   * Format currency to IDR
   */
  static formatCurrency(amount) {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  }

  /**
   * Format number with commas
   */
  static formatNumber(number) {
    return new Intl.NumberFormat('id-ID').format(number);
  }

  /**
   * Format date with timezone
   */
  static formatDate(date, format = 'DD/MM/YYYY HH:mm:ss', timezone = 'Asia/Jakarta') {
    return moment(date).tz(timezone).format(format);
  }

  /**
   * Format relative time
   */
  static timeAgo(date) {
    const now = moment();
    const then = moment(date);
    const diff = now.diff(then, 'seconds');

    if (diff < 60) return 'Baru saja';
    if (diff < 3600) return `${Math.floor(diff / 60)} menit yang lalu`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} jam yang lalu`;
    if (diff < 2592000) return `${Math.floor(diff / 86400)} hari yang lalu`;
    if (diff < 31104000) return `${Math.floor(diff / 2592000)} bulan yang lalu`;
    return `${Math.floor(diff / 31104000)} tahun yang lalu`;
  }

  /**
   * Format duration in seconds to human readable
   */
  static formatDuration(seconds) {
    if (seconds < 60) return `${seconds} detik`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)} menit`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)} jam`;
    return `${Math.floor(seconds / 86400)} hari`;
  }

  /**
   * Format file size
   */
  static formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
   * Parse phone numbers from text
   */
  static parsePhoneNumbers(text) {
    const lines = text.split(/[\n,;]+/);
    const numbers = [];

    for (let line of lines) {
      line = line.trim().replace(/[^\d+]/g, '');
      if (line && line.startsWith('+') && line.length >= 11) {
        numbers.push(line);
      }
    }

    return numbers;
  }

  /**
   * Validate phone number
   */
  static validatePhoneNumber(phoneNumber) {
    if (!phoneNumber || !phoneNumber.startsWith('+')) return false;
    
    const digits = phoneNumber.substring(1);
    
    if (digits.length < 10 || digits.length > 15) return false;
    if (!/^\d+$/.test(digits)) return false;
    
    return true;
  }

  /**
   * Get country from phone number
   */
  static getCountryFromPhone(phoneNumber) {
    const countryCodes = {
      '62': 'ID',
      '1': 'US',
      '44': 'UK',
      '966': 'SA',
      '7': 'RU',
      '91': 'IN',
      '81': 'JP',
      '86': 'CN',
      '971': 'AE',
      '60': 'MY',
      '65': 'SG',
      '66': 'TH',
      '84': 'VN',
      '63': 'PH',
      '82': 'KR',
      '49': 'DE',
      '33': 'FR',
      '39': 'IT',
      '34': 'ES',
      '55': 'BR',
      '52': 'MX'
    };

    const digits = phoneNumber.substring(1);
    
    for (const [code, country] of Object.entries(countryCodes)) {
      if (digits.startsWith(code)) {
        return country;
      }
    }

    return 'UNKNOWN';
  }

  /**
   * Get country flag emoji
   */
  static getCountryFlag(countryCode) {
    const flags = {
      'ID': '🇮🇩',
      'US': '🇺🇸',
      'UK': '🇬🇧',
      'SA': '🇸🇦',
      'RU': '🇷🇺',
      'IN': '🇮🇳',
      'JP': '🇯🇵',
      'CN': '🇨🇳',
      'AE': '🇦🇪',
      'MY': '🇲🇾',
      'SG': '🇸🇬',
      'TH': '🇹🇭',
      'VN': '🇻🇳',
      'PH': '🇵🇭',
      'KR': '🇰🇷',
      'DE': '🇩🇪',
      'FR': '🇫🇷',
      'IT': '🇮🇹',
      'ES': '🇪🇸',
      'BR': '🇧🇷',
      'MX': '🇲🇽'
    };

    return flags[countryCode] || '🏳️';
  }

  /**
   * Get role emoji
   */
  static getRoleEmoji(role) {
    const emojiMap = {
      owner: '👑',
      developer: '💻',
      partner: '🤝',
      admin: '🛡️',
      moderator: '⚔️',
      reseller: '💼',
      vvip: '💎',
      vip: '🌟',
      free: '👤',
      banned: '🚫'
    };
    return emojiMap[role] || '👤';
  }

  /**
   * Get medal emoji for ranking
   */
  static getMedalEmoji(rank) {
    switch (rank) {
      case 1: return '🥇';
      case 2: return '🥈';
      case 3: return '🥉';
      case 4: return '4️⃣';
      case 5: return '5️⃣';
      case 6: return '6️⃣';
      case 7: return '7️⃣';
      case 8: return '8️⃣';
      case 9: return '9️⃣';
      case 10: return '🔟';
      default: return `${rank}.`;
    }
  }

  /**
   * Get status emoji
   */
  static getStatusEmoji(status) {
    const emojiMap = {
      pending: '⏳',
      processing: '🔄',
      success: '✅',
      completed: '✅',
      failed: '❌',
      cancelled: '🚫',
      expired: '⏰',
      paid: '💰',
      active: '🟢',
      inactive: '🔴',
      queued: '📋'
    };
    return emojiMap[status] || '📌';
  }

  /**
   * Truncate text with ellipsis
   */
  static truncate(text, maxLength = 100) {
    if (!text || text.length <= maxLength) return text;
    return text.substring(0, maxLength - 3) + '...';
  }

  /**
   * Escape Markdown special characters
   */
  static escapeMarkdown(text) {
    if (!text) return '';
    const specialChars = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!'];
    let escaped = text;
    for (const char of specialChars) {
      escaped = escaped.replace(new RegExp('\\' + char, 'g'), '\\' + char);
    }
    return escaped;
  }

  /**
   * Escape HTML special characters
   */
  static escapeHtml(text) {
    if (!text) return '';
    const htmlChars = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, char => htmlChars[char] || char);
  }

  /**
   * Generate random string
   */
  static randomString(length = 10) {
    return crypto.randomBytes(Math.ceil(length / 2))
      .toString('hex')
      .substring(0, length);
  }

  /**
   * Hash password
   */
  static hashPassword(password) {
    return crypto.createHash('sha256').update(password).digest('hex');
  }

  /**
   * Compare password with hash
   */
  static comparePassword(password, hash) {
    return this.hashPassword(password) === hash;
  }

  /**
   * Encrypt data
   */
  static encrypt(text, key) {
    const algorithm = 'aes-256-gcm';
    const encryptionKey = crypto.scryptSync(key || process.env.ENCRYPTION_KEY || 'default', 'salt', 32);
    const iv = crypto.randomBytes(16);
    
    const cipher = crypto.createCipheriv(algorithm, encryptionKey, iv);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    const authTag = cipher.getAuthTag();
    
    return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
  }

  /**
   * Decrypt data
   */
  static decrypt(encryptedText, key) {
    const algorithm = 'aes-256-gcm';
    const encryptionKey = crypto.scryptSync(key || process.env.ENCRYPTION_KEY || 'default', 'salt', 32);
    
    const parts = encryptedText.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const authTag = Buffer.from(parts[1], 'hex');
    const encrypted = parts[2];
    
    const decipher = crypto.createDecipheriv(algorithm, encryptionKey, iv);
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  }

  /**
   * Sleep/delay function
   */
  static sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Retry function with exponential backoff
   */
  static async retry(fn, maxRetries = 3, baseDelay = 1000) {
    for (let i = 0; i < maxRetries; i++) {
      try {
        return await fn();
      } catch (error) {
        if (i === maxRetries - 1) throw error;
        const delay = baseDelay * Math.pow(2, i);
        await this.sleep(delay);
      }
    }
  }

  /**
   * Chunk array into smaller arrays
   */
  static chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  /**
   * Calculate percentage
   */
  static percentage(value, total, decimals = 1) {
    if (total === 0) return 0;
    return parseFloat(((value / total) * 100).toFixed(decimals));
  }

  /**
   * Calculate win rate
   */
  static winRate(success, total, decimals = 1) {
    return this.percentage(success, total, decimals);
  }

  /**
   * Deep clone object
   */
  static deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  /**
   * Merge objects deeply
   */
  static deepMerge(target, source) {
    const output = { ...target };
    for (const key of Object.keys(source)) {
      if (source[key] instanceof Object && key in target) {
        output[key] = this.deepMerge(target[key], source[key]);
      } else {
        output[key] = source[key];
      }
    }
    return output;
  }

  /**
   * Validate email format
   */
  static isValidEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  }

  /**
   * Get greeting based on time
   */
  static getGreeting(timezone = 'Asia/Jakarta') {
    const hour = moment().tz(timezone).hour();
    if (hour < 12) return 'Selamat Pagi';
    if (hour < 15) return 'Selamat Siang';
    if (hour < 18) return 'Selamat Sore';
    return 'Selamat Malam';
  }
}

module.exports = Helpers;