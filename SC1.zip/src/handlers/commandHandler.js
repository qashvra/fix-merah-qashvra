const moment = require('moment-timezone');

class CommandHandler {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    this.commands = new Map();
  }

  registerCommands() {
    this.logger.info('Registering commands...');

    // Register all commands
    this.registerStartCommand();
    this.registerHelpCommand();
    this.registerProfileCommand();
    this.registerMenuCommand();
    this.registerVerifyCommand();
    this.registerOwnerCommands();
    this.registerAdminCommands();
    this.registerBroadcastCommand();

    // Set bot commands for Telegram menu
    this.setBotCommands();

    this.logger.info(`Registered ${this.commands.size} commands`);
  }

  registerStartCommand() {
    this.bot.bot.start(async (ctx) => {
      try {
        const userId = ctx.from.id;
        const startPayload = ctx.startPayload;

        // Handle referral
        if (startPayload && startPayload !== userId.toString()) {
          await this.handleReferralStart(ctx, startPayload);
        }

        // Create or update user
        const user = await this.getOrCreateUser(ctx.from, startPayload);

        // Check verification
        const isVerified = await this.checkUserVerification(userId);
        
        if (!isVerified) {
          return this.sendVerificationMessage(ctx);
        }

        // Send welcome message
        await this.sendWelcomeMessage(ctx, user);

        // Log start
        await this.logActivity(userId, 'start', 'User started bot');

      } catch (error) {
        this.logger.error(`Start command error for ${ctx.from.id}:`, error);
        await ctx.reply('⚠️ Terjadi kesalahan. Silakan coba lagi.').catch(() => {});
      }
    });
  }

  async getOrCreateUser(from, referredBy) {
    try {
      const User = this.bot.managers.database.models.User;
      
      let user = await User.findOne({ userId: from.id });

      if (!user) {
        user = new User({
          userId: from.id,
          username: from.username || `user_${from.id}`,
          firstName: from.first_name || '',
          lastName: from.last_name || '',
          fullName: [from.first_name, from.last_name].filter(Boolean).join(' ') || from.username || `User ${from.id}`,
          language: from.language_code || 'id',
          role: from.id === parseInt(process.env.OWNER_ID) ? 'owner' : 'free',
          referralCode: this.generateReferralCode(from.id),
          referredBy: referredBy ? parseInt(referredBy) : null,
          createdAt: new Date(),
          updatedAt: new Date()
        });

        await user.save();

        // Process referral if applicable
        if (referredBy && referredBy !== from.id.toString()) {
          try {
            await this.bot.services.referral.processReferral(parseInt(referredBy), from.id);
          } catch (error) {
            this.logger.warn(`Failed to process referral: ${error.message}`);
          }
        }

        // Update statistics
        await this.updateUserStats('new_user');
      } else {
        // Update existing user
        user.username = from.username || user.username;
        user.firstName = from.first_name || user.firstName;
        user.lastName = from.last_name || user.lastName;
        user.fullName = [from.first_name, from.last_name].filter(Boolean).join(' ') || user.fullName;
        user.updatedAt = new Date();
        
        if (!user.referralCode) {
          user.referralCode = this.generateReferralCode(from.id);
        }
        
        await user.save();
      }

      return user;

    } catch (error) {
      this.logger.error('Failed to get or create user:', error);
      throw error;
    }
  }

  generateReferralCode(userId) {
    const hash = Buffer.from(userId.toString()).toString('base64').substring(0, 8);
    return `REF${hash}`;
  }

  async checkUserVerification(userId) {
    try {
      const verificationEnabled = this.bot.configManager.get('verification.enabled');
      if (!verificationEnabled) return true;

      const User = this.bot.managers.database.models.User;
      const user = await User.findOne({ userId });

      if (!user || !user.isVerified) {
        // Perform actual verification check
        const { verificationMiddleware } = require('../middleware/verification');
        // We'll implement a simpler check here
        return false;
      }

      return true;

    } catch (error) {
      this.logger.error(`Verification check failed for ${userId}:`, error);
      return false;
    }
  }

  async sendVerificationMessage(ctx) {
    const message = `
⚠️ *VERIFIKASI DIPERLUKAN*

Untuk menggunakan Qashvra Fix Merah Pro, Anda harus bergabung dengan channel/group resmi kami:

📢 *Channel Resmi:*
• @qashvra_channel
• @qashvra_group

Klik tombol di bawah untuk bergabung, lalu verifikasi:
    `.trim();

    const keyboard = {
      inline_keyboard: [
        [
          { text: '📢 JOIN CHANNEL', url: 'https://t.me/qashvra_channel' },
          { text: '👥 JOIN GROUP', url: 'https://t.me/qashvra_group' }
        ],
        [
          { text: '✅ CEK VERIFIKASI', callback_data: 'check_verification' }
        ],
        [
          { text: 'ℹ️ BANTUAN', callback_data: 'help_verification' }
        ]
      ]
    };

    await ctx.reply(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard,
      disable_web_page_preview: true
    });
  }

  async sendWelcomeMessage(ctx, user) {
    try {
      const stats = await this.getGlobalStats();
      const userStats = await this.getUserStats(user.userId);
      
      const runtime = this.bot.formatUptime();
      const now = moment().tz('Asia/Jakarta');
      
      const message = `
🔴 *WELCOME TO QASHVRA FIX MERAH PRO*

━━━━━━━━━━━━━━━━━━━━━━
👤 *INFORMASI AKUN*
├ 👤 Nama: ${this.maskName(user.fullName)}
├ 🆔 Akun ID: ${user.userId}
├ 👑 Status: ${this.getRoleEmoji(user.role)} ${user.role.toUpperCase()}
└ 🌐 Bahasa: ${user.language.toUpperCase()}
━━━━━━━━━━━━━━━━━━━━━━

📊 *STATISTIK PRIBADI*
├ 🛠️ Total Fix: ${userStats.totalFix || 0}
├ 🎯 Berhasil: ${userStats.successFix || 0}
├ ❌ Gagal: ${userStats.failedFix || 0}
└ 📈 Win Rate: ${userStats.winRate || 0}%
━━━━━━━━━━━━━━━━━━━━━━

🌍 *STATISTIK GLOBAL*
├ 📧 Sender Aktif: ${stats.activeSMTP}/${stats.totalSMTP}
├ 👥 Pengguna: ${stats.totalUsers}
├ 🛠️ Total Fix: ${stats.totalFix}
└ 📈 Win Rate Global: ${stats.globalWinRate}%
━━━━━━━━━━━━━━━━━━━━━━

📅 ${now.format('dddd, DD MMMM YYYY')}
⏰ ${now.format('HH:mm:ss')} WIB
⏱️ Runtime: ${runtime}

Gunakan tombol di bawah untuk memulai! 👇
      `.trim();

      const keyboard = this.buildMainMenuKeyboard(user.role);

      // Send welcome image if exists
      try {
        const welcomeImage = './src/assets/images/welcome.png';
        await ctx.replyWithPhoto(
          { source: welcomeImage },
          {
            caption: message,
            parse_mode: 'Markdown',
            reply_markup: keyboard
          }
        );
      } catch (error) {
        // Send without image
        await ctx.reply(message, {
          parse_mode: 'Markdown',
          reply_markup: keyboard,
          disable_web_page_preview: true
        });
      }

      // Send notification to owner for new users
      if (user.createdAt && (Date.now() - user.createdAt.getTime()) < 60000) {
        await this.bot.managers.notification.notifyOwner(
          '👤 New User',
          `New user started bot:\nName: ${user.fullName}\nID: ${user.userId}\nUsername: @${user.username || 'N/A'}`
        );
      }

    } catch (error) {
      this.logger.error(`Failed to send welcome message to ${user.userId}:`, error);
      await ctx.reply('🔴 *Welcome to Qashvra Fix Merah Pro*', {
        parse_mode: 'Markdown',
        reply_markup: this.buildMainMenuKeyboard('free')
      }).catch(() => {});
    }
  }

  buildMainMenuKeyboard(role) {
    const keyboard = {
      inline_keyboard: [
        [
          { text: '🛠️ FIX MERAH', callback_data: 'menu_fix_merah' },
          { text: '👑 VIP / VVIP', callback_data: 'menu_vip_vvip' }
        ],
        [
          { text: '🎁 REFERRAL', callback_data: 'menu_referral' },
          { text: '📜 RIWAYAT', callback_data: 'menu_history' }
        ],
        [
          { text: '🏆 TOP GLOBAL', callback_data: 'menu_leaderboard' },
          { text: '✅ TESTIMONI', callback_data: 'menu_testimoni' }
        ],
        [
          { text: '⚙️ SETTINGS', callback_data: 'menu_settings' },
          { text: '👤 PROFILE', callback_data: 'menu_profile' }
        ]
      ]
    };

    // Add owner panel for privileged users
    const privilegedRoles = ['owner', 'developer', 'partner', 'admin'];
    if (privilegedRoles.includes(role)) {
      keyboard.inline_keyboard.push([
        { text: '🔧 OWNER PANEL', callback_data: 'menu_owner_panel' }
      ]);
    }

    return keyboard;
  }

  getRoleEmoji(role) {
    const emojiMap = {
      owner: '👑',
      developer: '💻',
      partner: '🤝',
      admin: '🛡️',
      moderator: '⚔️',
      reseller: '💼',
      vvip: '💎',
      vip: '🌟',
      free: '👤',
      banned: '🚫'
    };
    return emojiMap[role] || '👤';
  }

  maskName(name) {
    if (!name || name.length <= 2) return name;
    const visible = 2;
    return name.substring(0, visible) + '*'.repeat(Math.max(name.length - visible * 2, 0)) + name.substring(name.length - visible);
  }

  async getGlobalStats() {
    try {
      const Statistics = this.bot.managers.database.models.Statistics;
      const SMTPConfig = this.bot.managers.database.models.SMTPConfig;
      const User = this.bot.managers.database.models.User;
      
      const totalUsers = await User.countDocuments();
      const activeSMTP = await SMTPConfig.countDocuments({ status: 'active' });
      const totalSMTP = await SMTPConfig.countDocuments();
      
      const today = new Date().toISOString().split('T')[0];
      const todayStats = await Statistics.findOne({ date: today });
      
      const totalFix = todayStats?.totalFix || 0;
      const successFix = todayStats?.successFix || 0;
      const globalWinRate = totalFix > 0 ? ((successFix / totalFix) * 100).toFixed(1) : 100;
      
      return {
        totalUsers,
        activeSMTP,
        totalSMTP,
        totalFix,
        globalWinRate
      };
    } catch (error) {
      return {
        totalUsers: 0,
        activeSMTP: 0,
        totalSMTP: 0,
        totalFix: 0,
        globalWinRate: 100
      };
    }
  }

  async getUserStats(userId) {
    try {
      const User = this.bot.managers.database.models.User;
      const user = await User.findOne({ userId });
      
      const totalFix = user?.totalFix || 0;
      const successFix = user?.successFix || 0;
      const winRate = totalFix > 0 ? ((successFix / totalFix) * 100).toFixed(1) : 0;
      
      return {
        totalFix,
        successFix,
        failedFix: user?.failedFix || 0,
        winRate
      };
    } catch (error) {
      return { totalFix: 0, successFix: 0, failedFix: 0, winRate: 0 };
    }
  }

  async handleReferralStart(ctx, referrerId) {
    try {
      const userId = ctx.from.id;
      
      // Process referral in background
      setTimeout(async () => {
        try {
          await this.bot.services.referral.processReferral(parseInt(referrerId), userId);
        } catch (error) {
          this.logger.warn(`Referral processing failed: ${error.message}`);
        }
      }, 1000);
      
    } catch (error) {
      this.logger.error(`Handle referral start error:`, error);
    }
  }

  registerHelpCommand() {
    this.bot.bot.help(async (ctx) => {
      const message = `
ℹ️ *BANTUAN QASHVRA FIX MERAH PRO*

🛠️ *Fix Merah*
Proses pemulihan akun WhatsApp yang terkena masalah login.

👑 *VIP / VVIP*
Upgrade akun untuk fitur premium dan limit lebih besar.

🎁 *Referral*
Ajak teman dan dapatkan koin untuk ditukar VIP.

📜 *Riwayat*
Lihat riwayat fix merah Anda.

🏆 *Top Global*
Lihat peringkat pengguna teratas.

⚙️ *Settings*
Atur preferensi akun Anda.

📞 *Butuh bantuan?*
Hubungi: @qashvra
      `.trim();

      await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🏠 MENU UTAMA', callback_data: 'menu_main' }]
          ]
        }
      });
    });
  }

  registerProfileCommand() {
    this.bot.bot.command('profile', async (ctx) => {
      const userId = ctx.from.id;
      const User = this.bot.managers.database.models.User;
      const user = await User.findOne({ userId });

      if (!user) {
        return ctx.reply('❌ Akun tidak ditemukan. Silakan /start terlebih dahulu.');
      }

      const message = `
👤 *PROFILE AKUN*

🆔 ID: ${user.userId}
👤 Nama: ${user.fullName}
📛 Username: @${user.username || 'N/A'}
👑 Status: ${this.getRoleEmoji(user.role)} ${user.role.toUpperCase()}
📅 Member Sejak: ${moment(user.createdAt).format('DD/MM/YYYY')}
${user.membershipExpiry ? `⏰ Expired: ${moment(user.membershipExpiry).format('DD/MM/YYYY HH:mm')}` : ''}
🪙 Koin: ${user.coins || 0}
👥 Referral: ${user.referralCount || 0}
      `.trim();

      await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🏠 MENU UTAMA', callback_data: 'menu_main' }]
          ]
        }
      });
    });
  }

  registerMenuCommand() {
    this.bot.bot.command('menu', async (ctx) => {
      const User = this.bot.managers.database.models.User;
      const user = await User.findOne({ userId: ctx.from.id });
      
      await ctx.reply('🔴 *MENU UTAMA*', {
        parse_mode: 'Markdown',
        reply_markup: this.buildMainMenuKeyboard(user?.role || 'free')
      });
    });
  }

  registerVerifyCommand() {
    this.bot.bot.command('verify', async (ctx) => {
      const isVerified = await this.checkUserVerification(ctx.from.id);
      
      if (isVerified) {
        await ctx.reply('✅ Anda sudah terverifikasi!', {
          reply_markup: {
            inline_keyboard: [
              [{ text: '🏠 MENU UTAMA', callback_data: 'menu_main' }]
            ]
          }
        });
      } else {
        await this.sendVerificationMessage(ctx);
      }
    });
  }

  registerOwnerCommands() {
    // Owner commands
    const ownerCommands = [
      'owner', 'dashboard', 'broadcast', 'maintenance',
      'backup', 'restore', 'clearlogs', 'clearqueue',
      'reload', 'restart'
    ];

    for (const cmd of ownerCommands) {
      this.bot.bot.command(cmd, async (ctx) => {
        if (!this.isOwner(ctx.from.id)) {
          return ctx.reply('⛔ Akses ditolak. Command ini hanya untuk owner.');
        }
        
        await this.handleOwnerCommand(ctx, cmd);
      });
    }
  }

  isOwner(userId) {
    return userId === parseInt(process.env.OWNER_ID);
  }

  async handleOwnerCommand(ctx, command) {
    try {
      switch (command) {
        case 'owner':
          await this.showOwnerPanel(ctx);
          break;
        case 'dashboard':
          await this.showDashboard(ctx);
          break;
        case 'broadcast':
          await this.handleBroadcastCommand(ctx);
          break;
        case 'maintenance':
          await this.toggleMaintenance(ctx);
          break;
        case 'backup':
          await this.performBackup(ctx);
          break;
        case 'restore':
          await this.performRestore(ctx);
          break;
        case 'clearlogs':
          await this.clearLogs(ctx);
          break;
        case 'clearqueue':
          await this.clearQueue(ctx);
          break;
        case 'reload':
          await this.reloadConfig(ctx);
          break;
        case 'restart':
          await this.restartBot(ctx);
          break;
        default:
          await ctx.reply('❌ Unknown command');
      }
    } catch (error) {
      this.logger.error(`Owner command error:`, error);
      await ctx.reply(`❌ Error: ${error.message}`);
    }
  }

  async showOwnerPanel(ctx) {
    const stats = await this.bot.managers.database.getStats();
    const queueStats = this.bot.managers.queue.getStats();
    
    const message = `
👑 *OWNER PANEL - QASHVRA FIX MERAH PRO*

📊 *SYSTEM STATUS*
├ CPU: ${process.cpuUsage().user / 1000000}%
├ RAM: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB
├ Uptime: ${this.bot.formatUptime()}
└ Environment: ${process.env.NODE_ENV}

📈 *DATABASE*
├ Users: ${stats.User || 0}
├ Payments: ${stats.Payment || 0}
├ Fix History: ${stats.FixHistory || 0}
└ Queue: ${queueStats.currentQueueSize}

📧 *SMTP*
├ Active: ${queueStats.queueSizes ? 'Running' : 'Active'}
└ Processing: ${queueStats.processingNow}

🛠️ *QUICK ACTIONS*
    `.trim();

    const keyboard = {
      inline_keyboard: [
        [
          { text: '📊 DASHBOARD', callback_data: 'owner_dashboard' },
          { text: '📢 BROADCAST', callback_data: 'owner_broadcast' }
        ],
        [
          { text: '🔄 RELOAD CONFIG', callback_data: 'owner_reload' },
          { text: '🔧 MAINTENANCE', callback_data: 'owner_maintenance' }
        ],
        [
          { text: '💾 BACKUP', callback_data: 'owner_backup' },
          { text: '📥 RESTORE', callback_data: 'owner_restore' }
        ],
        [
          { text: '🗑️ CLEAR LOGS', callback_data: 'owner_clearlogs' },
          { text: '🧹 CLEAR QUEUE', callback_data: 'owner_clearqueue' }
        ],
        [
          { text: '🔌 RESTART BOT', callback_data: 'owner_restart' },
          { text: '⚠️ EMERGENCY', callback_data: 'owner_emergency' }
        ],
        [
          { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
        ]
      ]
    };

    await ctx.reply(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  async showDashboard(ctx) {
    try {
      const today = new Date().toISOString().split('T')[0];
      const Statistics = this.bot.managers.database.models.Statistics;
      const stats = await Statistics.findOne({ date: today });
      
      const User = this.bot.managers.database.models.User;
      const SMTPConfig = this.bot.managers.database.models.SMTPConfig;
      const Payment = this.bot.managers.database.models.Payment;
      
      const totalUsers = await User.countDocuments();
      const newUsersToday = await User.countDocuments({
        createdAt: { $gte: new Date(today) }
      });
      const activeSMTP = await SMTPConfig.countDocuments({ status: 'active' });
      const failedSMTP = await SMTPConfig.countDocuments({ status: 'failed' });
      
      const todayRevenue = await Payment.aggregate([
        {
          $match: {
            status: 'paid',
            paidAt: { $gte: new Date(today) }
          }
        },
        {
          $group: {
            _id: null,
            total: { $sum: '$amount' },
            count: { $sum: 1 }
          }
        }
      ]);

      const message = `
📊 *REALTIME DASHBOARD*

👥 *USERS*
├ Total: ${totalUsers}
├ New Today: ${newUsersToday}
└ Active: ${stats?.activeUsers || 0}

🛠️ *FIX STATS TODAY*
├ Total: ${stats?.totalFix || 0}
├ Success: ${stats?.successFix || 0}
├ Failed: ${stats?.failedFix || 0}
└ Win Rate: ${stats?.totalFix > 0 ? ((stats.successFix / stats.totalFix) * 100).toFixed(1) : 0}%

📧 *SMTP STATUS*
├ Active: ${activeSMTP}
├ Failed: ${failedSMTP}
└ Total: ${activeSMTP + failedSMTP}

💰 *REVENUE TODAY*
├ Transactions: ${todayRevenue[0]?.count || 0}
└ Total: Rp ${(todayRevenue[0]?.total || 0).toLocaleString('id-ID')}

⏰ ${moment().format('HH:mm:ss')} WIB
      `.trim();

      await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🔄 REFRESH', callback_data: 'owner_dashboard' },
              { text: '👥 USERS', callback_data: 'owner_users' }
            ],
            [
              { text: '📧 SMTP', callback_data: 'owner_smtp' },
              { text: '💰 PAYMENTS', callback_data: 'owner_payments' }
            ],
            [
              { text: '🔙 BACK', callback_data: 'menu_owner_panel' }
            ]
          ]
        }
      });

    } catch (error) {
      this.logger.error('Dashboard error:', error);
      await ctx.reply('❌ Failed to load dashboard');
    }
  }

  async handleBroadcastCommand(ctx) {
    await ctx.reply(
      '📢 *BROADCAST*\n\n' +
      'Silakan kirim pesan yang akan dibroadcast ke semua user.\n\n' +
      'Format: /sendbroadcast [pesan]\n\n' +
      'Atau reply pesan yang ingin dibroadcast.',
      { parse_mode: 'Markdown' }
    );
  }

  async toggleMaintenance(ctx) {
    const currentMode = this.bot.configManager.get('bot.maintenance_mode');
    const newMode = !currentMode;
    
    await this.bot.configManager.set('bot.maintenance_mode', newMode);
    
    await ctx.reply(
      `🔧 Maintenance Mode: ${newMode ? '✅ AKTIF' : '❌ NON-AKTIF'}`,
      { parse_mode: 'Markdown' }
    );
  }

  async performBackup(ctx) {
    await ctx.reply('💾 Memulai backup...');
    
    const backupFile = await this.bot.managers.database.backup();
    
    await ctx.reply(`✅ Backup berhasil: ${backupFile}`);
  }

  async performRestore(ctx) {
    await ctx.reply(
      '📥 Kirim file backup (.tar.gz) yang ingin direstore.\n' +
      '⚠️ Warning: Ini akan menimpa database saat ini!'
    );
  }

  async clearLogs(ctx) {
    const Log = this.bot.managers.database.models.Log;
    const result = await Log.deleteMany({});
    
    await ctx.reply(`✅ ${result.deletedCount} log berhasil dihapus.`);
  }

  async clearQueue(ctx) {
    const count = await this.bot.managers.queue.clearQueue();
    await ctx.reply(`✅ ${count} queue items cleared.`);
  }

  async reloadConfig(ctx) {
    await this.bot.configManager.loadConfigs();
    await ctx.reply('✅ Config reloaded successfully.');
  }

  async restartBot(ctx) {
    await ctx.reply('🔄 Restarting bot...');
    
    setTimeout(() => {
      process.exit(0);
    }, 1000);
  }

  registerAdminCommands() {
    const adminCommands = ['admin', 'users', 'addpremium', 'removepremium', 'ban', 'unban'];
    
    for (const cmd of adminCommands) {
      this.bot.bot.command(cmd, async (ctx) => {
        const isAdmin = await this.isAdmin(ctx.from.id);
        
        if (!isAdmin) {
          return ctx.reply('⛔ Akses ditolak.');
        }
        
        await this.handleAdminCommand(ctx, cmd);
      });
    }
  }

  async isAdmin(userId) {
    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });
    return user && ['owner', 'developer', 'partner', 'admin'].includes(user.role);
  }

  async handleAdminCommand(ctx, command) {
    switch (command) {
      case 'admin':
        await this.showAdminPanel(ctx);
        break;
      case 'users':
        await this.showUserList(ctx);
        break;
      case 'addpremium':
        await this.addPremiumUser(ctx);
        break;
      case 'removepremium':
        await this.removePremiumUser(ctx);
        break;
      case 'ban':
        await this.banUser(ctx);
        break;
      case 'unban':
        await this.unbanUser(ctx);
        break;
    }
  }

  async showAdminPanel(ctx) {
    const keyboard = {
      inline_keyboard: [
        [
          { text: '👥 MANAGE USERS', callback_data: 'admin_users' },
          { text: '📧 SMTP MANAGER', callback_data: 'admin_smtp' }
        ],
        [
          { text: '📢 BROADCAST', callback_data: 'admin_broadcast' },
          { text: '📊 STATISTICS', callback_data: 'admin_stats' }
        ],
        [
          { text: '🔙 BACK', callback_data: 'menu_owner_panel' }
        ]
      ]
    };

    await ctx.reply('🛡️ *ADMIN PANEL*', {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  async showUserList(ctx) {
    const User = this.bot.managers.database.models.User;
    const users = await User.find().sort({ createdAt: -1 }).limit(20);
    
    let message = '👥 *USER LIST (Last 20)*\n\n';
    
    for (const user of users) {
      message += `${this.getRoleEmoji(user.role)} ${user.fullName} (${user.userId})\n`;
    }

    await ctx.reply(message, { parse_mode: 'Markdown' });
  }

  async addPremiumUser(ctx) {
    const args = ctx.message.text.split(' ');
    
    if (args.length < 4) {
      return ctx.reply(
        'Format: /addpremium [user_id] [vip/vvip] [days]\n' +
        'Example: /addpremium 123456789 vip 30'
      );
    }

    const userId = parseInt(args[1]);
    const type = args[2].toLowerCase();
    const days = parseInt(args[3]);

    if (!['vip', 'vvip'].includes(type)) {
      return ctx.reply('❌ Type must be vip or vvip');
    }

    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });

    if (!user) {
      return ctx.reply('❌ User not found');
    }

    const expiryDate = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
    
    user.role = type;
    user.membershipExpiry = expiryDate;
    await user.save();

    await ctx.reply(`✅ User ${userId} upgraded to ${type.toUpperCase()} for ${days} days.`);

    // Notify user
    try {
      await this.bot.bot.telegram.sendMessage(userId,
        `🎉 Selamat! Akun Anda telah diupgrade ke ${type.toUpperCase()} selama ${days} hari!`
      );
    } catch (error) {
      this.logger.warn(`Failed to notify user ${userId}`);
    }
  }

  async removePremiumUser(ctx) {
    const args = ctx.message.text.split(' ');
    
    if (args.length < 2) {
      return ctx.reply('Format: /removepremium [user_id]');
    }

    const userId = parseInt(args[1]);
    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });

    if (!user) {
      return ctx.reply('❌ User not found');
    }

    user.role = 'free';
    user.membershipExpiry = null;
    await user.save();

    await ctx.reply(`✅ Premium removed from user ${userId}.`);
  }

  async banUser(ctx) {
    const args = ctx.message.text.split(' ');
    
    if (args.length < 2) {
      return ctx.reply('Format: /ban [user_id] [reason]');
    }

    const userId = parseInt(args[1]);
    const reason = args.slice(2).join(' ') || 'No reason provided';

    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });

    if (!user) {
      return ctx.reply('❌ User not found');
    }

    user.role = 'banned';
    user.isBanned = true;
    user.banReason = reason;
    await user.save();

    await ctx.reply(`✅ User ${userId} banned.\nReason: ${reason}`);

    // Notify user
    try {
      await this.bot.bot.telegram.sendMessage(userId,
        `🚫 Akun Anda telah dibanned.\n\nAlasan: ${reason}\n\nHubungi @qashvra untuk banding.`
      );
    } catch (error) {
      this.logger.warn(`Failed to notify banned user ${userId}`);
    }
  }

  async unbanUser(ctx) {
    const args = ctx.message.text.split(' ');
    
    if (args.length < 2) {
      return ctx.reply('Format: /unban [user_id]');
    }

    const userId = parseInt(args[1]);
    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });

    if (!user) {
      return ctx.reply('❌ User not found');
    }

    user.role = 'free';
    user.isBanned = false;
    user.banReason = null;
    await user.save();

    await ctx.reply(`✅ User ${userId} unbanned.`);

    // Notify user
    try {
      await this.bot.bot.telegram.sendMessage(userId,
        '✅ Akun Anda telah di-unban. Selamat datang kembali!'
      );
    } catch (error) {
      this.logger.warn(`Failed to notify unbanned user ${userId}`);
    }
  }

  registerBroadcastCommand() {
    this.bot.bot.command('sendbroadcast', async (ctx) => {
      const isAdmin = await this.isAdmin(ctx.from.id);
      
      if (!isAdmin) {
        return ctx.reply('⛔ Akses ditolak.');
      }

      const message = ctx.message.text.replace('/sendbroadcast', '').trim();
      
      if (!message) {
        return ctx.reply('❌ Pesan tidak boleh kosong.');
      }

      await this.sendBroadcast(ctx, message);
    });
  }

  async sendBroadcast(ctx, message) {
    try {
      const User = this.bot.managers.database.models.User;
      const users = await User.find({ role: { $ne: 'banned' } });
      
      await ctx.reply(`📢 Mengirim broadcast ke ${users.length} users...`);

      let successCount = 0;
      let failCount = 0;

      for (const user of users) {
        try {
          await this.bot.bot.telegram.sendMessage(user.userId, 
            `📢 *BROADCAST*\n\n${message}`,
            { parse_mode: 'Markdown' }
          );
          successCount++;
        } catch (error) {
          failCount++;
        }

        // Delay between messages
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      await ctx.reply(
        `✅ Broadcast selesai!\n\n` +
        `Berhasil: ${successCount}\n` +
        `Gagal: ${failCount}`
      );

    } catch (error) {
      this.logger.error('Broadcast error:', error);
      await ctx.reply('❌ Gagal mengirim broadcast.');
    }
  }

  async logActivity(userId, type, message) {
    try {
      const Log = this.bot.managers.database.models.Log;
      await Log.create({
        type: 'system',
        level: 'info',
        userId,
        message,
        timestamp: new Date()
      });
    } catch (error) {
      this.logger.error('Failed to log activity:', error);
    }
  }

  async updateUserStats(event) {
    try {
      const Statistics = this.bot.managers.database.models.Statistics;
      const today = new Date().toISOString().split('T')[0];

      const update = {};
      
      switch (event) {
        case 'new_user':
          update.$inc = { newUsers: 1, totalUsers: 1 };
          break;
        case 'active_user':
          update.$inc = { activeUsers: 1 };
          break;
      }

      await Statistics.findOneAndUpdate(
        { date: today },
        update,
        { upsert: true }
      );

    } catch (error) {
      this.logger.error('Failed to update user stats:', error);
    }
  }

  setBotCommands() {
    const commands = [
      { command: 'start', description: '🚀 Mulai bot' },
      { command: 'menu', description: '📋 Tampilkan menu utama' },
      { command: 'profile', description: '👤 Lihat profile' },
      { command: 'help', description: 'ℹ️ Bantuan' },
      { command: 'verify', description: '✅ Verifikasi akun' }
    ];

    this.bot.bot.telegram.setMyCommands(commands).catch(err => {
      this.logger.error('Failed to set bot commands:', err);
    });
  }
}

module.exports = CommandHandler;