class CallbackHandler {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    this.callbacks = new Map();
  }

  registerCallbacks() {
    this.logger.info('Registering callback handlers...');

    // Main menu callbacks
    this.register('menu_main', this.handleMainMenu.bind(this));
    this.register('menu_fix_merah', this.handleFixMerahMenu.bind(this));
    this.register('menu_vip_vvip', this.handleVIPMenu.bind(this));
    this.register('menu_referral', this.handleReferralMenu.bind(this));
    this.register('menu_history', this.handleHistoryMenu.bind(this));
    this.register('menu_leaderboard', this.handleLeaderboardMenu.bind(this));
    this.register('menu_testimoni', this.handleTestimoniMenu.bind(this));
    this.register('menu_settings', this.handleSettingsMenu.bind(this));
    this.register('menu_profile', this.handleProfileMenu.bind(this));
    this.register('menu_owner_panel', this.handleOwnerPanelMenu.bind(this));

    // Verification callback
    this.register('check_verification', this.handleCheckVerification.bind(this));
    this.register('help_verification', this.handleHelpVerification.bind(this));

    // Fix Merah callbacks
    this.register('start_fix', this.handleStartFix.bind(this));
    this.register('cancel_fix', this.handleCancelFix.bind(this));

    // VIP callbacks
    this.register('buy_vip', this.handleBuyVIP.bind(this));
    this.register('buy_vvip', this.handleBuyVVIP.bind(this));
    this.register('redeem_vip', this.handleRedeemVIP.bind(this));

    // Payment callbacks
    this.register(/check_payment_(.+)/, this.handleCheckPayment.bind(this));
    this.register(/cancel_payment_(.+)/, this.handleCancelPayment.bind(this));
    this.register(/select_package_(.+)/, this.handleSelectPackage.bind(this));

    // Referral callbacks
    this.register('share_referral', this.handleShareReferral.bind(this));
    this.register('referral_stats', this.handleReferralStats.bind(this));

    // History callbacks
    this.register('refresh_history', this.handleRefreshHistory.bind(this));
    this.register('clear_history', this.handleClearHistory.bind(this));

    // Leaderboard callbacks
    this.register('leaderboard_users', this.handleLeaderboardUsers.bind(this));
    this.register('leaderboard_countries', this.handleLeaderboardCountries.bind(this));

    // Testimoni callbacks
    this.register('refresh_testimoni', this.handleRefreshTestimoni.bind(this));
    this.register('load_more_testimoni', this.handleLoadMoreTestimoni.bind(this));

    // Settings callbacks
    this.register('settings_language', this.handleSettingsLanguage.bind(this));
    this.register('settings_theme', this.handleSettingsTheme.bind(this));
    this.register('settings_timezone', this.handleSettingsTimezone.bind(this));
    this.register('settings_notification', this.handleSettingsNotification.bind(this));
    this.register(/set_language_(.+)/, this.handleSetLanguage.bind(this));
    this.register(/set_theme_(.+)/, this.handleSetTheme.bind(this));
    this.register(/set_timezone_(.+)/, this.handleSetTimezone.bind(this));

    // Owner panel callbacks
    this.register('owner_dashboard', this.handleOwnerDashboard.bind(this));
    this.register('owner_broadcast', this.handleOwnerBroadcast.bind(this));
    this.register('owner_reload', this.handleOwnerReload.bind(this));
    this.register('owner_maintenance', this.handleOwnerMaintenance.bind(this));
    this.register('owner_backup', this.handleOwnerBackup.bind(this));
    this.register('owner_restore', this.handleOwnerRestore.bind(this));
    this.register('owner_clearlogs', this.handleOwnerClearLogs.bind(this));
    this.register('owner_clearqueue', this.handleOwnerClearQueue.bind(this));
    this.register('owner_restart', this.handleOwnerRestart.bind(this));
    this.register('owner_emergency', this.handleOwnerEmergency.bind(this));
    this.register('owner_users', this.handleOwnerUsers.bind(this));
    this.register('owner_smtp', this.handleOwnerSMTP.bind(this));
    this.register('owner_payments', this.handleOwnerPayments.bind(this));

    // Back navigation
    this.register('back_to_main', this.handleMainMenu.bind(this));

    // Register with bot
    this.bot.bot.on('callback_query', async (ctx) => {
      await this.handleCallback(ctx);
    });

    this.logger.info(`Registered ${this.callbacks.size} callback handlers`);
  }

  register(pattern, handler) {
    this.callbacks.set(pattern, handler);
  }

  async handleCallback(ctx) {
    try {
      const callbackData = ctx.callbackQuery.data;
      
      // Answer callback query
      await ctx.answerCbQuery().catch(() => {});

      // Find matching handler
      let handler = this.callbacks.get(callbackData);

      // Try regex patterns
      if (!handler) {
        for (const [pattern, h] of this.callbacks) {
          if (pattern instanceof RegExp && pattern.test(callbackData)) {
            handler = h;
            break;
          }
        }
      }

      if (handler) {
        await handler(ctx);
      } else {
        this.logger.warn(`No handler for callback: ${callbackData}`);
        await ctx.reply('⚠️ Menu tidak tersedia. Gunakan /menu untuk menu utama.');
      }

    } catch (error) {
      this.logger.error('Callback handler error:', error);
      await ctx.reply('⚠️ Terjadi kesalahan. Silakan coba lagi.').catch(() => {});
    }
  }

  async handleMainMenu(ctx) {
    const userId = ctx.from.id;
    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });

    const keyboard = this.buildMainMenuKeyboard(user?.role || 'free');

    await ctx.editMessageText('🔴 *MENU UTAMA QASHVRA FIX MERAH PRO*', {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    }).catch(async () => {
      await ctx.reply('🔴 *MENU UTAMA QASHVRA FIX MERAH PRO*', {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    });
  }

  buildMainMenuKeyboard(role) {
    const keyboard = {
      inline_keyboard: [
        [
          { text: '🛠️ FIX MERAH', callback_data: 'menu_fix_merah' },
          { text: '👑 VIP / VVIP', callback_data: 'menu_vip_vvip' }
        ],
        [
          { text: '🎁 REFERRAL', callback_data: 'menu_referral' },
          { text: '📜 RIWAYAT', callback_data: 'menu_history' }
        ],
        [
          { text: '🏆 TOP GLOBAL', callback_data: 'menu_leaderboard' },
          { text: '✅ TESTIMONI', callback_data: 'menu_testimoni' }
        ],
        [
          { text: '⚙️ SETTINGS', callback_data: 'menu_settings' },
          { text: '👤 PROFILE', callback_data: 'menu_profile' }
        ]
      ]
    };

    const privilegedRoles = ['owner', 'developer', 'partner', 'admin'];
    if (privilegedRoles.includes(role)) {
      keyboard.inline_keyboard.push([
        { text: '🔧 OWNER PANEL', callback_data: 'menu_owner_panel' }
      ]);
    }

    return keyboard;
  }

  async handleFixMerahMenu(ctx) {
    const userId = ctx.from.id;
    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });

    if (!user) {
      return ctx.reply('❌ Silakan /start terlebih dahulu.');
    }

    // Get SMTP stats
    const SMTPConfig = this.bot.managers.database.models.SMTPConfig;
    const activeSMTP = await SMTPConfig.countDocuments({ status: 'active' });
    const totalSMTP = await SMTPConfig.countDocuments();

    // Get user limits
    const dailyLimit = this.getDailyLimit(user.role);
    const bulkLimit = this.getBulkLimit(user.role);
    const usedToday = user.dailyFixCount || 0;
    const remaining = Math.max(0, dailyLimit - usedToday);

    const message = `
🛠️ *MENU INPUT FIX MERAH*

📌 Gunakan fitur ini jika:
🔸 Nomor terkena login tidak tersedia
🔸 Nomor harus sudah terdaftar di WA
🔸 Login berubah menjadi SMS
🔸 Verifikasi gagal terus menerus

━━━━━━━━━━━━━━━━━━━━━━
👤 *INFORMASI AKUN*
├ 👑 Status: ${this.getRoleEmoji(user.role)} ${user.role.toUpperCase()}
├ 📊 Limit Harian: ${dailyLimit} Kali
├ 📧 Sender Aktif: ${activeSMTP}/${totalSMTP}
└ 📦 Slot Terpakai: ${usedToday}/${dailyLimit} (Sisa: ${remaining})
━━━━━━━━━━━━━━━━━━━━━━

📥 *Kirim nomor telepon*
Format: 1 nomor per baris

Contoh:
+62812345678910

⚠️ *Maksimal ${bulkLimit} nomor per kirim*
    `.trim();

    const keyboard = {
      inline_keyboard: [
        [
          { text: '❌ BATAL', callback_data: 'cancel_fix' },
          { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
        ]
      ]
    };

    // Set user state to waiting for fix input
    await User.findOneAndUpdate(
      { userId },
      { state: 'waiting_fix_input' }
    );

    await ctx.editMessageText(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    }).catch(async () => {
      await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    });
  }

  getDailyLimit(role) {
    const limitMap = {
      owner: 9999,
      developer: 9999,
      partner: 9999,
      admin: 9999,
      vvip: 9999,
      vip: 999,
      free: 2
    };
    return limitMap[role] || 2;
  }

  getBulkLimit(role) {
    const limitMap = {
      owner: 100,
      developer: 100,
      partner: 50,
      admin: 50,
      vvip: 25,
      vip: 5,
      free: 1
    };
    return limitMap[role] || 1;
  }

  getRoleEmoji(role) {
    const emojiMap = {
      owner: '👑',
      developer: '💻',
      partner: '🤝',
      admin: '🛡️',
      vvip: '💎',
      vip: '🌟',
      free: '👤'
    };
    return emojiMap[role] || '👤';
  }

  async handleVIPMenu(ctx) {
    const userId = ctx.from.id;
    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });

    const message = `
👑 *AKSES PREMIUM*

✨ *VIP:*
├ Unlimited Limit
├ 5 Nomor Sekaligus
├ Priority Queue
└ cPanel SMTP Access

🌟 *VVIP:*
├ Unlimited Limit
├ 25 Nomor Sekaligus
├ Highest Priority
└ Dedicated SMTP

━━━━━━━━━━━━━━━━━━━━━━
🛒 *PILIH PAKET:*
    `.trim();

    const packages = await this.bot.services.payment.getPackages();
    
    const keyboard = {
      inline_keyboard: []
    };

    for (const pkg of packages) {
      keyboard.inline_keyboard.push([
        {
          text: `${pkg.name} - Rp ${pkg.price.toLocaleString('id-ID')}`,
          callback_data: `select_package_${pkg.packageId}`
        }
      ]);
    }

    keyboard.inline_keyboard.push([
      { text: '🎁 TUKAR DENGAN KOIN', callback_data: 'redeem_vip' }
    ]);
    keyboard.inline_keyboard.push([
      { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
    ]);

    await ctx.editMessageText(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    }).catch(async () => {
      await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    });
  }

  async handleSelectPackage(ctx) {
    const packageId = ctx.callbackQuery.data.replace('select_package_', '');
    const userId = ctx.from.id;

    try {
      await ctx.reply('⏳ Membuat invoice...');

      const payment = await this.bot.services.payment.createInvoice(userId, packageId);

      await ctx.reply(
        `✅ Invoice berhasil dibuat!\n\n` +
        `Order ID: ${payment.orderId}\n` +
        `Silakan lakukan pembayaran sebelum expired.`
      );

    } catch (error) {
      await ctx.reply(`❌ Gagal membuat invoice: ${error.message}`);
    }
  }

  async handleCheckPayment(ctx) {
    const orderId = ctx.callbackQuery.data.replace('check_payment_', '');
    
    try {
      const result = await this.bot.services.payment.checkPayment(orderId);

      if (result.paid) {
        await ctx.reply('✅ Pembayaran berhasil! Akun Anda telah diupgrade.');
      } else if (result.expired) {
        await ctx.reply('⏰ Invoice sudah expired. Silakan buat invoice baru.');
      } else {
        await ctx.reply('⏳ Pembayaran belum terdeteksi. Silakan cek kembali.');
      }

    } catch (error) {
      await ctx.reply(`❌ Error: ${error.message}`);
    }
  }

  async handleReferralMenu(ctx) {
    const userId = ctx.from.id;
    const stats = await this.bot.services.referral.getReferralStats(userId);

    const message = `
🧧 *MENU REFERRAL*

📌 *Cara Kerja:*
1. Share link referral Anda
2. Teman join bot melalui link
3. Dapatkan koin
4. Tukar koin dengan VIP

━━━━━━━━━━━━━━━━━━━━━━
📊 *STATISTIK REFERRAL*
├ 👥 Total Referral: ${stats?.totalReferrals || 0}
├ ✅ Aktif: ${stats?.activeReferrals || 0}
├ 💰 Sukses: ${stats?.successfulReferrals || 0}
└ 🪙 Total Koin: ${stats?.totalCoins || 0}

🔗 *Link Referral:*
\`https://t.me/${process.env.BOT_USERNAME?.replace('@', '')}?start=${userId}\`

🏆 ${this.bot.services.referral?.coinsForVIP1Day || 100} Koin = VIP 1 Hari
🏆 ${this.bot.services.referral?.coinsForVIP7Days || 500} Koin = VIP 7 Hari
    `.trim();

    const keyboard = {
      inline_keyboard: [
        [
          { text: '📤 SHARE REFERRAL', switch_inline_query: `start=${userId}` },
          { text: '📊 STATISTIK', callback_data: 'referral_stats' }
        ],
        [
          { text: '🎁 TUKAR VIP', callback_data: 'redeem_vip' },
          { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
        ]
      ]
    };

    await ctx.editMessageText(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    }).catch(async () => {
      await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    });
  }

  async handleHistoryMenu(ctx) {
    const userId = ctx.from.id;
    const FixHistory = this.bot.managers.database.models.FixHistory;
    
    const history = await FixHistory.find({ userId })
      .sort({ createdAt: -1 })
      .limit(10);

    if (history.length === 0) {
      return ctx.editMessageText(
        '📜 *RIWAYAT FIX MERAH*\n\nBelum ada riwayat.',
        {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [
              [{ text: '🏠 MENU UTAMA', callback_data: 'menu_main' }]
            ]
          }
        }
      );
    }

    let message = '📜 *RIWAYAT FIX MERAH*\n\n';
    
    for (const item of history) {
      const statusEmoji = {
        pending: '⏳',
        processing: '🔄',
        success: '✅',
        failed: '❌',
        cancelled: '🚫'
      };

      const maskedPhone = this.maskPhoneNumber(item.phoneNumber);
      const date = moment(item.createdAt).format('DD/MM HH:mm');
      
      message += `${statusEmoji[item.status]} *${item.bandingId}*\n`;
      message += `├ 📱 ${maskedPhone}\n`;
      message += `├ 📅 ${date}\n`;
      message += `└ Status: ${item.status.toUpperCase()}\n\n`;
    }

    const keyboard = {
      inline_keyboard: [
        [
          { text: '🔄 REFRESH', callback_data: 'refresh_history' },
          { text: '🗑️ CLEAR', callback_data: 'clear_history' }
        ],
        [
          { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
        ]
      ]
    };

    await ctx.editMessageText(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    }).catch(async () => {
      await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    });
  }

  maskPhoneNumber(phoneNumber) {
    if (!phoneNumber || phoneNumber.length < 6) return phoneNumber || 'N/A';
    const start = phoneNumber.substring(0, 4);
    const end = phoneNumber.substring(phoneNumber.length - 4);
    return `${start}****${end}`;
  }

  async handleLeaderboardMenu(ctx) {
    const message = '🏆 *TOP GLOBAL*\n\nPilih kategori:';

    const keyboard = {
      inline_keyboard: [
        [
          { text: '👥 TOP USERS', callback_data: 'leaderboard_users' },
          { text: '🌍 TOP COUNTRIES', callback_data: 'leaderboard_countries' }
        ],
        [
          { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
        ]
      ]
    };

    await ctx.editMessageText(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    }).catch(async () => {
      await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    });
  }

  async handleCheckVerification(ctx) {
    const userId = ctx.from.id;
    
    // Check verification
    const { verificationMiddleware } = require('../middleware/verification');
    const isVerified = await checkUserVerification(this.bot, userId);

    if (isVerified) {
      // Update user
      const User = this.bot.managers.database.models.User;
      await User.findOneAndUpdate(
        { userId },
        { isVerified: true }
      );

      await ctx.reply('✅ Verifikasi berhasil! Selamat datang di Qashvra Fix Merah Pro.');
      
      // Send welcome message
      const user = await User.findOne({ userId });
      await this.sendWelcomeMessage(ctx, user);
    } else {
      await ctx.reply(
        '❌ Verifikasi gagal.\n\n' +
        'Pastikan Anda sudah bergabung dengan:\n' +
        '• @qashvra_channel\n' +
        '• @qashvra_group\n\n' +
        'Klik tombol JOIN di atas untuk bergabung.',
        {
          reply_markup: {
            inline_keyboard: [
              [
                { text: '📢 JOIN CHANNEL', url: 'https://t.me/qashvra_channel' },
                { text: '👥 JOIN GROUP', url: 'https://t.me/qashvra_group' }
              ],
              [
                { text: '✅ COBA LAGI', callback_data: 'check_verification' }
              ]
            ]
          }
        }
      );
    }
  }

  async handleSettingsMenu(ctx) {
    const message = '⚙️ *SETTINGS*\n\nPilih pengaturan:';

    const keyboard = {
      inline_keyboard: [
        [
          { text: '🌐 BAHASA', callback_data: 'settings_language' },
          { text: '🎨 TEMA', callback_data: 'settings_theme' }
        ],
        [
          { text: '🕐 TIMEZONE', callback_data: 'settings_timezone' },
          { text: '🔔 NOTIFIKASI', callback_data: 'settings_notification' }
        ],
        [
          { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
        ]
      ]
    };

    await ctx.editMessageText(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    }).catch(async () => {
      await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    });
  }

  async handleOwnerDashboard(ctx) {
    // Similar to showDashboard in CommandHandler
    await ctx.reply('📊 Loading dashboard...');
    // Implementation...
  }

  // Additional callback handlers would continue...
  // For brevity, I'm showing the structure. Each handler follows the same pattern.

  async handleStartFix(ctx) {
    // Set user state to waiting for phone numbers
    const User = this.bot.managers.database.models.User;
    await User.findOneAndUpdate(
      { userId: ctx.from.id },
      { state: 'waiting_fix_input' }
    );
  }

  async handleCancelFix(ctx) {
    const User = this.bot.managers.database.models.User;
    await User.findOneAndUpdate(
      { userId: ctx.from.id },
      { state: null }
    );

    await ctx.reply('❌ Fix Merah dibatalkan.', {
      reply_markup: {
        inline_keyboard: [
          [{ text: '🏠 MENU UTAMA', callback_data: 'menu_main' }]
        ]
      }
    });
  }

  async handleRedeemVIP(ctx) {
    const userId = ctx.from.id;
    const coins = await this.bot.services.referral.getTotalCoins(userId);

    const message = `
🎁 *TUKAR KOIN DENGAN VIP*

🪙 Koin Anda: ${coins}

Pilih paket:
    `.trim();

    const keyboard = {
      inline_keyboard: [
        [
          { text: '⭐ VIP 1 Hari (100 Koin)', callback_data: 'redeem_vip_1_day' },
        ],
        [
          { text: '🌟 VIP 7 Hari (500 Koin)', callback_data: 'redeem_vip_7_days' },
        ],
        [
          { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
        ]
      ]
    };

    await ctx.editMessageText(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    }).catch(async () => {
      await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    });
  }

  // More handlers would continue...
}

module.exports = CallbackHandler;