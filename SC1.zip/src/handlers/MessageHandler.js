const moment = require('moment-timezone');

class MessageHandler {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    this.userStates = new Map();
  }

  registerHandlers() {
    this.logger.info('Registering message handlers...');

    // Handle text messages
    this.bot.bot.on('text', async (ctx) => {
      await this.handleTextMessage(ctx);
    });

    // Handle photo messages (for payment proof)
    this.bot.bot.on('photo', async (ctx) => {
      await this.handlePhotoMessage(ctx);
    });

    // Handle document messages (for backup restore)
    this.bot.bot.on('document', async (ctx) => {
      await this.handleDocumentMessage(ctx);
    });

    this.logger.info('Message handlers registered');
  }

  async handleTextMessage(ctx) {
    try {
      const userId = ctx.from.id;
      const messageText = ctx.message.text;

      // Skip command messages
      if (messageText.startsWith('/')) {
        return;
      }

      // Get user state
      const userState = await this.getUserState(userId);

      // Route based on user state
      switch (userState) {
        case 'waiting_fix_input':
          await this.handleFixInput(ctx);
          break;
        case 'waiting_broadcast':
          await this.handleBroadcastInput(ctx);
          break;
        case 'waiting_smtp_config':
          await this.handleSMTPConfigInput(ctx);
          break;
        case 'waiting_custom_package':
          await this.handleCustomPackageInput(ctx);
          break;
        case 'waiting_search_user':
          await this.handleSearchUser(ctx);
          break;
        case 'waiting_add_premium':
          await this.handleAddPremiumInput(ctx);
          break;
        case 'waiting_ban_reason':
          await this.handleBanReasonInput(ctx);
          break;
        default:
          // Check for phone number pattern
          if (this.isPhoneNumber(messageText)) {
            await this.handleFixInput(ctx);
          }
          break;
      }

    } catch (error) {
      this.logger.error('Message handler error:', error);
    }
  }

  async handleFixInput(ctx) {
    const userId = ctx.from.id;
    const messageText = ctx.message.text;

    try {
      // Validate user
      const User = this.bot.managers.database.models.User;
      const user = await User.findOne({ userId });

      if (!user) {
        return ctx.reply('❌ Silakan /start terlebih dahulu.');
      }

      if (user.isBanned) {
        return ctx.reply(`🚫 Akun Anda dibanned.\nAlasan: ${user.banReason || 'Tidak ada alasan'}`);
      }

      // Parse phone numbers
      const phoneNumbers = this.parsePhoneNumbers(messageText);

      if (phoneNumbers.length === 0) {
        return ctx.reply(
          '❌ Format nomor tidak valid.\n\n' +
          'Kirim nomor dengan format:\n+62812345678910\n\n' +
          'Atau kirim beberapa nomor (1 per baris).'
        );
      }

      // Check bulk limit
      const bulkLimit = this.getBulkLimit(user.role);
      if (phoneNumbers.length > bulkLimit) {
        return ctx.reply(
          `⚠️ Maksimal ${bulkLimit} nomor per kirim untuk status ${user.role.toUpperCase()}.\n` +
          `Anda mengirim ${phoneNumbers.length} nomor.`
        );
      }

      // Check daily limit
      const dailyLimit = this.getDailyLimit(user.role);
      const usedToday = user.dailyFixCount || 0;
      
      if (usedToday >= dailyLimit && user.role !== 'owner' && user.role !== 'developer') {
        return ctx.reply(
          `⚠️ Limit harian Anda sudah habis (${dailyLimit} per hari).\n` +
          `Upgrade ke VIP untuk unlimited limit.`
        );
      }

      // Validate each phone number
      const validNumbers = [];
      const invalidNumbers = [];

      for (const number of phoneNumbers) {
        if (this.validatePhoneNumber(number)) {
          validNumbers.push(number);
        } else {
          invalidNumbers.push(number);
        }
      }

      if (validNumbers.length === 0) {
        return ctx.reply(
          '❌ Semua nomor tidak valid.\n\n' +
          'Format yang benar: +62812345678910'
        );
      }

      // Process fix
      await ctx.reply(`⏳ Memproses ${validNumbers.length} nomor...`);

      const results = await this.bot.managers.queue.addBulkToQueue(
        userId,
        validNumbers,
        user.role
      );

      // Send results
      let responseMessage = `📊 *HASIL INPUT FIX MERAH*\n\n`;
      
      let queuedCount = 0;
      let errorCount = 0;

      for (const result of results) {
        if (result.success) {
          queuedCount++;
          responseMessage += `✅ ${this.maskPhoneNumber(result.phoneNumber)}\n`;
          responseMessage += `├ 🆔 ${result.bandingId}\n`;
          responseMessage += `├ 📍 Posisi: ${result.position}\n`;
          responseMessage += `└ ⏱️ Estimasi: ${result.estimatedTime}\n\n`;
        } else {
          errorCount++;
          responseMessage += `❌ ${this.maskPhoneNumber(result.phoneNumber)}: ${result.error}\n\n`;
        }
      }

      responseMessage += `━━━━━━━━━━━━━━━━━━━━━━\n`;
      responseMessage += `📊 Total: ${validNumbers.length} | ✅ ${queuedCount} | ❌ ${errorCount}\n`;
      
      if (invalidNumbers.length > 0) {
        responseMessage += `⚠️ ${invalidNumbers.length} nomor tidak valid\n`;
      }

      const keyboard = {
        inline_keyboard: [
          [
            { text: '📜 LIHAT RIWAYAT', callback_data: 'menu_history' },
            { text: '🔄 FIX LAGI', callback_data: 'menu_fix_merah' }
          ],
          [
            { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
          ]
        ]
      };

      await ctx.reply(responseMessage, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });

      // Clear user state
      await User.findOneAndUpdate({ userId }, { state: null });

      // Log activity
      await this.logActivity(userId, 'fix', `Processed ${validNumbers.length} numbers`);

    } catch (error) {
      this.logger.error(`Fix input error for ${userId}:`, error);
      
      let errorMessage = '❌ Gagal memproses fix.';

      if (error.message.includes('Daily limit')) {
        errorMessage = '⚠️ ' + error.message;
      } else if (error.message.includes('Cooldown')) {
        errorMessage = '⏰ ' + error.message;
      } else if (error.message.includes('queue')) {
        errorMessage = '📋 ' + error.message;
      }

      await ctx.reply(errorMessage, {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🏠 MENU UTAMA', callback_data: 'menu_main' }]
          ]
        }
      });
    }
  }

  parsePhoneNumbers(text) {
    // Split by newline or comma
    const lines = text.split(/[\n,]+/);
    const numbers = [];

    for (let line of lines) {
      line = line.trim();
      
      // Remove any non-numeric characters except +
      line = line.replace(/[^\d+]/g, '');
      
      if (line) {
        numbers.push(line);
      }
    }

    return numbers;
  }

  validatePhoneNumber(phoneNumber) {
    // Must start with +
    if (!phoneNumber.startsWith('+')) {
      return false;
    }

    // Remove + for length check
    const digits = phoneNumber.substring(1);
    
    // Must be between 10-15 digits
    if (digits.length < 10 || digits.length > 15) {
      return false;
    }

    // Must be all digits after +
    if (!/^\d+$/.test(digits)) {
      return false;
    }

    // Common country codes validation
    const validPrefixes = [
      '62',   // Indonesia
      '1',    // US/Canada
      '44',   // UK
      '966',  // Saudi Arabia
      '7',    // Russia
      '91',   // India
      '81',   // Japan
      '86',   // China
      '971',  // UAE
      '60',   // Malaysia
    ];

    const countryCode = digits.substring(0, digits.length - 8);
    if (!validPrefixes.some(prefix => countryCode.startsWith(prefix))) {
      // Still accept unknown country codes but log warning
      this.logger.warn(`Unknown country code: ${countryCode}`);
    }

    return true;
  }

  isPhoneNumber(text) {
    const lines = text.trim().split(/[\n,]+/);
    
    for (const line of lines) {
      const cleaned = line.trim().replace(/[^\d+]/g, '');
      
      if (cleaned.startsWith('+') && cleaned.length >= 11) {
        return true;
      }
    }

    return false;
  }

  getBulkLimit(role) {
    const limitMap = {
      owner: 100,
      developer: 100,
      partner: 50,
      admin: 50,
      moderator: 10,
      reseller: 20,
      vvip: 25,
      vip: 5,
      free: 1
    };
    return limitMap[role] || 1;
  }

  getDailyLimit(role) {
    const limitMap = {
      owner: 99999,
      developer: 99999,
      partner: 9999,
      admin: 9999,
      moderator: 999,
      reseller: 500,
      vvip: 9999,
      vip: 999,
      free: 2
    };
    return limitMap[role] || 2;
  }

  maskPhoneNumber(phoneNumber) {
    if (!phoneNumber || phoneNumber.length < 6) return phoneNumber || 'N/A';
    const start = phoneNumber.substring(0, 4);
    const end = phoneNumber.substring(phoneNumber.length - 4);
    return `${start}****${end}`;
  }

  async handlePhotoMessage(ctx) {
    const userId = ctx.from.id;
    const userState = await this.getUserState(userId);

    if (userState === 'waiting_payment_proof') {
      await this.handlePaymentProof(ctx);
    } else {
      // Default photo handling
      await ctx.reply('📸 Foto diterima. Gunakan menu yang sesuai untuk upload.');
    }
  }

  async handlePaymentProof(ctx) {
    const userId = ctx.from.id;
    const photo = ctx.message.photo[ctx.message.photo.length - 1];

    try {
      // Get file
      const file = await this.bot.bot.telegram.getFile(photo.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${process.env.BOT_TOKEN}/${file.file_path}`;

      // Save payment proof
      const Payment = this.bot.managers.database.models.Payment;
      const pendingPayment = await Payment.findOne({
        userId,
        status: 'pending'
      }).sort({ createdAt: -1 });

      if (!pendingPayment) {
        return ctx.reply('❌ Tidak ada invoice pending.');
      }

      pendingPayment.paymentProof = fileUrl;
      await pendingPayment.save();

      await ctx.reply(
        '✅ Bukti pembayaran diterima.\n\n' +
        'Admin akan memverifikasi pembayaran Anda.\n' +
        'Anda akan menerima notifikasi setelah diverifikasi.',
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: '✅ CEK STATUS', callback_data: `check_payment_${pendingPayment.orderId}` }],
              [{ text: '🏠 MENU UTAMA', callback_data: 'menu_main' }]
            ]
          }
        }
      );

      // Notify admins
      await this.notifyAdmins(
        '📸 New Payment Proof',
        `User: ${userId}\nOrder: ${pendingPayment.orderId}\nAmount: Rp ${pendingPayment.amount.toLocaleString('id-ID')}`
      );

      // Clear state
      const User = this.bot.managers.database.models.User;
      await User.findOneAndUpdate({ userId }, { state: null });

    } catch (error) {
      this.logger.error(`Payment proof error:`, error);
      await ctx.reply('❌ Gagal memproses bukti pembayaran.');
    }
  }

  async handleDocumentMessage(ctx) {
    const userId = ctx.from.id;
    const userState = await this.getUserState(userId);

    if (userState === 'waiting_restore_file') {
      await this.handleRestoreFile(ctx);
    }
  }

  async handleRestoreFile(ctx) {
    const userId = ctx.from.id;

    // Only owner can restore
    if (userId !== parseInt(process.env.OWNER_ID)) {
      return;
    }

    const document = ctx.message.document;

    if (!document.file_name?.endsWith('.tar.gz')) {
      return ctx.reply('❌ File harus berformat .tar.gz');
    }

    try {
      const file = await this.bot.bot.telegram.getFile(document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${process.env.BOT_TOKEN}/${file.file_path}`;

      await ctx.reply('⏳ Memproses restore...');

      // Download and restore
      // Implementation would download file and call restore function

      await ctx.reply('✅ Restore berhasil!');

      // Clear state
      const User = this.bot.managers.database.models.User;
      await User.findOneAndUpdate({ userId }, { state: null });

    } catch (error) {
      this.logger.error(`Restore error:`, error);
      await ctx.reply('❌ Gagal restore.');
    }
  }

  async handleBroadcastInput(ctx) {
    const userId = ctx.from.id;
    
    // Check if admin
    const isAdmin = await this.isAdmin(userId);
    if (!isAdmin) return;

    const message = ctx.message.text;

    await ctx.reply('📢 Mengirim broadcast...');

    // Send broadcast
    await this.bot.handlers?.commandHandler?.sendBroadcast(ctx, message);

    // Clear state
    const User = this.bot.managers.database.models.User;
    await User.findOneAndUpdate({ userId }, { state: null });
  }

  async handleSMTPConfigInput(ctx) {
    const userId = ctx.from.id;
    const messageText = ctx.message.text;

    try {
      // Parse SMTP config
      // Format: host:port:username:password
      const parts = messageText.split(':');
      
      if (parts.length < 4) {
        return ctx.reply(
          '❌ Format tidak valid.\n\n' +
          'Format: host:port:username:password\n' +
          'Contoh: smtp.gmail.com:587:email@gmail.com:apppassword'
        );
      }

      const smtpConfig = {
        host: parts[0].trim(),
        port: parseInt(parts[1]),
        secure: parts[1] === '465',
        username: parts[2].trim(),
        password: parts.slice(3).join(':').trim()
      };

      const result = await this.bot.services.smtp.addUserSMTP(userId, smtpConfig);

      if (result.success) {
        await ctx.reply(
          '✅ SMTP berhasil ditambahkan!\n\n' +
          'SMTP Anda akan digunakan untuk proses fix merah.'
        );
      }

    } catch (error) {
      await ctx.reply(`❌ Gagal menambah SMTP: ${error.message}`);
    }

    // Clear state
    const User = this.bot.managers.database.models.User;
    await User.findOneAndUpdate({ userId }, { state: null });
  }

  async handleCustomPackageInput(ctx) {
    // Implementation for custom package input
  }

  async handleSearchUser(ctx) {
    const userId = ctx.from.id;
    const searchQuery = ctx.message.text;

    try {
      const User = this.bot.managers.database.models.User;
      
      let user;
      if (/^\d+$/.test(searchQuery)) {
        user = await User.findOne({ userId: parseInt(searchQuery) });
      } else {
        user = await User.findOne({
          $or: [
            { username: searchQuery.replace('@', '') },
            { fullName: { $regex: searchQuery, $options: 'i' } }
          ]
        });
      }

      if (!user) {
        return ctx.reply('❌ User tidak ditemukan.');
      }

      const message = `
👤 *USER DITEMUKAN*

🆔 ID: ${user.userId}
👤 Nama: ${user.fullName}
📛 Username: @${user.username || 'N/A'}
👑 Status: ${user.role.toUpperCase()}
📅 Bergabung: ${moment(user.createdAt).format('DD/MM/YYYY')}
🛠️ Total Fix: ${user.totalFix || 0}
🎯 Berhasil: ${user.successFix || 0}
💰 Total Payment: ${await this.getUserTotalPayment(user.userId)}
      `.trim();

      const keyboard = {
        inline_keyboard: [
          [
            { text: '👑 ADD PREMIUM', callback_data: `add_premium_${user.userId}` },
            { text: '🚫 BAN USER', callback_data: `ban_user_${user.userId}` }
          ],
          [
            { text: '🔙 BACK', callback_data: 'owner_users' }
          ]
        ]
      };

      await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });

    } catch (error) {
      this.logger.error(`Search user error:`, error);
      await ctx.reply('❌ Gagal mencari user.');
    }

    // Clear state
    const User = this.bot.managers.database.models.User;
    await User.findOneAndUpdate({ userId }, { state: null });
  }

  async handleAddPremiumInput(ctx) {
    // Implementation for adding premium
  }

  async handleBanReasonInput(ctx) {
    // Implementation for ban reason
  }

  async getUserState(userId) {
    // Check cache first
    if (this.userStates.has(userId)) {
      return this.userStates.get(userId);
    }

    // Check database
    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });
    
    const state = user?.state || null;
    
    // Cache state
    if (state) {
      this.userStates.set(userId, state);
      // Clear cache after 5 minutes
      setTimeout(() => this.userStates.delete(userId), 300000);
    }
    
    return state;
  }

  async isAdmin(userId) {
    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });
    return user && ['owner', 'developer', 'partner', 'admin'].includes(user.role);
  }

  async logActivity(userId, type, message) {
    try {
      const Log = this.bot.managers.database.models.Log;
      await Log.create({
        type,
        level: 'info',
        userId,
        message,
        timestamp: new Date()
      });
    } catch (error) {
      this.logger.error('Failed to log activity:', error);
    }
  }

  async getUserTotalPayment(userId) {
    try {
      const Payment = this.bot.managers.database.models.Payment;
      const result = await Payment.aggregate([
        { $match: { userId, status: 'paid' } },
        { $group: { _id: null, total: { $sum: '$amount' } } }
      ]);
      return result[0]?.total || 0;
    } catch (error) {
      return 0;
    }
  }

  async notifyAdmins(title, message) {
    const User = this.bot.managers.database.models.User;
    const admins = await User.find({
      role: { $in: ['owner', 'developer', 'admin'] }
    });

    for (const admin of admins) {
      try {
        await this.bot.bot.telegram.sendMessage(
          admin.userId,
          `📢 ${title}\n\n${message}`
        );
      } catch (error) {
        this.logger.warn(`Failed to notify admin ${admin.userId}`);
      }
    }
  }
}

module.exports = MessageHandler;