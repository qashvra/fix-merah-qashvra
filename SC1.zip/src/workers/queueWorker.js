const { parentPort, workerData } = require('worker_threads');
const mongoose = require('mongoose');
const nodemailer = require('nodemailer');

class QueueWorker {
  constructor() {
    this.workerId = workerData.workerId;
    this.isProcessing = false;
    this.stats = {
      processed: 0,
      success: 0,
      failed: 0
    };
    
    this.log(`Worker ${this.workerId} started`);
  }

  async initialize() {
    try {
      // Connect to MongoDB
      await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/qashvra_bot', {
        maxPoolSize: 2,
        serverSelectionTimeoutMS: 5000
      });
      
      this.log('Connected to MongoDB');
      
      // Listen for messages from parent
      parentPort.on('message', async (message) => {
        await this.handleMessage(message);
      });

      // Send ready signal
      parentPort.postMessage({ 
        type: 'worker_ready', 
        data: { workerId: this.workerId }
      });

      // Send periodic stats
      setInterval(() => {
        parentPort.postMessage({
          type: 'worker_stats',
          data: this.stats
        });
      }, 30000);

    } catch (error) {
      this.log(`Initialization failed: ${error.message}`);
      parentPort.postMessage({
        type: 'error',
        data: error.message
      });
    }
  }

  async handleMessage(message) {
    try {
      switch (message.type) {
        case 'process_fix':
          await this.processFix(message.data);
          break;
        case 'shutdown':
          await this.shutdown();
          break;
        default:
          this.log(`Unknown message type: ${message.type}`);
      }
    } catch (error) {
      this.log(`Error handling message: ${error.message}`);
      parentPort.postMessage({
        type: 'error',
        data: error.message
      });
    }
  }

  async processFix(data) {
    const { queueId, userId, phoneNumber, bandingId } = data;
    
    this.isProcessing = true;
    this.log(`Processing fix for ${phoneNumber} (${bandingId})`);

    try {
      // Get SMTP sender
      const smtpConfig = await this.getSMTPConfig(userId);
      
      if (!smtpConfig) {
        throw new Error('No SMTP configuration available');
      }

      // Get template
      const template = await this.getTemplate(phoneNumber);
      
      if (!template) {
        throw new Error('No template available');
      }

      // Create transporter
      const transporter = nodemailer.createTransport({
        host: smtpConfig.host,
        port: smtpConfig.port,
        secure: smtpConfig.secure,
        auth: {
          user: smtpConfig.username,
          pass: this.decryptPassword(smtpConfig.password)
        }
      });

      // Generate email content
      const emailContent = this.generateEmailContent(template, phoneNumber);
      
      // Send email
      const email = await transporter.sendMail({
        from: `"WhatsApp Support" <${smtpConfig.username}>`,
        to: this.getTargetEmail(phoneNumber),
        subject: emailContent.subject,
        text: emailContent.body
      });

      this.log(`Email sent for ${phoneNumber}: ${email.messageId}`);
      
      // Update SMTP stats
      await this.updateSMTPStats(smtpConfig._id, true);
      
      // Send success response
      parentPort.postMessage({
        type: 'fix_completed',
        data: {
          queueId,
          userId,
          phoneNumber,
          bandingId,
          result: {
            messageId: email.messageId,
            smtpUsed: smtpConfig.username,
            templateUsed: template.templateId
          }
        }
      });

      this.stats.success++;
      this.stats.processed++;

    } catch (error) {
      this.log(`Failed to process fix for ${phoneNumber}: ${error.message}`);
      
      // Send failure response
      parentPort.postMessage({
        type: 'fix_failed',
        data: {
          queueId,
          userId,
          phoneNumber,
          bandingId,
          error: error.message,
          attemptCount: 1
        }
      });

      this.stats.failed++;
      this.stats.processed++;

    } finally {
      this.isProcessing = false;
    }
  }

  async getSMTPConfig(userId) {
    try {
      const SMTPConfig = mongoose.model('SMTPConfig');
      
      // Get user's role
      const User = mongoose.model('User');
      const user = await User.findOne({ userId });
      const userRole = user?.role || 'free';
      
      // Get active SMTP based on role
      const query = { status: 'active' };
      
      if (userRole === 'vip' || userRole === 'vvip') {
        query.type = { $in: ['owner', 'premium'] };
      } else {
        query.type = 'shared';
      }
      
      const smtpConfigs = await SMTPConfig.find(query).sort({ totalSent: 1 });
      
      if (smtpConfigs.length === 0) {
        return null;
      }
      
      // Return least used SMTP
      return smtpConfigs[0];
      
    } catch (error) {
      this.log(`Failed to get SMTP config: ${error.message}`);
      return null;
    }
  }

  async getTemplate(phoneNumber) {
    try {
      const Template = mongoose.model('Template');
      
      // Get country from phone number
      const country = this.detectCountry(phoneNumber);
      
      // Get active templates for country
      let templates = await Template.find({ 
        country: country, 
        isActive: true,
        cooldown: { $lte: Date.now() }
      }).sort({ successRate: -1, priority: 1 });
      
      if (templates.length === 0) {
        // Fallback to general templates
        templates = await Template.find({ 
          country: 'all', 
          isActive: true,
          cooldown: { $lte: Date.now() }
        }).sort({ successRate: -1, priority: 1 });
      }
      
      if (templates.length === 0) {
        return null;
      }
      
      // Random selection with higher chance for high success rate
      const totalWeight = templates.reduce((sum, t) => sum + (t.successRate || 1), 0);
      let random = Math.random() * totalWeight;
      
      for (const template of templates) {
        random -= (template.successRate || 1);
        if (random <= 0) {
          return template;
        }
      }
      
      return templates[0];
      
    } catch (error) {
      this.log(`Failed to get template: ${error.message}`);
      return null;
    }
  }

  generateEmailContent(template, phoneNumber) {
    const verificationLink = this.generateVerificationLink(phoneNumber);
    
    return {
      subject: template.subject,
      body: template.body.replace('{verification_link}', verificationLink)
    };
  }

  generateVerificationLink(phoneNumber) {
    // Generate a realistic-looking verification link
    const timestamp = Date.now();
    const hash = Buffer.from(`${phoneNumber}:${timestamp}`).toString('base64');
    return `https://wa.me/verify?phone=${phoneNumber}&token=${hash}`;
  }

  getTargetEmail(phoneNumber) {
    // Generate target email based on phone number
    // This would be customized based on your needs
    return `support@whatsapp.com`;
  }

  detectCountry(phoneNumber) {
    // Simple country detection based on phone prefix
    if (phoneNumber.startsWith('+62')) return 'ID';
    if (phoneNumber.startsWith('+1')) return 'US';
    if (phoneNumber.startsWith('+44')) return 'UK';
    if (phoneNumber.startsWith('+966')) return 'SA';
    if (phoneNumber.startsWith('+7')) return 'RU';
    return 'all';
  }

  async updateSMTPStats(smtpId, success) {
    try {
      const SMTPConfig = mongoose.model('SMTPConfig');
      const update = success
        ? { $inc: { totalSent: 1 }, lastUsed: new Date() }
        : { $inc: { totalFailed: 1 }, lastUsed: new Date() };
      
      await SMTPConfig.findByIdAndUpdate(smtpId, update);
    } catch (error) {
      this.log(`Failed to update SMTP stats: ${error.message}`);
    }
  }

  decryptPassword(encryptedPassword) {
    // In production, implement proper decryption
    // This is a placeholder
    return encryptedPassword;
  }

  log(message) {
    console.log(`[Worker ${this.workerId}] ${new Date().toISOString()} - ${message}`);
  }

  async shutdown() {
    this.log('Shutting down...');
    await mongoose.disconnect();
    process.exit(0);
  }
}

// Initialize worker
const worker = new QueueWorker();
worker.initialize().catch((error) => {
  console.error(`Worker initialization failed:`, error);
  process.exit(1);
});