const crypto = require('crypto');
const CRC32 = require('crc-32');
const QRCode = require('qrcode');

class QRISGenerator {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    
    // Base QRIS static configuration
    this.baseQRIS = '00020101021126570011ID.DANA.WWW011893600915382506702602098250670260303UMI51440014ID.CO.QRIS.WWW0215ID10253714442470303UMI5204481453033605802ID5907ALL PAY6011Kab. Bantul6105557726304F065';
    
    // QRIS Constants
    this.merchantInfo = {
      name: process.env.QRIS_MERCHANT_NAME || 'ALL PAY',
      city: process.env.QRIS_MERCHANT_CITY || 'Kab. Bantul',
      postal: process.env.QRIS_MERCHANT_POSTAL || '55772'
    };
  }

  async initialize() {
    this.logger.info('QRIS Generator initialized');
  }

  /**
   * Generate dynamic QRIS string with custom amount
   * @param {number} amount - Amount in Rupiah
   * @returns {string} QRIS string
   */
  generateQRISString(amount) {
    try {
      // Validate amount
      if (!amount || amount <= 0) {
        throw new Error('Invalid amount');
      }

      // Parse base QRIS
      let qrisString = this.baseQRIS;

      // Modify amount field (tag 54)
      const amountStr = amount.toString();
      const amountLength = amountStr.length.toString().padStart(2, '0');
      const amountTag = `54${amountLength}${amountStr}`;

      // Replace or insert amount tag
      if (qrisString.includes('54')) {
        qrisString = qrisString.replace(/54\d{2}\d+/, amountTag);
      } else {
        // Insert before CRC
        const crcPosition = qrisString.length - 8;
        qrisString = qrisString.slice(0, crcPosition) + amountTag + qrisString.slice(crcPosition);
      }

      // Update merchant info
      qrisString = this.updateMerchantInfo(qrisString);

      // Recalculate CRC16
      const qrisWithoutCRC = qrisString.slice(0, -8);
      const newCRC = this.calculateCRC(qrisWithoutCRC);
      
      return qrisWithoutCRC + newCRC;

    } catch (error) {
      this.logger.error('Failed to generate QRIS string:', error);
      throw error;
    }
  }

  /**
   * Update merchant information in QRIS string
   * @param {string} qrisString 
   * @returns {string}
   */
  updateMerchantInfo(qrisString) {
    // Update merchant name (tag 59)
    if (this.merchantInfo.name) {
      const merchantName = this.merchantInfo.name;
      const nameLength = merchantName.length.toString().padStart(2, '0');
      const nameTag = `59${nameLength}${merchantName}`;
      
      if (qrisString.includes('59')) {
        qrisString = qrisString.replace(/59\d{2}[^5]+/, nameTag);
      }
    }

    // Update merchant city (tag 60)
    if (this.merchantInfo.city) {
      const merchantCity = this.merchantInfo.city;
      const cityLength = merchantCity.length.toString().padStart(2, '0');
      const cityTag = `60${cityLength}${merchantCity}`;
      
      if (qrisString.includes('60')) {
        qrisString = qrisString.replace(/60\d{2}[^6]+/, cityTag);
      }
    }

    // Update postal code (tag 61)
    if (this.merchantInfo.postal) {
      const postalCode = this.merchantInfo.postal;
      const postalLength = postalCode.length.toString().padStart(2, '0');
      const postalTag = `61${postalLength}${postalCode}`;
      
      if (qrisString.includes('61')) {
        qrisString = qrisString.replace(/61\d{2}[^6]+/, postalTag);
      }
    }

    return qrisString;
  }

  /**
   * Calculate CRC16 for QRIS
   * @param {string} data 
   * @returns {string}
   */
  calculateCRC(data) {
    // Convert string to bytes
    const bytes = Buffer.from(data, 'utf8');
    
    // Calculate CRC16-CCITT
    const crc = CRC32.buf(bytes) & 0xFFFF;
    
    // Convert to 4-character hex string
    return crc.toString(16).toUpperCase().padStart(4, '0');
  }

  /**
   * Generate QR code image from QRIS string
   * @param {string} qrisString 
   * @returns {Buffer} QR code image buffer
   */
  async generateQRCodeImage(qrisString) {
    try {
      const qrCodeBuffer = await QRCode.toBuffer(qrisString, {
        type: 'png',
        width: 500,
        margin: 4,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });

      return qrCodeBuffer;

    } catch (error) {
      this.logger.error('Failed to generate QR code image:', error);
      throw error;
    }
  }

  /**
   * Generate invoice with QR code
   * @param {object} invoiceData 
   * @returns {object}
   */
  async generateInvoice(invoiceData) {
    try {
      const {
        orderId,
        userId,
        packageName,
        amount,
        duration
      } = invoiceData;

      // Generate QRIS string
      const qrisString = this.generateQRISString(amount);
      
      // Generate QR code
      const qrCodeImage = await this.generateQRCodeImage(qrisString);
      
      // Generate expiry time (10 minutes)
      const expiryTime = new Date(Date.now() + 10 * 60 * 1000);
      
      // Format invoice message
      const invoiceMessage = `
💳 INVOICE PAYMENT

🔖 Order ID: ${orderId}
📦 Paket: ${packageName}
💰 Total: Rp ${amount.toLocaleString('id-ID')}
⏰ Expired: 10 Menit

⚠️ Klik CEK PEMBAYARAN setelah transfer!

Powered by Qashvra Fix Merah Pro
      `.trim();

      const invoice = {
        orderId,
        userId,
        qrisString,
        qrCodeImage,
        amount,
        packageName,
        duration,
        expiryTime,
        status: 'pending',
        message: invoiceMessage,
        createdAt: new Date()
      };

      // Save invoice to database
      await this.saveInvoice(invoice);

      return invoice;

    } catch (error) {
      this.logger.error('Failed to generate invoice:', error);
      throw error;
    }
  }

  /**
   * Save invoice to database
   * @param {object} invoice 
   */
  async saveInvoice(invoice) {
    try {
      const Invoice = mongoose.model('Invoice');
      const newInvoice = new Invoice(invoice);
      await newInvoice.save();
      
      this.logger.info(`Invoice ${invoice.orderId} saved successfully`);
    } catch (error) {
      this.logger.error('Failed to save invoice:', error);
      throw error;
    }
  }

  /**
   * Validate QRIS string format
   * @param {string} qrisString 
   * @returns {boolean}
   */
  validateQRIS(qrisString) {
    try {
      if (!qrisString || qrisString.length < 20) {
        return false;
      }

      // Check if starts with QRIS header
      if (!qrisString.startsWith('000201')) {
        return false;
      }

      // Extract CRC
      const dataWithoutCRC = qrisString.slice(0, -4);
      const crcReceived = qrisString.slice(-4);
      
      // Calculate CRC
      const crcCalculated = this.calculateCRC(dataWithoutCRC);
      
      // Compare CRC
      return crcReceived.toUpperCase() === crcCalculated.toUpperCase();

    } catch (error) {
      return false;
    }
  }

  /**
   * Parse QRIS string to object
   * @param {string} qrisString 
   * @returns {object}
   */
  parseQRIS(qrisString) {
    try {
      const result = {};
      let index = 0;
      
      while (index < qrisString.length - 4) { // Exclude CRC
        const tag = qrisString.substring(index, index + 2);
        const length = parseInt(qrisString.substring(index + 2, index + 4));
        const value = qrisString.substring(index + 4, index + 4 + length);
        
        result[tag] = value;
        index += 4 + length;
      }
      
      result.crc = qrisString.slice(-4);
      
      return result;

    } catch (error) {
      this.logger.error('Failed to parse QRIS:', error);
      return null;
    }
  }
}

const mongoose = require('mongoose');

// Invoice Schema
const invoiceSchema = new mongoose.Schema({
  orderId: { type: String, required: true, unique: true },
  userId: { type: Number, required: true },
  qrisString: { type: String, required: true },
  amount: { type: Number, required: true },
  packageName: { type: String, required: true },
  duration: { type: Number, required: true },
  status: { 
    type: String, 
    enum: ['pending', 'paid', 'expired', 'failed', 'cancelled'],
    default: 'pending'
  },
  expiryTime: { type: Date, required: true },
  paidAt: Date,
  transactionId: String,
  paymentMethod: String,
  createdAt: { type: Date, default: Date.now }
});

mongoose.model('Invoice', invoiceSchema);

module.exports = QRISGenerator;