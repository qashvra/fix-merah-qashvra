const mongoose = require('mongoose');
const moment = require('moment-timezone');

class StatisticsService {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    this.updateInterval = null;
    this.cache = {
      lastUpdate: null,
      data: {}
    };
  }

  async initialize() {
    this.logger.info('Initializing Statistics Service...');
    
    // Start real-time stats update
    this.startStatsUpdate();
    
    // Initialize today's stats
    await this.initializeTodayStats();
    
    this.logger.info('Statistics Service initialized');
  }

  async initializeTodayStats() {
    try {
      const Statistics = this.bot.managers.database.models.Statistics;
      const today = new Date().toISOString().split('T')[0];
      
      const existing = await Statistics.findOne({ date: today });
      
      if (!existing) {
        await Statistics.create({
          date: today,
          totalUsers: 0,
          newUsers: 0,
          activeUsers: 0,
          totalFix: 0,
          successFix: 0,
          failedFix: 0,
          totalPayments: 0,
          totalRevenue: 0,
          activeSMTP: 0,
          queueSize: 0,
          hourlyStats: [],
          createdAt: new Date()
        });
      }
    } catch (error) {
      this.logger.error('Failed to initialize today stats:', error);
    }
  }

  startStatsUpdate() {
    // Update stats every 30 seconds
    this.updateInterval = setInterval(async () => {
      try {
        await this.updateRealtimeStats();
      } catch (error) {
        this.logger.error('Stats update failed:', error);
      }
    }, 30000);
  }

  async updateRealtimeStats() {
    const stats = await this.collectAllStats();
    this.cache.data = stats;
    this.cache.lastUpdate = new Date();

    // Emit stats via Socket.IO if available
    if (this.bot.io) {
      this.bot.io.emit('stats:update', stats);
    }
  }

  async collectAllStats() {
    const User = this.bot.managers.database.models.User;
    const SMTPConfig = this.bot.managers.database.models.SMTPConfig;
    const Payment = this.bot.managers.database.models.Payment;
    const FixHistory = this.bot.managers.database.models.FixHistory;
    const Queue = this.bot.managers.database.models.Queue;

    const today = new Date().toISOString().split('T')[0];

    // Users stats
    const totalUsers = await User.countDocuments();
    const newUsersToday = await User.countDocuments({
      createdAt: { $gte: new Date(today) }
    });
    const activeUsersToday = await this.getActiveUsersToday();

    // SMTP stats
    const activeSMTP = await SMTPConfig.countDocuments({ status: 'active' });
    const totalSMTP = await SMTPConfig.countDocuments();
    const failedSMTP = await SMTPConfig.countDocuments({ status: 'failed' });

    // Fix stats
    const totalFix = await FixHistory.countDocuments();
    const todayFix = await FixHistory.countDocuments({
      createdAt: { $gte: new Date(today) }
    });
    const todaySuccess = await FixHistory.countDocuments({
      createdAt: { $gte: new Date(today) },
      status: 'success'
    });
    const todayFailed = await FixHistory.countDocuments({
      createdAt: { $gte: new Date(today) },
      status: 'failed'
    });

    // Payment stats
    const totalPayments = await Payment.countDocuments({ status: 'paid' });
    const todayPayments = await Payment.countDocuments({
      status: 'paid',
      paidAt: { $gte: new Date(today) }
    });

    const todayRevenue = await Payment.aggregate([
      {
        $match: {
          status: 'paid',
          paidAt: { $gte: new Date(today) }
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$amount' }
        }
      }
    ]);

    // Queue stats
    const queueSize = await Queue.countDocuments({ status: { $in: ['queued', 'processing'] } });

    // Country stats
    const topCountries = await this.getTopCountries();

    // Hourly stats
    const hourlyStats = await this.getHourlyStats();

    // Role distribution
    const roleDistribution = await this.getRoleDistribution();

    return {
      timestamp: new Date(),
      users: {
        total: totalUsers,
        newToday: newUsersToday,
        activeToday: activeUsersToday,
        roleDistribution
      },
      smtp: {
        active: activeSMTP,
        total: totalSMTP,
        failed: failedSMTP,
        uptime: totalSMTP > 0 ? ((activeSMTP / totalSMTP) * 100).toFixed(1) : 0
      },
      fix: {
        total: totalFix,
        today: todayFix,
        success: todaySuccess,
        failed: todayFailed,
        successRate: todayFix > 0 ? ((todaySuccess / todayFix) * 100).toFixed(1) : 0
      },
      payments: {
        total: totalPayments,
        today: todayPayments,
        revenue: todayRevenue[0]?.total || 0
      },
      queue: {
        size: queueSize,
        processing: await Queue.countDocuments({ status: 'processing' })
      },
      countries: topCountries,
      hourly: hourlyStats,
      system: {
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        cpu: process.cpuUsage()
      }
    };
  }

  async getActiveUsersToday() {
    const today = new Date().toISOString().split('T')[0];
    const FixHistory = this.bot.managers.database.models.FixHistory;
    
    const activeUsers = await FixHistory.aggregate([
      {
        $match: {
          createdAt: { $gte: new Date(today) }
        }
      },
      {
        $group: {
          _id: '$userId'
        }
      },
      {
        $count: 'count'
      }
    ]);

    return activeUsers[0]?.count || 0;
  }

  async getTopCountries(limit = 10) {
    try {
      const User = this.bot.managers.database.models.User;
      
      // This is a simplified version. In reality, you'd determine country from phone numbers
      return await User.aggregate([
        {
          $group: {
            _id: '$language',
            count: { $sum: 1 }
          }
        },
        {
          $sort: { count: -1 }
        },
        {
          $limit: limit
        }
      ]);
    } catch (error) {
      return [];
    }
  }

  async getHourlyStats() {
    const today = new Date().toISOString().split('T')[0];
    const FixHistory = this.bot.managers.database.models.FixHistory;
    
    return await FixHistory.aggregate([
      {
        $match: {
          createdAt: { $gte: new Date(today) }
        }
      },
      {
        $group: {
          _id: { $hour: '$createdAt' },
          total: { $sum: 1 },
          success: {
            $sum: { $cond: [{ $eq: ['$status', 'success'] }, 1, 0] }
          }
        }
      },
      {
        $sort: { _id: 1 }
      }
    ]);
  }

  async getRoleDistribution() {
    const User = this.bot.managers.database.models.User;
    
    const distribution = await User.aggregate([
      {
        $group: {
          _id: '$role',
          count: { $sum: 1 }
        }
      }
    ]);

    const result = {};
    for (const item of distribution) {
      result[item._id] = item.count;
    }

    return result;
  }

  async getUserStats(userId) {
    const FixHistory = this.bot.managers.database.models.FixHistory;
    const Payment = this.bot.managers.database.models.Payment;

    const fixStats = await FixHistory.aggregate([
      { $match: { userId } },
      {
        $group: {
          _id: null,
          total: { $sum: 1 },
          success: {
            $sum: { $cond: [{ $eq: ['$status', 'success'] }, 1, 0] }
          },
          failed: {
            $sum: { $cond: [{ $eq: ['$status', 'failed'] }, 1, 0] }
          },
          avgTime: { $avg: '$processingTime' }
        }
      }
    ]);

    const paymentStats = await Payment.aggregate([
      { $match: { userId, status: 'paid' } },
      {
        $group: {
          _id: null,
          totalSpent: { $sum: '$amount' },
          totalPayments: { $sum: 1 }
        }
      }
    ]);

    return {
      fix: fixStats[0] || { total: 0, success: 0, failed: 0, avgTime: 0 },
      payment: paymentStats[0] || { totalSpent: 0, totalPayments: 0 }
    };
  }

  async getDashboardStats() {
    const stats = this.cache.data || await this.collectAllStats();
    
    return {
      ...stats,
      generated: new Date(),
      refreshInterval: 30
    };
  }

  getStats() {
    return this.cache.data || {};
  }

  stop() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
    }
  }
}

module.exports = StatisticsService;