const mongoose = require('mongoose');

class ReferralService {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    this.coinsPerReferral = bot.configManager.get('features.referral.coins_per_referral') || 10;
    this.coinsForVIP1Day = bot.configManager.get('features.referral.coins_for_vip_1_day') || 100;
    this.coinsForVIP7Days = bot.configManager.get('features.referral.coins_for_vip_7_days') || 500;
  }

  async initialize() {
    this.logger.info('Initializing Referral Service...');
    
    try {
      // Load settings
      await this.loadSettings();
      
      this.logger.info('Referral Service initialized successfully');
    } catch (error) {
      this.logger.error('Referral Service initialization failed:', error);
      throw error;
    }
  }

  async loadSettings() {
    const config = this.bot.configManager.get('features.referral');
    if (config) {
      this.coinsPerReferral = config.coins_per_referral || 10;
      this.coinsForVIP1Day = config.coins_for_vip_1_day || 100;
      this.coinsForVIP7Days = config.coins_for_vip_7_days || 500;
    }
  }

  async processReferral(referrerId, referredId) {
    try {
      const User = this.bot.managers.database.models.User;
      const Referral = this.bot.managers.database.models.Referral;

      // Validate
      if (referrerId === referredId) {
        throw new Error('Cannot refer yourself');
      }

      // Check if already referred
      const existingReferral = await Referral.findOne({ referredId });
      if (existingReferral) {
        throw new Error('User already referred');
      }

      // Check if referrer exists
      const referrer = await User.findOne({ userId: referrerId });
      if (!referrer) {
        throw new Error('Referrer not found');
      }

      // Anti-fake: Check if referred user has joined required groups
      const isVerified = await this.verifyReferredUser(referredId);
      if (!isVerified) {
        throw new Error('Referred user not verified');
      }

      // Create referral record
      const referral = new Referral({
        referrerId,
        referredId,
        status: 'active',
        coinsEarned: this.coinsPerReferral,
        level: 1,
        createdAt: new Date()
      });

      await referral.save();

      // Add coins to referrer
      await User.findOneAndUpdate(
        { userId: referrerId },
        {
          $inc: {
            coins: this.coinsPerReferral,
            referralCount: 1
          }
        }
      );

      // Update referred user
      await User.findOneAndUpdate(
        { userId: referredId },
        { referredBy: referrerId }
      );

      // Send notification to referrer
      await this.sendReferralNotification(referrerId, referredId, this.coinsPerReferral);

      // Check if referrer can claim VIP
      await this.checkAutoUpgrade(referrerId);

      this.logger.info(`Referral processed: ${referrerId} referred ${referredId}`);

      return {
        success: true,
        coinsEarned: this.coinsPerReferral,
        totalCoins: (referrer.coins || 0) + this.coinsPerReferral
      };

    } catch (error) {
      this.logger.error('Failed to process referral:', error);
      throw error;
    }
  }

  async verifyReferredUser(userId) {
    try {
      const User = this.bot.managers.database.models.User;
      const user = await User.findOne({ userId });
      
      if (!user) return false;
      
      // Check if user has been active for at least 24 hours
      const createdAt = user.createdAt;
      const hoursSinceJoin = (Date.now() - createdAt.getTime()) / (1000 * 60 * 60);
      
      if (hoursSinceJoin < 24) {
        return false;
      }

      // Check if user has completed verification
      if (!user.isVerified) {
        return false;
      }

      // Check if user has used the bot at least once
      if (user.totalFix < 1) {
        return false;
      }

      return true;

    } catch (error) {
      this.logger.error('Failed to verify referred user:', error);
      return false;
    }
  }

  async sendReferralNotification(referrerId, referredId, coins) {
    try {
      const User = this.bot.managers.database.models.User;
      const referredUser = await User.findOne({ userId: referredId });
      
      const message = `
🎉 REFERRAL BERHASIL!

👤 User baru: ${referredUser?.username || referredId}
💰 Koin didapat: +${coins} coins
🪙 Total koin: ${await this.getTotalCoins(referrerId)} coins

Ajak lebih banyak teman untuk mendapatkan VIP GRATIS!

🏆 ${this.coinsForVIP1Day} coins = VIP 1 Hari
🏆 ${this.coinsForVIP7Days} coins = VIP 7 Hari
      `.trim();

      await this.bot.bot.telegram.sendMessage(referrerId, message, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🔗 SHARE REFERRAL', callback_data: 'menu_referral' },
              { text: '🎁 TUKAR VIP', callback_data: 'redeem_vip' }
            ]
          ]
        }
      });

    } catch (error) {
      this.logger.error(`Failed to send referral notification to ${referrerId}:`, error);
    }
  }

  async getTotalCoins(userId) {
    try {
      const User = this.bot.managers.database.models.User;
      const user = await User.findOne({ userId });
      return user?.coins || 0;
    } catch (error) {
      return 0;
    }
  }

  async checkAutoUpgrade(userId) {
    try {
      const coins = await this.getTotalCoins(userId);
      const User = this.bot.managers.database.models.User;
      const user = await User.findOne({ userId });
      
      // Auto upgrade to VIP 1 day if coins >= 100
      if (coins >= this.coinsForVIP1Day && (user.role === 'free')) {
        await this.redeemVIP(userId, 'vip_1_day');
        this.logger.info(`Auto-upgraded user ${userId} to VIP 1 Day`);
      }
      
    } catch (error) {
      this.logger.error('Failed to check auto upgrade:', error);
    }
  }

  async redeemVIP(userId, packageId) {
    try {
      const User = this.bot.managers.database.models.User;
      const user = await User.findOne({ userId });
      
      const packageConfig = {
        'vip_1_day': { coins: this.coinsForVIP1Day, duration: 1, role: 'vip' },
        'vip_7_days': { coins: this.coinsForVIP7Days, duration: 7, role: 'vip' }
      };
      
      const config = packageConfig[packageId];
      
      if (!config) {
        throw new Error('Invalid package');
      }

      if (user.coins < config.coins) {
        throw new Error(`Insufficient coins. Need ${config.coins} coins, you have ${user.coins} coins`);
      }

      // Deduct coins
      user.coins -= config.coins;

      // Calculate expiry
      const now = new Date();
      const currentExpiry = user.membershipExpiry || now;
      const startDate = currentExpiry > now ? currentExpiry : now;
      const expiryDate = new Date(startDate.getTime() + config.duration * 24 * 60 * 60 * 1000);

      user.role = config.role;
      user.membershipExpiry = expiryDate;
      
      await user.save();

      // Send success message
      const message = `
🎉 SELAMAT! VIP BERHASIL DITUKAR!

👑 Status: ${config.role.toUpperCase()}
📅 Berlaku hingga: ${expiryDate.toLocaleDateString('id-ID')} ${expiryDate.toLocaleTimeString('id-ID')}
🪙 Koin tersisa: ${user.coins}

Nikmati fitur premium Anda sekarang!
      `.trim();

      await this.bot.bot.telegram.sendMessage(userId, message, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            { text: '🛠️ MULAI FIX MERAH', callback_data: 'menu_fix_merah' }
          ]]
        }
      });

      return true;

    } catch (error) {
      this.logger.error(`Failed to redeem VIP for ${userId}:`, error);
      
      await this.bot.bot.telegram.sendMessage(userId, 
        `❌ Gagal menukar VIP: ${error.message}`,
        { parse_mode: 'HTML' }
      );
      
      throw error;
    }
  }

  async getReferralStats(userId) {
    try {
      const User = this.bot.managers.database.models.User;
      const Referral = this.bot.managers.database.models.Referral;

      const user = await User.findOne({ userId });
      const referrals = await Referral.find({ referrerId: userId });
      
      // Get active referrals (referred users who are active)
      const activeReferrals = referrals.filter(r => r.status === 'active');
      
      // Get successful referrals (referred users who made payments)
      const successfulReferrals = [];
      for (const ref of referrals) {
        const Payment = this.bot.managers.database.models.Payment;
        const payment = await Payment.findOne({ 
          userId: ref.referredId, 
          status: 'paid' 
        });
        
        if (payment) {
          successfulReferrals.push(ref);
        }
      }

      return {
        totalReferrals: referrals.length,
        activeReferrals: activeReferrals.length,
        successfulReferrals: successfulReferrals.length,
        totalCoins: user?.coins || 0,
        referralLink: `https://t.me/${process.env.BOT_USERNAME.replace('@', '')}?start=${userId}`,
        canClaimVIP: (user?.coins || 0) >= this.coinsForVIP1Day
      };

    } catch (error) {
      this.logger.error(`Failed to get referral stats for ${userId}:`, error);
      return null;
    }
  }

  async getLeaderboard(limit = 10) {
    try {
      const User = this.bot.managers.database.models.User;
      
      return await User.find({})
        .sort({ referralCount: -1 })
        .limit(limit)
        .select('userId username referralCount coins');
        
    } catch (error) {
      this.logger.error('Failed to get referral leaderboard:', error);
      return [];
    }
  }
}

module.exports = ReferralService;