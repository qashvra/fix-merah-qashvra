const mongoose = require('mongoose');

class LeaderboardService {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    this.cache = {
      users: null,
      countries: null,
      lastUpdate: null
    };
    this.updateInterval = null;
  }

  async initialize() {
    this.logger.info('Initializing Leaderboard Service...');
    
    // Start periodic update
    this.startPeriodicUpdate();
    
    // Initial load
    await this.updateLeaderboards();
    
    this.logger.info('Leaderboard Service initialized');
  }

  startPeriodicUpdate() {
    // Update leaderboards every 1 minute
    this.updateInterval = setInterval(async () => {
      await this.updateLeaderboards();
    }, 60000);
  }

  async updateLeaderboards() {
    try {
      this.cache.users = await this.getTopUsers(20);
      this.cache.countries = await this.getTopCountries(10);
      this.cache.lastUpdate = new Date();
    } catch (error) {
      this.logger.error('Failed to update leaderboards:', error);
    }
  }

  async getTopUsers(limit = 10) {
    try {
      const User = this.bot.managers.database.models.User;
      
      const topUsers = await User.find({
        role: { $nin: ['banned'] }
      })
      .sort({ totalFix: -1, successFix: -1 })
      .limit(limit)
      .select('userId username fullName totalFix successFix role');

      return topUsers.map((user, index) => ({
        rank: index + 1,
        userId: user.userId,
        name: this.maskName(user.fullName),
        totalFix: user.totalFix || 0,
        successFix: user.successFix || 0,
        successRate: user.totalFix > 0 
          ? ((user.successFix / user.totalFix) * 100).toFixed(1) 
          : 0,
        role: user.role,
        isPremium: ['vvip', 'vip', 'owner'].includes(user.role)
      }));

    } catch (error) {
      this.logger.error('Failed to get top users:', error);
      return [];
    }
  }

  async getTopCountries(limit = 10) {
    try {
      const User = this.bot.managers.database.models.User;
      
      // Aggregate by language as a proxy for country
      const countryStats = await User.aggregate([
        {
          $match: { role: { $nin: ['banned'] } }
        },
        {
          $group: {
            _id: '$language',
            totalUsers: { $sum: 1 },
            totalFix: { $sum: '$totalFix' },
            totalSuccess: { $sum: '$successFix' }
          }
        },
        {
          $sort: { totalFix: -1 }
        },
        {
          $limit: limit
        }
      ]);

      return countryStats.map((country, index) => ({
        rank: index + 1,
        country: this.getCountryName(country._id),
        flag: this.getCountryFlag(country._id),
        totalUsers: country.totalUsers,
        totalFix: country.totalFix,
        totalSuccess: country.totalSuccess,
        successRate: country.totalFix > 0 
          ? ((country.totalSuccess / country.totalFix) * 100).toFixed(1) 
          : 0
      }));

    } catch (error) {
      this.logger.error('Failed to get top countries:', error);
      return [];
    }
  }

  async getUserRank(userId) {
    try {
      const User = this.bot.managers.database.models.User;
      const user = await User.findOne({ userId });
      
      if (!user || user.totalFix === 0) return null;
      
      const rank = await User.countDocuments({
        $or: [
          { totalFix: { $gt: user.totalFix } },
          { 
            totalFix: user.totalFix,
            successFix: { $gt: user.successFix }
          }
        ],
        role: { $nin: ['banned'] }
      });

      return rank + 1;

    } catch (error) {
      this.logger.error(`Failed to get rank for ${userId}:`, error);
      return null;
    }
  }

  async formatLeaderboardMessage(type = 'users', limit = 10) {
    if (type === 'users') {
      const topUsers = this.cache.users || await this.getTopUsers(limit);
      
      let message = '🏆 *TOP USERS GLOBAL*\n\n';
      
      for (const user of topUsers.slice(0, limit)) {
        const medal = this.getMedalEmoji(user.rank);
        const premium = user.isPremium ? ' 💎' : '';
        
        message += `${medal} *${user.name}*${premium}\n`;
        message += `├ 🛠️ Total Fix: ${user.totalFix}\n`;
        message += `├ 🎯 Sukses: ${user.successFix}\n`;
        message += `└ 📈 Win Rate: ${user.successRate}%\n\n`;
      }

      return message;

    } else if (type === 'countries') {
      const topCountries = this.cache.countries || await this.getTopCountries(limit);
      
      let message = '🌍 *TOP COUNTRIES*\n\n';
      
      for (const country of topCountries.slice(0, limit)) {
        message += `${country.flag} *${country.country}*\n`;
        message += `├ 👥 Users: ${country.totalUsers}\n`;
        message += `├ 🛠️ Total Fix: ${country.totalFix}\n`;
        message += `└ 📈 Success Rate: ${country.successRate}%\n\n`;
      }

      return message;
    }

    return 'Invalid type';
  }

  getMedalEmoji(rank) {
    switch (rank) {
      case 1: return '🥇';
      case 2: return '🥈';
      case 3: return '🥉';
      default: return `${rank}.`;
    }
  }

  getCountryName(languageCode) {
    const countryMap = {
      'id': 'Indonesia',
      'en': 'English',
      'ar': 'Arabic',
      'ru': 'Russia',
      'ms': 'Malaysia',
      'ja': 'Japan',
      'ko': 'Korea',
      'zh': 'China',
      'hi': 'India',
      'th': 'Thailand'
    };
    return countryMap[languageCode] || languageCode?.toUpperCase() || 'Unknown';
  }

  getCountryFlag(languageCode) {
    const flagMap = {
      'id': '🇮🇩',
      'en': '🇺🇸',
      'ar': '🇸🇦',
      'ru': '🇷🇺',
      'ms': '🇲🇾',
      'ja': '🇯🇵',
      'ko': '🇰🇷',
      'zh': '🇨🇳',
      'hi': '🇮🇳',
      'th': '🇹🇭'
    };
    return flagMap[languageCode] || '🏳️';
  }

  maskName(name) {
    if (!name || name.length <= 2) return name || 'Anonymous';
    const visible = 2;
    return name.substring(0, visible) + '***' + name.substring(name.length - visible);
  }

  async getReferralLeaderboard(limit = 10) {
    try {
      return await this.bot.services.referral.getLeaderboard(limit);
    } catch (error) {
      return [];
    }
  }

  getStats() {
    return {
      lastUpdate: this.cache.lastUpdate,
      userCount: this.cache.users?.length || 0,
      countryCount: this.cache.countries?.length || 0
    };
  }

  stop() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
    }
  }
}

module.exports = LeaderboardService;