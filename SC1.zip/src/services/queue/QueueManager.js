const { EventEmitter } = require('events');
const PQueue = require('p-queue');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const path = require('path');

class QueueManager extends EventEmitter {
  constructor(bot) {
    super();
    this.bot = bot;
    this.logger = bot.logger;
    
    // Priority queues
    this.queues = {
      owner: new PQueue({ concurrency: 5 }),
      vvip: new PQueue({ concurrency: 3 }),
      vip: new PQueue({ concurrency: 2 }),
      free: new PQueue({ concurrency: 1 })
    };
    
    this.workers = [];
    this.isProcessing = false;
    this.stats = {
      totalProcessed: 0,
      totalSuccess: 0,
      totalFailed: 0,
      currentQueueSize: 0,
      processingNow: 0
    };
  }

  async initialize() {
    this.logger.info('Initializing Queue Manager...');
    
    try {
      // Initialize workers
      await this.initializeWorkers();
      
      // Start queue processor
      this.startQueueProcessor();
      
      // Load pending queues from database
      await this.loadPendingQueues();
      
      this.logger.info('Queue Manager initialized successfully');
      
      this.emit('queue:ready');
      
    } catch (error) {
      this.logger.error('Queue Manager initialization failed:', error);
      throw error;
    }
  }

  async initializeWorkers() {
    const workerCount = this.bot.configManager.get('queue.concurrency') || 4;
    
    for (let i = 0; i < workerCount; i++) {
      const worker = new Worker(path.join(__dirname, '../../workers/queueWorker.js'), {
        workerData: { 
          workerId: i + 1,
          botConfig: this.bot.configManager.getAll()
        }
      });

      worker.on('message', (message) => {
        this.handleWorkerMessage(worker, message);
      });

      worker.on('error', (error) => {
        this.logger.error(`Worker ${i + 1} error:`, error);
        this.handleWorkerError(worker, error);
      });

      worker.on('exit', (code) => {
        if (code !== 0) {
          this.logger.warn(`Worker ${i + 1} exited with code ${code}`);
          this.restartWorker(i);
        }
      });

      this.workers.push(worker);
    }

    this.logger.info(`${workerCount} workers initialized`);
  }

  handleWorkerMessage(worker, message) {
    switch (message.type) {
      case 'fix_completed':
        this.handleFixCompleted(message.data);
        break;
      case 'fix_failed':
        this.handleFixFailed(message.data);
        break;
      case 'worker_stats':
        this.updateWorkerStats(message.data);
        break;
      case 'error':
        this.logger.error(`Worker error: ${message.data}`);
        break;
      default:
        this.logger.debug(`Unknown worker message: ${message.type}`);
    }
  }

  handleWorkerError(worker, error) {
    this.logger.error('Worker error:', error);
    // Implement recovery logic
  }

  async restartWorker(index) {
    try {
      this.logger.info(`Restarting worker ${index + 1}...`);
      
      this.workers[index].terminate();
      
      const worker = new Worker(path.join(__dirname, '../../workers/queueWorker.js'), {
        workerData: { 
          workerId: index + 1,
          botConfig: this.bot.configManager.getAll()
        }
      });

      worker.on('message', (message) => {
        this.handleWorkerMessage(worker, message);
      });

      worker.on('error', (error) => {
        this.handleWorkerError(worker, error);
      });

      this.workers[index] = worker;
      
      this.logger.info(`Worker ${index + 1} restarted`);
    } catch (error) {
      this.logger.error(`Failed to restart worker ${index + 1}:`, error);
    }
  }

  async addToQueue(userId, phoneNumber, userStatus = 'free') {
    try {
      // Check rate limits
      await this.checkRateLimits(userId);
      
      // Check for duplicates
      await this.checkDuplicates(userId, phoneNumber);
      
      // Generate banding ID
      const bandingId = this.generateBandingId(userId, phoneNumber);
      
      // Determine priority
      const priority = this.getPriority(userStatus);
      
      // Create queue entry
      const Queue = this.bot.managers.database.models.Queue;
      const queueEntry = new Queue({
        userId,
        phoneNumber,
        bandingId,
        priority,
        status: 'queued',
        createdAt: new Date()
      });

      await queueEntry.save();

      // Add to appropriate queue
      const queueKey = this.getQueueKey(userStatus);
      await this.queues[queueKey].add(() => this.processQueueItem(queueEntry));

      // Update stats
      this.stats.currentQueueSize = await this.getQueueSize();

      // Emit event
      this.emit('queue:added', { userId, phoneNumber, bandingId, priority });

      // Save to fix history
      await this.saveToFixHistory(userId, phoneNumber, bandingId);

      return {
        success: true,
        bandingId,
        position: await this.getQueuePosition(bandingId),
        estimatedTime: this.calculateEstimatedTime(priority)
      };

    } catch (error) {
      this.logger.error(`Failed to add to queue for user ${userId}:`, error);
      throw error;
    }
  }

  async addBulkToQueue(userId, phoneNumbers, userStatus = 'free') {
    try {
      const results = [];
      const bulkLimit = this.getBulkLimit(userStatus);
      
      if (phoneNumbers.length > bulkLimit) {
        throw new Error(`Bulk limit exceeded. Maximum ${bulkLimit} numbers per batch`);
      }

      for (const phoneNumber of phoneNumbers) {
        try {
          const result = await this.addToQueue(userId, phoneNumber, userStatus);
          results.push({ phoneNumber, ...result });
        } catch (error) {
          results.push({ phoneNumber, success: false, error: error.message });
        }
      }

      return results;

    } catch (error) {
      this.logger.error(`Failed to add bulk to queue for user ${userId}:`, error);
      throw error;
    }
  }

  async processQueueItem(queueEntry) {
    try {
      this.stats.processingNow++;
      
      // Update status
      const Queue = this.bot.managers.database.models.Queue;
      await Queue.findByIdAndUpdate(queueEntry._id, {
        status: 'processing',
        startedAt: new Date()
      });

      // Send to worker for processing
      const worker = this.getAvailableWorker();
      
      if (!worker) {
        throw new Error('No available workers');
      }

      worker.postMessage({
        type: 'process_fix',
        data: {
          queueId: queueEntry._id,
          userId: queueEntry.userId,
          phoneNumber: queueEntry.phoneNumber,
          bandingId: queueEntry.bandingId
        }
      });

      // Wait for worker response (with timeout)
      const timeout = this.bot.configManager.get('queue.timeout') || 300000;
      
      return new Promise((resolve, reject) => {
        const timeoutId = setTimeout(() => {
          reject(new Error('Processing timeout'));
        }, timeout);

        const handler = (message) => {
          if (message.data.bandingId === queueEntry.bandingId) {
            worker.removeListener('message', handler);
            clearTimeout(timeoutId);
            
            if (message.type === 'fix_completed') {
              resolve(message.data);
            } else {
              reject(new Error(message.data.error || 'Processing failed'));
            }
          }
        };

        worker.on('message', handler);
      });

    } catch (error) {
      this.logger.error(`Failed to process queue item:`, error);
      this.stats.totalFailed++;
      throw error;
    } finally {
      this.stats.processingNow--;
      this.stats.totalProcessed++;
    }
  }

  getAvailableWorker() {
    // Round-robin worker selection
    const availableWorkers = this.workers.filter(w => !w.isBusy);
    
    if (availableWorkers.length === 0) {
      return this.workers[Math.floor(Math.random() * this.workers.length)];
    }
    
    return availableWorkers[0];
  }

  async handleFixCompleted(data) {
    try {
      const { queueId, userId, bandingId, phoneNumber, result } = data;

      // Update queue status
      const Queue = this.bot.managers.database.models.Queue;
      await Queue.findByIdAndUpdate(queueId, {
        status: 'completed',
        completedAt: new Date()
      });

      // Update fix history
      const FixHistory = this.bot.managers.database.models.FixHistory;
      await FixHistory.findOneAndUpdate(
        { bandingId },
        {
          status: 'success',
          completedAt: new Date(),
          smtpUsed: result.smtpUsed,
          templateUsed: result.templateUsed
        }
      );

      // Update user stats
      const User = this.bot.managers.database.models.User;
      await User.findOneAndUpdate(
        { userId },
        {
          $inc: {
            totalFix: 1,
            successFix: 1
          },
          $set: {
            dailyFixCount: (await this.getDailyFixCount(userId)) + 1,
            lastFixDate: new Date()
          }
        }
      );

      // Update global statistics
      await this.updateGlobalStats(true);

      // Send notification to user
      await this.sendSuccessNotification(userId, phoneNumber, bandingId, result);

      // Auto post to testimonial channel
      await this.bot.services.smtp?.postTestimonial({
        userId,
        phoneNumber,
        bandingId,
        status: 'success'
      });

      this.stats.totalSuccess++;
      this.emit('fix:completed', { userId, bandingId, phoneNumber });

    } catch (error) {
      this.logger.error('Failed to handle fix completed:', error);
    }
  }

  async handleFixFailed(data) {
    try {
      const { queueId, userId, bandingId, phoneNumber, error, attemptCount } = data;

      const Queue = this.bot.managers.database.models.Queue;
      const queueEntry = await Queue.findById(queueId);

      if (!queueEntry) return;

      // Check if should retry
      if (attemptCount < queueEntry.maxAttempts) {
        // Update attempt count
        queueEntry.attempts = attemptCount;
        await queueEntry.save();

        // Re-add to queue with delay
        setTimeout(async () => {
          await this.addToQueue(userId, phoneNumber, this.getUserStatus(userId));
        }, 60000); // Retry after 1 minute

      } else {
        // Mark as failed
        await Queue.findByIdAndUpdate(queueId, {
          status: 'failed',
          completedAt: new Date(),
          errorMessage: error
        });

        // Update fix history
        const FixHistory = this.bot.managers.database.models.FixHistory;
        await FixHistory.findOneAndUpdate(
          { bandingId },
          {
            status: 'failed',
            errorMessage: error
          }
        );

        // Update user stats
        const User = this.bot.managers.database.models.User;
        await User.findOneAndUpdate(
          { userId },
          { $inc: { totalFix: 1, failedFix: 1 } }
        );

        // Send failure notification
        await this.sendFailureNotification(userId, phoneNumber, bandingId, error);
      }

      this.stats.totalFailed++;
      this.emit('fix:failed', { userId, bandingId, error });

    } catch (err) {
      this.logger.error('Failed to handle fix failed:', err);
    }
  }

  async checkRateLimits(userId) {
    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });

    if (!user) return;

    const config = this.bot.configManager.get('features.fix_merah');
    const today = new Date().toDateString();

    // Check daily limit
    if (user.lastFixDate?.toDateString() === today) {
      const dailyLimit = this.getDailyLimit(user.role);
      
      if (user.dailyFixCount >= dailyLimit) {
        throw new Error(`Daily limit reached (${dailyLimit} per day)`);
      }
    }

    // Check cooldown
    const cooldown = this.getCooldown(user.role);
    if (cooldown > 0 && user.lastFixDate) {
      const timeSinceLastFix = Date.now() - user.lastFixDate.getTime();
      
      if (timeSinceLastFix < cooldown * 1000) {
        const remainingSeconds = Math.ceil((cooldown * 1000 - timeSinceLastFix) / 1000);
        throw new Error(`Cooldown active. Please wait ${remainingSeconds} seconds`);
      }
    }
  }

  async checkDuplicates(userId, phoneNumber) {
    const Queue = this.bot.managers.database.models.Queue;
    const FixHistory = this.bot.managers.database.models.FixHistory;

    // Check active queue
    const activeQueue = await Queue.findOne({
      userId,
      phoneNumber,
      status: { $in: ['queued', 'processing'] }
    });

    if (activeQueue) {
      throw new Error('This number is already in queue');
    }

    // Check recent history (last 10 minutes)
    const tenMinutesAgo = new Date(Date.now() - 10 * 60 * 1000);
    const recentHistory = await FixHistory.findOne({
      userId,
      phoneNumber,
      createdAt: { $gt: tenMinutesAgo }
    });

    if (recentHistory) {
      throw new Error('This number was recently processed. Please wait before retrying');
    }
  }

  generateBandingId(userId, phoneNumber) {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `MADS-${timestamp.toString(36).toUpperCase()}${random}`;
  }

  getPriority(userStatus) {
    const priorityMap = {
      owner: 1,
      vvip: 2,
      vip: 3,
      free: 4
    };
    return priorityMap[userStatus] || 4;
  }

  getQueueKey(userStatus) {
    const keyMap = {
      owner: 'owner',
      vvip: 'vvip',
      vip: 'vip',
      free: 'free'
    };
    return keyMap[userStatus] || 'free';
  }

  getDailyLimit(role) {
    const config = this.bot.configManager.get('features.fix_merah');
    const limitMap = {
      owner: 9999,
      developer: 9999,
      partner: 9999,
      admin: 9999,
      moderator: 999,
      reseller: 999,
      vvip: config.max_daily_limit_vvip || 9999,
      vip: config.max_daily_limit_vip || 999,
      free: config.max_daily_limit_free || 2
    };
    return limitMap[role] || 2;
  }

  getBulkLimit(userStatus) {
    const config = this.bot.configManager.get('features.fix_merah');
    const limitMap = {
      owner: 100,
      developer: 100,
      partner: 50,
      admin: 50,
      vvip: config.bulk_limit_vvip || 25,
      vip: config.bulk_limit_vip || 5,
      free: config.bulk_limit_free || 1
    };
    return limitMap[userStatus] || 1;
  }

  getCooldown(role) {
    const config = this.bot.configManager.get('features.fix_merah');
    const cooldownMap = {
      owner: 0,
      developer: 0,
      partner: 0,
      admin: 0,
      vvip: config.cooldown_vvip || 0,
      vip: config.cooldown_vip || 60,
      free: config.cooldown_free || 300
    };
    return cooldownMap[role] || 300;
  }

  async getDailyFixCount(userId) {
    const today = new Date().toDateString();
    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });
    
    if (user?.lastFixDate?.toDateString() === today) {
      return user.dailyFixCount;
    }
    
    return 0;
  }

  async getQueueSize() {
    const Queue = this.bot.managers.database.models.Queue;
    return await Queue.countDocuments({ status: { $in: ['queued', 'processing'] } });
  }

  async getQueuePosition(bandingId) {
    const Queue = this.bot.managers.database.models.Queue;
    const queueItem = await Queue.findOne({ bandingId });
    
    if (!queueItem) return 0;
    
    return await Queue.countDocuments({
      priority: { $lt: queueItem.priority },
      status: 'queued',
      createdAt: { $lt: queueItem.createdAt }
    });
  }

  calculateEstimatedTime(priority) {
    const queueSize = this.stats.currentQueueSize;
    const processingRate = this.workers.length * 0.5; // 0.5 fixes per second per worker
    
    const estimatedSeconds = (queueSize * priority) / processingRate;
    
    if (estimatedSeconds < 60) {
      return `${Math.ceil(estimatedSeconds)} detik`;
    } else if (estimatedSeconds < 3600) {
      return `${Math.ceil(estimatedSeconds / 60)} menit`;
    } else {
      return `${Math.ceil(estimatedSeconds / 3600)} jam`;
    }
  }

  async saveToFixHistory(userId, phoneNumber, bandingId) {
    try {
      const FixHistory = this.bot.managers.database.models.FixHistory;
      
      const history = new FixHistory({
        userId,
        phoneNumber,
        bandingId,
        status: 'pending',
        createdAt: new Date()
      });

      await history.save();
    } catch (error) {
      this.logger.error('Failed to save fix history:', error);
    }
  }

  async updateGlobalStats(success = true) {
    try {
      const Statistics = this.bot.managers.database.models.Statistics;
      const today = new Date().toISOString().split('T')[0];

      await Statistics.findOneAndUpdate(
        { date: today },
        {
          $inc: {
            totalFix: 1,
            successFix: success ? 1 : 0,
            failedFix: success ? 0 : 1
          }
        },
        { upsert: true }
      );

    } catch (error) {
      this.logger.error('Failed to update global stats:', error);
    }
  }

  async sendSuccessNotification(userId, phoneNumber, bandingId, result) {
    try {
      const maskedPhone = this.maskPhoneNumber(phoneNumber);
      
      const message = `
🔴 PROSES FIX MERAH BERHASIL 🔴

🆔 ID Banding:
${bandingId}

📱 Nomor:
${maskedPhone}

📌 Status:
✅ SUKSES

🤖 Powered by
Qashvra Fix Merah Pro
      `.trim();

      await this.bot.bot.telegram.sendMessage(userId, message, {
        parse_mode: 'HTML'
      });

    } catch (error) {
      this.logger.error(`Failed to send success notification to ${userId}:`, error);
    }
  }

  async sendFailureNotification(userId, phoneNumber, bandingId, error) {
    try {
      const maskedPhone = this.maskPhoneNumber(phoneNumber);
      
      const message = `
❌ PROSES FIX MERAH GAGAL

🆔 ID Banding:
${bandingId}

📱 Nomor:
${maskedPhone}

📌 Status:
❌ GAGAL

Alasan: ${error || 'Unknown error'}

Silakan coba lagi nanti.

🤖 Powered by
Qashvra Fix Merah Pro
      `.trim();

      await this.bot.bot.telegram.sendMessage(userId, message, {
        parse_mode: 'HTML'
      });

    } catch (error) {
      this.logger.error(`Failed to send failure notification to ${userId}:`, error);
    }
  }

  maskPhoneNumber(phoneNumber) {
    if (!phoneNumber || phoneNumber.length < 6) return phoneNumber;
    const start = phoneNumber.substring(0, 4);
    const end = phoneNumber.substring(phoneNumber.length - 4);
    const masked = '*'.repeat(phoneNumber.length - 8);
    return `${start}${masked}${end}`;
  }

  async loadPendingQueues() {
    try {
      const Queue = this.bot.managers.database.models.Queue;
      const pendingItems = await Queue.find({ status: 'queued' })
        .sort({ priority: 1, createdAt: 1 })
        .limit(100);

      for (const item of pendingItems) {
        const queueKey = this.getQueueKey(this.getUserStatus(item.userId));
        await this.queues[queueKey].add(() => this.processQueueItem(item));
      }

      this.logger.info(`Loaded ${pendingItems.length} pending queue items`);
    } catch (error) {
      this.logger.error('Failed to load pending queues:', error);
    }
  }

  async getUserStatus(userId) {
    try {
      const User = this.bot.managers.database.models.User;
      const user = await User.findOne({ userId });
      return user?.role || 'free';
    } catch (error) {
      return 'free';
    }
  }

  startQueueProcessor() {
    setInterval(async () => {
      try {
        this.stats.currentQueueSize = await this.getQueueSize();
        
        // Emit queue stats
        this.emit('queue:stats', this.getStats());
        
      } catch (error) {
        this.logger.error('Queue processor error:', error);
      }
    }, 5000);
  }

  getStats() {
    return {
      ...this.stats,
      timestamp: new Date(),
      workers: this.workers.length,
      queueSizes: {
        owner: this.queues.owner.size,
        vvip: this.queues.vvip.size,
        vip: this.queues.vip.size,
        free: this.queues.free.size
      }
    };
  }

  async clearQueue(userId = null) {
    try {
      const Queue = this.bot.managers.database.models.Queue;
      
      const filter = userId 
        ? { userId, status: { $in: ['queued', 'processing'] } }
        : { status: { $in: ['queued', 'processing'] } };
      
      const result = await Queue.updateMany(filter, {
        status: 'cancelled',
        completedAt: new Date()
      });

      // Clear in-memory queues
      for (const queue of Object.values(this.queues)) {
        queue.clear();
      }

      this.logger.info(`Cleared ${result.modifiedCount} queue items`);
      return result.modifiedCount;

    } catch (error) {
      this.logger.error('Failed to clear queue:', error);
      throw error;
    }
  }

  async stop() {
    this.logger.info('Stopping Queue Manager...');
    
    for (const queue of Object.values(this.queues)) {
      queue.clear();
    }
    
    for (const worker of this.workers) {
      worker.terminate();
    }
    
    this.workers = [];
    this.isProcessing = false;
    
    this.logger.info('Queue Manager stopped');
  }
}

module.exports = QueueManager;