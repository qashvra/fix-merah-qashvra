const crypto = require('crypto');
const Joi = require('joi');

class SecurityManager {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    this.blockedIPs = new Set();
    this.blockedUsers = new Set();
    this.sessionTokens = new Map();
    this.failedAttempts = new Map();
  }

  async initialize() {
    this.logger.info('Initializing Security Manager...');
    
    // Load blocked users from database
    await this.loadBlockedUsers();
    
    // Start cleanup jobs
    this.startCleanupJob();
    
    this.logger.info('Security Manager initialized');
  }

  async checkRequest(ctx) {
    const userId = ctx.from?.id;
    
    if (!userId) return true;

    // Check if user is blocked
    if (this.blockedUsers.has(userId)) {
      await ctx.reply('🚫 Anda telah diblokir dari sistem.').catch(() => {});
      return false;
    }

    // Check for brute force
    if (this.isBruteForce(userId)) {
      this.logger.warn(`Brute force detected from user ${userId}`);
      await this.blockUser(userId, 'Brute force detected');
      return false;
    }

    // Validate input
    const messageText = ctx.message?.text;
    if (messageText) {
      const validation = this.validateInput(messageText);
      if (!validation.valid) {
        this.logger.warn(`Invalid input from user ${userId}: ${validation.reason}`);
        return false;
      }
    }

    // Check for suspicious patterns
    if (this.isSuspiciousActivity(ctx)) {
      this.logger.warn(`Suspicious activity from user ${userId}`);
      this.recordFailedAttempt(userId);
      return false;
    }

    return true;
  }

  validateInput(text) {
    // Check for SQL injection patterns
    const sqlPatterns = [
      /(\bSELECT\b.*\bFROM\b)/i,
      /(\bINSERT\b.*\bINTO\b)/i,
      /(\bDELETE\b.*\bFROM\b)/i,
      /(\bDROP\b.*\bTABLE\b)/i,
      /(\bUNION\b.*\bSELECT\b)/i,
      /('.*OR.*'.*'=.*')/i
    ];

    for (const pattern of sqlPatterns) {
      if (pattern.test(text)) {
        return { valid: false, reason: 'SQL injection pattern detected' };
      }
    }

    // Check for XSS patterns
    const xssPatterns = [
      /<script.*>/i,
      /javascript:/i,
      /onerror\s*=/i,
      /onload\s*=/i,
      /<iframe/i,
      /<embed/i,
      /<object/i
    ];

    for (const pattern of xssPatterns) {
      if (pattern.test(text)) {
        return { valid: false, reason: 'XSS pattern detected' };
      }
    }

    // Check text length
    if (text.length > 4096) {
      return { valid: false, reason: 'Text too long' };
    }

    return { valid: true };
  }

  isBruteForce(userId) {
    const attempts = this.failedAttempts.get(userId) || [];
    const now = Date.now();
    
    // Clean old attempts
    const recent = attempts.filter(t => now - t < 60000); // Last minute
    
    // More than 10 failed attempts in 1 minute = brute force
    if (recent.length > 10) {
      return true;
    }

    this.failedAttempts.set(userId, recent);
    return false;
  }

  isSuspiciousActivity(ctx) {
    const userId = ctx.from?.id;
    
    // Check for rapid message sending
    const messages = this.getRecentMessages(userId);
    if (messages.length > 20) { // More than 20 messages in 10 seconds
      return true;
    }

    // Check for duplicate messages
    const messageText = ctx.message?.text;
    if (messageText) {
      const duplicates = messages.filter(m => m === messageText);
      if (duplicates.length > 5) {
        return true;
      }
    }

    // Check for unusual hours (optional)
    const hour = new Date().getHours();
    const userTimezone = ctx.state?.user?.timezone || 'UTC';
    // Implementation depends on timezone logic

    return false;
  }

  getRecentMessages(userId) {
    // This would be implemented with Redis or in-memory cache
    return [];
  }

  recordFailedAttempt(userId) {
    const attempts = this.failedAttempts.get(userId) || [];
    attempts.push(Date.now());
    this.failedAttempts.set(userId, attempts);
  }

  async blockUser(userId, reason) {
    this.blockedUsers.add(userId);

    const User = this.bot.managers.database.models.User;
    await User.findOneAndUpdate(
      { userId },
      { 
        isBanned: true,
        banReason: reason,
        role: 'banned',
        bannedAt: new Date()
      }
    );

    // Notify admins
    await this.bot.managers.notification.notifyOwner(
      '🚫 User Blocked',
      `User ID: ${userId}\nReason: ${reason}\nTime: ${new Date().toISOString()}`
    );

    this.logger.warn(`User ${userId} blocked: ${reason}`);
  }

  async unblockUser(userId) {
    this.blockedUsers.delete(userId);

    const User = this.bot.managers.database.models.User;
    await User.findOneAndUpdate(
      { userId },
      { 
        isBanned: false,
        banReason: null,
        role: 'free',
        bannedAt: null
      }
    );
  }

  generateToken(userId) {
    const token = crypto.randomBytes(32).toString('hex');
    const expiry = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
    
    this.sessionTokens.set(token, { userId, expiry });
    
    // Clean expired tokens
    for (const [key, value] of this.sessionTokens) {
      if (Date.now() > value.expiry) {
        this.sessionTokens.delete(key);
      }
    }

    return token;
  }

  validateToken(token) {
    const session = this.sessionTokens.get(token);
    
    if (!session) return null;
    
    if (Date.now() > session.expiry) {
      this.sessionTokens.delete(token);
      return null;
    }

    return session.userId;
  }

  encryptData(data) {
    const algorithm = 'aes-256-gcm';
    const key = crypto.scryptSync(process.env.ENCRYPTION_KEY || 'default-key', 'salt', 32);
    const iv = crypto.randomBytes(16);
    
    const cipher = crypto.createCipheriv(algorithm, key, iv);
    let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
    encrypted += cipher.final('hex');
    const authTag = cipher.getAuthTag();
    
    return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
  }

  decryptData(encryptedData) {
    const algorithm = 'aes-256-gcm';
    const key = crypto.scryptSync(process.env.ENCRYPTION_KEY || 'default-key', 'salt', 32);
    
    const parts = encryptedData.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const authTag = Buffer.from(parts[1], 'hex');
    const encrypted = parts[2];
    
    const decipher = crypto.createDecipheriv(algorithm, key, iv);
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return JSON.parse(decrypted);
  }

  hashData(data) {
    return crypto.createHash('sha256').update(data).digest('hex');
  }

  async loadBlockedUsers() {
    try {
      const User = this.bot.managers.database.models.User;
      const blockedUsers = await User.find({ isBanned: true });
      
      for (const user of blockedUsers) {
        this.blockedUsers.add(user.userId);
      }
      
      this.logger.info(`Loaded ${blockedUsers.length} blocked users`);
    } catch (error) {
      this.logger.error('Failed to load blocked users:', error);
    }
  }

  startCleanupJob() {
    // Clean up failed attempts every 5 minutes
    setInterval(() => {
      const now = Date.now();
      
      for (const [userId, attempts] of this.failedAttempts) {
        const recent = attempts.filter(t => now - t < 300000); // 5 minutes
        if (recent.length === 0) {
          this.failedAttempts.delete(userId);
        } else {
          this.failedAttempts.set(userId, recent);
        }
      }
    }, 300000);
  }

  getStats() {
    return {
      blockedUsers: this.blockedUsers.size,
      activeSessions: this.sessionTokens.size,
      failedAttempts: this.failedAttempts.size
    };
  }
}

module.exports = SecurityManager;