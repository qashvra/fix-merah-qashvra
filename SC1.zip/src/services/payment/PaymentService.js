const mongoose = require('mongoose');
const moment = require('moment-timezone');

class PaymentService {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    this.qrisGenerator = bot.services.qris;
    this.packages = [];
    this.paymentCheckInterval = null;
  }

  async initialize() {
    this.logger.info('Initializing Payment Service...');
    
    try {
      // Load packages
      await this.loadPackages();
      
      // Start payment checker
      this.startPaymentChecker();
      
      // Start invoice expiry checker
      this.startExpiryChecker();
      
      this.logger.info('Payment Service initialized successfully');
    } catch (error) {
      this.logger.error('Payment Service initialization failed:', error);
      throw error;
    }
  }

  async loadPackages() {
    try {
      const Package = this.bot.managers.database.models.Package;
      this.packages = await Package.find({ isActive: true }).sort({ sortOrder: 1 });
      
      if (this.packages.length === 0) {
        // Create default packages
        await this.createDefaultPackages();
        this.packages = await Package.find({ isActive: true }).sort({ sortOrder: 1 });
      }
      
      this.logger.info(`Loaded ${this.packages.length} packages`);
    } catch (error) {
      this.logger.error('Failed to load packages:', error);
      throw error;
    }
  }

  async createDefaultPackages() {
    const Package = this.bot.managers.database.models.Package;
    
    const defaultPackages = [
      {
        packageId: 'vip_1_day',
        name: 'VIP 1 Hari',
        type: 'vip',
        duration: 1,
        price: 1007,
        originalPrice: 2000,
        discount: 50,
        features: [
          'Unlimited Fix',
          '5 Nomor Sekaligus',
          'Priority Queue',
          'cPanel SMTP Access'
        ],
        isActive: true,
        sortOrder: 1
      },
      {
        packageId: 'vip_7_days',
        name: 'VIP 7 Hari',
        type: 'vip',
        duration: 7,
        price: 5007,
        originalPrice: 10000,
        discount: 50,
        features: [
          'Unlimited Fix',
          '5 Nomor Sekaligus',
          'Priority Queue',
          'cPanel SMTP Access'
        ],
        isActive: true,
        sortOrder: 2
      },
      {
        packageId: 'vip_30_days',
        name: 'VIP 30 Hari',
        type: 'vip',
        duration: 30,
        price: 15007,
        originalPrice: 30000,
        discount: 50,
        features: [
          'Unlimited Fix',
          '5 Nomor Sekaligus',
          'Priority Queue',
          'cPanel SMTP Access'
        ],
        isActive: true,
        sortOrder: 3
      },
      {
        packageId: 'vvip_30_days',
        name: 'VVIP 30 Hari',
        type: 'vvip',
        duration: 30,
        price: 25007,
        originalPrice: 50000,
        discount: 50,
        features: [
          'Unlimited Fix',
          '25 Nomor Sekaligus',
          'Highest Priority',
          'Dedicated SMTP',
          'Bypass Cooldown'
        ],
        isActive: true,
        sortOrder: 4
      }
    ];

    await Package.insertMany(defaultPackages);
    this.logger.info('Default packages created');
  }

  async getPackages() {
    return this.packages;
  }

  async getPackage(packageId) {
    return this.packages.find(p => p.packageId === packageId);
  }

  async updatePackage(packageId, updates) {
    try {
      const Package = this.bot.managers.database.models.Package;
      const updated = await Package.findOneAndUpdate(
        { packageId },
        { ...updates, updatedAt: new Date() },
        { new: true }
      );
      
      await this.loadPackages(); // Reload packages
      
      return updated;
    } catch (error) {
      this.logger.error('Failed to update package:', error);
      throw error;
    }
  }

  async createInvoice(userId, packageId) {
    try {
      const packageData = await this.getPackage(packageId);
      
      if (!packageData) {
        throw new Error('Package not found');
      }

      // Check for existing pending invoices
      const Payment = this.bot.managers.database.models.Payment;
      const existingInvoice = await Payment.findOne({
        userId,
        packageId,
        status: 'pending',
        expiryTime: { $gt: new Date() }
      });

      if (existingInvoice) {
        return existingInvoice;
      }

      // Generate order ID
      const orderId = this.generateOrderId(userId, packageId);
      
      // Generate invoice with QRIS
      const invoiceData = {
        orderId,
        userId,
        packageName: packageData.name,
        amount: packageData.price,
        duration: packageData.duration
      };

      const invoice = await this.qrisGenerator.generateInvoice(invoiceData);
      
      // Save payment record
      const payment = new Payment({
        orderId,
        userId,
        packageId,
        packageName: packageData.name,
        amount: packageData.price,
        status: 'pending',
        paymentMethod: 'qris',
        qrisString: invoice.qrisString,
        expiryTime: invoice.expiryTime
      });

      await payment.save();

      // Send invoice to user
      await this.sendInvoiceToUser(userId, payment);

      // Notify owner about new payment attempt
      await this.bot.managers.notification.notifyOwner(
        '💳 New Payment Attempt',
        `User: ${userId}\nPackage: ${packageData.name}\nAmount: Rp ${packageData.price.toLocaleString('id-ID')}\nOrder ID: ${orderId}`
      );

      return payment;

    } catch (error) {
      this.logger.error('Failed to create invoice:', error);
      throw error;
    }
  }

  generateOrderId(userId, packageId) {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 100000);
    return `QASHVRA-${packageId.toUpperCase()}-${userId}-${timestamp.toString(36)}-${random}`;
  }

  async sendInvoiceToUser(userId, payment) {
    try {
      const invoiceMessage = `
💳 INVOICE PAYMENT

🔖 Order ID: ${payment.orderId}
📦 Paket: ${payment.packageName}
💰 Total: Rp ${payment.amount.toLocaleString('id-ID')}
⏰ Expired: 10 Menit

⚠️ Klik tombol di bawah untuk memeriksa pembayaran!

Powered by Qashvra Fix Merah Pro
      `.trim();

      const keyboard = {
        inline_keyboard: [
          [
            { text: '✅ CEK PEMBAYARAN', callback_data: `check_payment_${payment.orderId}` },
            { text: '❌ BATALKAN', callback_data: `cancel_payment_${payment.orderId}` }
          ],
          [
            { text: '🏠 MENU UTAMA', callback_data: 'menu_main' }
          ]
        ]
      };

      // Send QR code if available
      if (payment.qrisString) {
        const qrBuffer = await this.qrisGenerator.generateQRCodeImage(payment.qrisString);
        
        await this.bot.bot.telegram.sendPhoto(userId, { source: qrBuffer }, {
          caption: invoiceMessage,
          reply_markup: keyboard,
          parse_mode: 'HTML'
        });
      } else {
        await this.bot.bot.telegram.sendMessage(userId, invoiceMessage, {
          reply_markup: keyboard,
          parse_mode: 'HTML'
        });
      }

      this.logger.info(`Invoice sent to user ${userId}`);

    } catch (error) {
      this.logger.error(`Failed to send invoice to user ${userId}:`, error);
    }
  }

  async checkPayment(orderId) {
    try {
      const Payment = this.bot.managers.database.models.Payment;
      const payment = await Payment.findOne({ orderId });

      if (!payment) {
        throw new Error('Payment not found');
      }

      if (payment.status === 'paid') {
        return { paid: true, payment };
      }

      if (payment.status === 'expired') {
        return { paid: false, expired: true, payment };
      }

      // Check expiry
      if (new Date() > payment.expiryTime) {
        payment.status = 'expired';
        await payment.save();
        return { paid: false, expired: true, payment };
      }

      // Auto check payment (DANA simulation or real API)
      const paymentStatus = await this.verifyPayment(payment);

      if (paymentStatus.paid) {
        payment.status = 'paid';
        payment.paidAt = new Date();
        payment.transactionId = paymentStatus.transactionId;
        await payment.save();

        // Activate membership
        await this.activateMembership(payment.userId, payment.packageId);

        // Notify user
        await this.notifyPaymentSuccess(payment.userId, payment);

        // Notify owner
        await this.bot.managers.notification.notifyOwner(
          '✅ Payment Success',
          `User: ${payment.userId}\nPackage: ${payment.packageName}\nAmount: Rp ${payment.amount.toLocaleString('id-ID')}\nOrder ID: ${orderId}`
        );

        return { paid: true, payment };
      }

      return { paid: false, payment };

    } catch (error) {
      this.logger.error(`Failed to check payment ${orderId}:`, error);
      throw error;
    }
  }

  async verifyPayment(payment) {
    try {
      // This is where you would integrate with DANA API or payment gateway
      // For now, we'll implement a basic verification
      
      // Check if payment amount matches any recent transfers
      // In production, replace with actual API call to payment gateway
      
      const mockVerification = {
        paid: false,
        transactionId: null
      };

      // Simulate payment verification (replace with actual API)
      // In a real scenario, you would:
      // 1. Call DANA API to check recent transfers
      // 2. Match amount and timestamp
      // 3. Verify transaction details
      
      return mockVerification;

    } catch (error) {
      this.logger.error('Payment verification failed:', error);
      return { paid: false, transactionId: null };
    }
  }

  async activateMembership(userId, packageId) {
    try {
      const User = this.bot.managers.database.models.User;
      const packageData = await this.getPackage(packageId);
      
      if (!packageData) {
        throw new Error('Package not found');
      }

      const user = await User.findOne({ userId });
      
      if (!user) {
        throw new Error('User not found');
      }

      // Calculate expiry date
      const now = new Date();
      const currentExpiry = user.membershipExpiry || now;
      const startDate = currentExpiry > now ? currentExpiry : now;
      const expiryDate = new Date(startDate.getTime() + packageData.duration * 24 * 60 * 60 * 1000);

      // Update user
      user.role = packageData.type;
      user.membershipExpiry = expiryDate;
      await user.save();

      // Log activation
      await this.bot.managers.database.models.Log.create({
        type: 'payment',
        level: 'info',
        userId,
        message: `Membership activated: ${packageData.name} until ${expiryDate.toISOString()}`
      });

      // Send notification to user
      await this.sendMembershipNotification(userId, packageData, expiryDate);

      this.logger.info(`Membership activated for user ${userId}: ${packageData.name}`);

    } catch (error) {
      this.logger.error(`Failed to activate membership for user ${userId}:`, error);
      throw error;
    }
  }

  async sendMembershipNotification(userId, packageData, expiryDate) {
    try {
      const message = `
🎉 SELAMAT! PEMBAYARAN BERHASIL!

✅ Paket: ${packageData.name}
📅 Berlaku hingga: ${moment(expiryDate).format('DD/MM/YYYY HH:mm')} WIB

🎁 Fitur Anda Sekarang:
${packageData.features.map(f => `├ ${f}`).join('\n')}

Terima kasih telah berlangganan!

Powered by Qashvra Fix Merah Pro
      `.trim();

      await this.bot.bot.telegram.sendMessage(userId, message, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            { text: '🛠️ MULAI FIX MERAH', callback_data: 'menu_fix_merah' }
          ]]
        }
      });

    } catch (error) {
      this.logger.error(`Failed to send membership notification to ${userId}:`, error);
    }
  }

  async notifyPaymentSuccess(userId, payment) {
    try {
      const message = `
✅ PEMBAYARAN TERVERIFIKASI

🔖 Order ID: ${payment.orderId}
📦 Paket: ${payment.packageName}
💰 Total: Rp ${payment.amount.toLocaleString('id-ID')}
⏰ Waktu: ${moment().format('DD/MM/YYYY HH:mm:ss')} WIB

Status: ✅ SUKSES

Powered by Qashvra Fix Merah Pro
      `.trim();

      await this.bot.bot.telegram.sendMessage(userId, message);
    } catch (error) {
      this.logger.error(`Failed to notify payment success to ${userId}:`, error);
    }
  }

  async cancelPayment(orderId, userId) {
    try {
      const Payment = this.bot.managers.database.models.Payment;
      const payment = await Payment.findOne({ orderId, userId });

      if (!payment) {
        throw new Error('Payment not found');
      }

      if (payment.status !== 'pending') {
        throw new Error('Payment cannot be cancelled');
      }

      payment.status = 'cancelled';
      await payment.save();

      return payment;

    } catch (error) {
      this.logger.error(`Failed to cancel payment ${orderId}:`, error);
      throw error;
    }
  }

  startPaymentChecker() {
    // Check pending payments every 30 seconds
    this.paymentCheckInterval = setInterval(async () => {
      try {
        const Payment = this.bot.managers.database.models.Payment;
        const pendingPayments = await Payment.find({
          status: 'pending',
          expiryTime: { $gt: new Date() }
        }).limit(50);

        for (const payment of pendingPayments) {
          await this.checkPayment(payment.orderId);
        }

      } catch (error) {
        this.logger.error('Payment checker error:', error);
      }
    }, 30000);
  }

  startExpiryChecker() {
    // Check expired payments every minute
    setInterval(async () => {
      try {
        const Payment = this.bot.managers.database.models.Payment;
        const now = new Date();

        await Payment.updateMany(
          {
            status: 'pending',
            expiryTime: { $lt: now }
          },
          {
            status: 'expired'
          }
        );

      } catch (error) {
        this.logger.error('Expiry checker error:', error);
      }
    }, 60000);
  }

  async getPaymentHistory(userId, limit = 10) {
    try {
      const Payment = this.bot.managers.database.models.Payment;
      return await Payment.find({ userId })
        .sort({ createdAt: -1 })
        .limit(limit);
    } catch (error) {
      this.logger.error(`Failed to get payment history for ${userId}:`, error);
      return [];
    }
  }

  async getTotalRevenue(startDate, endDate) {
    try {
      const Payment = this.bot.managers.database.models.Payment;
      
      const result = await Payment.aggregate([
        {
          $match: {
            status: 'paid',
            paidAt: {
              $gte: startDate || new Date(0),
              $lte: endDate || new Date()
            }
          }
        },
        {
          $group: {
            _id: null,
            totalRevenue: { $sum: '$amount' },
            totalTransactions: { $sum: 1 },
            averageAmount: { $avg: '$amount' }
          }
        }
      ]);

      return result[0] || { totalRevenue: 0, totalTransactions: 0, averageAmount: 0 };

    } catch (error) {
      this.logger.error('Failed to get total revenue:', error);
      return { totalRevenue: 0, totalTransactions: 0, averageAmount: 0 };
    }
  }

  stop() {
    if (this.paymentCheckInterval) {
      clearInterval(this.paymentCheckInterval);
    }
  }
}

module.exports = PaymentService;