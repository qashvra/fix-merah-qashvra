const nodemailer = require('nodemailer');
const mongoose = require('mongoose');
const crypto = require('crypto');

class SMTPService {
  constructor(bot) {
    this.bot = bot;
    this.logger = bot.logger;
    this.transporters = new Map();
    this.activePool = [];
    this.failedPool = [];
    this.cooldownPool = [];
    this.rotationIndex = 0;
    this.lock = false;
    
    this.stats = {
      totalSent: 0,
      totalFailed: 0,
      activeCount: 0
    };
  }

  async initialize() {
    this.logger.info('Initializing SMTP Service...');
    
    try {
      // Load SMTP configurations
      await this.loadSMTPConfigs();
      
      // Start health check
      this.startHealthCheck();
      
      // Start rotation
      this.startRotation();
      
      this.logger.info(`SMTP Service initialized with ${this.activePool.length} active senders`);
    } catch (error) {
      this.logger.error('SMTP Service initialization failed:', error);
      throw error;
    }
  }

  async loadSMTPConfigs() {
    try {
      // Load owner SMTP
      const ownerSMTP = await SMTPConfig.find({ type: 'owner', status: 'active' });
      
      // Load premium SMTP
      const premiumSMTP = await SMTPConfig.find({ type: 'premium', status: 'active' });
      
      // Load shared SMTP (Gmail App Passwords from users)
      const sharedSMTP = await SMTPConfig.find({ type: 'shared', status: 'active' });
      
      // Combine all active SMTP
      this.activePool = [...ownerSMTP, ...premiumSMTP, ...sharedSMTP];
      
      // Load failed and cooldown pools
      this.failedPool = await SMTPConfig.find({ status: 'failed' });
      this.cooldownPool = await SMTPConfig.find({ status: 'cooldown' });
      
      // Create transporters for active SMTP
      for (const config of this.activePool) {
        await this.createTransporter(config);
      }
      
    } catch (error) {
      this.logger.error('Failed to load SMTP configs:', error);
      throw error;
    }
  }

  async createTransporter(config) {
    try {
      const transporter = nodemailer.createTransport({
        host: config.host,
        port: config.port,
        secure: config.secure,
        auth: {
          user: config.username,
          pass: this.decryptPassword(config.password)
        },
        pool: true,
        maxConnections: config.maxConnections || 5,
        maxMessages: config.maxMessages || Infinity,
        rateDelta: config.rateDelta || 1000,
        rateLimit: config.rateLimit || 5,
        socketTimeout: 30000,
        connectionTimeout: 10000
      });

      // Verify connection
      await transporter.verify();
      
      this.transporters.set(config._id.toString(), {
        transporter,
        config,
        stats: {
          sent: 0,
          failed: 0,
          lastUsed: null,
          lastError: null
        }
      });

      this.logger.info(`SMTP transporter created for ${config.username}@${config.host}`);
      return true;

    } catch (error) {
      this.logger.error(`Failed to create transporter for ${config.username}:`, error);
      
      // Move to failed pool
      config.status = 'failed';
      config.errorMessage = error.message;
      config.lastCheck = new Date();
      await config.save();
      
      return false;
    }
  }

  async getSender(userStatus = 'free') {
    try {
      const availableSenders = [];
      
      for (const [id, sender] of this.transporters) {
        const config = sender.config;
        
        // Skip failed or cooldown senders
        if (config.status !== 'active') continue;
        
        // For free users, only use shared pool (Gmail)
        if (userStatus === 'free' && config.type !== 'shared') continue;
        
        // For premium users, use premium and owner pools
        if (userStatus === 'vip' || userStatus === 'vvip') {
          if (config.type === 'shared') continue;
        }
        
        // Check rate limits
        if (this.isRateLimited(sender)) continue;
        
        availableSenders.push({ id, sender });
      }
      
      if (availableSenders.length === 0) {
        // Try to recover some senders from cooldown
        await this.recoverCooldownSenders();
        
        // Retry without rate limit check
        for (const [id, sender] of this.transporters) {
          if (sender.config.status === 'active') {
            availableSenders.push({ id, sender });
            break;
          }
        }
        
        if (availableSenders.length === 0) {
          throw new Error('No available SMTP senders');
        }
      }
      
      // Round-robin selection
      const selected = availableSenders[this.rotationIndex % availableSenders.length];
      this.rotationIndex = (this.rotationIndex + 1) % availableSenders.length;
      
      return selected;
      
    } catch (error) {
      this.logger.error('Failed to get sender:', error);
      throw error;
    }
  }

  isRateLimited(sender) {
    const now = Date.now();
    const { stats, config } = sender;
    
    // Check rate limit
    if (stats.lastUsed && (now - stats.lastUsed) < config.rateDelta) {
      return true;
    }
    
    // Check max messages per hour
    if (config.maxMessagesPerHour && stats.sentThisHour >= config.maxMessagesPerHour) {
      return true;
    }
    
    return false;
  }

  async sendEmail(to, subject, body, userStatus = 'free') {
    try {
      const { sender } = await this.getSender(userStatus);
      
      const mailOptions = {
        from: `"WhatsApp Security" <${sender.config.username}>`,
        to: to,
        subject: subject,
        text: body,
        headers: {
          'X-Priority': '1',
          'X-MSMail-Priority': 'High',
          'Importance': 'high'
        }
      };

      const info = await sender.transporter.sendMail(mailOptions);
      
      // Update stats
      sender.stats.sent++;
      sender.stats.lastUsed = Date.now();
      this.stats.totalSent++;
      
      // Update config
      sender.config.lastUsed = new Date();
      sender.config.totalSent = (sender.config.totalSent || 0) + 1;
      await sender.config.save();
      
      this.logger.info(`Email sent successfully to ${to} via ${sender.config.username}`);
      
      return {
        success: true,
        messageId: info.messageId,
        sender: sender.config.username,
        timestamp: new Date()
      };
      
    } catch (error) {
      this.stats.totalFailed++;
      this.logger.error(`Failed to send email to ${to}:`, error);
      
      // Handle sender failure
      await this.handleSenderFailure(error);
      
      // Retry with different sender
      return this.sendEmail(to, subject, body, userStatus);
    }
  }

  async handleSenderFailure(error) {
    // Implementation for handling sender failure
    this.logger.warn('Handling sender failure...');
  }

  async addUserSMTP(userId, smtpConfig) {
    try {
      // Validate SMTP
      const isValid = await this.validateSMTP(smtpConfig);
      
      if (!isValid.valid) {
        throw new Error(isValid.message);
      }
      
      // Check if already exists
      const existing = await SMTPConfig.findOne({
        userId: userId,
        username: smtpConfig.username,
        host: smtpConfig.host
      });
      
      if (existing) {
        throw new Error('SMTP configuration already exists');
      }
      
      // Save to database
      const config = new SMTPConfig({
        userId: userId,
        type: 'shared',
        host: smtpConfig.host,
        port: smtpConfig.port,
        secure: smtpConfig.secure,
        username: smtpConfig.username,
        password: this.encryptPassword(smtpConfig.password),
        status: 'active',
        maxMessagesPerHour: 100,
        addedBy: userId,
        addedAt: new Date()
      });
      
      await config.save();
      
      // Create transporter
      await this.createTransporter(config);
      
      this.logger.info(`User ${userId} added SMTP: ${smtpConfig.username}`);
      
      return {
        success: true,
        message: 'SMTP added successfully',
        configId: config._id
      };
      
    } catch (error) {
      this.logger.error('Failed to add user SMTP:', error);
      throw error;
    }
  }

  async validateSMTP(smtpConfig) {
    try {
      const testTransporter = nodemailer.createTransport({
        host: smtpConfig.host,
        port: smtpConfig.port,
        secure: smtpConfig.secure,
        auth: {
          user: smtpConfig.username,
          pass: smtpConfig.password
        },
        connectionTimeout: 10000
      });
      
      await testTransporter.verify();
      testTransporter.close();
      
      return {
        valid: true,
        message: 'SMTP configuration is valid'
      };
      
    } catch (error) {
      return {
        valid: false,
        message: `SMTP validation failed: ${error.message}`
      };
    }
  }

  encryptPassword(password) {
    const algorithm = 'aes-256-gcm';
    const key = crypto.scryptSync(process.env.ENCRYPTION_KEY, 'salt', 32);
    const iv = crypto.randomBytes(16);
    
    const cipher = crypto.createCipheriv(algorithm, key, iv);
    let encrypted = cipher.update(password, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    const authTag = cipher.getAuthTag();
    
    return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
  }

  decryptPassword(encryptedPassword) {
    const algorithm = 'aes-256-gcm';
    const key = crypto.scryptSync(process.env.ENCRYPTION_KEY, 'salt', 32);
    
    const parts = encryptedPassword.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const authTag = Buffer.from(parts[1], 'hex');
    const encrypted = parts[2];
    
    const decipher = crypto.createDecipheriv(algorithm, key, iv);
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  }

  startHealthCheck() {
    setInterval(async () => {
      try {
        for (const [id, sender] of this.transporters) {
          try {
            await sender.transporter.verify();
            
            // Update status if was failed
            if (sender.config.status === 'failed') {
              sender.config.status = 'active';
              await sender.config.save();
              this.logger.info(`SMTP ${sender.config.username} recovered`);
            }
          } catch (error) {
            // Move to cooldown if active
            if (sender.config.status === 'active') {
              sender.config.status = 'cooldown';
              sender.stats.lastError = error.message;
              await sender.config.save();
              this.logger.warn(`SMTP ${sender.config.username} moved to cooldown`);
            }
          }
        }
        
        // Update stats
        this.stats.activeCount = Array.from(this.transporters.values())
          .filter(s => s.config.status === 'active').length;
          
      } catch (error) {
        this.logger.error('Health check error:', error);
      }
    }, this.bot.configManager.get('smtp.active_check_interval') * 1000 || 300000);
  }

  startRotation() {
    setInterval(() => {
      this.rotationIndex = (this.rotationIndex + 1) % Math.max(this.activePool.length, 1);
    }, this.bot.configManager.get('smtp.rotation_interval') * 1000 || 60000);
  }

  async recoverCooldownSenders() {
    try {
      const cooldownSenders = this.cooldownPool.filter(s => {
        const cooldownTime = s.cooldownUntil || 0;
        return Date.now() >= cooldownTime;
      });
      
      for (const sender of cooldownSenders) {
        await this.createTransporter(sender);
        sender.status = 'active';
        await sender.save();
        this.logger.info(`SMTP ${sender.username} recovered from cooldown`);
      }
    } catch (error) {
      this.logger.error('Failed to recover cooldown senders:', error);
    }
  }

  getStats() {
    return {
      ...this.stats,
      activeCount: this.transporters.size,
      poolSizes: {
        active: this.activePool.length,
        failed: this.failedPool.length,
        cooldown: this.cooldownPool.length
      }
    };
  }
}

// SMTP Config Model
const smtpConfigSchema = new mongoose.Schema({
  userId: { type: Number, required: true },
  type: { type: String, enum: ['owner', 'premium', 'shared', 'custom'], default: 'shared' },
  host: { type: String, required: true },
  port: { type: Number, required: true },
  secure: { type: Boolean, default: false },
  username: { type: String, required: true },
  password: { type: String, required: true },
  status: { type: String, enum: ['active', 'failed', 'cooldown', 'disabled'], default: 'active' },
  maxConnections: { type: Number, default: 5 },
  maxMessagesPerHour: { type: Number, default: 100 },
  rateDelta: { type: Number, default: 1000 },
  rateLimit: { type: Number, default: 5 },
  totalSent: { type: Number, default: 0 },
  errorMessage: String,
  lastUsed: Date,
  lastCheck: Date,
  cooldownUntil: Date,
  addedBy: { type: Number, required: true },
  addedAt: { type: Date, default: Date.now }
});

const SMTPConfig = mongoose.model('SMTPConfig', smtpConfigSchema);

module.exports = SMTPService;