const winston = require('winston');
const path = require('path');
const fs = require('fs').promises;

class LoggerService {
  constructor(options = {}) {
    this.logDir = options.logDir || path.join(__dirname, '../../../logs');
    this.retentionDays = options.retentionDays || 30;
    this.maxFileSize = options.maxFileSize || '20m';
    this.maxFiles = options.maxFiles || '14d';
    
    this.initialize();
  }

  async initialize() {
    try {
      // Ensure log directory exists
      await fs.mkdir(this.logDir, { recursive: true });

      // Create Winston logger
      this.logger = winston.createLogger({
        level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
        format: this.getLogFormat(),
        transports: this.getTransports(),
        exceptionHandlers: [
          new winston.transports.File({ 
            filename: path.join(this.logDir, 'exceptions.log'),
            maxsize: this.maxFileSize,
            maxFiles: this.maxFiles
          })
        ],
        rejectionHandlers: [
          new winston.transports.File({ 
            filename: path.join(this.logDir, 'rejections.log'),
            maxsize: this.maxFileSize,
            maxFiles: this.maxFiles
          })
        ]
      });

      // Start log cleanup
      this.startLogCleanup();

      this.info('Logger service initialized');
    } catch (error) {
      console.error('Failed to initialize logger:', error);
    }
  }

  getLogFormat() {
    const customFormat = winston.format.printf(({ level, message, timestamp, ...metadata }) => {
      let msg = `${timestamp} [${level.toUpperCase()}] ${message}`;
      
      if (Object.keys(metadata).length > 0) {
        msg += ` ${JSON.stringify(metadata)}`;
      }
      
      return msg;
    });

    return winston.format.combine(
      winston.format.timestamp({
        format: 'YYYY-MM-DD HH:mm:ss.SSS'
      }),
      winston.format.errors({ stack: true }),
      winston.format.metadata({ fillExcept: ['message', 'level', 'timestamp', 'label'] }),
      customFormat
    );
  }

  getTransports() {
    const transports = [
      // Console transport for development
      new winston.transports.Console({
        format: winston.format.combine(
          winston.format.colorize(),
          winston.format.simple()
        )
      })
    ];

    // File transports for production
    if (process.env.NODE_ENV === 'production') {
      transports.push(
        // Combined logs
        new winston.transports.File({
          filename: path.join(this.logDir, 'combined.log'),
          maxsize: this.maxFileSize,
          maxFiles: this.maxFiles,
          level: 'info'
        }),
        // Error logs
        new winston.transports.File({
          filename: path.join(this.logDir, 'error.log'),
          maxsize: this.maxFileSize,
          maxFiles: this.maxFiles,
          level: 'error'
        }),
        // Payment logs
        new winston.transports.File({
          filename: path.join(this.logDir, 'payment.log'),
          maxsize: this.maxFileSize,
          maxFiles: this.maxFiles,
          level: 'info'
        }),
        // SMTP logs
        new winston.transports.File({
          filename: path.join(this.logDir, 'smtp.log'),
          maxsize: this.maxFileSize,
          maxFiles: this.maxFiles,
          level: 'info'
        }),
        // Security logs
        new winston.transports.File({
          filename: path.join(this.logDir, 'security.log'),
          maxsize: this.maxFileSize,
          maxFiles: this.maxFiles,
          level: 'warn'
        }),
        // Admin logs
        new winston.transports.File({
          filename: path.join(this.logDir, 'admin.log'),
          maxsize: this.maxFileSize,
          maxFiles: this.maxFiles,
          level: 'info'
        }),
        // Queue logs
        new winston.transports.File({
          filename: path.join(this.logDir, 'queue.log'),
          maxsize: this.maxFileSize,
          maxFiles: this.maxFiles,
          level: 'info'
        })
      );
    }

    return transports;
  }

  info(message, metadata = {}) {
    this.logger.info(message, metadata);
  }

  warn(message, metadata = {}) {
    this.logger.warn(message, metadata);
  }

  error(message, metadata = {}) {
    this.logger.error(message, metadata);
  }

  debug(message, metadata = {}) {
    this.logger.debug(message, metadata);
  }

  verbose(message, metadata = {}) {
    this.logger.verbose(message, metadata);
  }

  // Specialized logging methods
  logPayment(message, metadata = {}) {
    this.info(`[PAYMENT] ${message}`, { ...metadata, category: 'payment' });
  }

  logSMTP(message, metadata = {}) {
    this.info(`[SMTP] ${message}`, { ...metadata, category: 'smtp' });
  }

  logSecurity(message, metadata = {}) {
    this.warn(`[SECURITY] ${message}`, { ...metadata, category: 'security' });
  }

  logAdmin(userId, action, metadata = {}) {
    this.info(`[ADMIN] User ${userId} - ${action}`, { ...metadata, category: 'admin', userId });
  }

  logQueue(message, metadata = {}) {
    this.info(`[QUEUE] ${message}`, { ...metadata, category: 'queue' });
  }

  logUserAction(userId, action, metadata = {}) {
    this.info(`[USER] ${userId} - ${action}`, { ...metadata, category: 'user', userId });
  }

  logAPI(method, path, statusCode, metadata = {}) {
    const message = `${method} ${path} - ${statusCode}`;
    const level = statusCode >= 400 ? 'warn' : 'info';
    this.logger[level](`[API] ${message}`, { ...metadata, category: 'api' });
  }

  async query(options = {}) {
    try {
      const {
        level,
        category,
        startDate,
        endDate,
        limit = 100,
        offset = 0
      } = options;

      // Read log files
      const logFiles = await this.getLogFiles();
      const results = [];

      for (const file of logFiles) {
        const content = await fs.readFile(file, 'utf8');
        const lines = content.split('\n').filter(Boolean);

        for (const line of lines) {
          try {
            const log = this.parseLogLine(line);
            
            if (this.matchesFilter(log, options)) {
              results.push(log);
            }
          } catch (error) {
            // Skip invalid log lines
          }
        }
      }

      // Sort by timestamp
      results.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

      // Apply pagination
      return results.slice(offset, offset + limit);
    } catch (error) {
      this.error('Failed to query logs:', error);
      return [];
    }
  }

  parseLogLine(line) {
    // Parse log line in format: "2024-01-01 12:00:00.000 [INFO] message {"key":"value"}"
    const match = line.match(/^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}) \[(\w+)\] (.+)$/);
    
    if (!match) {
      throw new Error('Invalid log format');
    }

    const [, timestamp, level, rest] = match;
    
    // Try to parse JSON metadata
    let message = rest;
    let metadata = {};

    const jsonMatch = rest.match(/^(.+) (\{.*\})$/);
    if (jsonMatch) {
      message = jsonMatch[1];
      try {
        metadata = JSON.parse(jsonMatch[2]);
      } catch (error) {
        // Not JSON, keep as part of message
        message = rest;
      }
    }

    return {
      timestamp,
      level: level.toLowerCase(),
      message,
      ...metadata
    };
  }

  matchesFilter(log, filter) {
    if (filter.level && log.level !== filter.level) return false;
    if (filter.category && log.category !== filter.category) return false;
    
    if (filter.startDate && new Date(log.timestamp) < new Date(filter.startDate)) return false;
    if (filter.endDate && new Date(log.timestamp) > new Date(filter.endDate)) return false;
    
    if (filter.userId && log.userId !== filter.userId) return false;
    if (filter.search && !log.message.toLowerCase().includes(filter.search.toLowerCase())) return false;
    
    return true;
  }

  async getLogFiles() {
    try {
      const files = await fs.readdir(this.logDir);
      return files
        .filter(f => f.endsWith('.log'))
        .map(f => path.join(this.logDir, f));
    } catch (error) {
      return [];
    }
  }

  async getLogStats() {
    try {
      const logFiles = await this.getLogFiles();
      const stats = {};

      for (const file of logFiles) {
        const filename = path.basename(file);
        const fileStats = await fs.stat(file);
        
        const content = await fs.readFile(file, 'utf8');
        const lines = content.split('\n').filter(Boolean);
        
        stats[filename] = {
          size: fileStats.size,
          lines: lines.length,
          lastModified: fileStats.mtime,
          errors: lines.filter(l => l.includes('[ERROR]')).length,
          warnings: lines.filter(l => l.includes('[WARN]')).length
        };
      }

      return stats;
    } catch (error) {
      return {};
    }
  }

  async clearLogs(olderThan = this.retentionDays) {
    try {
      const logFiles = await this.getLogFiles();
      const cutoffDate = new Date(Date.now() - olderThan * 24 * 60 * 60 * 1000);
      let clearedCount = 0;

      for (const file of logFiles) {
        const stats = await fs.stat(file);
        
        if (stats.mtime < cutoffDate) {
          await fs.unlink(file);
          clearedCount++;
        }
      }

      this.info(`Cleared ${clearedCount} old log files`);
      return clearedCount;
    } catch (error) {
      this.error('Failed to clear logs:', error);
      return 0;
    }
  }

  async exportLogs(options = {}) {
    try {
      const logs = await this.query(options);
      const exportPath = path.join(this.logDir, `export-${Date.now()}.json`);
      
      await fs.writeFile(exportPath, JSON.stringify(logs, null, 2));
      
      return exportPath;
    } catch (error) {
      this.error('Failed to export logs:', error);
      return null;
    }
  }

  startLogCleanup() {
    // Clean old logs every day
    setInterval(async () => {
      try {
        const cleared = await this.clearLogs();
        if (cleared > 0) {
          this.info(`Auto-cleanup: removed ${cleared} old log files`);
        }
      } catch (error) {
        this.error('Log cleanup failed:', error);
      }
    }, 24 * 60 * 60 * 1000);
  }
}

module.exports = LoggerService;