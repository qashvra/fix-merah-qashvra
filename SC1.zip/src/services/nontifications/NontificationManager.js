const mongoose = require('mongoose');
const EventEmitter = require('events');

class NotificationManager extends EventEmitter {
  constructor(bot) {
    super();
    this.bot = bot;
    this.logger = bot?.logger;
    this.notificationQueue = [];
    this.isProcessing = false;
    this.ownerChatId = parseInt(process.env.OWNER_ID);
  }

  async initialize() {
    this.logger?.info('Initializing Notification Manager...');
    
    // Start processing notifications
    this.startProcessing();
    
    // Load pending notifications
    await this.loadPendingNotifications();
    
    this.logger?.info('Notification Manager initialized');
  }

  async notifyOwner(title, message, priority = 'normal') {
    try {
      const ownerId = this.ownerChatId || parseInt(process.env.OWNER_ID);
      
      if (!ownerId) {
        this.logger?.warn('Owner ID not set, cannot send notification');
        return;
      }

      // Check if notification settings allow this
      if (!this.shouldNotify('owner')) {
        return;
      }

      const formattedMessage = `
🔔 *${title}*

${message}

⏰ ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
      `.trim();

      await this.bot.bot.telegram.sendMessage(ownerId, formattedMessage, {
        parse_mode: 'Markdown',
        disable_notification: priority === 'low'
      });

      // Save notification to database
      await this.saveNotification(ownerId, title, message, 'system');

    } catch (error) {
      this.logger?.error('Failed to notify owner:', error);
    }
  }

  async notifyUser(userId, title, message, type = 'system') {
    try {
      const formattedMessage = this.formatUserNotification(title, message, type);

      await this.bot.bot.telegram.sendMessage(userId, formattedMessage, {
        parse_mode: 'Markdown',
        reply_markup: this.getNotificationKeyboard(type)
      });

      // Save to database
      await this.saveNotification(userId, title, message, type);

    } catch (error) {
      // If user blocked bot or chat not found, mark as inactive
      if (error.code === 403 || error.description?.includes('blocked')) {
        this.logger?.info(`User ${userId} blocked bot`);
        await this.handleBlockedUser(userId);
      } else {
        this.logger?.error(`Failed to notify user ${userId}:`, error);
      }
    }
  }

  async notifyAdmins(title, message, priority = 'normal') {
    try {
      const User = this.bot.managers.database.models.User;
      const admins = await User.find({
        role: { $in: ['owner', 'developer', 'admin'] },
        isBanned: false
      });

      for (const admin of admins) {
        await this.notifyUser(admin.userId, title, message, 'admin');
        
        // Small delay between notifications
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    } catch (error) {
      this.logger?.error('Failed to notify admins:', error);
    }
  }

  async notifyPayment(userId, payment) {
    const title = '💳 Pembayaran';
    let message;

    switch (payment.status) {
      case 'pending':
        message = `Invoice ${payment.orderId} menunggu pembayaran`;
        break;
      case 'paid':
        message = `✅ Pembayaran ${payment.orderId} berhasil!`;
        break;
      case 'expired':
        message = `⏰ Invoice ${payment.orderId} telah expired`;
        break;
      case 'failed':
        message = `❌ Pembayaran ${payment.orderId} gagal`;
        break;
      default:
        message = `Status pembayaran: ${payment.status}`;
    }

    await this.notifyUser(userId, title, message, 'payment');

    // Also notify owner for successful payments
    if (payment.status === 'paid') {
      await this.notifyOwner(
        '💰 Payment Received',
        `User: ${userId}\nOrder: ${payment.orderId}\nAmount: Rp ${payment.amount.toLocaleString('id-ID')}`,
        'high'
      );
    }
  }

  async notifyFixComplete(userId, phoneNumber, bandingId, result) {
    const title = '🛠️ Fix Merah Selesai';
    const maskedPhone = this.maskPhoneNumber(phoneNumber);
    
    const message = result.success 
      ? `✅ Fix berhasil untuk ${maskedPhone}\nID: ${bandingId}`
      : `❌ Fix gagal untuk ${maskedPhone}\nID: ${bandingId}\nAlasan: ${result.error || 'Unknown'}`;

    await this.notifyUser(userId, title, message, 'fix');
  }

  async notifyQueueUpdate(userId, queueInfo) {
    const title = '📋 Update Antrian';
    const message = `Posisi antrian: ${queueInfo.position}\nEstimasi: ${queueInfo.estimatedTime}`;
    
    await this.notifyUser(userId, title, message, 'fix');
  }

  async notifyVIPExpiry(userId, daysRemaining) {
    if (daysRemaining <= 3) {
      const title = '⚠️ VIP Akan Berakhir';
      const message = `Masa VIP Anda akan berakhir dalam ${daysRemaining} hari.\nPerpanjang sekarang untuk terus menikmati fitur premium!`;
      
      await this.notifyUser(userId, title, message, 'system');
    }
  }

  async notifyReferral(userId, referredUserId, coins) {
    const title = '🎉 Referral Baru!';
    const message = `Selamat! Anda mendapatkan ${coins} koin dari referral baru.\nTotal koin: ${await this.getTotalCoins(userId)}`;
    
    await this.notifyUser(userId, title, message, 'referral');
  }

  async notifySMTPError(smtpConfig, error) {
    const title = '📧 SMTP Error';
    const message = `SMTP ${smtpConfig.username} mengalami error:\n${error}\n\nHost: ${smtpConfig.host}\nStatus: ${smtpConfig.status}`;
    
    await this.notifyOwner(title, message, 'high');
  }

  async notifyQueueOverload(queueSize) {
    const title = '⚠️ Queue Overload';
    const message = `Antrian melebihi batas!\nQueue size: ${queueSize}\n\nPertimbangkan untuk menambah worker.`;
    
    await this.notifyOwner(title, message, 'high');
  }

  async notifyNewUser(user) {
    const title = '👤 New User';
    const message = `User baru bergabung!\n\nID: ${user.userId}\nNama: ${user.fullName}\nUsername: @${user.username || 'N/A'}\nBahasa: ${user.language}`;
    
    await this.notifyOwner(title, message, 'low');
  }

  async notifyBan(userId, reason, bannedBy) {
    const title = '🚫 User Banned';
    const message = `User ID: ${userId}\nBanned by: ${bannedBy}\nReason: ${reason}`;
    
    await this.notifyOwner(title, message, 'high');
    await this.notifyAdmins(title, message, 'high');
  }

  formatUserNotification(title, message, type) {
    const typeEmoji = {
      payment: '💳',
      fix: '🛠️',
      system: 'ℹ️',
      referral: '🎉',
      admin: '🛡️',
      promo: '🎁'
    };

    const emoji = typeEmoji[type] || '📢';

    return `${emoji} *${title}*\n\n${message}\n\n_Powered by Qashvra Fix Merah Pro_`;
  }

  getNotificationKeyboard(type) {
    switch (type) {
      case 'payment':
        return {
          inline_keyboard: [
            [{ text: '💳 LIHAT INVOICE', callback_data: 'menu_payment' }],
            [{ text: '🏠 MENU UTAMA', callback_data: 'menu_main' }]
          ]
        };
      case 'fix':
        return {
          inline_keyboard: [
            [{ text: '📜 LIHAT RIWAYAT', callback_data: 'menu_history' }],
            [{ text: '🏠 MENU UTAMA', callback_data: 'menu_main' }]
          ]
        };
      case 'referral':
        return {
          inline_keyboard: [
            [{ text: '🎁 LIHAT REFERRAL', callback_data: 'menu_referral' }],
            [{ text: '🏠 MENU UTAMA', callback_data: 'menu_main' }]
          ]
        };
      default:
        return {
          inline_keyboard: [
            [{ text: '🏠 MENU UTAMA', callback_data: 'menu_main' }]
          ]
        };
    }
  }

  async saveNotification(userId, title, message, type) {
    try {
      const Notification = this.bot.managers.database.models.Notification;
      
      await Notification.create({
        userId,
        type,
        title,
        message,
        isRead: false,
        createdAt: new Date()
      });
    } catch (error) {
      this.logger?.error('Failed to save notification:', error);
    }
  }

  async getUnreadNotifications(userId, limit = 10) {
    try {
      const Notification = this.bot.managers.database.models.Notification;
      
      return await Notification.find({
        userId,
        isRead: false
      })
      .sort({ createdAt: -1 })
      .limit(limit);
    } catch (error) {
      return [];
    }
  }

  async markAsRead(notificationId, userId) {
    try {
      const Notification = this.bot.managers.database.models.Notification;
      
      await Notification.findOneAndUpdate(
        { _id: notificationId, userId },
        { isRead: true }
      );
    } catch (error) {
      this.logger?.error('Failed to mark notification as read:', error);
    }
  }

  async markAllAsRead(userId) {
    try {
      const Notification = this.bot.managers.database.models.Notification;
      
      await Notification.updateMany(
        { userId, isRead: false },
        { isRead: true }
      );
    } catch (error) {
      this.logger?.error('Failed to mark all notifications as read:', error);
    }
  }

  async clearNotifications(userId) {
    try {
      const Notification = this.bot.managers.database.models.Notification;
      await Notification.deleteMany({ userId });
    } catch (error) {
      this.logger?.error('Failed to clear notifications:', error);
    }
  }

  shouldNotify(type) {
    const settings = this.bot.configManager?.get('settings.bot_settings.notifications');
    
    if (!settings) return true;

    switch (type) {
      case 'owner':
        return true; // Owner always gets notifications
      case 'payment':
        return settings.payment !== false;
      case 'smtp_error':
        return settings.smtp_error !== false;
      case 'queue_overload':
        return settings.queue_overload !== false;
      case 'vip_upgrade':
        return settings.vip_upgrade !== false;
      default:
        return true;
    }
  }

  async handleBlockedUser(userId) {
    try {
      const User = this.bot.managers.database.models.User;
      await User.findOneAndUpdate(
        { userId },
        { 
          isActive: false,
          lastActive: new Date()
        }
      );
    } catch (error) {
      this.logger?.error('Failed to handle blocked user:', error);
    }
  }

  async getTotalCoins(userId) {
    const User = this.bot.managers.database.models.User;
    const user = await User.findOne({ userId });
    return user?.coins || 0;
  }

  maskPhoneNumber(phoneNumber) {
    if (!phoneNumber || phoneNumber.length < 6) return phoneNumber;
    return phoneNumber.substring(0, 4) + '****' + phoneNumber.substring(phoneNumber.length - 4);
  }

  async loadPendingNotifications() {
    try {
      const Notification = this.bot.managers.database.models.Notification;
      const pending = await Notification.find({
        isRead: false,
        createdAt: { $gt: new Date(Date.now() - 24 * 60 * 60 * 1000) } // Last 24 hours
      });

      this.logger?.info(`Loaded ${pending.length} pending notifications`);
    } catch (error) {
      this.logger?.error('Failed to load pending notifications:', error);
    }
  }

  startProcessing() {
    // Process notification queue every 5 seconds
    setInterval(async () => {
      if (this.isProcessing || this.notificationQueue.length === 0) return;
      
      this.isProcessing = true;
      
      try {
        const batch = this.notificationQueue.splice(0, 10); // Process 10 at a time
        
        for (const notification of batch) {
          await this.sendNotification(notification);
        }
      } catch (error) {
        this.logger?.error('Notification processing error:', error);
      } finally {
        this.isProcessing = false;
      }
    }, 5000);
  }

  async sendNotification(notification) {
    try {
      const { userId, title, message, type } = notification;
      
      if (userId === this.ownerChatId) {
        await this.notifyOwner(title, message);
      } else {
        await this.notifyUser(userId, title, message, type);
      }
    } catch (error) {
      this.logger?.error('Failed to send notification:', error);
    }
  }

  queueNotification(userId, title, message, type = 'system') {
    this.notificationQueue.push({ userId, title, message, type });
  }
}

module.exports = NotificationManager;