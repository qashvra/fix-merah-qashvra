module.exports = {
  apps: [{
    name: 'qashvra-fix-merah-pro',
    script: 'src/index.js',
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: './src/logs/pm2-error.log',
    out_file: './src/logs/pm2-out.log',
    log_file: './src/logs/pm2-combined.log',
    time: true,
    autorestart: true,
    max_restarts: 10,
    restart_delay: 5000,
    kill_timeout: 5000,
    listen_timeout: 5000
  }]
};