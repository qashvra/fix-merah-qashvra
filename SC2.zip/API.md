
## Authentication
Include `x-api-key` header with your API secret key.

## Endpoints

### GET /health
Check system health status.

**Response:**
```json
{
  "status": "ok",
  "uptime": 123456,
  "timestamp": 1700000000000
}