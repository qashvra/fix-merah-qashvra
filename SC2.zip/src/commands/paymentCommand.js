class PaymentCommand {
  async execute(ctx) {
    const PaymentHandler = require('../services/payment/PaymentHandler');
    const handler = new PaymentHandler();
    
    await ctx.reply(
      `💳 *PEMBAYARAN*\n\n` +
      `Pilih paket VIP/VVIP:\n\n` +
      `⭐ VIP 1 Hari - Rp1.007\n` +
      `⭐ VIP 7 Hari - Rp5.007\n` +
      `⭐ VIP 30 Hari - Rp15.007\n` +
      `💎 VVIP 30 Hari - Rp30.007`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '⭐ VIP 1 Hari - Rp1.007', callback_data: 'payment_vip_1day' }],
            [{ text: '⭐ VIP 7 Hari - Rp5.007', callback_data: 'payment_vip_7day' }],
            [{ text: '⭐ VIP 30 Hari - Rp15.007', callback_data: 'payment_vip_30day' }],
            [{ text: '💎 VVIP 30 Hari - Rp30.007', callback_data: 'payment_vvip_30day' }],
            [{ text: '🔙 Kembali', callback_data: 'menu_back' }]
          ]
        }
      }
    );
  }
}

module.exports = new PaymentCommand();