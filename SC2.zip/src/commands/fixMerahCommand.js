class FixMerahCommand {
  constructor() {
    this.name = 'fixmerah';
    this.description = 'Mulai proses Fix Merah';
  }

  async execute(ctx) {
    const user = ctx.state.user;
    
    await ctx.reply(
      `🛠️ *FIX MERAH*\n\n` +
      `Kirim nomor telepon untuk memulai.\n\n` +
      `Format: +62812345678910\n\n` +
      `Status: ${user.role}\n` +
      `Limit: ${user.role === 'FREE_USER' ? '2/hari' : 'Unlimited'}`,
      { parse_mode: 'Markdown' }
    );
  }
}

module.exports = new FixMerahCommand();