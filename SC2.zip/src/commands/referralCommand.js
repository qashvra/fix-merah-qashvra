class ReferralCommand {
  async execute(ctx) {
    const userId = ctx.state.userId;
    const referralLink = `https://t.me/${process.env.BOT_USERNAME?.replace('@', '')}?start=referral_${userId}`;
    
    await ctx.reply(
      `🧧 *REFERRAL*\n\n` +
      `🔗 Link referral Anda:\n` +
      `\`${referralLink}\`\n\n` +
      `Bagikan link ini dan dapatkan 50 koin per referral!\n` +
      `Kumpulkan 500 koin untuk redeem VIP 1 Hari.`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '📤 Bagikan', switch_inline_query: `referral_${userId}` }],
            [{ text: '🔙 Kembali', callback_data: 'menu_back' }]
          ]
        }
      }
    );
  }
}

module.exports = new ReferralCommand();