class InlineKeyboards {
  static mainMenu(role) {
    const keyboard = [];

    // Row 1 - Main Features
    keyboard.push([
      { text: '🛠️ Fix Merah', callback_data: 'menu_fix_merah' },
      { text: '👑 VIP / VVIP', callback_data: 'menu_vip_vvip' }
    ]);

    // Row 2 - Secondary Features
    keyboard.push([
      { text: '🧧 Referal', callback_data: 'menu_referral' },
      { text: '📜 Riwayat', callback_data: 'menu_history' }
    ]);

    // Row 3 - Stats
    keyboard.push([
      { text: '🏆 Top Global', callback_data: 'menu_leaderboard' },
      { text: '✅ Testimoni', callback_data: 'menu_testimoni' }
    ]);

    // Row 4 - Settings
    keyboard.push([
      { text: '⚙️ Settings', callback_data: 'menu_settings' },
      { text: '👤 Profile', callback_data: 'menu_profile' }
    ]);

    // Admin/Owner row
    if (['OWNER', 'DEVELOPER', 'PARTNER', 'ADMIN'].includes(role)) {
      const adminRow = [{ text: '🔧 Admin Panel', callback_data: 'menu_admin' }];
      if (['OWNER', 'DEVELOPER'].includes(role)) {
        adminRow.push({ text: '👑 Owner', callback_data: 'menu_owner' });
      }
      keyboard.push(adminRow);
    }

    return { inline_keyboard: keyboard };
  }

  static paymentMethods() {
    return {
      inline_keyboard: [
        [{ text: '💳 QRIS (DANA/Gopay/OVO)', callback_data: 'payment_qris' }],
        [{ text: '🏦 Transfer Bank', callback_data: 'payment_bank' }],
        [{ text: '🔙 Kembali', callback_data: 'menu_back' }]
      ]
    };
  }

  static vipPackages() {
    return {
      inline_keyboard: [
        [{ text: '⭐ VIP 1 Hari - Rp1.007', callback_data: 'payment_vip_1day' }],
        [{ text: '⭐ VIP 7 Hari - Rp5.007', callback_data: 'payment_vip_7day' }],
        [{ text: '⭐ VIP 30 Hari - Rp15.007', callback_data: 'payment_vip_30day' }],
        [{ text: '💎 VVIP 30 Hari - Rp30.007', callback_data: 'payment_vvip_30day' }],
        [{ text: '🔙 Kembali', callback_data: 'menu_back' }]
      ]
    };
  }

  static settings() {
    return {
      inline_keyboard: [
        [{ text: '🌐 Bahasa / Language', callback_data: 'settings_language' }],
        [{ text: '🔔 Notifikasi', callback_data: 'settings_notification' }],
        [{ text: '🎨 Tema', callback_data: 'settings_theme' }],
        [{ text: '⏰ Timezone', callback_data: 'settings_timezone' }],
        [{ text: '🔙 Kembali', callback_data: 'menu_back' }]
      ]
    };
  }

  static languages() {
    return {
      inline_keyboard: [
        [{ text: '🇮🇩 Indonesia', callback_data: 'lang_id' }],
        [{ text: '🇬🇧 English', callback_data: 'lang_en' }],
        [{ text: '🇸🇦 العربية', callback_data: 'lang_ar' }],
        [{ text: '🇷🇺 Русский', callback_data: 'lang_ru' }],
        [{ text: '🔙 Kembali', callback_data: 'menu_settings' }]
      ]
    };
  }
}

module.exports = InlineKeyboards;