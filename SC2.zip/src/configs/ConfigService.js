const fs = require('fs').promises;
const path = require('path');

class ConfigService {
  constructor() {
    this.configs = {};
    this.configPath = path.join(__dirname, '../../');
    this.loaded = false;
  }

  async initialize() {
    await this.loadAll();
    this.loaded = true;
    console.log('✅ ConfigService initialized');
  }

  async loadAll() {
    try {
      this.configs.config = await this.loadJSON('config.json');
      this.configs.permissions = await this.loadJSON('permissions.json');
      this.configs.settings = await this.loadJSON('settings.json');
      this.configs.smtp = await this.loadJSON('smtp.json');
      this.configs.templates = await this.loadJSON('templates.json');
      console.log('✅ All configurations loaded');
    } catch (error) {
      console.error('❌ Error loading configurations:', error);
      throw error;
    }
  }

  async loadJSON(filename) {
    const filePath = path.join(this.configPath, filename);
    const data = await fs.readFile(filePath, 'utf-8');
    return JSON.parse(data);
  }

  async saveJSON(filename, data) {
    const filePath = path.join(this.configPath, filename);
    await fs.writeFile(filePath, JSON.stringify(data, null, 2), 'utf-8');
  }

  getConfig(key) {
    return key ? this.configs.config[key] : this.configs.config;
  }

  getPermissions() {
    return this.configs.permissions;
  }

  getSettings() {
    return this.configs.settings;
  }

  getSMTPConfig() {
    return this.configs.smtp;
  }

  getTemplates() {
    return this.configs.templates;
  }

  async updateConfig(section, key, value) {
    if (this.configs.config[section]) {
      this.configs.config[section][key] = value;
      await this.saveJSON('config.json', this.configs.config);
      return true;
    }
    return false;
  }

  async updatePermissions(role, permissions) {
    if (this.configs.permissions.roles[role]) {
      this.configs.permissions.roles[role].permissions = permissions;
      await this.saveJSON('permissions.json', this.configs.permissions);
      return true;
    }
    return false;
  }

  async updateSMTPConfig(section, key, value) {
    if (this.configs.smtp[section]) {
      this.configs.smtp[section][key] = value;
      await this.saveJSON('smtp.json', this.configs.smtp);
      return true;
    }
    return false;
  }

  async addTemplate(template) {
    this.configs.templates.banding.push(template);
    await this.saveJSON('templates.json', this.configs.templates);
    return true;
  }

  async removeTemplate(templateId) {
    this.configs.templates.banding = this.configs.templates.banding.filter(
      t => t.id !== templateId
    );
    await this.saveJSON('templates.json', this.configs.templates);
    return true;
  }

  async reloadAll() {
    await this.loadAll();
    return true;
  }
}

module.exports = ConfigService;