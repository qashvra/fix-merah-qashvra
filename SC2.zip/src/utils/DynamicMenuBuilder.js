class DynamicMenuBuilder {
  constructor() {
    this.menus = {};
    this.defaultConfig = {
      showBanner: true,
      showStats: true,
      compactView: false,
      animationEffects: true
    };
  }

  async loadMenus() {
    const ConfigService = require('../configs/ConfigService');
    const config = new ConfigService();
    this.menus = config.getConfig('menus') || {};
    return this.menus;
  }

  async buildMenu(menuName, user) {
    await this.loadMenus();
    const menu = this.menus[menuName];
    
    if (!menu) {
      return this.buildDefaultMenu(user);
    }

    const keyboard = this.buildKeyboard(menu.buttons, user.role);
    const caption = this.buildCaption(menu, user);

    return { caption, keyboard };
  }

  buildKeyboard(buttons, role) {
    const keyboard = [];
    let currentRow = [];

    buttons.forEach((button, index) => {
      // Check role access
      if (button.roles && !button.roles.includes(role)) return;

      const btn = {
        text: `${button.emoji || ''} ${button.text}`,
        callback_data: button.callback || button.url ? undefined : button.callback,
        url: button.url
      };

      currentRow.push(btn);

      // New row every 2 buttons or at end
      if (currentRow.length === 2 || index === buttons.length - 1) {
        keyboard.push(currentRow);
        currentRow = [];
      }
    });

    return { inline_keyboard: keyboard };
  }

  buildCaption(menu, user) {
    let caption = '';

    if (menu.showBanner !== false) {
      caption += `🔴 *QASHVRA FIX MERAH PRO*\n\n`;
    }

    caption += menu.title || '';

    if (menu.showStats && user) {
      caption += `\n\n├ 👑 Status: ${user.role}\n`;
      caption += `├ 📊 Limit: ${user.daily_limit || '∞'}\n`;
    }

    return caption;
  }

  buildDefaultMenu(user) {
    return {
      caption: `🔴 *QASHVRA FIX MERAH PRO*\n\n` +
               `👤 *MENU UTAMA*\n\n` +
               `Pilih menu di bawah ini:`,
      keyboard: {
        inline_keyboard: [
          [
            { text: '🛠️ Fix Merah', callback_data: 'menu_fix_merah' },
            { text: '👑 VIP/VVIP', callback_data: 'menu_vip_vvip' }
          ],
          [
            { text: '🧧 Referral', callback_data: 'menu_referral' },
            { text: '📜 Riwayat', callback_data: 'menu_history' }
          ],
          [
            { text: '🏆 Top Global', callback_data: 'menu_leaderboard' },
            { text: '✅ Testimoni', callback_data: 'menu_testimoni' }
          ]
        ]
      }
    };
  }

  async updateMenu(menuName, config) {
    const ConfigService = require('../configs/ConfigService');
    const configService = new ConfigService();
    
    const menus = await configService.getConfig('menus') || {};
    menus[menuName] = {
      ...menus[menuName],
      ...config
    };
    
    await configService.updateConfig('menus', menuName, menus[menuName]);
    return true;
  }

  async addButton(menuName, button) {
    const ConfigService = require('../configs/ConfigService');
    const configService = new ConfigService();
    
    const menus = await configService.getConfig('menus') || {};
    const menu = menus[menuName] || { buttons: [] };
    
    menu.buttons.push(button);
    menus[menuName] = menu;
    
    await configService.updateConfig('menus', menuName, menu);
    return true;
  }

  async removeButton(menuName, buttonIndex) {
    const ConfigService = require('../configs/ConfigService');
    const configService = new ConfigService();
    
    const menus = await configService.getConfig('menus') || {};
    const menu = menus[menuName];
    
    if (menu && menu.buttons) {
      menu.buttons.splice(buttonIndex, 1);
      await configService.updateConfig('menus', menuName, menu);
      return true;
    }
    
    return false;
  }
}

module.exports = DynamicMenuBuilder;