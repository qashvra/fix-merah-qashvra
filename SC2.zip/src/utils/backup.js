const DatabaseService = require('../services/database/DatabaseService');
const fs = require('fs').promises;
const path = require('path');

class BackupManager {
  async createBackup() {
    const db = new DatabaseService();
    const backupPath = await db.createBackup();
    console.log(`✅ Backup created at: ${backupPath}`);
    return backupPath;
  }

  async restoreBackup(backupDir) {
    const db = new DatabaseService();
    await db.restoreBackup(backupDir);
    console.log(`✅ Backup restored from: ${backupDir}`);
    return true;
  }

  async listBackups() {
    const backupDir = path.join(__dirname, '../../backups');
    const dirs = await fs.readdir(backupDir);
    return dirs.map(dir => ({
      name: dir,
      path: path.join(backupDir, dir),
      date: new Date(dir.replace(/-/g, ':'))
    }));
  }

  async deleteOldBackups(days = 30) {
    const backups = await this.listBackups();
    const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
    
    for (const backup of backups) {
      if (backup.date < cutoff) {
        const fs = require('fs').promises;
        await fs.rm(backup.path, { recursive: true, force: true });
      }
    }
  }
}

// CLI support
if (require.main === module) {
  const backup = new BackupManager();
  const command = process.argv[2];
  
  if (command === 'create') {
    backup.createBackup().then(console.log);
  } else if (command === 'list') {
    backup.listBackups().then(backups => console.log(JSON.stringify(backups, null, 2)));
  } else if (command === 'restore' && process.argv[3]) {
    backup.restoreBackup(process.argv[3]).then(console.log);
  } else {
    console.log('Usage: node backup.js [create|list|restore <path>]');
  }
}

module.exports = BackupManager;