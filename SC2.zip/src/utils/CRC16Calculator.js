class CRC16Calculator {
  /**
   * Calculate CRC16-CCITT for QRIS
   * @param {string} data - Input string
   * @returns {string} 4-character hex CRC
   */
  static calculate(data) {
    let crc = 0xFFFF;
    
    for (let i = 0; i < data.length; i++) {
      crc ^= data.charCodeAt(i) << 8;
      
      for (let j = 0; j < 8; j++) {
        if (crc & 0x8000) {
          crc = (crc << 1) ^ 0x1021;
        } else {
          crc = crc << 1;
        }
      }
      
      crc &= 0xFFFF;
    }
    
    return crc.toString(16).toUpperCase().padStart(4, '0');
  }

  /**
   * Verify CRC16 checksum
   * @param {string} data - Data with CRC at end
   * @returns {boolean} Whether CRC is valid
   */
  static verify(data) {
    if (data.length < 4) return false;
    
    const payload = data.slice(0, -4);
    const providedCRC = data.slice(-4);
    const calculatedCRC = this.calculate(payload);
    
    return providedCRC.toUpperCase() === calculatedCRC.toUpperCase();
  }

  /**
   * Add CRC16 to data
   * @param {string} data - Input data
   * @returns {string} Data with CRC appended
   */
  static append(data) {
    const crc = this.calculate(data);
    return data + crc;
  }
}

module.exports = CRC16Calculator;