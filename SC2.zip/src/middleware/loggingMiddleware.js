const LoggerService = require('../services/logs/LoggerService');

const logger = new LoggerService();

const loggingMiddleware = async (ctx, next) => {
  const startTime = Date.now();
  
  try {
    await next();
    
    const duration = Date.now() - startTime;
    
    // Log successful requests
    if (ctx.updateType && ctx.from) {
      logger.info('Request processed', {
        user_id: ctx.from.id,
        username: ctx.from.username,
        update_type: ctx.updateType,
        chat_id: ctx.chat?.id,
        duration_ms: duration,
        timestamp: new Date().toISOString()
      });
    }
  } catch (error) {
    const duration = Date.now() - startTime;
    
    logger.error('Request failed', {
      user_id: ctx.from?.id,
      update_type: ctx.updateType,
      error: error.message,
      duration_ms: duration
    });
    
    throw error;
  }
};

module.exports = { loggingMiddleware };