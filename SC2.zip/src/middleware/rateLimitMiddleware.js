const { RateLimiterMemory } = require('rate-limiter-flexible');

const rateLimiter = new RateLimiterMemory({
  points: 30,
  duration: 60,
  blockDuration: 120
});

const rateLimitMiddleware = async (ctx, next) => {
  try {
    if (!ctx.from) {
      return next();
    }

    const userId = ctx.from.id;
    
    try {
      await rateLimiter.consume(userId);
      return next();
    } catch (error) {
      const retryAfter = Math.round(error.msBeforeNext / 1000) || 1;
      
      await ctx.reply(
        `⏳ *Rate Limit Tercapai*\n\n` +
        `Silakan tunggu *${retryAfter} detik* sebelum mengirim request lagi.\n\n` +
        `🔐 Ini adalah sistem keamanan untuk mencegah spam.`,
        { parse_mode: 'Markdown' }
      ).catch(() => {});
      
      return;
    }
  } catch (error) {
    console.error('Rate Limit Middleware Error:', error);
    return next();
  }
};

module.exports = { rateLimitMiddleware };