class AntiAbuseMiddleware {
  constructor() {
    this.userActions = new Map();
    this.blockedUsers = new Map();
  }

  async checkAbuse(ctx, next) {
    try {
      if (!ctx.from) return next();

      const userId = ctx.from.id;
      const action = this.detectAction(ctx);

      // Check if user is blocked
      if (this.isUserBlocked(userId)) {
        const blockInfo = this.blockedUsers.get(userId);
        const remaining = Math.ceil((blockInfo.until - Date.now()) / 1000 / 60);
        
        return ctx.reply(
          `🚫 *AKSES DIBLOKIR*\n\n` +
          `Anda diblokir selama ${remaining} menit karena aktivitas mencurigakan.\n\n` +
          `Alasan: ${blockInfo.reason}`,
          { parse_mode: 'Markdown' }
        );
      }

      // Track user actions
      this.trackAction(userId, action);

      // Check for abuse patterns
      const abuseDetected = await this.detectAbuse(userId);

      if (abuseDetected) {
        const reason = abuseDetected.reason;
        const duration = 30 * 60 * 1000; // 30 minutes
        
        this.blockUser(userId, duration, reason);
        
        return ctx.reply(
          `⚠️ *AKTIVITAS MENCURIGAKAN TERDETEKSI*\n\n` +
          `Anda diblokir sementara selama 30 menit.\n\n` +
          `Alasan: ${reason}\n\n` +
          `Hubungi @qashvra jika ini kesalahan.`,
          { parse_mode: 'Markdown' }
        );
      }

      return next();
    } catch (error) {
      console.error('Anti-abuse middleware error:', error);
      return next();
    }
  }

  detectAction(ctx) {
    if (ctx.callbackQuery) return 'callback';
    if (ctx.message?.text) return 'message';
    if (ctx.message?.photo) return 'photo';
    return 'other';
  }

  trackAction(userId, action) {
    const key = `${userId}`;
    const actions = this.userActions.get(key) || [];
    const now = Date.now();
    
    actions.push({
      action,
      timestamp: now
    });

    // Keep only last 50 actions in last 5 minutes
    const recent = actions.filter(a => now - a.timestamp < 300000).slice(-50);
    this.userActions.set(key, recent);
  }

  async detectAbuse(userId) {
    const actions = this.userActions.get(userId) || [];
    const now = Date.now();
    const recentActions = actions.filter(a => now - a.timestamp < 60000);

    // Check for rapid fire
    if (recentActions.length > 20) {
      return { reason: 'Terlalu banyak request dalam 1 menit' };
    }

    // Check for callback spam
    const callbacks = recentActions.filter(a => a.action === 'callback');
    if (callbacks.length > 15) {
      return { reason: 'Spam tombol terdeteksi' };
    }

    // Check for duplicate messages
    const messages = recentActions.filter(a => a.action === 'message');
    if (messages.length > 10) {
      return { reason: 'Terlalu banyak pesan' };
    }

    return null;
  }

  blockUser(userId, duration, reason) {
    this.blockedUsers.set(userId, {
      reason,
      until: Date.now() + duration,
      blockedAt: Date.now()
    });

    // Auto unblock after duration
    setTimeout(() => {
      this.blockedUsers.delete(userId);
    }, duration);
  }

  isUserBlocked(userId) {
    const block = this.blockedUsers.get(userId);
    if (!block) return false;
    
    if (Date.now() > block.until) {
      this.blockedUsers.delete(userId);
      return false;
    }
    
    return true;
  }

  unblockUser(userId) {
    this.blockedUsers.delete(userId);
    return true;
  }
}

module.exports = new AntiAbuseMiddleware();