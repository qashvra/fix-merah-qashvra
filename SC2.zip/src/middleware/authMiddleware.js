const DatabaseService = require('../services/database/DatabaseService');
const PermissionService = require('../services/permissions/PermissionService');

const db = new DatabaseService();
const permissionService = new PermissionService();

const authMiddleware = async (ctx, next) => {
  try {
    if (!ctx.from) {
      return next();
    }

    const userId = ctx.from.id;
    const username = ctx.from.username;
    
    // Get or create user
    let user = await db.getUser(userId);
    
    if (!user) {
      user = await db.createUser({
        user_id: userId,
        username: username || '',
        first_name: ctx.from.first_name || '',
        last_name: ctx.from.last_name || '',
        language_code: ctx.from.language_code || 'id',
        role: userId === parseInt(process.env.OWNER_ID) ? 'OWNER' : 'FREE_USER',
        joined_at: Date.now(),
        last_active: Date.now(),
        status: 'active'
      });
    }

    // Update last active
    await db.updateUser(userId, {
      last_active: Date.now(),
      username: username || user.username,
      first_name: ctx.from.first_name || user.first_name
    });

    // Check if banned
    if (user.role === 'BANNED') {
      return ctx.reply('⛔ Akun Anda telah dibanned.\n\nSilakan hubungi @qashvra untuk informasi lebih lanjut.');
    }

    // Set user info in context
    ctx.state.user = user;
    ctx.state.userId = userId;
    ctx.state.role = user.role;
    
    // Check permissions
    ctx.state.hasPermission = (permission) => {
      return permissionService.hasPermission(user.role, permission);
    };

    return next();
  } catch (error) {
    console.error('Auth Middleware Error:', error);
    return next();
  }
};

const roleMiddleware = (requiredRole) => {
  return async (ctx, next) => {
    const userRole = ctx.state.role;
    
    if (!permissionService.hasMinimumRole(userRole, requiredRole)) {
      return ctx.reply('⛔ Anda tidak memiliki akses ke fitur ini.');
    }
    
    return next();
  };
};

module.exports = { authMiddleware, roleMiddleware };