const ConfigService = require('../configs/ConfigService');

class VerificationMiddleware {
  constructor() {
    this.config = new ConfigService();
  }

  async checkVerification(ctx, next) {
    try {
      // Skip for owner
      const userId = ctx.from?.id;
      if (userId?.toString() === process.env.OWNER_ID) {
        return next();
      }

      const verificationConfig = this.config.getConfig('verification');
      
      if (!verificationConfig?.enabled) {
        return next();
      }

      // Check if user is verified
      const isVerified = await this.verifyUserMembership(ctx);
      
      if (!isVerified) {
        return this.showVerificationPrompt(ctx);
      }

      return next();
    } catch (error) {
      console.error('Verification middleware error:', error);
      return next();
    }
  }

  async verifyUserMembership(ctx) {
    const userId = ctx.from.id;
    const verificationConfig = this.config.getConfig('verification');
    
    // Check channels
    for (const channel of verificationConfig.channels || []) {
      if (channel.required) {
        const isMember = await this.checkChannelMembership(ctx, channel.id);
        if (!isMember) return false;
      }
    }

    // Check groups
    for (const group of verificationConfig.groups || []) {
      if (group.required) {
        const isMember = await this.checkChannelMembership(ctx, group.id);
        if (!isMember) return false;
      }
    }

    return true;
  }

  async checkChannelMembership(ctx, channelId) {
    try {
      const member = await ctx.telegram.getChatMember(
        channelId,
        ctx.from.id
      );
      
      const allowedStatuses = ['member', 'administrator', 'creator'];
      return allowedStatuses.includes(member.status);
    } catch (error) {
      console.error(`Error checking membership for ${channelId}:`, error.message);
      return false;
    }
  }

  async showVerificationPrompt(ctx) {
    const verificationConfig = this.config.getConfig('verification');
    
    const message = 
      `⚠️ *VERIFIKASI DIPERLUKAN*\n\n` +
      `Anda harus bergabung ke channel/group berikut:\n\n` +
      this.formatRequiredChannels(verificationConfig) +
      `\nKlik tombol JOIN, lalu klik CEK VERIFIKASI.`;

    const keyboard = this.buildVerificationKeyboard(verificationConfig);

    await ctx.reply(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  formatRequiredChannels(config) {
    let text = '';
    
    config.channels?.forEach(ch => {
      if (ch.required) {
        text += `📢 ${ch.id}\n`;
      }
    });
    
    config.groups?.forEach(gr => {
      if (gr.required) {
        text += `👥 ${gr.id}\n`;
      }
    });
    
    return text;
  }

  buildVerificationKeyboard(config) {
    const keyboard = [];
    
    // Join buttons for channels
    config.channels?.forEach(ch => {
      keyboard.push([{
        text: `📢 JOIN ${ch.id}`,
        url: `https://t.me/${ch.id.replace('@', '')}`
      }]);
    });
    
    // Join buttons for groups
    config.groups?.forEach(gr => {
      keyboard.push([{
        text: `👥 JOIN ${gr.id}`,
        url: `https://t.me/${gr.id.replace('@', '')}`
      }]);
    });
    
    // Verify button
    keyboard.push([{
      text: '✅ CEK VERIFIKASI',
      callback_data: 'verify_check'
    }]);
    
    return {
      inline_keyboard: keyboard
    };
  }
}

module.exports = new VerificationMiddleware();