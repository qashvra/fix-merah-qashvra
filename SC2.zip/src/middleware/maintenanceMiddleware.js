const ConfigService = require('../configs/ConfigService');

const config = new ConfigService();

const maintenanceMiddleware = async (ctx, next) => {
  try {
    const isMaintenance = config.getConfig('bot')?.maintenance || false;
    
    if (isMaintenance && ctx.from) {
      const userId = ctx.from.id;
      const ownerId = process.env.OWNER_ID;
      
      // Owner bypass maintenance mode
      if (userId.toString() === ownerId) {
        return next();
      }
      
      // Notify user about maintenance
      return ctx.reply(
        '🔧 *MAINTENANCE MODE*\n\n' +
        'Bot sedang dalam pemeliharaan.\n' +
        'Silakan kembali nanti.\n\n' +
        '📅 Estimasi selesai: Segera\n' +
        '👑 Powered by Qashvra Fix Merah Pro',
        { parse_mode: 'Markdown' }
      );
    }
    
    return next();
  } catch (error) {
    console.error('Maintenance Middleware Error:', error);
    return next();
  }
};

module.exports = { maintenanceMiddleware };