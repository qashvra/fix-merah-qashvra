const fs = require('fs').promises;
const path = require('path');

class DatabaseOptimizer {
  constructor() {
    this.dbPath = path.join(__dirname, '../../database');
    this.optimizationInterval = 3600000; // 1 hour
    this.isRunning = false;
  }

  start() {
    this.isRunning = true;
    this.runOptimization();
    setInterval(() => this.runOptimization(), this.optimizationInterval);
    console.log('✅ Database Optimizer started');
  }

  stop() {
    this.isRunning = false;
    console.log('✅ Database Optimizer stopped');
  }

  async runOptimization() {
    try {
      const collections = await fs.readdir(this.dbPath);
      
      for (const collection of collections) {
        const collectionPath = path.join(this.dbPath, collection);
        const stat = await fs.stat(collectionPath);
        
        if (stat.isDirectory()) {
          await this.optimizeCollection(collection);
        }
      }

      console.log('✅ Database optimization completed');
    } catch (error) {
      console.error('Database optimization error:', error);
    }
  }

  async optimizeCollection(collection) {
    const indexPath = path.join(this.dbPath, collection, 'index.json');
    
    try {
      const data = await fs.readFile(indexPath, 'utf-8');
      let records = JSON.parse(data);
      
      // Remove duplicates
      const uniqueRecords = this.removeDuplicates(records);
      
      // Sort by timestamp if available
      uniqueRecords.sort((a, b) => (b.timestamp || b.created_at || 0) - (a.timestamp || a.created_at || 0));
      
      // Limit collection size
      const maxRecords = 10000;
      if (uniqueRecords.length > maxRecords) {
        uniqueRecords.splice(maxRecords);
      }
      
      // Compact JSON (remove whitespace)
      await fs.writeFile(indexPath, JSON.stringify(uniqueRecords), 'utf-8');
      
      console.log(`✅ Optimized ${collection}: ${records.length} → ${uniqueRecords.length} records`);
    } catch (error) {
      if (error.code !== 'ENOENT') {
        console.error(`Error optimizing ${collection}:`, error.message);
      }
    }
  }

  removeDuplicates(records) {
    const seen = new Set();
    return records.filter(record => {
      const key = record.id || JSON.stringify(record);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  async getCollectionSize(collection) {
    const indexPath = path.join(this.dbPath, collection, 'index.json');
    try {
      const data = await fs.readFile(indexPath, 'utf-8');
      return JSON.parse(data).length;
    } catch {
      return 0;
    }
  }

  async getDatabaseStats() {
    const collections = await fs.readdir(this.dbPath);
    const stats = {};
    
    for (const collection of collections) {
      const collectionPath = path.join(this.dbPath, collection);
      const stat = await fs.stat(collectionPath);
      
      if (stat.isDirectory()) {
        const indexPath = path.join(collectionPath, 'index.json');
        try {
          const fileStat = await fs.stat(indexPath);
          const recordCount = await this.getCollectionSize(collection);
          
          stats[collection] = {
            records: recordCount,
            size: fileStat.size,
            lastModified: fileStat.mtime
          };
        } catch {
          stats[collection] = { records: 0, size: 0 };
        }
      }
    }
    
    return stats;
  }

  async compactAll() {
    const collections = await fs.readdir(this.dbPath);
    
    for (const collection of collections) {
      await this.optimizeCollection(collection);
    }
    
    return this.getDatabaseStats();
  }
}

module.exports = DatabaseOptimizer;