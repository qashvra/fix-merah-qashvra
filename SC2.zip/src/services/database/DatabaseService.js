const fs = require('fs').promises;
const path = require('path');

class DatabaseService {
  constructor() {
    this.dbPath = path.join(__dirname, '../../database');
    this.cache = new Map();
    this.writeQueue = new Map();
    this.initialized = false;
  }

  async initialize() {
    await this.ensureDirectories();
    this.initialized = true;
    console.log('✅ DatabaseService initialized');
  }

  async ensureDirectories() {
    const dirs = ['users', 'smtp', 'payments', 'referrals', 'templates', 'logs', 'statistics'];
    
    for (const dir of dirs) {
      const dirPath = path.join(this.dbPath, dir);
      await fs.mkdir(dirPath, { recursive: true });
      
      // Create index file if not exists
      const indexPath = path.join(dirPath, 'index.json');
      try {
        await fs.access(indexPath);
      } catch {
        await fs.writeFile(indexPath, '[]', 'utf-8');
      }
    }
  }

  async readCollection(collection) {
    try {
      const filePath = path.join(this.dbPath, collection, 'index.json');
      const data = await fs.readFile(filePath, 'utf-8');
      return JSON.parse(data);
    } catch (error) {
      if (error.code === 'ENOENT') {
        return [];
      }
      throw error;
    }
  }

  async writeCollection(collection, data) {
    const filePath = path.join(this.dbPath, collection, 'index.json');
    const tempPath = filePath + '.tmp';
    
    // Write to temp file first
    await fs.writeFile(tempPath, JSON.stringify(data, null, 2), 'utf-8');
    
    // Rename to actual file (atomic operation)
    await fs.rename(tempPath, filePath);
  }

  // User operations
  async getUser(userId) {
    const users = await this.readCollection('users');
    return users.find(u => u.user_id === userId);
  }

  async createUser(userData) {
    const users = await this.readCollection('users');
    const newUser = {
      ...userData,
      created_at: Date.now(),
      updated_at: Date.now()
    };
    users.push(newUser);
    await this.writeCollection('users', users);
    return newUser;
  }

  async updateUser(userId, updates) {
    const users = await this.readCollection('users');
    const index = users.findIndex(u => u.user_id === userId);
    
    if (index !== -1) {
      users[index] = {
        ...users[index],
        ...updates,
        updated_at: Date.now()
      };
      await this.writeCollection('users', users);
      return users[index];
    }
    return null;
  }

  async deleteUser(userId) {
    const users = await this.readCollection('users');
    const filtered = users.filter(u => u.user_id !== userId);
    await this.writeCollection('users', filtered);
  }

  async getAllUsers() {
    return await this.readCollection('users');
  }

  async getTotalUsers() {
    const users = await this.readCollection('users');
    return users.length;
  }

  async getUsersByRole(role) {
    const users = await this.readCollection('users');
    return users.filter(u => u.role === role);
  }

  // SMTP operations
  async getSMTPConfigs() {
    return await this.readCollection('smtp');
  }

  async addSMTPConfig(config) {
    const smtps = await this.readCollection('smtp');
    const newConfig = {
      ...config,
      id: `smtp_${Date.now()}`,
      created_at: Date.now(),
      updated_at: Date.now()
    };
    smtps.push(newConfig);
    await this.writeCollection('smtp', smtps);
    return newConfig;
  }

  async updateSMTPConfig(id, updates) {
    const smtps = await this.readCollection('smtp');
    const index = smtps.findIndex(s => s.id === id);
    
    if (index !== -1) {
      smtps[index] = {
        ...smtps[index],
        ...updates,
        updated_at: Date.now()
      };
      await this.writeCollection('smtp', smtps);
      return smtps[index];
    }
    return null;
  }

  async deleteSMTPConfig(id) {
    const smtps = await this.readCollection('smtp');
    const filtered = smtps.filter(s => s.id !== id);
    await this.writeCollection('smtp', filtered);
  }

  async getActiveSMTPCount() {
    const smtps = await this.readCollection('smtp');
    return smtps.filter(s => s.status === 'active').length;
  }

  async getTotalSMTPCount() {
    const smtps = await this.readCollection('smtp');
    return smtps.length;
  }

  // Payment operations
  async getPayments() {
    return await this.readCollection('payments');
  }

  async createPayment(paymentData) {
    const payments = await this.readCollection('payments');
    const newPayment = {
      ...paymentData,
      id: `PAY_${Date.now()}`,
      created_at: Date.now(),
      updated_at: Date.now()
    };
    payments.push(newPayment);
    await this.writeCollection('payments', payments);
    return newPayment;
  }

  async updatePayment(id, updates) {
    const payments = await this.readCollection('payments');
    const index = payments.findIndex(p => p.id === id);
    
    if (index !== -1) {
      payments[index] = {
        ...payments[index],
        ...updates,
        updated_at: Date.now()
      };
      await this.writeCollection('payments', payments);
      return payments[index];
    }
    return null;
  }

  async getUserPayments(userId) {
    const payments = await this.readCollection('payments');
    return payments.filter(p => p.user_id === userId);
  }

  // Referral operations
  async getReferrals() {
    return await this.readCollection('referrals');
  }

  async createReferral(referralData) {
    const referrals = await this.readCollection('referrals');
    const newReferral = {
      ...referralData,
      id: `REF_${Date.now()}`,
      created_at: Date.now()
    };
    referrals.push(newReferral);
    await this.writeCollection('referrals', referrals);
    return newReferral;
  }

  async getUserReferrals(userId) {
    const referrals = await this.readCollection('referrals');
    return referrals.filter(r => r.referrer_id === userId);
  }

  async getReferralCount(userId) {
    const referrals = await this.readCollection('referrals');
    return referrals.filter(r => r.referrer_id === userId).length;
  }

  // Statistics operations
  async getStatistics() {
    return await this.readCollection('statistics');
  }

  async updateStatistics(stats) {
    const statistics = await this.readCollection('statistics');
    statistics.push({
      ...stats,
      timestamp: Date.now()
    });
    // Keep only last 1000 entries
    const trimmed = statistics.slice(-1000);
    await this.writeCollection('statistics', trimmed);
  }

  async getTotalFixes() {
    const stats = await this.readCollection('statistics');
    return stats.reduce((total, s) => total + (s.total_fixes || 0), 0);
  }

  async getSuccessRate() {
    const stats = await this.readCollection('statistics');
    const total = stats.reduce((sum, s) => sum + (s.total_fixes || 0), 0);
    const success = stats.reduce((sum, s) => sum + (s.success_fixes || 0), 0);
    return total > 0 ? (success / total) * 100 : 0;
  }

  // Log operations
  async addLog(logData) {
    const logs = await this.readCollection('logs');
    logs.push({
      ...logData,
      timestamp: Date.now()
    });
    // Keep only last 5000 logs
    const trimmed = logs.slice(-5000);
    await this.writeCollection('logs', trimmed);
  }

  async getLogs(type, limit = 100) {
    const logs = await this.readCollection('logs');
    const filtered = type ? logs.filter(l => l.type === type) : logs;
    return filtered.slice(-limit);
  }

  // Backup operations
  async createBackup() {
    const timestamp = new Date().toISOString().replace(/:/g, '-');
    const backupDir = path.join(__dirname, '../../../backups', timestamp);
    
    await fs.mkdir(backupDir, { recursive: true });
    
    const collections = ['users', 'smtp', 'payments', 'referrals', 'templates', 'logs', 'statistics'];
    
    for (const collection of collections) {
      const data = await this.readCollection(collection);
      const filePath = path.join(backupDir, `${collection}.json`);
      await fs.writeFile(filePath, JSON.stringify(data, null, 2), 'utf-8');
    }
    
    return backupDir;
  }

  async restoreBackup(backupDir) {
    const collections = ['users', 'smtp', 'payments', 'referrals', 'templates', 'logs', 'statistics'];
    
    for (const collection of collections) {
      const filePath = path.join(backupDir, `${collection}.json`);
      try {
        const data = await fs.readFile(filePath, 'utf-8');
        await this.writeCollection(collection, JSON.parse(data));
      } catch (error) {
        console.error(`Error restoring ${collection}:`, error.message);
      }
    }
    
    return true;
  }

  async close() {
    this.initialized = false;
    console.log('✅ DatabaseService closed');
  }
}

module.exports = DatabaseService;