const crypto = require('crypto');
const CryptoJS = require('crypto-js');

class SecurityService {
  constructor() {
    this.encryptionKey = process.env.ENCRYPTION_KEY || 'qashvra-default-key';
    this.rateLimitMap = new Map();
    this.blacklistIPs = new Set();
    this.sessionTokens = new Map();
  }

  async initialize() {
    console.log('✅ SecurityService initialized');
  }

  // Encryption
  encrypt(data) {
    if (typeof data !== 'string') {
      data = JSON.stringify(data);
    }
    return CryptoJS.AES.encrypt(data, this.encryptionKey).toString();
  }

  decrypt(encryptedData) {
    try {
      const bytes = CryptoJS.AES.decrypt(encryptedData, this.encryptionKey);
      return bytes.toString(CryptoJS.enc.Utf8);
    } catch (error) {
      return null;
    }
  }

  // Hash
  hash(data) {
    return crypto.createHash('sha256').update(data.toString()).digest('hex');
  }

  compareHash(data, hash) {
    return this.hash(data) === hash;
  }

  // Token generation
  generateToken() {
    return crypto.randomBytes(32).toString('hex');
  }

  generateOTP(length = 6) {
    const digits = '0123456789';
    let otp = '';
    for (let i = 0; i < length; i++) {
      otp += digits[Math.floor(Math.random() * 10)];
    }
    return otp;
  }

  // Session management
  createSession(userId) {
    const token = this.generateToken();
    const session = {
      userId,
      token,
      createdAt: Date.now(),
      expiresAt: Date.now() + (24 * 60 * 60 * 1000) // 24 hours
    };
    this.sessionTokens.set(token, session);
    return token;
  }

  validateSession(token) {
    const session = this.sessionTokens.get(token);
    if (!session) return false;
    if (Date.now() > session.expiresAt) {
      this.sessionTokens.delete(token);
      return false;
    }
    return session;
  }

  deleteSession(token) {
    this.sessionTokens.delete(token);
  }

  // Anti-spam
  checkSpam(userId, action, windowMs = 10000, maxRequests = 5) {
    const key = `${userId}_${action}`;
    const now = Date.now();
    
    if (!this.rateLimitMap.has(key)) {
      this.rateLimitMap.set(key, []);
    }
    
    const requests = this.rateLimitMap.get(key);
    const recentRequests = requests.filter(t => now - t < windowMs);
    
    if (recentRequests.length >= maxRequests) {
      return false;
    }
    
    recentRequests.push(now);
    this.rateLimitMap.set(key, recentRequests);
    
    // Cleanup old entries
    if (this.rateLimitMap.size > 1000) {
      this.cleanupRateLimitMap();
    }
    
    return true;
  }

  cleanupRateLimitMap() {
    const now = Date.now();
    for (const [key, times] of this.rateLimitMap.entries()) {
      const recent = times.filter(t => now - t < 60000);
      if (recent.length === 0) {
        this.rateLimitMap.delete(key);
      } else {
        this.rateLimitMap.set(key, recent);
      }
    }
  }

  // Input validation
  sanitizeInput(input) {
    if (typeof input !== 'string') return input;
    return input
      .replace(/<[^>]*>/g, '') // Remove HTML tags
      .replace(/[<>]/g, '') // Remove angle brackets
      .trim();
  }

  validatePhoneNumber(phone) {
    // Remove non-digit characters except +
    phone = phone.replace(/[^\d+]/g, '');
    
    // Check format
    const phoneRegex = /^\+?\d{10,15}$/;
    return phoneRegex.test(phone);
  }

  validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  // Anti-duplicate
  isDuplicate(setKey, value, ttlMs = 3600000) {
    const key = `${setKey}_${value}`;
    const now = Date.now();
    
    if (this.rateLimitMap.has(key)) {
      const timestamp = this.rateLimitMap.get(key);
      if (now - timestamp < ttlMs) {
        return true;
      }
    }
    
    this.rateLimitMap.set(key, now);
    return false;
  }

  // IP Blacklisting
  blacklistIP(ip) {
    this.blacklistIPs.add(ip);
  }

  unblacklistIP(ip) {
    this.blacklistIPs.delete(ip);
  }

  isIPBlacklisted(ip) {
    return this.blacklistIPs.has(ip);
  }

  // QRIS Security
  validateQRISPayload(payload) {
    if (!payload || typeof payload !== 'string') return false;
    if (!payload.startsWith('0002')) return false;
    if (payload.length < 50) return false;
    return true;
  }

  // Payment verification
  verifyPaymentSignature(data, signature) {
    const computedSignature = this.hash(JSON.stringify(data) + this.encryptionKey);
    return computedSignature === signature;
  }

  // Generate unique IDs
  generateUniqueId(prefix = '') {
    const timestamp = Date.now().toString(36);
    const random = crypto.randomBytes(4).toString('hex');
    return `${prefix}${timestamp}${random}`.toUpperCase();
  }

  // Mask sensitive data
  maskPhoneNumber(phone) {
    if (phone.length < 8) return phone;
    const visibleStart = 4;
    const visibleEnd = 4;
    const maskedLength = phone.length - visibleStart - visibleEnd;
    return phone.slice(0, visibleStart) + '*'.repeat(maskedLength) + phone.slice(-visibleEnd);
  }

  maskEmail(email) {
    const [username, domain] = email.split('@');
    if (username.length <= 2) return email;
    return username[0] + '*'.repeat(username.length - 2) + username.slice(-1) + '@' + domain;
  }

  maskUsername(username) {
    if (username.length <= 3) return username;
    return username.slice(0, 3) + '*'.repeat(username.length - 3);
  }

  // Security audit log
  async logSecurityEvent(event) {
    const LoggerService = require('../logs/LoggerService');
    const logger = new LoggerService();
    logger.warn('Security Event', event);
  }
}

module.exports = SecurityService;