const crypto = require('crypto');

class SecurityManager {
  constructor() {
    this.blockedUsers = new Set();
    this.blockedIPs = new Set();
    this.suspiciousActivities = new Map();
    this.sessionStore = new Map();
  }

  // Anti-brute force
  trackFailedAttempt(userId, action) {
    const key = `${userId}_${action}`;
    const attempts = (this.suspiciousActivities.get(key) || 0) + 1;
    this.suspiciousActivities.set(key, attempts);

    if (attempts >= 5) {
      this.blockUser(userId, 3600000); // Block 1 hour
      return { blocked: true, reason: 'Too many failed attempts' };
    }

    // Reset after 15 minutes
    setTimeout(() => {
      this.suspiciousActivities.delete(key);
    }, 900000);

    return { blocked: false, attempts };
  }

  blockUser(userId, duration = 3600000) {
    this.blockedUsers.add(userId);
    setTimeout(() => this.blockedUsers.delete(userId), duration);
  }

  isUserBlocked(userId) {
    return this.blockedUsers.has(userId);
  }

  // Session management
  createSession(userId, data = {}) {
    const sessionId = crypto.randomBytes(32).toString('hex');
    const session = {
      id: sessionId,
      userId,
      data,
      createdAt: Date.now(),
      expiresAt: Date.now() + (24 * 60 * 60 * 1000)
    };
    
    this.sessionStore.set(sessionId, session);
    return sessionId;
  }

  validateSession(sessionId) {
    const session = this.sessionStore.get(sessionId);
    if (!session) return null;
    if (Date.now() > session.expiresAt) {
      this.sessionStore.delete(sessionId);
      return null;
    }
    return session;
  }

  destroySession(sessionId) {
    this.sessionStore.delete(sessionId);
  }

  // Anti-fake payment detection
  detectFakePayment(paymentData) {
    const redFlags = [];

    // Check for impossible amounts
    if (paymentData.amount < 1000) {
      redFlags.push('Amount too low');
    }

    // Check for rapid successive payments
    const recentPayments = this.getRecentPayments(paymentData.userId);
    if (recentPayments.length > 10) {
      redFlags.push('Unusual payment frequency');
    }

    // Check for mismatched signatures
    if (!this.verifyPaymentSignature(paymentData)) {
      redFlags.push('Invalid signature');
    }

    return {
      isFake: redFlags.length > 0,
      flags: redFlags
    };
  }

  verifyPaymentSignature(data) {
    const secret = process.env.API_SECRET_KEY || 'qashvra-secret';
    const expectedSignature = crypto
      .createHmac('sha256', secret)
      .update(JSON.stringify({
        orderId: data.orderId,
        amount: data.amount,
        timestamp: data.timestamp
      }))
      .digest('hex');
    
    return data.signature === expectedSignature;
  }

  getRecentPayments(userId) {
    // Implement payment history tracking
    return [];
  }

  // Input validation and sanitization
  sanitizeString(input) {
    if (typeof input !== 'string') return '';
    return input
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/<[^>]*>/g, '')
      .replace(/[<>{}]/g, '')
      .trim()
      .substring(0, 1000); // Limit length
  }

  validatePhoneNumber(phone) {
    const cleaned = phone.replace(/[^\d+]/g, '');
    const regex = /^\+?\d{10,15}$/;
    return regex.test(cleaned);
  }

  // Rate limiting helper
  checkRateLimit(key, limit = 10, windowMs = 60000) {
    const now = Date.now();
    const requests = this.suspiciousActivities.get(key) || [];
    const recentRequests = requests.filter(t => now - t < windowMs);
    
    if (recentRequests.length >= limit) {
      return false; // Rate limited
    }
    
    recentRequests.push(now);
    this.suspiciousActivities.set(key, recentRequests);
    return true;
  }

  // Anti-spam
  detectSpam(userId, content) {
    const key = `spam_${userId}`;
    const history = this.suspiciousActivities.get(key) || [];
    
    // Check for duplicate messages
    const isDuplicate = history.includes(content);
    
    // Check frequency
    const recentCount = history.length;
    
    history.push(content);
    if (history.length > 100) history.shift();
    this.suspiciousActivities.set(key, history);

    return {
      isSpam: isDuplicate || recentCount > 20,
      duplicate: isDuplicate,
      frequency: recentCount
    };
  }

  // Emergency lockdown
  emergencyLockdown() {
    this.blockedUsers.clear();
    this.blockedIPs.clear();
    // Block all non-owner access
    console.log('🚨 EMERGENCY LOCKDOWN ACTIVATED');
    return true;
  }

  // Security audit
  auditAction(userId, action, details = {}) {
    const auditLog = {
      userId,
      action,
      details,
      timestamp: Date.now(),
      ip: details.ip || 'unknown'
    };
    
    console.log('🔒 Security Audit:', auditLog);
    // Store audit log
    return auditLog;
  }
}

module.exports = SecurityManager;