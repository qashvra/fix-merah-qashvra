class SMTPHealthChecker {
  constructor() {
    this.checkInterval = 600000; // 10 minutes
    this.isRunning = false;
    this.interval = null;
  }

  start() {
    this.isRunning = true;
    this.runHealthCheck();
    this.interval = setInterval(() => this.runHealthCheck(), this.checkInterval);
    console.log('✅ SMTP Health Checker started');
  }

  stop() {
    this.isRunning = false;
    if (this.interval) clearInterval(this.interval);
    console.log('✅ SMTP Health Checker stopped');
  }

  async runHealthCheck() {
    const DatabaseService = require('../database/DatabaseService');
    const SMTPValidator = require('./SMTPValidator');
    
    const db = new DatabaseService();
    const validator = new SMTPValidator();
    const smtps = await db.getSMTPConfigs();

    for (const smtp of smtps) {
      if (smtp.status === 'active') {
        const result = await validator.validateSMTP(smtp);
        
        if (!result.valid) {
          console.log(`⚠️ SMTP ${smtp.id} failed health check: ${result.message}`);
          
          // Mark as failed after multiple failures
          const failures = (smtp.failures || 0) + 1;
          await db.updateSMTPConfig(smtp.id, {
            failures,
            status: failures >= 3 ? 'failed' : 'active',
            last_check: Date.now()
          });
        } else {
          await db.updateSMTPConfig(smtp.id, {
            failures: 0,
            last_check: Date.now(),
            status: 'active'
          });
        }
      }
    }
  }
}

module.exports = SMTPHealthChecker;