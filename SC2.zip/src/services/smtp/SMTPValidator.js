const nodemailer = require('nodemailer');

class SMTPValidator {
  async validateSMTP(smtpConfig) {
    try {
      const transporter = nodemailer.createTransport({
        host: smtpConfig.host,
        port: smtpConfig.port,
        secure: smtpConfig.secure,
        auth: {
          user: smtpConfig.email,
          pass: smtpConfig.password
        },
        connectionTimeout: 10000,
        greetingTimeout: 10000,
        socketTimeout: 10000
      });

      // Verify connection
      await transporter.verify();
      
      // Close connection
      transporter.close();
      
      return {
        valid: true,
        message: 'SMTP is valid and working'
      };
    } catch (error) {
      return {
        valid: false,
        message: error.message,
        code: error.code
      };
    }
  }

  async testSMTP(smtpConfig, testEmail) {
    try {
      const transporter = nodemailer.createTransport({
        host: smtpConfig.host,
        port: smtpConfig.port,
        secure: smtpConfig.secure,
        auth: {
          user: smtpConfig.email,
          pass: smtpConfig.password
        }
      });

      const result = await transporter.sendMail({
        from: smtpConfig.email,
        to: testEmail,
        subject: 'SMTP Test - Qashvra Fix Merah Pro',
        html: '<h1>SMTP Test Successful</h1><p>Your SMTP configuration is working correctly.</p>'
      });

      transporter.close();
      
      return {
        success: true,
        messageId: result.messageId
      };
    } catch (error) {
      return {
        success: false,
        message: error.message
      };
    }
  }
}

module.exports = SMTPValidator;