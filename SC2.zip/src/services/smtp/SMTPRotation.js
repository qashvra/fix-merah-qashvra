class SMTPRotation {
  constructor() {
    this.currentIndex = 0;
    this.senders = [];
    this.failedSenders = new Map();
    this.cooldownSenders = new Map();
  }

  async initialize() {
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();
    this.senders = await db.getSMTPConfigs();
    console.log(`✅ SMTP Rotation initialized with ${this.senders.length} senders`);
  }

  async getNextSender(userPriority = 'free') {
    const availableSenders = this.getAvailableSenders(userPriority);
    if (availableSenders.length === 0) return null;
    
    const sender = availableSenders[this.currentIndex % availableSenders.length];
    this.currentIndex++;
    return sender;
  }

  getAvailableSenders(userPriority) {
    const now = Date.now();
    
    return this.senders.filter(sender => {
      if (sender.status !== 'active') return false;
      
      // Check cooldown
      if (this.cooldownSenders.has(sender.id)) {
        const cooldownUntil = this.cooldownSenders.get(sender.id);
        if (now < cooldownUntil) return false;
        this.cooldownSenders.delete(sender.id);
      }
      
      // Check daily limit
      if (sender.daily_sent >= sender.daily_limit) return false;
      
      // Priority routing
      if (userPriority === 'premium' && sender.priority === 'high') return true;
      if (userPriority === 'free' && sender.priority === 'shared') return true;
      
      return true;
    });
  }

  markFailed(senderId) {
    const count = (this.failedSenders.get(senderId) || 0) + 1;
    this.failedSenders.set(senderId, count);
    
    if (count >= 3) {
      // Auto-disable after 3 failures
      this.disableSender(senderId);
    } else {
      // Put in cooldown
      const cooldownUntil = Date.now() + (5 * 60 * 1000);
      this.cooldownSenders.set(senderId, cooldownUntil);
    }
  }

  async disableSender(senderId) {
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();
    await db.updateSMTPConfig(senderId, { status: 'failed' });
    console.log(`⚠️ Sender ${senderId} disabled due to failures`);
  }

  getStats() {
    return {
      total: this.senders.length,
      active: this.senders.filter(s => s.status === 'active').length,
      failed: this.senders.filter(s => s.status === 'failed').length,
      cooldown: this.cooldownSenders.size,
      rotationIndex: this.currentIndex
    };
  }
}

module.exports = SMTPRotation;