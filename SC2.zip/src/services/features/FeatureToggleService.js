class FeatureToggleService {
  constructor() {
    this.features = {};
    this.defaultFeatures = {
      verification: true,
      fixMerah: true,
      payment: true,
      referral: true,
      leaderboard: true,
      testimonial: true,
      broadcast: true,
      backup: true,
      multiLanguage: true,
      userSMTP: true,
      animationEffects: true
    };
  }

  async initialize() {
    const ConfigService = require('../../configs/ConfigService');
    const config = new ConfigService();
    this.features = config.getConfig('features') || this.defaultFeatures;
  }

  isEnabled(featureName) {
    return this.features[featureName] !== false;
  }

  async toggleFeature(featureName, enabled) {
    this.features[featureName] = enabled;
    
    const ConfigService = require('../../configs/ConfigService');
    const config = new ConfigService();
    await config.updateConfig('features', featureName, enabled);
    
    return true;
  }

  async enableFeature(featureName) {
    return this.toggleFeature(featureName, true);
  }

  async disableFeature(featureName) {
    return this.toggleFeature(featureName, false);
  }

  getFeaturesList() {
    return Object.keys(this.features).map(key => ({
      name: key,
      enabled: this.features[key],
      description: this.getFeatureDescription(key)
    }));
  }

  getFeatureDescription(feature) {
    const descriptions = {
      verification: 'Verifikasi group/channel',
      fixMerah: 'Fitur Fix Merah',
      payment: 'Sistem pembayaran',
      referral: 'Sistem referral',
      leaderboard: 'Leaderboard global',
      testimonial: 'Testimoni otomatis',
      broadcast: 'Broadcast message',
      backup: 'Auto backup system',
      multiLanguage: 'Multi bahasa',
      userSMTP: 'User dapat menambah SMTP',
      animationEffects: 'Efek animasi loading'
    };
    return descriptions[feature] || feature;
  }
}

module.exports = FeatureToggleService;