const crypto = require('crypto');
const QRCode = require('qrcode');

class QRISGenerator {
  constructor() {
    this.merchantId = 'ID1025371444247';
    this.terminalId = 'UMI';
  }

  /**
   * Generate QRIS payload with dynamic amount
   * @param {number} amount - Payment amount in IDR
   * @returns {string} QRIS payload string
   */
  generateDynamicQRIS(amount) {
    // Format amount to fixed length
    const amountStr = amount.toString().padStart(13, '0');
    
    // Build QRIS payload
    let payload = '';
    payload += '000201'; // Payload Format Indicator
    payload += '010211'; // Point of Initiation Method
    payload += '26570011ID.DANA.WWW0118936009153825067026020982506702603'; // Merchant Account Information
    payload += '03UMI'; // Merchant Category Code
    payload += '51440014ID.CO.QRIS.WWW0215'; // Additional Data
    payload += this.merchantId;
    payload += '0303UMI'; // Terminal ID
    payload += '52044814'; // Transaction Currency (IDR)
    payload += '5303'; // Country Code (360 = Indonesia)
    payload += '5802ID'; // Country Code
    payload += '5907ALL PAY'; // Merchant Name
    payload += '6011Kab. Bantul'; // Merchant City
    payload += '610555772'; // Postal Code
    payload += '54'; // Additional Data Field Template
    payload += amountStr; // Transaction Amount
    payload += '6304'; // CRC16 placeholder
    
    // Calculate CRC16
    const crc = this.calculateCRC16(payload);
    payload += crc.toUpperCase();
    
    return payload;
  }

  /**
   * Generate static QRIS (fixed amount)
   * @returns {string} QRIS payload string
   */
  generateStaticQRIS() {
    return '00020101021126570011ID.DANA.WWW011893600915382506702602098250670260303UMI51440014ID.CO.QRIS.WWW0215ID10253714442470303UMI5204481453033605802ID5907ALL PAY6011Kab. Bantul6105557726304F065';
  }

  /**
   * Calculate CRC16 for QRIS
   * @param {string} data - Data to calculate CRC
   * @returns {string} CRC16 hex value
   */
  calculateCRC16(data) {
    let crc = 0xFFFF;
    
    for (let i = 0; i < data.length; i++) {
      crc ^= data.charCodeAt(i) << 8;
      for (let j = 0; j < 8; j++) {
        if (crc & 0x8000) {
          crc = (crc << 1) ^ 0x1021;
        } else {
          crc = crc << 1;
        }
      }
    }
    
    return (crc & 0xFFFF).toString(16).padStart(4, '0');
  }

  /**
   * Validate QRIS payload
   * @param {string} payload - QRIS payload
   * @returns {boolean} Validation result
   */
  validateQRIS(payload) {
    if (!payload || !payload.startsWith('000201')) {
      return false;
    }
    
    // Extract CRC from payload
    const crcPosition = payload.length - 4;
    const dataWithoutCRC = payload.substring(0, crcPosition - 4);
    const expectedCRC = payload.substring(crcPosition);
    
    // Calculate CRC
    const calculatedCRC = this.calculateCRC16(dataWithoutCRC + '6304');
    
    return expectedCRC.toUpperCase() === calculatedCRC.toUpperCase();
  }

  /**
   * Extract amount from QRIS payload
   * @param {string} payload - QRIS payload
   * @returns {number} Transaction amount
   */
  extractAmount(payload) {
    const amountIndex = payload.indexOf('54');
    if (amountIndex !== -1) {
      const amountStr = payload.substring(amountIndex + 5, amountIndex + 18);
      return parseInt(amountStr);
    }
    return 0;
  }

  /**
   * Generate QR Code image from payload
   * @param {string} payload - QRIS payload
   * @param {string} filePath - Output file path
   * @returns {Promise<string>} File path
   */
  async generateQRCode(payload, filePath) {
    try {
      await QRCode.toFile(filePath, payload, {
        type: 'png',
        width: 400,
        margin: 4,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });
      return filePath;
    } catch (error) {
      console.error('QR Code generation error:', error);
      throw error;
    }
  }

  /**
   * Generate QR Code as buffer
   * @param {string} payload - QRIS payload
   * @returns {Promise<Buffer>} QR Code buffer
   */
  async generateQRCodeBuffer(payload) {
    try {
      return await QRCode.toBuffer(payload, {
        type: 'png',
        width: 400,
        margin: 4
      });
    } catch (error) {
      console.error('QR Code buffer error:', error);
      throw error;
    }
  }

  /**
   * Parse QRIS payload to object
   * @param {string} payload - QRIS payload
   * @returns {object} Parsed QRIS data
   */
  parseQRIS(payload) {
    return {
      version: payload.substring(0, 6),
      method: payload.substring(6, 8),
      merchantInfo: this.parseMerchantInfo(payload),
      currency: 'IDR',
      amount: this.extractAmount(payload),
      merchantName: this.parseMerchantName(payload),
      city: this.parseMerchantCity(payload),
      valid: this.validateQRIS(payload)
    };
  }

  parseMerchantInfo(payload) {
    // Extract merchant info from payload
    return {
      id: this.merchantId,
      terminal: this.terminalId
    };
  }

  parseMerchantName(payload) {
    const nameIndex = payload.indexOf('59');
    if (nameIndex !== -1) {
      const length = parseInt(payload.substring(nameIndex + 2, nameIndex + 4));
      return payload.substring(nameIndex + 4, nameIndex + 4 + length);
    }
    return 'ALL PAY';
  }

  parseMerchantCity(payload) {
    const cityIndex = payload.indexOf('60');
    if (cityIndex !== -1) {
      const length = parseInt(payload.substring(cityIndex + 2, cityIndex + 4));
      return payload.substring(cityIndex + 4, cityIndex + 4 + length);
    }
    return 'Kab. Bantul';
  }
}

module.exports = QRISGenerator;