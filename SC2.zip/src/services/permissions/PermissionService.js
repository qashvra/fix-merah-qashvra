class PermissionService {
  constructor() {
    this.roles = {
      OWNER: 10,
      DEVELOPER: 9,
      PARTNER: 8,
      ADMIN: 7,
      MODERATOR: 6,
      RESELLER: 5,
      VVIP: 4,
      VIP: 3,
      FREE_USER: 1,
      BANNED: 0
    };
  }

  hasPermission(role, permission) {
    const ConfigService = require('../../configs/ConfigService');
    const config = new ConfigService();
    const permissions = config.getPermissions();
    
    if (role === 'OWNER') return true;
    
    const rolePermissions = permissions.roles[role]?.permissions || [];
    return rolePermissions.includes(permission) || rolePermissions.includes('all');
  }

  hasMinimumRole(userRole, requiredRole) {
    const userLevel = this.roles[userRole] || 0;
    const requiredLevel = this.roles[requiredRole] || 0;
    return userLevel >= requiredLevel;
  }

  canAccessFeature(role, feature) {
    const ConfigService = require('../../configs/ConfigService');
    const config = new ConfigService();
    const permissions = config.getPermissions();
    
    const allowedRoles = permissions.feature_access[feature] || [];
    return allowedRoles.includes(role);
  }
}

module.exports = PermissionService;