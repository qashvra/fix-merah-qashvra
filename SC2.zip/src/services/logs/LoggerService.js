const fs = require('fs').promises;
const path = require('path');
const chalk = require('chalk');

class LoggerService {
  constructor() {
    this.logPath = path.join(__dirname, '../../logs');
    this.colors = {
      info: 'blue',
      warn: 'yellow',
      error: 'red',
      success: 'green',
      debug: 'gray'
    };
  }

  async ensureLogDirectory() {
    await fs.mkdir(this.logPath, { recursive: true });
  }

  async writeLog(type, message, meta = {}) {
    await this.ensureLogDirectory();
    
    const timestamp = new Date().toISOString();
    const logEntry = {
      timestamp,
      type,
      message,
      ...meta
    };
    
    // Console output with colors
    this.consoleLog(type, message, meta);
    
    // Write to daily log file
    const date = new Date().toISOString().split('T')[0];
    const logFile = path.join(this.logPath, `${type}_${date}.log`);
    
    try {
      await fs.appendFile(
        logFile,
        JSON.stringify(logEntry) + '\n',
        'utf-8'
      );
    } catch (error) {
      console.error('Failed to write log:', error);
    }
  }

  consoleLog(type, message, meta = {}) {
    const timestamp = new Date().toLocaleTimeString();
    const prefix = {
      info: 'ℹ️',
      warn: '⚠️',
      error: '❌',
      success: '✅',
      debug: '🔍'
    };
    
    const color = this.colors[type] || 'white';
    const emoji = prefix[type] || '📝';
    
    console.log(
      chalk[color](`${emoji} [${timestamp}] [${type.toUpperCase()}] ${message}`)
    );
    
    if (Object.keys(meta).length > 0) {
      console.log(chalk.gray(JSON.stringify(meta, null, 2)));
    }
  }

  info(message, meta = {}) {
    this.writeLog('info', message, meta);
  }

  warn(message, meta = {}) {
    this.writeLog('warn', message, meta);
  }

  error(message, meta = {}) {
    this.writeLog('error', message, meta);
  }

  success(message, meta = {}) {
    this.writeLog('success', message, meta);
  }

  debug(message, meta = {}) {
    this.writeLog('debug', message, meta);
  }

  async getLogs(type, date) {
    const logFile = path.join(this.logPath, `${type}_${date}.log`);
    try {
      const data = await fs.readFile(logFile, 'utf-8');
      return data.split('\n').filter(Boolean).map(JSON.parse);
    } catch (error) {
      return [];
    }
  }

  async clearLogs(days = 7) {
    const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
    
    try {
      const files = await fs.readdir(this.logPath);
      
      for (const file of files) {
        const filePath = path.join(this.logPath, file);
        const stats = await fs.stat(filePath);
        
        if (stats.mtimeMs < cutoff) {
          await fs.unlink(filePath);
        }
      }
      
      console.log(`✅ Logs older than ${days} days cleared`);
    } catch (error) {
      console.error('Error clearing logs:', error);
    }
  }
}

module.exports = LoggerService;