class ChannelAutomation {
  constructor() {
    this.testimoniChannel = '@FixMerahQashvra';
    this.logsChannel = '@QashvraLogs';
    this.paymentChannel = '@QashvraPayments';
  }

  async postTestimoni(bot, data) {
    try {
      const message = this.formatTestimoniMessage(data);
      
      await bot.telegram.sendMessage(
        this.testimoniChannel,
        message,
        { parse_mode: 'Markdown', disable_web_page_preview: false }
      );
      
      return true;
    } catch (error) {
      console.error('Post testimoni error:', error);
      return false;
    }
  }

  async postLog(bot, logData) {
    try {
      const message = this.formatLogMessage(logData);
      
      await bot.telegram.sendMessage(
        this.logsChannel,
        message,
        { parse_mode: 'Markdown' }
      );
      
      return true;
    } catch (error) {
      console.error('Post log error:', error);
      return false;
    }
  }

  async postPaymentNotification(bot, paymentData) {
    try {
      const message = this.formatPaymentMessage(paymentData);
      
      await bot.telegram.sendMessage(
        this.paymentChannel,
        message,
        { parse_mode: 'Markdown' }
      );
      
      return true;
    } catch (error) {
      console.error('Post payment notification error:', error);
      return false;
    }
  }

  formatTestimoniMessage(data) {
    return `🔴 *PROSES FIX MERAH BERHASIL*\n\n` +
           `🆔 ID Banding:\n\`${data.bandingId}\`\n\n` +
           `📱 Nomor:\n\`${data.phone}\`\n\n` +
           `📌 Status:\n✅ SUKSES\n\n` +
           `🤖 Powered by\n[Qashvra Fix Merah Pro](https://t.me/FixMerahQashvra_bot)`;
  }

  formatLogMessage(data) {
    return `📊 *LOG*\n` +
           `├ Type: ${data.type}\n` +
           `├ User: \`${data.userId}\`\n` +
           `├ Action: ${data.action}\n` +
           `└ Time: ${new Date().toLocaleString('id-ID')}`;
  }

  formatPaymentMessage(data) {
    return `💰 *PAYMENT RECEIVED*\n` +
           `├ Order: \`${data.orderId}\`\n` +
           `├ Package: ${data.packageName}\n` +
           `├ Amount: Rp ${data.amount.toLocaleString('id-ID')}\n` +
           `└ User: \`${data.userId}\``;
  }

  async updateChannel(channelType, newChannel) {
    const channelMap = {
      'testimoni': 'testimoniChannel',
      'logs': 'logsChannel',
      'payment': 'paymentChannel'
    };

    const property = channelMap[channelType];
    if (property) {
      this[property] = newChannel;
      return true;
    }
    return false;
  }
}

module.exports = ChannelAutomation;