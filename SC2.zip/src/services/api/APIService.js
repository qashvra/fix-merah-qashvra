class APIService {
  constructor() {
    this.apiKey = process.env.API_SECRET_KEY || 'qashvra-api-secret';
  }

  validateRequest(headers) {
    const apiKey = headers['x-api-key'];
    return apiKey === this.apiKey;
  }

  getStats() {
    return {
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      cpu: process.cpuUsage(),
      timestamp: Date.now()
    };
  }

  async getDetailedStats() {
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();
    
    return {
      users: await db.getTotalUsers(),
      smtp_active: await db.getActiveSMTPCount(),
      smtp_total: await db.getTotalSMTPCount(),
      total_fixes: await db.getTotalFixes(),
      success_rate: await db.getSuccessRate(),
      payments: {
        total: (await db.getPayments()).length,
        paid: (await db.getPayments()).filter(p => p.status === 'paid').length
      }
    };
  }

  async broadcastMessage(message, parseMode = 'Markdown') {
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();
    const users = await db.getAllUsers();
    
    const bot = global.qashvraBot?.bot;
    let sent = 0;
    let failed = 0;

    for (const user of users) {
      try {
        await bot.telegram.sendMessage(user.user_id, message, {
          parse_mode: parseMode
        });
        sent++;
        await new Promise(resolve => setTimeout(resolve, 50)); // Rate limit
      } catch (error) {
        failed++;
      }
    }

    return { sent, failed, total: users.length };
  }
}

module.exports = APIService;