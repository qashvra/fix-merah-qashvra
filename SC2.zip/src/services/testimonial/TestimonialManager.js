class TestimonialManager {
  constructor() {
    this.testimonials = [];
    this.maxStored = 100;
  }

  async addTestimonial(data) {
    const testimonial = {
      id: `TST-${Date.now()}`,
      phone: data.phone,
      bandingId: data.bandingId,
      userId: data.userId,
      status: 'success',
      timestamp: Date.now()
    };

    this.testimonials.unshift(testimonial);
    
    // Keep only latest 100
    if (this.testimonials.length > this.maxStored) {
      this.testimonials = this.testimonials.slice(0, this.maxStored);
    }

    // Save to database
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();
    await db.addLog({
      type: 'testimonial',
      ...testimonial
    });

    return testimonial;
  }

  async getTestimonials(page = 1, limit = 5) {
    const start = (page - 1) * limit;
    const end = start + limit;
    
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();
    const logs = await db.getLogs('testimonial', 100);
    
    const testimonials = logs
      .filter(log => log.status === 'success')
      .slice(start, end)
      .map(log => ({
        phone: this.maskPhone(log.phone),
        bandingId: log.bandingId,
        timestamp: log.timestamp
      }));

    return {
      data: testimonials,
      page,
      total: logs.length,
      hasMore: end < logs.length
    };
  }

  async getLatestTestimonials(limit = 5) {
    return this.getTestimonials(1, limit);
  }

  maskPhone(phone) {
    if (!phone || phone.length < 8) return phone || '****';
    return phone.slice(0, 4) + '*'.repeat(phone.length - 8) + phone.slice(-4);
  }

  formatTestimonialMessage(testimonial) {
    return `✅ *TESTIMONI*\n` +
           `├ 🆔 \`${testimonial.bandingId}\`\n` +
           `├ 📱 \`${testimonial.phone}\`\n` +
           `└ 📅 ${new Date(testimonial.timestamp).toLocaleDateString('id-ID')}`;
  }
}

module.exports = TestimonialManager;