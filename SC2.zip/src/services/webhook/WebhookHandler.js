class WebhookHandler {
  async handlePaymentWebhook(data) {
    try {
      const { order_id, amount, status, signature } = data;

      // Verify signature
      const SecurityService = require('../security/SecurityService');
      const security = new SecurityService();
      
      const isValid = security.verifyPaymentSignature(
        { orderId: order_id, amount, timestamp: Date.now() },
        signature
      );

      if (!isValid) {
        return { success: false, error: 'Invalid signature' };
      }

      // Update payment
      const DatabaseService = require('../database/DatabaseService');
      const db = new DatabaseService();
      
      const payment = await db.getPayment(order_id);
      if (!payment) {
        return { success: false, error: 'Payment not found' };
      }

      if (status === 'paid') {
        payment.status = 'paid';
        payment.paidAt = Date.now();
        await db.updatePayment(order_id, payment);

        // Activate membership
        const packageData = payment.package;
        const durationMs = packageData.duration * 24 * 60 * 60 * 1000;
        
        await db.updateUser(payment.userId, {
          role: packageData.type.toUpperCase(),
          membership_type: packageData.type,
          membership_expires: Date.now() + durationMs,
          membership_active: true
        });

        return { success: true, message: 'Payment processed' };
      }

      return { success: true, message: 'Status unchanged' };
    } catch (error) {
      console.error('Webhook error:', error);
      return { success: false, error: error.message };
    }
  }
}

module.exports = WebhookHandler;