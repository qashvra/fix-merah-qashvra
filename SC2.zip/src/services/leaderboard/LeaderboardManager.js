class LeaderboardManager {
  async getTopUsers(limit = 10) {
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();
    const users = await db.getAllUsers();
    
    return users
      .sort((a, b) => (b.total_fixes || 0) - (a.total_fixes || 0))
      .slice(0, limit)
      .map((user, index) => ({
        rank: index + 1,
        username: this.maskUsername(user.username || user.first_name),
        total_fixes: user.total_fixes || 0,
        success_rate: user.success_rate || 0
      }));
  }

  async getTopCountries(limit = 5) {
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();
    const stats = await db.getStatistics();
    
    // Group by country (simplified)
    const countryStats = {};
    stats.forEach(s => {
      const country = s.country || 'ID';
      if (!countryStats[country]) {
        countryStats[country] = { total: 0, success: 0 };
      }
      countryStats[country].total++;
      if (s.success) countryStats[country].success++;
    });

    return Object.entries(countryStats)
      .map(([country, data]) => ({
        country,
        flag: this.getCountryFlag(country),
        total: data.total,
        success_rate: ((data.success / data.total) * 100).toFixed(1)
      }))
      .sort((a, b) => b.total - a.total)
      .slice(0, limit);
  }

  maskUsername(username) {
    if (!username || username.length <= 3) return username || 'User***';
    return username.slice(0, 3) + '*'.repeat(username.length - 3);
  }

  getCountryFlag(countryCode) {
    const flags = {
      'ID': '🇮🇩',
      'US': '🇺🇸',
      'MY': '🇲🇾',
      'SG': '🇸🇬',
      'PH': '🇵🇭',
      'IN': '🇮🇳',
      'BR': '🇧🇷',
      'NG': '🇳🇬',
      'EG': '🇪🇬',
      'SA': '🇸🇦'
    };
    return flags[countryCode] || '🏳️';
  }
}

module.exports = LeaderboardManager;