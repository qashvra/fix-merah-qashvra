class NotificationManager {
  async notifyOwner(message, type = 'info') {
    try {
      const ownerId = process.env.OWNER_ID;
      if (!ownerId) return;

      const emoji = {
        info: 'ℹ️',
        success: '✅',
        warning: '⚠️',
        error: '🚨',
        payment: '💰'
      };

      const prefix = emoji[type] || emoji.info;
      
      // Send notification to owner
      const bot = global.qashvraBot?.bot;
      if (bot) {
        await bot.telegram.sendMessage(
          ownerId,
          `${prefix} *QASHVRA NOTIFICATION*\n\n${message}`,
          { parse_mode: 'Markdown' }
        );
      }
    } catch (error) {
      console.error('Notification error:', error);
    }
  }

  async sendPaymentAlert(payment) {
    const message = 
      `💰 *NEW PAYMENT*\n` +
      `├ Order: \`${payment.orderId}\`\n` +
      `├ Amount: Rp ${payment.amount.toLocaleString('id-ID')}\n` +
      `├ User: \`${payment.userId}\`\n` +
      `└ Time: ${new Date().toLocaleString('id-ID')}`;
    
    await this.notifyOwner(message, 'payment');
  }

  async sendSMTPAlert(smtpId, issue) {
    const message = 
      `📧 *SMTP ALERT*\n` +
      `├ Sender: \`${smtpId}\`\n` +
      `├ Issue: ${issue}\n` +
      `└ Time: ${new Date().toLocaleString('id-ID')}`;
    
    await this.notifyOwner(message, 'warning');
  }

  async sendErrorAlert(error) {
    const message = 
      `🚨 *ERROR ALERT*\n` +
      `├ Error: ${error.message}\n` +
      `└ Stack: \`${error.stack?.substring(0, 200)}...\``;
    
    await this.notifyOwner(message, 'error');
  }
}

module.exports = NotificationManager;