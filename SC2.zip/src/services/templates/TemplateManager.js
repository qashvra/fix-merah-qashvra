class TemplateManager {
  constructor() {
    this.templates = [];
    this.categories = ['general', 'indonesia', 'english', 'arabic', 'custom'];
  }

  async loadTemplates() {
    const ConfigService = require('../../configs/ConfigService');
    const config = new ConfigService();
    const configData = config.getTemplates();
    this.templates = configData.banding || [];
    return this.templates;
  }

  async getRandomTemplate(category = null, country = null) {
    await this.loadTemplates();
    
    let available = this.templates.filter(t => t.active);
    
    if (category) {
      available = available.filter(t => t.category === category);
    }
    
    if (country) {
      available = available.filter(t => t.country === country);
    }
    
    if (available.length === 0) {
      available = this.templates.filter(t => t.active);
    }
    
    if (available.length === 0) {
      return this.getDefaultTemplate();
    }
    
    return available[Math.floor(Math.random() * available.length)];
  }

  async addTemplate(templateData) {
    const newTemplate = {
      id: `template_${Date.now()}`,
      ...templateData,
      active: true,
      usage_count: 0,
      success_rate: 0,
      created_at: Date.now(),
      updated_at: Date.now()
    };

    this.templates.push(newTemplate);
    
    const ConfigService = require('../../configs/ConfigService');
    const config = new ConfigService();
    await config.addTemplate(newTemplate);
    
    return newTemplate;
  }

  async updateTemplate(templateId, updates) {
    const index = this.templates.findIndex(t => t.id === templateId);
    if (index !== -1) {
      this.templates[index] = {
        ...this.templates[index],
        ...updates,
        updated_at: Date.now()
      };
      
      const ConfigService = require('../../configs/ConfigService');
      const config = new ConfigService();
      await config.saveJSON('templates.json', { banding: this.templates });
      
      return this.templates[index];
    }
    return null;
  }

  async deleteTemplate(templateId) {
    this.templates = this.templates.filter(t => t.id !== templateId);
    
    const ConfigService = require('../../configs/ConfigService');
    const config = new ConfigService();
    await config.removeTemplate(templateId);
    
    return true;
  }

  async toggleTemplate(templateId) {
    const template = this.templates.find(t => t.id === templateId);
    if (template) {
      return this.updateTemplate(templateId, { active: !template.active });
    }
    return null;
  }

  getTemplateById(templateId) {
    return this.templates.find(t => t.id === templateId) || null;
  }

  getTemplatesByCategory(category) {
    return this.templates.filter(t => t.category === category);
  }

  getCategories() {
    return this.categories;
  }

  getDefaultTemplate() {
    return {
      id: 'default',
      name: 'Default Template',
      subject: 'Account Appeal - {id_banding}',
      body: 'Dear Support Team,\n\nI am appealing for my account: {phone_number}\n\nThank you.',
      active: true
    };
  }

  fillTemplate(template, data) {
    let subject = template.subject;
    let body = template.body;

    // Replace placeholders
    Object.entries(data).forEach(([key, value]) => {
      const placeholder = `{${key}}`;
      subject = subject.replace(new RegExp(placeholder, 'g'), value);
      body = body.replace(new RegExp(placeholder, 'g'), value);
    });

    return { subject, body };
  }
}

module.exports = TemplateManager;