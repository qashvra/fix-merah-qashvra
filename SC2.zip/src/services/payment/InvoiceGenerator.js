const QRISGenerator = require('../qris/QRISGenerator');
const path = require('path');

class InvoiceGenerator {
  constructor() {
    this.qrisGenerator = new QRISGenerator();
  }

  async generateInvoice(userId, packageData) {
    const orderId = this.generateOrderId('QASHVRA', userId);
    const amount = packageData.price;
    
    // Generate QRIS
    const qrisPayload = this.qrisGenerator.generateDynamicQRIS(amount);
    
    // Generate QR Code
    const qrPath = path.join(__dirname, '../../assets/qris', `${orderId}.png`);
    await this.qrisGenerator.generateQRCode(qrisPayload, qrPath);

    const invoice = {
      orderId,
      userId,
      packageName: packageData.name,
      packageType: packageData.type,
      amount,
      qrisPayload,
      qrPath,
      status: 'pending',
      createdAt: Date.now(),
      expiresAt: Date.now() + (10 * 60 * 1000), // 10 minutes
      paymentMethod: 'qris'
    };

    return invoice;
  }

  generateOrderId(prefix, userId) {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substr(2, 5).toUpperCase();
    const counter = Math.floor(Math.random() * 10000);
    return `${prefix}-${userId}-${counter}-${timestamp}${random}`;
  }

  formatInvoiceMessage(invoice) {
    return {
      text: `💳 *INVOICE PAYMENT*\n\n` +
            `🔖 Order ID: \`${invoice.orderId}\`\n` +
            `📦 Paket: ${invoice.packageName}\n` +
            `💰 Total: Rp ${invoice.amount.toLocaleString('id-ID')}\n` +
            `⏰ Expired: 10 Menit\n\n` +
            `⚠️ *Klik CEK PEMBAYARAN setelah transfer!*\n\n` +
            `Powered by Qashvra Fix Merah Pro`,
      parse_mode: 'Markdown'
    };
  }

  getPaymentKeyboard(orderId) {
    return {
      inline_keyboard: [
        [{ text: '💳 Cek Pembayaran', callback_data: `payment_check_${orderId}` }],
        [{ text: '❌ Batalkan', callback_data: `payment_cancel_${orderId}` }],
        [{ text: '🔙 Kembali', callback_data: 'menu_back' }]
      ]
    };
  }
}

module.exports = InvoiceGenerator;