const axios = require('axios');
const crypto = require('crypto');

class DanaChecker {
  constructor() {
    this.apiEndpoint = 'https://api.dana.id/v1/transaction/check';
    this.pendingPayments = new Map();
    this.checkInterval = 30000; // 30 seconds
    this.isChecking = false;
  }

  /**
   * Start auto-checking for payments
   */
  startAutoCheck() {
    this.isChecking = true;
    this.runAutoCheck();
  }

  /**
   * Stop auto-checking
   */
  stopAutoCheck() {
    this.isChecking = false;
  }

  /**
   * Run continuous auto-check
   */
  async runAutoCheck() {
    while (this.isChecking) {
      try {
        await this.checkPendingPayments();
        await this.sleep(this.checkInterval);
      } catch (error) {
        console.error('Auto-check error:', error.message);
        await this.sleep(5000);
      }
    }
  }

  /**
   * Check all pending payments
   */
  async checkPendingPayments() {
    const now = Date.now();
    const expiredPayments = [];

    for (const [orderId, payment] of this.pendingPayments) {
      // Check if payment is expired
      if (now > payment.expiresAt) {
        expiredPayments.push(orderId);
        continue;
      }

      // Check payment status
      await this.checkPayment(orderId);
    }

    // Clean expired payments
    for (const orderId of expiredPayments) {
      const payment = this.pendingPayments.get(orderId);
      payment.status = 'expired';
      this.pendingPayments.delete(orderId);
      this.emitPaymentUpdate(payment);
    }
  }

  /**
   * Check single payment status
   * @param {string} orderId - Payment order ID
   */
  async checkPayment(orderId) {
    try {
      // Simulate payment check
      // In production, this would call DANA API
      const payment = this.pendingPayments.get(orderId);
      
      if (!payment) return null;

      // Mock payment check logic
      const isPaid = this.mockPaymentCheck(payment);
      
      if (isPaid) {
        payment.status = 'paid';
        payment.paidAt = Date.now();
        this.pendingPayments.delete(orderId);
        this.emitPaymentUpdate(payment);
      }

      return payment;
    } catch (error) {
      console.error('Payment check error:', error);
      return null;
    }
  }

  /**
   * Mock payment check (for demonstration)
   * In production, implement actual DANA API integration
   */
  mockPaymentCheck(payment) {
    // Simulate 30% chance of payment being completed
    // In production, this would be real API call
    const elapsed = Date.now() - payment.createdAt;
    const minCheckTime = 30000; // Minimum 30 seconds before checking
    
    if (elapsed < minCheckTime) return false;
    
    // Simulate payment success based on time
    const probability = Math.min((elapsed - minCheckTime) / 60000, 0.8);
    return Math.random() < probability;
  }

  /**
   * Add payment to monitoring queue
   * @param {object} payment - Payment data
   */
  addPayment(payment) {
    this.pendingPayments.set(payment.orderId, payment);
    console.log(`✅ Payment added to monitoring: ${payment.orderId}`);
  }

  /**
   * Remove payment from monitoring
   * @param {string} orderId - Payment order ID
   */
  removePayment(orderId) {
    this.pendingPayments.delete(orderId);
  }

  /**
   * Get payment status
   * @param {string} orderId - Payment order ID
   * @returns {object|null} Payment data
   */
  getPaymentStatus(orderId) {
    return this.pendingPayments.get(orderId) || null;
  }

  /**
   * Emit payment update event
   * @param {object} payment - Payment data
   */
  emitPaymentUpdate(payment) {
    const EventEmitter = require('events').EventEmitter;
    const emitter = new EventEmitter();
    emitter.emit('payment_update', payment);
  }

  /**
   * Verify payment signature
   * @param {object} data - Payment verification data
   * @param {string} signature - Received signature
   * @returns {boolean} Verification result
   */
  verifySignature(data, signature) {
    const secret = process.env.API_SECRET_KEY || 'qashvra-secret';
    const computedSignature = crypto
      .createHmac('sha256', secret)
      .update(JSON.stringify(data))
      .digest('hex');
    
    return signature === computedSignature;
  }

  /**
   * Generate order ID
   * @param {string} prefix - Order prefix
   * @param {number} userId - User ID
   * @returns {string} Generated order ID
   */
  generateOrderId(prefix, userId) {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substr(2, 5).toUpperCase();
    const counter = this.pendingPayments.size + 1;
    
    return `${prefix}-${userId}-${counter}-${timestamp}${random}`;
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = DanaChecker;