class PaymentCheckerService {
  constructor() {
    this.isRunning = false;
    this.interval = null;
    this.checkInterval = 30000; // 30 seconds
  }

  start() {
    this.isRunning = true;
    this.runCheck();
    this.interval = setInterval(() => this.runCheck(), this.checkInterval);
    console.log('✅ Payment Checker Service started');
  }

  stop() {
    this.isRunning = false;
    if (this.interval) clearInterval(this.interval);
    console.log('✅ Payment Checker Service stopped');
  }

  async runCheck() {
    try {
      const DatabaseService = require('../database/DatabaseService');
      const db = new DatabaseService();
      
      const payments = await db.getPayments();
      const pendingPayments = payments.filter(
        p => p.status === 'pending' && Date.now() < p.expiresAt
      );

      for (const payment of pendingPayments) {
        await this.checkPayment(payment);
      }
    } catch (error) {
      console.error('Payment check error:', error);
    }
  }

  async checkPayment(payment) {
    // Implement actual payment verification logic
    console.log(`Checking payment: ${payment.id}`);
  }
}

module.exports = PaymentCheckerService;