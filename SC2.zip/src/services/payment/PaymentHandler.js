const QRISGenerator = require('../qris/QRISGenerator');
const DanaChecker = require('./DanaChecker');
const DatabaseService = require('../database/DatabaseService');
const ConfigService = require('../../configs/ConfigService');
const path = require('path');

const qrisGenerator = new QRISGenerator();
const danaChecker = new DanaChecker();
const db = new DatabaseService();
const config = new ConfigService();

class PaymentHandler {
  constructor() {
    this.activePayments = new Map();
  }

  /**
   * Create new payment invoice
   * @param {object} ctx - Telegram context
   * @param {string} packageType - Package type (vip_1day, vip_7day, etc.)
   */
  async createPayment(ctx, packageType) {
    try {
      const userId = ctx.state.userId;
      const packages = config.getConfig('payment')?.packages || {};
      const selectedPackage = packages[packageType];

      if (!selectedPackage) {
        return ctx.reply('❌ Paket tidak ditemukan.');
      }

      // Check for existing pending payment
      const existingPayment = await this.getUserPendingPayment(userId);
      if (existingPayment) {
        return this.showExistingPayment(ctx, existingPayment);
      }

      // Generate order ID
      const orderId = danaChecker.generateOrderId('QASHVRA', userId);
      
      // Generate QRIS
      const amount = selectedPackage.price;
      const qrisPayload = qrisGenerator.generateDynamicQRIS(amount);
      
      // Generate QR Code image
      const qrPath = path.join(__dirname, '../../assets/qris', `${orderId}.png`);
      await qrisGenerator.generateQRCode(qrisPayload, qrPath);

      // Create payment record
      const payment = {
        orderId,
        userId,
        package: selectedPackage,
        amount,
        status: 'pending',
        qrisPayload,
        qrPath,
        createdAt: Date.now(),
        expiresAt: Date.now() + (10 * 60 * 1000) // 10 minutes
      };

      // Save to database
      await db.createPayment(payment);
      
      // Add to monitoring
      danaChecker.addPayment(payment);
      
      // Store in memory
      this.activePayments.set(orderId, payment);

      // Send invoice to user
      await this.sendInvoice(ctx, payment);

      return payment;

    } catch (error) {
      console.error('Create payment error:', error);
      ctx.reply('❌ Gagal membuat pembayaran. Silakan coba lagi.');
    }
  }

  /**
   * Send invoice message to user
   * @param {object} ctx - Telegram context
   * @param {object} payment - Payment data
   */
  async sendInvoice(ctx, payment) {
    const invoiceMessage = 
      `💳 *INVOICE PAYMENT*\n\n` +
      `🔖 Order ID: \`${payment.orderId}\`\n` +
      `📦 Paket: ${payment.package.name}\n` +
      `💰 Total: Rp ${payment.amount.toLocaleString('id-ID')}\n` +
      `⏰ Expired: 10 Menit\n\n` +
      `⚠️ *Klik CEK PEMBAYARAN setelah transfer!*\n\n` +
      `Powered by Qashvra Fix Merah Pro`;

    const keyboard = {
      inline_keyboard: [
        [{ text: '💳 Cek Pembayaran', callback_data: `payment_check_${payment.orderId}` }],
        [{ text: '❌ Batalkan', callback_data: `payment_cancel_${payment.orderId}` }],
        [{ text: '🔙 Kembali', callback_data: 'menu_back' }]
      ]
    };

    // Send QR code image
    await ctx.replyWithPhoto(
      { source: payment.qrPath },
      {
        caption: invoiceMessage,
        parse_mode: 'Markdown',
        reply_markup: keyboard
      }
    );
  }

  /**
   * Check payment status
   * @param {object} ctx - Telegram context
   * @param {string} orderId - Payment order ID
   */
  async checkPayment(ctx, orderId) {
    try {
      const payment = await db.getPayment(orderId);

      if (!payment) {
        return ctx.reply('❌ Pembayaran tidak ditemukan.');
      }

      // Check status with DANA checker
      const status = await danaChecker.checkPayment(orderId);

      if (status === 'paid') {
        await this.processSuccessfulPayment(ctx, payment);
      } else if (status === 'expired') {
        await this.processExpiredPayment(ctx, payment);
      } else {
        await ctx.reply(
          '⏳ *Pembayaran Belum Terkonfirmasi*\n\n' +
          'Silakan lakukan transfer sesuai nominal dan cek kembali.\n\n' +
          '💳 Pastikan Anda transfer ke QRIS yang diberikan.',
          { parse_mode: 'Markdown' }
        );
      }

    } catch (error) {
      console.error('Check payment error:', error);
      ctx.reply('❌ Gagal mengecek pembayaran.');
    }
  }

  /**
   * Process successful payment
   * @param {object} ctx - Telegram context
   * @param {object} payment - Payment data
   */
  async processSuccessfulPayment(ctx, payment) {
    try {
      const userId = payment.userId;
      const packageData = payment.package;

      // Update payment status
      payment.status = 'paid';
      payment.paidAt = Date.now();
      await db.updatePayment(payment.orderId, payment);

      // Calculate membership expiry
      const now = Date.now();
      const durationMs = packageData.duration * 24 * 60 * 60 * 1000;
      const expiresAt = now + durationMs;

      // Update user membership
      await db.updateUser(userId, {
        role: packageData.type.toUpperCase(),
        membership_type: packageData.type,
        membership_expires: expiresAt,
        membership_active: true
      });

      // Send success notification
      await ctx.reply(
        `✅ *PEMBAYARAN BERHASIL*\n\n` +
        `🎉 Selamat! Akun Anda telah diupgrade ke *${packageData.name}*\n\n` +
        `📦 Paket: ${packageData.name}\n` +
        `⏰ Berlaku hingga: ${new Date(expiresAt).toLocaleDateString('id-ID')}\n` +
        `🔖 Order ID: \`${payment.orderId}\`\n\n` +
        `Nikmati fitur premium Qashvra Fix Merah Pro! 🚀`,
        { parse_mode: 'Markdown' }
      );

      // Notify owner
      this.notifyOwner(payment);

      // Remove from active payments
      this.activePayments.delete(payment.orderId);
      danaChecker.removePayment(payment.orderId);

    } catch (error) {
      console.error('Process payment error:', error);
      ctx.reply('❌ Terjadi kesalahan saat memproses pembayaran. Hubungi admin.');
    }
  }

  /**
   * Process expired payment
   * @param {object} ctx - Telegram context
   * @param {object} payment - Payment data
   */
  async processExpiredPayment(ctx, payment) {
    payment.status = 'expired';
    await db.updatePayment(payment.orderId, payment);

    this.activePayments.delete(payment.orderId);
    danaChecker.removePayment(payment.orderId);

    await ctx.reply(
      '⏰ *PEMBAYARAN EXPIRED*\n\n' +
      'Waktu pembayaran telah habis.\n' +
      'Silakan buat invoice baru untuk melanjutkan.',
      { parse_mode: 'Markdown' }
    );
  }

  /**
   * Cancel payment
   * @param {object} ctx - Telegram context
   * @param {string} orderId - Payment order ID
   */
  async cancelPayment(ctx, orderId) {
    const payment = await db.getPayment(orderId);

    if (!payment || payment.status !== 'pending') {
      return ctx.reply('❌ Pembayaran tidak dapat dibatalkan.');
    }

    payment.status = 'cancelled';
    await db.updatePayment(orderId, payment);

    this.activePayments.delete(orderId);
    danaChecker.removePayment(orderId);

    await ctx.reply('✅ Pembayaran telah dibatalkan.');
  }

  /**
   * Get user's pending payment
   * @param {number} userId - User ID
   * @returns {object|null} Pending payment
   */
  async getUserPendingPayment(userId) {
    const payments = await db.getUserPayments(userId);
    return payments.find(p => p.status === 'pending' && p.expiresAt > Date.now());
  }

  /**
   * Show existing payment to user
   * @param {object} ctx - Telegram context
   * @param {object} payment - Payment data
   */
  async showExistingPayment(ctx, payment) {
    const timeLeft = Math.ceil((payment.expiresAt - Date.now()) / 1000 / 60);
    
    const message = 
      `⚠️ *ANDA MEMILIKI PEMBAYARAN AKTIF*\n\n` +
      `🔖 Order ID: \`${payment.orderId}\`\n` +
      `📦 Paket: ${payment.package.name}\n` +
      `💰 Total: Rp ${payment.amount.toLocaleString('id-ID')}\n` +
      `⏰ Sisa Waktu: ${timeLeft} Menit\n\n` +
      `Silakan selesaikan pembayaran atau batalkan untuk membuat yang baru.`;

    const keyboard = {
      inline_keyboard: [
        [{ text: '💳 Cek Pembayaran', callback_data: `payment_check_${payment.orderId}` }],
        [{ text: '❌ Batalkan', callback_data: `payment_cancel_${payment.orderId}` }]
      ]
    };

    await ctx.reply(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  /**
   * Notify owner about successful payment
   * @param {object} payment - Payment data
   */
  async notifyOwner(payment) {
    try {
      const ownerId = process.env.OWNER_ID;
      if (!ownerId) return;

      const message = 
        `💰 *PEMBAYARAN BARU*\n\n` +
        `🔖 Order ID: \`${payment.orderId}\`\n` +
        `👤 User ID: \`${payment.userId}\`\n` +
        `📦 Paket: ${payment.package.name}\n` +
        `💰 Nominal: Rp ${payment.amount.toLocaleString('id-ID')}\n` +
        `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;

      // Send to owner
      const bot = require('../../../index');
      await bot.bot.telegram.sendMessage(ownerId, message, {
        parse_mode: 'Markdown'
      });
    } catch (error) {
      console.error('Notify owner error:', error);
    }
  }
}

module.exports = PaymentHandler;