class AutoBackupService {
  constructor() {
    this.isRunning = false;
    this.interval = null;
    this.backupInterval = 3600000; // 1 hour
  }

  start() {
    this.isRunning = true;
    this.runBackup();
    this.interval = setInterval(() => this.runBackup(), this.backupInterval);
    console.log('✅ Auto Backup Service started');
  }

  stop() {
    this.isRunning = false;
    if (this.interval) clearInterval(this.interval);
    console.log('✅ Auto Backup Service stopped');
  }

  async runBackup() {
    try {
      const BackupManager = require('../../utils/backup');
      const backup = new BackupManager();
      await backup.createBackup();
      await backup.deleteOldBackups(7); // Keep 7 days of backups
    } catch (error) {
      console.error('Auto backup error:', error);
    }
  }
}

module.exports = AutoBackupService;