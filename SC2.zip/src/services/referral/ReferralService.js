class ReferralService {
  async processReferral(referrerId, newUserId) {
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();
    
    // Check if already referred
    const existingReferral = await db.getReferrals().then(
      refs => refs.find(r => r.referred_id === newUserId)
    );
    
    if (existingReferral) return false;
    
    // Create referral record
    await db.createReferral({
      referrer_id: referrerId,
      referred_id: newUserId,
      reward: 50,
      claimed: false
    });
    
    // Update referrer stats
    const user = await db.getUser(referrerId);
    if (user) {
      await db.updateUser(referrerId, {
        referral_coins: (user.referral_coins || 0) + 50,
        total_referrals: (user.total_referrals || 0) + 1
      });
    }
    
    return true;
  }

  async redeemReward(ctx) {
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();
    
    const user = await db.getUser(ctx.state.userId);
    const coins = user.referral_coins || 0;
    
    if (coins < 500) {
      return ctx.reply(`❌ Koin tidak cukup. Anda memiliki ${coins} koin. Butuh 500 koin.`);
    }
    
    // Deduct coins and activate VIP
    await db.updateUser(ctx.state.userId, {
      referral_coins: coins - 500,
      role: 'VIP',
      membership_type: 'vip',
      membership_expires: Date.now() + (24 * 60 * 60 * 1000),
      membership_active: true
    });
    
    await ctx.reply('🎉 Selamat! Anda telah menukarkan 500 koin untuk VIP 1 Hari!');
  }
}

module.exports = ReferralService;