const { Worker } = require('worker_threads');
const path = require('path');
const EventEmitter = require('events');

class QueueService extends EventEmitter {
  constructor() {
    super();
    this.queues = {
      owner: [],
      vvip: [],
      vip: [],
      free: []
    };
    this.processing = new Map();
    this.completed = new Map();
    this.failed = new Map();
    this.workers = new Map();
    this.isProcessing = false;
    this.maxConcurrency = 5;
    this.currentConcurrency = 0;
  }

  async initialize() {
    console.log('✅ QueueService initialized');
  }

  async enqueue(priority, data) {
    const queueItem = {
      id: this.generateQueueId(),
      priority,
      data,
      addedAt: Date.now(),
      status: 'queued',
      attempts: 0
    };

    const queueMap = {
      owner: this.queues.owner,
      vvip: this.queues.vvip,
      vip: this.queues.vip,
      free: this.queues.free
    };

    const queue = queueMap[priority] || this.queues.free;
    queue.push(queueItem);

    this.emit('enqueued', queueItem);

    // Start processing if not already
    if (!this.isProcessing) {
      this.startProcessing();
    }

    return queueItem;
  }

  async startProcessing() {
    this.isProcessing = true;
    
    while (this.isProcessing) {
      const queueItem = this.getNextItem();
      
      if (!queueItem) {
        await this.sleep(1000);
        continue;
      }

      if (this.currentConcurrency >= this.maxConcurrency) {
        await this.sleep(500);
        continue;
      }

      this.processItem(queueItem);
    }
  }

  getNextItem() {
    // Priority order: owner > vvip > vip > free
    const priorityOrder = ['owner', 'vvip', 'vip', 'free'];
    
    for (const priority of priorityOrder) {
      const queue = this.queues[priority];
      if (queue.length > 0) {
        return queue.shift();
      }
    }
    
    return null;
  }

  async processItem(queueItem) {
    this.currentConcurrency++;
    queueItem.status = 'processing';
    queueItem.startedAt = Date.now();
    queueItem.attempts++;

    this.emit('processing', queueItem);
    this.processing.set(queueItem.id, queueItem);

    try {
      // Process in worker thread
      const result = await this.processInWorker(queueItem);
      
      queueItem.status = 'completed';
      queueItem.completedAt = Date.now();
      queueItem.result = result;
      
      this.completed.set(queueItem.id, queueItem);
      this.processing.delete(queueItem.id);
      
      this.emit('completed', queueItem);
      
    } catch (error) {
      queueItem.status = 'failed';
      queueItem.error = error.message;
      
      this.failed.set(queueItem.id, queueItem);
      this.processing.delete(queueItem.id);
      
      // Retry logic
      if (queueItem.attempts < 3) {
        const retryDelay = queueItem.attempts * 2000;
        setTimeout(() => {
          this.enqueue(queueItem.priority, queueItem.data);
        }, retryDelay);
      }
      
      this.emit('failed', queueItem);
    } finally {
      this.currentConcurrency--;
    }
  }

  async processInWorker(queueItem) {
    return new Promise((resolve, reject) => {
      const workerPath = path.join(__dirname, 'QueueWorker.js');
      
      const worker = new Worker(workerPath, {
        workerData: queueItem
      });

      const timeout = setTimeout(() => {
        worker.terminate();
        reject(new Error('Queue processing timeout'));
      }, 30000);

      worker.on('message', (result) => {
        clearTimeout(timeout);
        if (result.success) {
          resolve(result.data);
        } else {
          reject(new Error(result.error));
        }
        worker.terminate();
      });

      worker.on('error', (error) => {
        clearTimeout(timeout);
        reject(error);
        worker.terminate();
      });

      worker.on('exit', (code) => {
        clearTimeout(timeout);
        if (code !== 0) {
          reject(new Error(`Worker exited with code ${code}`));
        }
      });

      this.workers.set(queueItem.id, worker);
    });
  }

  async stop() {
    this.isProcessing = false;
    
    // Terminate all workers
    for (const [id, worker] of this.workers) {
      worker.terminate();
    }
    this.workers.clear();
    
    console.log('✅ QueueService stopped');
  }

  getQueueSize() {
    return (
      this.queues.owner.length +
      this.queues.vvip.length +
      this.queues.vip.length +
      this.queues.free.length
    );
  }

  getProcessingCount() {
    return this.processing.size;
  }

  getStats() {
    return {
      total_queued: this.getQueueSize(),
      processing: this.getProcessingCount(),
      completed: this.completed.size,
      failed: this.failed.size,
      concurrency: this.currentConcurrency
    };
  }

  async clearQueue() {
    this.queues.owner = [];
    this.queues.vvip = [];
    this.queues.vip = [];
    this.queues.free = [];
    this.emit('cleared');
  }

  generateQueueId() {
    return `QUEUE_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = QueueService;