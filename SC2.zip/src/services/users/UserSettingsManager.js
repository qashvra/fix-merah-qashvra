class UserSettingsManager {
  constructor() {
    this.defaultSettings = {
      language: 'id',
      theme: 'default',
      timezone: 'Asia/Jakarta',
      emojiStyle: 'default',
      notifications: {
        fixSuccess: true,
        fixFailed: true,
        paymentSuccess: true,
        referralBonus: true
      },
      privacy: {
        showInLeaderboard: true,
        allowNotifications: true
      }
    };
  }

  async getSettings(userId) {
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();
    const user = await db.getUser(userId);
    
    return user?.settings || this.defaultSettings;
  }

  async updateSettings(userId, settings) {
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();
    
    const currentSettings = await this.getSettings(userId);
    const newSettings = { ...currentSettings, ...settings };
    
    await db.updateUser(userId, { settings: newSettings });
    return newSettings;
  }

  async setLanguage(userId, language) {
    return this.updateSettings(userId, { language });
  }

  async setTheme(userId, theme) {
    return this.updateSettings(userId, { theme });
  }

  async setTimezone(userId, timezone) {
    return this.updateSettings(userId, { timezone });
  }

  async toggleNotification(userId, type, enabled) {
    const settings = await this.getSettings(userId);
    settings.notifications[type] = enabled;
    return this.updateSettings(userId, { notifications: settings.notifications });
  }

  getAvailableLanguages() {
    return [
      { code: 'id', name: '🇮🇩 Indonesia' },
      { code: 'en', name: '🇬🇧 English' },
      { code: 'ar', name: '🇸🇦 العربية' },
      { code: 'ru', name: '🇷🇺 Русский' }
    ];
  }

  getAvailableThemes() {
    return [
      { id: 'default', name: '🔴 Default Red' },
      { id: 'dark', name: '⚫ Dark Mode' },
      { id: 'light', name: '⚪ Light Mode' }
    ];
  }

  getAvailableTimezones() {
    return [
      { id: 'Asia/Jakarta', name: 'WIB (GMT+7)' },
      { id: 'Asia/Makassar', name: 'WITA (GMT+8)' },
      { id: 'Asia/Jayapura', name: 'WIT (GMT+9)' }
    ];
  }
}

module.exports = UserSettingsManager;