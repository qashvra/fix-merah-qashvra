class StatisticsManager {
  constructor() {
    this.cache = new Map();
    this.updateInterval = 60000; // 1 minute
    this.lastUpdate = 0;
  }

  async getGlobalStats() {
    if (this.shouldUpdateCache()) {
      await this.updateCache();
    }
    
    return this.cache.get('global') || this.getDefaultStats();
  }

  async updateCache() {
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();

    const stats = {
      total_users: await db.getTotalUsers(),
      total_fixes: await db.getTotalFixes(),
      success_rate: await db.getSuccessRate(),
      active_smtp: await db.getActiveSMTPCount(),
      total_smtp: await db.getTotalSMTPCount(),
      timestamp: Date.now()
    };

    this.cache.set('global', stats);
    this.lastUpdate = Date.now();
  }

  shouldUpdateCache() {
    return Date.now() - this.lastUpdate > this.updateInterval;
  }

  getDefaultStats() {
    return {
      total_users: 0,
      total_fixes: 0,
      success_rate: 0,
      active_smtp: 0,
      total_smtp: 0,
      timestamp: Date.now()
    };
  }

  async trackFix(userId, phone, success) {
    const DatabaseService = require('../database/DatabaseService');
    const db = new DatabaseService();

    await db.updateStatistics({
      user_id: userId,
      phone,
      success,
      type: 'fix_merah'
    });
  }
}

module.exports = StatisticsManager;