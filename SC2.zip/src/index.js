require('dotenv').config();
const { Telegraf } = require('telegraf');
const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const compression = require('compression');
const helmet = require('helmet');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

// Import core services
const DatabaseService = require('./services/database/DatabaseService');
const LoggerService = require('./services/logs/LoggerService');
const SecurityService = require('./services/security/SecurityService');
const QueueService = require('./services/queue/QueueService');
const ConfigService = require('./configs/ConfigService');

// Import middleware
const { authMiddleware } = require('./middleware/authMiddleware');
const { rateLimitMiddleware } = require('./middleware/rateLimitMiddleware');
const { maintenanceMiddleware } = require('./middleware/maintenanceMiddleware');
const { loggingMiddleware } = require('./middleware/loggingMiddleware');

// Import handlers
const commandHandler = require('./handlers/commandHandler');
const messageHandler = require('./handlers/messageHandler');
const callbackHandler = require('./handlers/callbackHandler');

// Initialize logger
const logger = new LoggerService();

class QashvraBot {
  constructor() {
    this.bot = null;
    this.app = null;
    this.server = null;
    this.io = null;
    this.isRunning = false;
    this.startTime = null;
    
    // Service instances
    this.database = null;
    this.security = null;
    this.queue = null;
    this.config = null;
    
    this.initialize();
  }

  async initialize() {
    try {
      logger.info('🚀 Initializing Qashvra Fix Merah Pro...');
      
      // Initialize services
      await this.initializeServices();
      
      // Initialize Telegram Bot
      await this.initializeBot();
      
      // Initialize Express Server
      await this.initializeServer();
      
      // Initialize Socket.IO
      await this.initializeSocketIO();
      
      // Load configurations
      await this.loadConfigurations();
      
      // Start services
      await this.startServices();
      
      // Setup graceful shutdown
      this.setupGracefulShutdown();
      
      this.startTime = Date.now();
      this.isRunning = true;
      
      logger.info('✅ Qashvra Fix Merah Pro is ready!');
      this.printStartupInfo();
      
    } catch (error) {
      logger.error('❌ Failed to initialize bot:', error);
      process.exit(1);
    }
  }

  async initializeServices() {
    // Initialize Database
    this.database = new DatabaseService();
    await this.database.initialize();
    
    // Initialize Security
    this.security = new SecurityService();
    await this.security.initialize();
    
    // Initialize Queue
    this.queue = new QueueService();
    await this.queue.initialize();
    
    // Initialize Config
    this.config = new ConfigService();
    await this.config.initialize();
    
    logger.info('✅ Core services initialized');
  }

  async initializeBot() {
    const token = process.env.BOT_TOKEN;
    
    if (!token || token === 'example') {
      throw new Error('Bot token is not configured!');
    }

    this.bot = new Telegraf(token, {
      telegram: {
        apiRoot: 'https://api.telegram.org',
        timeout: 30000
      }
    });

    // Apply middleware
    this.bot.use(loggingMiddleware);
    this.bot.use(maintenanceMiddleware);
    this.bot.use(rateLimitMiddleware);
    this.bot.use(authMiddleware);

    // Setup handlers
    this.setupHandlers();
    
    // Setup error handler
    this.bot.catch((err, ctx) => {
      logger.error('Bot error:', err);
      this.handleBotError(ctx, err);
    });

    logger.info('✅ Telegram Bot initialized');
  }

  setupHandlers() {
    // Command handlers
    this.bot.start(commandHandler.handleStart);
    this.bot.command('owner', commandHandler.handleOwner);
    this.bot.command('admin', commandHandler.handleAdmin);
    this.bot.command('broadcast', commandHandler.handleBroadcast);
    this.bot.command('backup', commandHandler.handleBackup);
    this.bot.command('stats', commandHandler.handleStats);
    
    // Message handlers
    this.bot.hears(/^\+?\d{10,15}$/, messageHandler.handlePhoneNumber);
    this.bot.hears(/\/start referral_(\d+)/, messageHandler.handleReferral);
    
    // Callback query handlers
    this.bot.action(/.*/, callbackHandler.handleCallback);
    
    // Generic message handler
    this.bot.on('message', messageHandler.handleMessage);
    this.bot.on('edited_message', messageHandler.handleEditedMessage);
    this.bot.on('channel_post', messageHandler.handleChannelPost);
    
    // Member events
    this.bot.on('new_chat_members', messageHandler.handleNewMembers);
    this.bot.on('left_chat_member', messageHandler.handleLeftMember);
    
    logger.info('✅ Handlers setup completed');
  }

  async initializeServer() {
    this.app = express();
    this.server = http.createServer(this.app);
    
    // Apply middleware
    this.app.use(helmet());
    this.app.use(compression());
    this.app.use(cors());
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    
    // Serve static files
    this.app.use('/assets', express.static(path.join(__dirname, 'assets')));
    
    // API Routes
    this.setupAPIRoutes();
    
    // Webhook route
    this.app.use(this.bot.webhookCallback('/webhook'));
    
    // Health check endpoint
    this.app.get('/health', (req, res) => {
      res.json({
        status: 'ok',
        uptime: process.uptime(),
        timestamp: Date.now(),
        bot_uptime: this.startTime ? Date.now() - this.startTime : 0
      });
    });
    
    const PORT = process.env.PORT || 3000;
    this.server.listen(PORT, process.env.HOST || '0.0.0.0', () => {
      logger.info(`✅ Express server running on port ${PORT}`);
    });
  }

  setupAPIRoutes() {
    const apiRouter = express.Router();
    
    // Stats API
    apiRouter.get('/stats', async (req, res) => {
      const stats = await this.getRealtimeStats();
      res.json(stats);
    });
    
    // Webhook for payment notifications
    apiRouter.post('/webhook/payment', async (req, res) => {
      await this.handlePaymentWebhook(req.body);
      res.json({ status: 'ok' });
    });
    
    this.app.use('/api', apiRouter);
  }

  async initializeSocketIO() {
    this.io = socketIO(this.server, {
      cors: {
        origin: '*',
        methods: ['GET', 'POST']
      }
    });
    
    this.io.on('connection', (socket) => {
      logger.info('New client connected:', socket.id);
      
      socket.on('subscribe_stats', () => {
        socket.join('stats_room');
        this.emitStats();
      });
      
      socket.on('disconnect', () => {
        logger.info('Client disconnected:', socket.id);
      });
    });
    
    // Periodic stats emission
    setInterval(() => {
      this.emitStats();
    }, 5000);
    
    logger.info('✅ Socket.IO initialized');
  }

  async emitStats() {
    if (this.io) {
      const stats = await this.getRealtimeStats();
      this.io.to('stats_room').emit('stats_update', stats);
    }
  }

  async getRealtimeStats() {
    try {
      const stats = {
        total_users: this.database.getTotalUsers(),
        online_users: 0,
        active_smtp: this.database.getActiveSMTPCount(),
        total_smtp: this.database.getTotalSMTPCount(),
        total_fixes: this.database.getTotalFixes(),
        success_rate: this.database.getSuccessRate(),
        queue_size: this.queue.getQueueSize(),
        cpu_usage: process.cpuUsage(),
        memory_usage: process.memoryUsage(),
        bot_uptime: this.startTime ? Date.now() - this.startTime : 0
      };
      return stats;
    } catch (error) {
      logger.error('Error getting stats:', error);
      return {};
    }
  }

  async loadConfigurations() {
    // Load and validate all configurations
    await this.config.loadAll();
    logger.info('✅ Configurations loaded');
  }

  async startServices() {
    // Start queue processor
    await this.queue.startProcessing();
    
    // Start SMTP health checker
    const { SMTPHealthChecker } = require('./services/smtp/SMTPHealthChecker');
    this.smtpHealthChecker = new SMTPHealthChecker();
    this.smtpHealthChecker.start();
    
    // Start auto backup
    const { AutoBackupService } = require('./services/backup/AutoBackupService');
    this.autoBackup = new AutoBackupService();
    this.autoBackup.start();
    
    // Start payment checker
    const { PaymentCheckerService } = require('./services/payment/PaymentCheckerService');
    this.paymentChecker = new PaymentCheckerService();
    this.paymentChecker.start();
    
    logger.info('✅ Background services started');
  }

  handleBotError(ctx, error) {
    const errorMessage = '❌ Maaf, terjadi kesalahan. Silakan coba lagi nanti.';
    
    try {
      if (ctx.chat && ctx.chat.id) {
        ctx.reply(errorMessage).catch(() => {});
      }
    } catch (e) {
      // Silently handle reply errors
    }
    
    // Log error to file
    logger.error('Bot Error:', {
      error: error.message,
      stack: error.stack,
      chat_id: ctx.chat?.id,
      user_id: ctx.from?.id
    });
    
    // Notify owner if critical
    if (error.message.includes('CRITICAL')) {
      this.notifyOwner(`🚨 Critical Error: ${error.message}`);
    }
  }

  async notifyOwner(message) {
    try {
      const ownerId = process.env.OWNER_ID;
      if (ownerId && this.bot) {
        await this.bot.telegram.sendMessage(ownerId, message);
      }
    } catch (error) {
      logger.error('Failed to notify owner:', error);
    }
  }

  setupGracefulShutdown() {
    const shutdown = async (signal) => {
      logger.info(`\n${signal} received. Shutting down gracefully...`);
      
      this.isRunning = false;
      
      // Stop background services
      if (this.smtpHealthChecker) this.smtpHealthChecker.stop();
      if (this.autoBackup) this.autoBackup.stop();
      if (this.paymentChecker) this.paymentChecker.stop();
      
      // Stop queue
      await this.queue.stop();
      
      // Close database
      await this.database.close();
      
      // Stop bot
      if (this.bot) this.bot.stop(signal);
      
      // Close server
      if (this.server) {
        this.server.close(() => {
          logger.info('HTTP server closed');
          process.exit(0);
        });
      } else {
        process.exit(0);
      }
      
      // Force exit after timeout
      setTimeout(() => {
        logger.error('Forced shutdown after timeout');
        process.exit(1);
      }, 10000);
    };
    
    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('uncaughtException', (error) => {
      logger.error('Uncaught Exception:', error);
      shutdown('UNCAUGHT_EXCEPTION');
    });
    process.on('unhandledRejection', (reason, promise) => {
      logger.error('Unhandled Rejection:', reason);
    });
  }

  printStartupInfo() {
    console.log('\n' + '='.repeat(50));
    console.log('🔴 QASHVRA FIX MERAH PRO');
    console.log('='.repeat(50));
    console.log(`📅 Started: ${new Date().toLocaleString()}`);
    console.log(`⚡ Environment: ${process.env.NODE_ENV}`);
    console.log(`🤖 Bot: ${process.env.BOT_USERNAME}`);
    console.log(`👑 Owner: ${process.env.OWNER_USERNAME}`);
    console.log(`🚀 Version: 1.0.0`);
    console.log('='.repeat(50) + '\n');
  }
}

// Start the bot
const qashvraBot = new QashvraBot();

// Export for use in other modules
module.exports = qashvraBot;