class AdminPanel {
  async showAdminPanel(ctx) {
    const message = 
      `🛡️ *ADMIN PANEL*\n\n` +
      `Pilih menu admin:`;

    const keyboard = {
      inline_keyboard: [
        [{ text: '👥 Kelola User', callback_data: 'admin_users' }],
        [{ text: '📊 Statistik', callback_data: 'admin_stats' }],
        [{ text: '📢 Broadcast', callback_data: 'admin_broadcast' }],
        [{ text: '📝 Template', callback_data: 'admin_templates' }],
        [{ text: '✅ Testimoni', callback_data: 'admin_testimoni' }],
        [{ text: '🔙 Kembali', callback_data: 'menu_back' }]
      ]
    };

    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    }).catch(() => {
      ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    });
  }
}

module.exports = new AdminPanel();