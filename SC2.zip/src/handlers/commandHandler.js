const DatabaseService = require('../services/database/DatabaseService');
const PermissionService = require('../services/permissions/PermissionService');
const ConfigService = require('../configs/ConfigService');

const db = new DatabaseService();
const permissionService = new PermissionService();
const config = new ConfigService();

class CommandHandler {
  async handleStart(ctx) {
    try {
      const user = ctx.state.user;
      const userId = ctx.state.userId;
      
      // Check if coming from referral
      const startPayload = ctx.message?.text?.split(' ')[1];
      if (startPayload && startPayload.startsWith('referral_')) {
        return this.handleReferralStart(ctx, startPayload);
      }
      
      // Show loading effect
      const loadingMessage = await ctx.reply('🔴 Loading...');
      await this.updateLoadingMessage(ctx, loadingMessage.message_id);
      
      // Get statistics
      const stats = await this.getGlobalStats();
      const userStats = await this.getUserStats(userId);
      
      // Build welcome message
      const welcomeMessage = this.buildWelcomeMessage(user, userStats, stats);
      
      // Delete loading message
      await ctx.deleteMessage(loadingMessage.message_id).catch(() => {});
      
      // Send welcome message with inline keyboard
      await ctx.replyWithPhoto(
        { source: './src/assets/banners/welcome-banner.jpg' },
        {
          caption: welcomeMessage,
          parse_mode: 'Markdown',
          reply_markup: this.getMainMenuKeyboard(user.role)
        }
      );
      
    } catch (error) {
      console.error('Start handler error:', error);
      ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
    }
  }

  async updateLoadingMessage(ctx, messageId, progress = 0) {
    const loadingChars = ['▱', '▰'];
    let currentProgress = progress;
    
    const interval = setInterval(async () => {
      currentProgress += 20;
      
      if (currentProgress > 100) {
        clearInterval(interval);
        return;
      }
      
      const bar = '▰'.repeat(Math.floor(currentProgress / 10)) + 
                  '▱'.repeat(10 - Math.floor(currentProgress / 10));
      
      const message = `🔴 *QASHVRA FIX MERAH PRO*\n\n` +
                      `⏳ Loading... ${currentProgress}%\n` +
                      `[${bar}]`;
      
      await ctx.telegram.editMessageText(
        ctx.chat.id,
        messageId,
        null,
        message,
        { parse_mode: 'Markdown' }
      ).catch(() => {});
    }, 300);
  }

  buildWelcomeMessage(user, userStats, globalStats) {
    const roleEmoji = {
      OWNER: '👑',
      DEVELOPER: '⚙️',
      PARTNER: '🤝',
      ADMIN: '🛡️',
      MODERATOR: '👮',
      RESELLER: '💼',
      VIP: '⭐',
      VVIP: '💎',
      FREE_USER: '👤'
    };

    const statusText = {
      OWNER: 'OWNER',
      DEVELOPER: 'DEVELOPER',
      PARTNER: 'PARTNER',
      ADMIN: 'ADMIN',
      MODERATOR: 'MODERATOR',
      RESELLER: 'RESELLER',
      VIP: 'VIP USER',
      VVIP: 'VVIP USER',
      FREE_USER: 'FREE USER'
    };

    const userRole = user.role || 'FREE_USER';
    const maskedName = this.maskName(user.first_name);

    return `🔴 *WELCOME TO QASHVRA FIX MERAH PRO*\n\n` +
           `👤 *INFORMASI AKUN*\n` +
           `├ 👤 Nama: ${maskedName}\n` +
           `├ 🆔 Akun ID: ${user.user_id}\n` +
           `├ 👑 Status: ${roleEmoji[userRole]} ${statusText[userRole]}\n\n` +
           `📊 *STATISTIK PRIBADI*\n` +
           `├ 🛠️ Total Fix: ${userStats.total_fix || 0}\n` +
           `├ 🎯 Berhasil: ${userStats.success_fix || 0}\n` +
           `└ 📈 Win Rate: ${userStats.win_rate || 0}%\n\n` +
           `🌍 *STATISTIK GLOBAL*\n` +
           `├ 📧 Sender Aktif: ${globalStats.active_smtp}/${globalStats.total_smtp}\n` +
           `├ 👥 Pengguna: ${globalStats.total_users}\n` +
           `├ 🛠️ Total Fix: ${globalStats.total_fixes}\n` +
           `└ 📈 Win Rate Global: ${globalStats.global_win_rate}%`;
  }

  getMainMenuKeyboard(role) {
    const inlineKeyboard = [];

    // Row 1 - Main Features
    const row1 = [];
    row1.push({ text: '🛠️ Fix Merah', callback_data: 'menu_fix_merah' });
    row1.push({ text: '👑 VIP / VVIP', callback_data: 'menu_vip_vvip' });
    inlineKeyboard.push(row1);

    // Row 2 - Secondary Features
    const row2 = [];
    row2.push({ text: '🧧 Referal', callback_data: 'menu_referral' });
    row2.push({ text: '📜 Riwayat', callback_data: 'menu_history' });
    inlineKeyboard.push(row2);

    // Row 3 - Statistics
    const row3 = [];
    row3.push({ text: '🏆 Top Global', callback_data: 'menu_leaderboard' });
    row3.push({ text: '✅ Testimoni', callback_data: 'menu_testimoni' });
    inlineKeyboard.push(row3);

    // Row 4 - Settings
    const row4 = [];
    row4.push({ text: '⚙️ Settings', callback_data: 'menu_settings' });
    row4.push({ text: '👤 Profile', callback_data: 'menu_profile' });
    inlineKeyboard.push(row4);

    // Row 5 - Admin/Owner menu
    if (['OWNER', 'DEVELOPER', 'PARTNER', 'ADMIN'].includes(role)) {
      const row5 = [];
      row5.push({ text: '🔧 Admin Panel', callback_data: 'menu_admin' });
      if (role === 'OWNER' || role === 'DEVELOPER') {
        row5.push({ text: '👑 Owner Panel', callback_data: 'menu_owner' });
      }
      inlineKeyboard.push(row5);
    }

    return {
      inline_keyboard: inlineKeyboard
    };
  }

  async handleReferralStart(ctx, payload) {
    const referrerId = parseInt(payload.split('_')[1]);
    const newUserId = ctx.from.id;

    // Check if not self-referral
    if (referrerId !== newUserId) {
      const ReferralService = require('../services/referral/ReferralService');
      const referralService = new ReferralService();
      await referralService.processReferral(referrerId, newUserId);
    }

    // Continue with normal start
    return this.handleStart(ctx);
  }

  async handleOwner(ctx) {
    if (!ctx.state.hasPermission('owner_panel')) {
      return ctx.reply('⛔ Akses ditolak.');
    }

    const ownerPanel = require('../owner/OwnerPanel');
    return ownerPanel.showOwnerPanel(ctx);
  }

  async handleAdmin(ctx) {
    if (!ctx.state.hasPermission('manage_users')) {
      return ctx.reply('⛔ Akses ditolak.');
    }

    const adminPanel = require('../admin/AdminPanel');
    return adminPanel.showAdminPanel(ctx);
  }

  async handleBroadcast(ctx) {
    if (!ctx.state.hasPermission('broadcast')) {
      return ctx.reply('⛔ Akses ditolak.');
    }

    return ctx.reply(
      '📢 *Broadcast Mode*\n\n' +
      'Kirim pesan yang ingin dibroadcast.\n' +
      'Ketik /cancel untuk membatalkan.',
      { parse_mode: 'Markdown' }
    );
  }

  async handleBackup(ctx) {
    if (!ctx.state.hasPermission('backup')) {
      return ctx.reply('⛔ Akses ditolak.');
    }

    try {
      const loading = await ctx.reply('🔄 Membuat backup...');
      const backupDir = await db.createBackup();
      
      await ctx.deleteMessage(loading.message_id);
      await ctx.reply(`✅ Backup berhasil dibuat!\n\n📁 Path: \`${backupDir}\``, {
        parse_mode: 'Markdown'
      });
    } catch (error) {
      ctx.reply('❌ Gagal membuat backup.');
    }
  }

  async handleStats(ctx) {
    const stats = await this.getGlobalStats();
    const message = 
      `📊 *STATISTIK BOT*\n\n` +
      `👥 Total Users: ${stats.total_users}\n` +
      `📧 SMTP Aktif: ${stats.active_smtp}/${stats.total_smtp}\n` +
      `🛠️ Total Fix: ${stats.total_fixes}\n` +
      `📈 Success Rate: ${stats.global_win_rate}%\n` +
      `⏱️ Uptime: ${this.getUptime()}`;
    
    ctx.reply(message, { parse_mode: 'Markdown' });
  }

  async getGlobalStats() {
    return {
      total_users: await db.getTotalUsers(),
      active_smtp: await db.getActiveSMTPCount(),
      total_smtp: await db.getTotalSMTPCount(),
      total_fixes: await db.getTotalFixes(),
      global_win_rate: await db.getSuccessRate().toFixed(1)
    };
  }

  async getUserStats(userId) {
    // Get user-specific stats from database
    return {
      total_fix: 0,
      success_fix: 0,
      win_rate: 0
    };
  }

  maskName(name) {
    if (name.length <= 3) return name;
    return name.slice(0, 3) + '*'.repeat(name.length - 3);
  }

  getUptime() {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    return `${hours}h ${minutes}m ${seconds}s`;
  }
}

module.exports = new CommandHandler();