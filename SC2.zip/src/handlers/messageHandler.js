class MessageHandler {
  async handlePhoneNumber(ctx) {
    const phone = ctx.message.text.trim();
    const userId = ctx.state.userId;
    const user = ctx.state.user;

    // Validate phone number
    const SecurityService = require('../services/security/SecurityService');
    const security = new SecurityService();
    
    if (!security.validatePhoneNumber(phone)) {
      return ctx.reply('❌ Format nomor tidak valid.\n\nContoh: +62812345678910');
    }

    // Check limits
    const ConfigService = require('../configs/ConfigService');
    const config = new ConfigService();
    const limits = config.getConfig('limits');
    const userLimit = limits[user.role.toLowerCase()] || limits.freeUser;

    // Check cooldown
    if (!security.checkSpam(userId, 'fix_merah', userLimit.cooldownMinutes * 60000, userLimit.dailyFixes)) {
      return ctx.reply(
        `⏳ *COOLDOWN*\n\n` +
        `Anda telah mencapai batas harian.\n` +
        `Batas: ${userLimit.dailyFixes} kali\n` +
        `Cooldown: ${userLimit.cooldownMinutes} menit\n\n` +
        `💎 Upgrade ke VIP untuk unlimited!`,
        { parse_mode: 'Markdown' }
      );
    }

    // Check duplicate
    if (security.isDuplicate(`fix_${userId}`, phone, 3600000)) {
      return ctx.reply('⚠️ Nomor ini sudah pernah dikirim. Silakan tunggu 1 jam.');
    }

    // Add to queue
    const QueueService = require('../services/queue/QueueService');
    const queue = new QueueService();
    
    const priority = this.getUserPriority(user.role);
    const queueItem = await queue.enqueue(priority, {
      type: 'fix_merah',
      phone,
      userId,
      template: await this.getRandomTemplate()
    });

    // Send processing message with loading effect
    const loadingMsg = await ctx.reply('🔄 Memproses... 0%');
    this.showProcessingEffect(ctx, loadingMsg.message_id, queueItem.id);

    // Reply with queue info
    await ctx.reply(
      `✅ *NOMOR DITERIMA*\n\n` +
      `📱 Nomor: \`${phone}\`\n` +
      `🆔 ID: \`${queueItem.id}\`\n` +
      `📊 Antrian: ${queue.getQueueSize()}\n` +
      `⏳ Status: Processing...\n\n` +
      `🤖 Powered by Qashvra Fix Merah Pro`,
      { parse_mode: 'Markdown' }
    );
  }

  async showProcessingEffect(ctx, messageId, queueId) {
    let progress = 0;
    
    const interval = setInterval(async () => {
      progress += Math.floor(Math.random() * 10) + 5;
      
      if (progress > 100) {
        clearInterval(interval);
        return;
      }
      
      const bar = '█'.repeat(Math.floor(progress / 10)) + 
                  '░'.repeat(10 - Math.floor(progress / 10));
      
      await ctx.telegram.editMessageText(
        ctx.chat.id,
        messageId,
        null,
        `🔄 *Processing...* ${progress}%\n[${bar}]\n\n🆔 \`${queueId}\``,
        { parse_mode: 'Markdown' }
      ).catch(() => {});
    }, 500);
  }

  getUserPriority(role) {
    const priorityMap = {
      OWNER: 'owner',
      VVIP: 'vvip',
      VIP: 'vip',
      FREE_USER: 'free'
    };
    return priorityMap[role] || 'free';
  }

  async getRandomTemplate() {
    const ConfigService = require('../configs/ConfigService');
    const config = new ConfigService();
    const templates = config.getTemplates().banding || [];
    const activeTemplates = templates.filter(t => t.active);
    
    if (activeTemplates.length > 0) {
      return activeTemplates[Math.floor(Math.random() * activeTemplates.length)];
    }
    
    return {
      subject: 'Banding Akun WhatsApp',
      body: 'Mohon untuk ditinjau kembali akun WhatsApp saya.'
    };
  }

  async handleReferral(ctx, match) {
    // Already handled in start command
  }

  async handleMessage(ctx) {
    // Handle general messages
    const text = ctx.message.text;
    
    if (text === '/start') return;
    
    // Default response
    ctx.reply(
      'Silakan gunakan menu yang tersedia atau kirim nomor telepon untuk Fix Merah.\n\n' +
      'Contoh: +62812345678910'
    );
  }

  async handleEditedMessage(ctx) {
    // Handle edited messages if needed
  }

  async handleChannelPost(ctx) {
    // Handle channel posts if needed
  }

  async handleNewMembers(ctx) {
    // Handle new members joining groups
  }

  async handleLeftMember(ctx) {
    // Handle members leaving groups
  }
}

module.exports = new MessageHandler();