const DatabaseService = require('../services/database/DatabaseService');
const ConfigService = require('../configs/ConfigService');

const db = new DatabaseService();
const config = new ConfigService();

class CallbackHandler {
  async handleCallback(ctx) {
    try {
      const callbackData = ctx.callbackQuery.data;
      const userId = ctx.state.userId;
      const user = ctx.state.user;

      // Answer callback query to remove loading state
      await ctx.answerCbQuery();

      // Route callback based on data
      if (callbackData.startsWith('menu_')) {
        return this.handleMenuCallback(ctx, callbackData);
      } else if (callbackData.startsWith('fix_')) {
        return this.handleFixCallback(ctx, callbackData);
      } else if (callbackData.startsWith('payment_')) {
        return this.handlePaymentCallback(ctx, callbackData);
      } else if (callbackData.startsWith('referral_')) {
        return this.handleReferralCallback(ctx, callbackData);
      } else if (callbackData.startsWith('settings_')) {
        return this.handleSettingsCallback(ctx, callbackData);
      } else if (callbackData.startsWith('admin_')) {
        return this.handleAdminCallback(ctx, callbackData);
      } else if (callbackData.startsWith('owner_')) {
        return this.handleOwnerCallback(ctx, callbackData);
      } else if (callbackData.startsWith('leaderboard_')) {
        return this.handleLeaderboardCallback(ctx, callbackData);
      }

      // Default response
      return ctx.reply('❌ Aksi tidak dikenali.');
      
    } catch (error) {
      console.error('Callback handler error:', error);
      ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.').catch(() => {});
    }
  }

  async handleMenuCallback(ctx, data) {
    const menuActions = {
      'menu_fix_merah': this.showFixMerahMenu,
      'menu_vip_vvip': this.showVipVvipMenu,
      'menu_referral': this.showReferralMenu,
      'menu_history': this.showHistoryMenu,
      'menu_leaderboard': this.showLeaderboardMenu,
      'menu_testimoni': this.showTestimoniMenu,
      'menu_settings': this.showSettingsMenu,
      'menu_profile': this.showProfileMenu,
      'menu_admin': this.showAdminMenu,
      'menu_owner': this.showOwnerMenu,
      'menu_back': this.showMainMenu
    };

    const action = menuActions[data];
    if (action) {
      return action.call(this, ctx);
    }

    return this.showMainMenu(ctx);
  }

  async showMainMenu(ctx) {
    const loadingEffect = await this.showLoadingEffect(ctx);
    
    const CommandHandler = require('./commandHandler');
    const handler = new CommandHandler();
    
    const user = ctx.state.user;
    const stats = await handler.getGlobalStats();
    const userStats = await handler.getUserStats(ctx.state.userId);
    
    const welcomeMessage = handler.buildWelcomeMessage(user, userStats, stats);
    const keyboard = handler.getMainMenuKeyboard(user.role);

    try {
      await ctx.editMessageCaption(welcomeMessage, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    } catch (error) {
      // If can't edit, send new message
      await ctx.reply(welcomeMessage, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    }
  }

  async showLoadingEffect(ctx) {
    const loadingMessage = await ctx.reply('⏳ Processing...');
    
    let progress = 0;
    const interval = setInterval(async () => {
      progress += 25;
      
      if (progress > 100) {
        clearInterval(interval);
        await ctx.deleteMessage(loadingMessage.message_id).catch(() => {});
        return;
      }
      
      const bar = '█'.repeat(Math.floor(progress / 10)) + 
                  '░'.repeat(10 - Math.floor(progress / 10));
      
      await ctx.telegram.editMessageText(
        ctx.chat.id,
        loadingMessage.message_id,
        null,
        `⏳ Processing... ${progress}%\n[${bar}]`
      ).catch(() => {});
    }, 200);

    return loadingMessage;
  }

  async showFixMerahMenu(ctx) {
    const user = ctx.state.user;
    const limits = config.getConfig('limits');
    const userLimit = limits[user.role.toLowerCase()] || limits.freeUser;

    const message = 
      `🛠️ *MENU INPUT FIX MERAH*\n\n` +
      `📌 *Gunakan fitur ini jika:*\n` +
      `🔸 Nomor terkena login tidak tersedia\n` +
      `🔸 Nomor harus sudah terdaftar di WA\n` +
      `🔸 Login berubah menjadi SMS\n` +
      `🔸 Verifikasi gagal terus menerus\n\n` +
      `├ 👑 Status: ${user.role}\n` +
      `├ 📊 Limit Harian: ${userLimit.dailyFixes} Kali\n` +
      `├ 📧 Sender Aktif: ${await db.getActiveSMTPCount()}/${await db.getTotalSMTPCount()}\n` +
      `└ 📦 Slot Terpakai: 0/${userLimit.concurrentFixes} (Sisa: ${userLimit.concurrentFixes})\n\n` +
      `📥 *Kirim nomor telepon* (1 nomor per baris)\n\n` +
      `Contoh:\n` +
      `\`+62812345678910\``;

    const keyboard = {
      inline_keyboard: [
        [{ text: '🔙 Kembali ke Menu', callback_data: 'menu_back' }]
      ]
    };

    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  async showVipVvipMenu(ctx) {
    const packages = config.getConfig('payment')?.packages || {};

    const message = 
      `👑 *AKSES PREMIUM*\n\n` +
      `✨ *VIP:*\n` +
      `├ Unlimited Limit\n` +
      `├ 5 Nomor Sekaligus\n` +
      `└ Priority Queue\n\n` +
      `🌟 *VVIP:*\n` +
      `├ Unlimited Limit\n` +
      `├ 25 Nomor Sekaligus\n` +
      `└ Highest Priority\n\n` +
      `📦 *PILIH PAKET:*`;

    const keyboard = {
      inline_keyboard: [
        [{ text: `⭐ VIP 1 Hari - Rp1.007`, callback_data: 'payment_vip_1day' }],
        [{ text: `⭐ VIP 7 Hari - Rp5.007`, callback_data: 'payment_vip_7day' }],
        [{ text: `⭐ VIP 30 Hari - Rp15.007`, callback_data: 'payment_vip_30day' }],
        [{ text: `💎 VVIP 30 Hari - Rp30.007`, callback_data: 'payment_vvip_30day' }],
        [{ text: '🔙 Kembali ke Menu', callback_data: 'menu_back' }]
      ]
    };

    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  async showReferralMenu(ctx) {
    const userId = ctx.state.userId;
    const referralLink = `https://t.me/${process.env.BOT_USERNAME.replace('@', '')}?start=referral_${userId}`;
    const referralCount = await db.getReferralCount(userId);

    const message = 
      `🧧 *MENU REFERRAL*\n\n` +
      `📌 *Cara Kerja:*\n` +
      `1. Share referral kamu\n` +
      `2. User join bot melalui link\n` +
      `3. Dapat koin reward\n` +
      `4. Tukar VIP\n\n` +
      `🔗 *Referral Link:*\n` +
      `\`${referralLink}\`\n\n` +
      `📊 *Statistik Referral:*\n` +
      `├ Total Referral: ${referralCount}\n` +
      `└ Reward: ${referralCount * 50} Koin`;

    const keyboard = {
      inline_keyboard: [
        [{ text: '📤 Share Referral', switch_inline_query: `referral_${userId}` }],
        [{ text: '🎁 Redeem VIP (500 Koin)', callback_data: 'referral_redeem' }],
        [{ text: '🔙 Kembali ke Menu', callback_data: 'menu_back' }]
      ]
    };

    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  async showHistoryMenu(ctx) {
    const userId = ctx.state.userId;
    // Get user history from database
    const history = []; // Placeholder

    const message = 
      `📜 *RIWAYAT FIX MERAH*\n\n` +
      (history.length > 0 
        ? history.map((h, i) => 
            `${i + 1}. 📱 ${h.phone}\n` +
            `   Status: ${h.status}\n` +
            `   📅 ${new Date(h.timestamp).toLocaleString()}`
          ).join('\n\n')
        : 'Belum ada riwayat.\n\nKirim nomor untuk memulai fix.');

    const keyboard = {
      inline_keyboard: [
        [{ text: '🔄 Refresh', callback_data: 'history_refresh' }],
        [{ text: '🔙 Kembali ke Menu', callback_data: 'menu_back' }]
      ]
    };

    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  async showLeaderboardMenu(ctx) {
    const message = 
      `🏆 *TOP GLOBAL LEADERBOARD*\n\n` +
      `🥇 User1*** - 1,234 fixes\n` +
      `🥈 User2*** - 1,100 fixes\n` +
      `🥉 User3*** - 987 fixes\n\n` +
      `🌍 *TOP COUNTRIES*\n` +
      `🇮🇩 Indonesia - 50,000 fixes\n` +
      `🇺🇸 USA - 25,000 fixes`;

    const keyboard = {
      inline_keyboard: [
        [{ text: '🔄 Refresh', callback_data: 'leaderboard_refresh' }],
        [{ text: '🔙 Kembali ke Menu', callback_data: 'menu_back' }]
      ]
    };

    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  async showTestimoniMenu(ctx) {
    const message = 
      `✅ *TESTIMONI TERBARU*\n\n` +
      `🔴 *PROSES FIX MERAH BERHASIL*\n` +
      `├ 🆔 ID: MADS-2382666512257698\n` +
      `├ 📱 +6288****8184\n` +
      `└ Status: ✅ SUKSES\n\n` +
      `🤖 Powered by Qashvra Fix Merah Pro`;

    const keyboard = {
      inline_keyboard: [
        [{ text: '🔄 Refresh', callback_data: 'testimoni_refresh' }],
        [{ text: '📢 Join Channel', url: 'https://t.me/FixMerahQashvra' }],
        [{ text: '🔙 Kembali ke Menu', callback_data: 'menu_back' }]
      ]
    };

    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  async showSettingsMenu(ctx) {
    const message = 
      `⚙️ *SETTINGS*\n\n` +
      `Pilih pengaturan yang ingin diubah:`;

    const keyboard = {
      inline_keyboard: [
        [{ text: '🌐 Bahasa', callback_data: 'settings_language' }],
        [{ text: '🔔 Notifikasi', callback_data: 'settings_notification' }],
        [{ text: '🎨 Tema', callback_data: 'settings_theme' }],
        [{ text: '🔙 Kembali ke Menu', callback_data: 'menu_back' }]
      ]
    };

    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  async showProfileMenu(ctx) {
    const user = ctx.state.user;

    const message = 
      `👤 *PROFILE*\n\n` +
      `├ Nama: ${user.first_name}\n` +
      `├ ID: \`${user.user_id}\`\n` +
      `├ Status: ${user.role}\n` +
      `├ Join: ${new Date(user.joined_at).toLocaleDateString()}\n` +
      `└ Terakhir Aktif: ${new Date(user.last_active).toLocaleString()}`;

    const keyboard = {
      inline_keyboard: [
        [{ text: '🔙 Kembali ke Menu', callback_data: 'menu_back' }]
      ]
    };

    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  async showAdminMenu(ctx) {
    const AdminPanel = require('../admin/AdminPanel');
    return AdminPanel.showAdminPanel(ctx);
  }

  async showOwnerMenu(ctx) {
    const OwnerPanel = require('../owner/OwnerPanel');
    return OwnerPanel.showOwnerPanel(ctx);
  }

  async handlePaymentCallback(ctx, data) {
    const PaymentHandler = require('../services/payment/PaymentHandler');
    const handler = new PaymentHandler();
    
    if (data.startsWith('payment_')) {
      const packageType = data.replace('payment_', '');
      return handler.createPayment(ctx, packageType);
    }
  }

  async handleFixCallback(ctx, data) {
    // Handle fix-related callbacks
    console.log('Fix callback:', data);
  }

  async handleReferralCallback(ctx, data) {
    const ReferralService = require('../services/referral/ReferralService');
    const referralService = new ReferralService();
    
    if (data === 'referral_redeem') {
      return referralService.redeemReward(ctx);
    }
  }

  async handleSettingsCallback(ctx, data) {
    console.log('Settings callback:', data);
    // Handle settings changes
  }

  async handleAdminCallback(ctx, data) {
    console.log('Admin callback:', data);
    // Handle admin actions
  }

  async handleOwnerCallback(ctx, data) {
    console.log('Owner callback:', data);
    // Handle owner actions
  }

  async handleLeaderboardCallback(ctx, data) {
    if (data === 'leaderboard_refresh') {
      return this.showLeaderboardMenu(ctx);
    }
  }
}

module.exports = new CallbackHandler();