class OwnerPanel {
  async showOwnerPanel(ctx) {
    const os = require('os');
    const uptime = process.uptime();
    
    const dashboard = 
      `👑 *OWNER PANEL - QASHVRA FIX MERAH PRO*\n\n` +
      `📊 *DASHBOARD*\n` +
      `├ 👥 Total Users: ${await this.getTotalUsers()}\n` +
      `├ 🟢 Online: ${await this.getOnlineUsers()}\n` +
      `├ 📧 SMTP Aktif: ${await this.getActiveSMTP()}\n` +
      `├ 📧 SMTP Gagal: ${await this.getFailedSMTP()}\n` +
      `├ 💰 Total Payment: ${await this.getTotalPayments()}\n` +
      `├ 📦 Queue: ${await this.getQueueSize()}\n` +
      `├ 💻 CPU: ${os.loadavg()[0].toFixed(2)}%\n` +
      `├ 🧠 RAM: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB\n` +
      `└ ⏱️ Uptime: ${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m\n\n` +
      `🔧 *TOOLS*\n` +
      `Pilih tools di bawah ini:`;

    const keyboard = {
      inline_keyboard: [
        [{ text: '🔄 Restart Bot', callback_data: 'owner_restart' }],
        [{ text: '🔧 Maintenance Mode', callback_data: 'owner_maintenance' }],
        [{ text: '💾 Backup Database', callback_data: 'owner_backup' }],
        [{ text: '📥 Restore Database', callback_data: 'owner_restore' }],
        [{ text: '🔄 Reload Config', callback_data: 'owner_reload' }],
        [{ text: '🗑️ Clear Logs', callback_data: 'owner_clearlogs' }],
        [{ text: '📊 Clear Queue', callback_data: 'owner_clearqueue' }],
        [{ text: '🆘 Emergency Stop', callback_data: 'owner_emergency' }],
        [{ text: '📢 Broadcast', callback_data: 'owner_broadcast' }],
        [{ text: '👥 Manage Users', callback_data: 'owner_users' }],
        [{ text: '📧 Manage SMTP', callback_data: 'owner_smtp' }],
        [{ text: '💰 Manage Prices', callback_data: 'owner_prices' }],
        [{ text: '🔙 Kembali', callback_data: 'menu_back' }]
      ]
    };

    await ctx.editMessageCaption(dashboard, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    }).catch(() => {
      ctx.reply(dashboard, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    });
  }

  async getTotalUsers() {
    const DatabaseService = require('../services/database/DatabaseService');
    const db = new DatabaseService();
    return await db.getTotalUsers();
  }

  async getOnlineUsers() {
    // Implement online user tracking
    return 0;
  }

  async getActiveSMTP() {
    const DatabaseService = require('../services/database/DatabaseService');
    const db = new DatabaseService();
    return await db.getActiveSMTPCount();
  }

  async getFailedSMTP() {
    const DatabaseService = require('../services/database/DatabaseService');
    const db = new DatabaseService();
    const smtps = await db.getSMTPConfigs();
    return smtps.filter(s => s.status === 'failed').length;
  }

  async getTotalPayments() {
    const DatabaseService = require('../services/database/DatabaseService');
    const db = new DatabaseService();
    const payments = await db.getPayments();
    return payments.filter(p => p.status === 'paid')
      .reduce((sum, p) => sum + p.amount, 0);
  }

  async getQueueSize() {
    const QueueService = require('../services/queue/QueueService');
    const queue = new QueueService();
    return queue.getQueueSize();
  }
}

module.exports = new OwnerPanel();