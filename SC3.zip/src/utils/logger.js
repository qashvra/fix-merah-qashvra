/**
 * QASHVRA FIX MERAH PRO - Logger Utility
 * Professional logging system with colors and file rotation
 */

import pino from 'pino';
import chalk from 'chalk';
import fs from 'fs-extra';
import path from 'path';

class Logger {
    constructor() {
        this.logDir = path.join(process.cwd(), 'logs');
        this.ensureLogDirectory();
        
        this.logger = this.createLogger();
    }

    /**
     * Ensure log directory exists
     */
    ensureLogDirectory() {
        fs.ensureDirSync(this.logDir);
        fs.ensureDirSync(path.join(this.logDir, 'daily'));
        fs.ensureDirSync(path.join(this.logDir, 'errors'));
        fs.ensureDirSync(path.join(this.logDir, 'access'));
    }

    /**
     * Create pino logger instance
     * @returns {Object} Logger instance
     */
    createLogger() {
        const streams = [
            // Console output with colors
            {
                stream: pino.transport({
                    target: 'pino-pretty',
                    options: {
                        colorize: true,
                        translateTime: 'SYS:yyyy-mm-dd HH:MM:ss',
                        ignore: 'pid,hostname',
                        messageFormat: '{msg}',
                        levelFirst: true
                    }
                })
            }
        ];

        // File output for production
        if (process.env.NODE_ENV === 'production') {
            streams.push(
                {
                    level: 'info',
                    stream: fs.createWriteStream(
                        path.join(this.logDir, 'daily', `${this.getDateString()}.log`),
                        { flags: 'a' }
                    )
                },
                {
                    level: 'error',
                    stream: fs.createWriteStream(
                        path.join(this.logDir, 'errors', `${this.getDateString()}-error.log`),
                        { flags: 'a' }
                    )
                }
            );
        }

        return pino({
            level: process.env.LOG_LEVEL || 'info',
            timestamp: pino.stdTimeFunctions.isoTime,
            formatters: {
                level: (label) => {
                    return { level: label.toUpperCase() };
                }
            }
        }, pino.multistream(streams));
    }

    /**
     * Get current date string
     * @returns {string} Date string
     */
    getDateString() {
        return new Date().toISOString().split('T')[0];
    }

    /**
     * Log info message
     * @param {string} message - Log message
     * @param {*} data - Additional data
     */
    info(message, data = null) {
        const formattedMessage = this.formatMessage('INFO', message);
        console.log(chalk.blue(formattedMessage));
        
        if (data) {
            this.logger.info({ data }, message);
        } else {
            this.logger.info(message);
        }
    }

    /**
     * Log success message
     * @param {string} message - Log message
     * @param {*} data - Additional data
     */
    success(message, data = null) {
        const formattedMessage = this.formatMessage('SUCCESS', message);
        console.log(chalk.green(formattedMessage));
        
        if (data) {
            this.logger.info({ data, type: 'success' }, message);
        } else {
            this.logger.info(message);
        }
    }

    /**
     * Log warning message
     * @param {string} message - Log message
     * @param {*} data - Additional data
     */
    warn(message, data = null) {
        const formattedMessage = this.formatMessage('WARN', message);
        console.log(chalk.yellow(formattedMessage));
        
        if (data) {
            this.logger.warn({ data }, message);
        } else {
            this.logger.warn(message);
        }
    }

    /**
     * Log error message
     * @param {string} message - Log message
     * @param {*} error - Error object or data
     */
    error(message, error = null) {
        const formattedMessage = this.formatMessage('ERROR', message);
        console.log(chalk.red(formattedMessage));
        
        if (error) {
            if (error instanceof Error) {
                this.logger.error({
                    error: {
                        message: error.message,
                        stack: error.stack,
                        name: error.name
                    }
                }, message);
            } else {
                this.logger.error({ error }, message);
            }
        } else {
            this.logger.error(message);
        }
    }

    /**
     * Log debug message
     * @param {string} message - Log message
     * @param {*} data - Additional data
     */
    debug(message, data = null) {
        if (process.env.NODE_ENV !== 'production') {
            const formattedMessage = this.formatMessage('DEBUG', message);
            console.log(chalk.gray(formattedMessage));
            
            if (data) {
                this.logger.debug({ data }, message);
            } else {
                this.logger.debug(message);
            }
        }
    }

    /**
     * Log bot event
     * @param {string} event - Event type
     * @param {*} data - Event data
     */
    botEvent(event, data = null) {
        const formattedMessage = this.formatMessage('BOT', `${event} event triggered`);
        console.log(chalk.cyan(formattedMessage));
        
        this.logger.info({
            type: 'bot_event',
            event,
            data
        }, event);
    }

    /**
     * Log user action
     * @param {number} userId - User ID
     * @param {string} action - Action performed
     * @param {*} data - Additional data
     */
    userAction(userId, action, data = null) {
        const formattedMessage = this.formatMessage('USER', `User ${userId}: ${action}`);
        console.log(chalk.magenta(formattedMessage));
        
        this.logger.info({
            type: 'user_action',
            userId,
            action,
            data
        }, `User ${userId}: ${action}`);
    }

    /**
     * Log payment event
     * @param {string} event - Payment event
     * @param {*} data - Payment data
     */
    payment(event, data = null) {
        const formattedMessage = this.formatMessage('PAYMENT', event);
        console.log(chalk.greenBright(formattedMessage));
        
        this.logger.info({
            type: 'payment',
            event,
            data
        }, event);
    }

    /**
     * Log SMTP activity
     * @param {string} action - SMTP action
     * @param {*} data - SMTP data
     */
    smtp(action, data = null) {
        const formattedMessage = this.formatMessage('SMTP', action);
        console.log(chalk.yellowBright(formattedMessage));
        
        this.logger.info({
            type: 'smtp',
            action,
            data
        }, action);
    }

    /**
     * Log system event
     * @param {string} event - System event
     * @param {*} data - Event data
     */
    system(event, data = null) {
        const formattedMessage = this.formatMessage('SYSTEM', event);
        console.log(chalk.blueBright(formattedMessage));
        
        this.logger.info({
            type: 'system',
            event,
            data
        }, event);
    }

    /**
     * Format log message with timestamp and level
     * @param {string} level - Log level
     * @param {string} message - Log message
     * @returns {string} Formatted message
     */
    formatMessage(level, message) {
        const timestamp = new Date().toLocaleTimeString('id-ID', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        
        return `[${timestamp}] [${level}] ${message}`;
    }

    /**
     * Create log divider
     */
    divider() {
        const divider = '='.repeat(80);
        console.log(chalk.gray(divider));
        this.logger.info(divider);
    }

    /**
     * Log startup banner
     */
    startupBanner() {
        console.log('');
        console.log(chalk.red.bold('╔══════════════════════════════════════════════════════╗'));
        console.log(chalk.red.bold('║           QASHVRA FIX MERAH PRO v1.0.0              ║'));
        console.log(chalk.red.bold('║     Professional Telegram Bot Automation System     ║'));
        console.log(chalk.red.bold('╚══════════════════════════════════════════════════════╝'));
        console.log('');
    }

    /**
     * Log memory usage
     */
    memoryUsage() {
        const used = process.memoryUsage();
        const format = (bytes) => `${(bytes / 1024 / 1024).toFixed(2)} MB`;
        
        this.debug('Memory Usage:', {
            heapTotal: format(used.heapTotal),
            heapUsed: format(used.heapUsed),
            rss: format(used.rss),
            external: format(used.external)
        });
    }

    /**
     * Clean old logs
     * @param {number} daysToKeep - Days to keep logs
     */
    async cleanOldLogs(daysToKeep = 30) {
        try {
            const cutoff = new Date();
            cutoff.setDate(cutoff.getDate() - daysToKeep);
            
            const dailyDir = path.join(this.logDir, 'daily');
            const errorDir = path.join(this.logDir, 'errors');
            
            await this.cleanDirectory(dailyDir, cutoff);
            await this.cleanDirectory(errorDir, cutoff);
            
            this.info(`Cleaned logs older than ${daysToKeep} days`);
        } catch (error) {
            this.error('Failed to clean old logs:', error);
        }
    }

    /**
     * Clean directory of old files
     * @param {string} dir - Directory path
     * @param {Date} cutoff - Cutoff date
     */
    async cleanDirectory(dir, cutoff) {
        try {
            const files = await fs.readdir(dir);
            
            for (const file of files) {
                const filePath = path.join(dir, file);
                const stats = await fs.stat(filePath);
                
                if (stats.mtime < cutoff) {
                    await fs.unlink(filePath);
                }
            }
        } catch (error) {
            this.error(`Failed to clean directory ${dir}:`, error);
        }
    }
}

// Export singleton instance
export const logger = new Logger();
export default logger;