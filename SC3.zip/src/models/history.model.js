/**
 * QASHVRA FIX MERAH PRO - History Model
 * Fix merah processing history schema
 */

import mongoose from 'mongoose';

const historySchema = new mongoose.Schema({
    // User Information
    userId: {
        type: Number,
        required: true,
        index: true
    },
    username: {
        type: String,
        default: 'Unknown'
    },
    
    // Fix Details
    trackingId: {
        type: String,
        required: true,
        unique: true
    },
    phoneNumber: {
        type: String,
        required: true
    },
    
    // Status
    status: {
        type: String,
        enum: ['SUCCESS', 'FAILED', 'PENDING', 'PROCESSING', 'CANCELLED'],
        default: 'PENDING',
        index: true
    },
    
    // Process Details
    attempts: {
        type: Number,
        default: 1
    },
    duration: {
        type: Number,
        default: 0
    },
    
    // Error Information
    error: {
        type: String,
        default: null
    },
    errorCode: {
        type: String,
        default: null
    },
    
    // SMTP Used
    smtpUsed: {
        type: String,
        default: null
    },
    
    // Country Information
    country: {
        type: String,
        default: null
    },
    countryCode: {
        type: String,
        default: null
    },
    
    // Timestamp
    timestamp: {
        type: Date,
        default: Date.now,
        index: true
    },
    
    // Additional Data
    metadata: {
        type: mongoose.Schema.Types.Mixed,
        default: {}
    }
}, {
    timestamps: true,
    collection: 'history'
});

// Compound indexes
historySchema.index({ userId: 1, timestamp: -1 });
historySchema.index({ status: 1, timestamp: -1 });
historySchema.index({ timestamp: -1 });

/**
 * Get formatted duration
 */
historySchema.methods.getFormattedDuration = function() {
    if (this.duration < 1000) return `${this.duration}ms`;
    if (this.duration < 60000) return `${(this.duration / 1000).toFixed(2)}s`;
    return `${(this.duration / 60000).toFixed(2)}m`;
};

// Static methods
historySchema.statics.getUserHistory = function(userId, limit = 10) {
    return this.find({ userId })
        .sort({ timestamp: -1 })
        .limit(limit)
        .select('-metadata -__v');
};

historySchema.statics.getGlobalStats = async function() {
    const stats = await this.aggregate([
        {
            $group: {
                _id: null,
                totalFixes: { $sum: 1 },
                successFixes: {
                    $sum: { $cond: [{ $eq: ['$status', 'SUCCESS'] }, 1, 0] }
                },
                failedFixes: {
                    $sum: { $cond: [{ $eq: ['$status', 'FAILED'] }, 1, 0] }
                },
                averageDuration: { $avg: '$duration' }
            }
        }
    ]);
    
    return stats[0] || {
        totalFixes: 0,
        successFixes: 0,
        failedFixes: 0,
        averageDuration: 0
    };
};

historySchema.statics.getTodayStats = async function() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return await this.aggregate([
        {
            $match: {
                timestamp: { $gte: today }
            }
        },
        {
            $group: {
                _id: '$status',
                count: { $sum: 1 }
            }
        }
    ]);
};

historySchema.statics.getTopCountries = async function(limit = 10) {
    return await this.aggregate([
        {
            $match: {
                status: 'SUCCESS',
                country: { $ne: null }
            }
        },
        {
            $group: {
                _id: '$country',
                count: { $sum: 1 }
            }
        },
        {
            $sort: { count: -1 }
        },
        {
            $limit: limit
        }
    ]);
};

export const History = mongoose.model('History', historySchema);
export default History;