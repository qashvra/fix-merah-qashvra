/**
 * QASHVRA FIX MERAH PRO - Permission Model
 * Advanced permission management system
 */

import mongoose from 'mongoose';

const permissionSchema = new mongoose.Schema({
    // Permission Name
    name: {
        type: String,
        required: true,
        unique: true
    },
    code: {
        type: String,
        required: true,
        unique: true
    },
    
    // Description
    description: {
        type: String,
        default: ''
    },
    
    // Category
    category: {
        type: String,
        enum: ['ADMIN', 'USER', 'PREMIUM', 'SYSTEM', 'CUSTOM'],
        default: 'USER'
    },
    
    // Access Level
    level: {
        type: Number,
        required: true,
        min: 1,
        max: 7
    },
    
    // Who can assign this permission
    requiredLevel: {
        type: Number,
        default: 7
    },
    
    // Status
    isActive: {
        type: Boolean,
        default: true
    },
    
    // Restrictions
    maxPerRole: {
        type: Number,
        default: -1 // -1 means unlimited
    },
    
    // Metadata
    metadata: {
        type: mongoose.Schema.Types.Mixed,
        default: {}
    }
}, {
    timestamps: true,
    collection: 'permissions'
});

// Static methods
permissionSchema.statics.getAllPermissions = function() {
    return this.find({ isActive: true }).sort({ level: 1 });
};

permissionSchema.statics.getPermissionsByLevel = function(level) {
    return this.find({
        isActive: true,
        level: { $lte: level }
    }).sort({ level: 1 });
};

permissionSchema.statics.getPermissionByCode = function(code) {
    return this.findOne({ code, isActive: true });
};

/**
 * Default permissions to seed
 */
permissionSchema.statics.getDefaultPermissions = function() {
    return [
        {
            name: 'View Dashboard',
            code: 'dashboard.view',
            description: 'Can view bot dashboard',
            category: 'USER',
            level: 1
        },
        {
            name: 'Use Fix Merah',
            code: 'fixmerah.use',
            description: 'Can use fix merah feature',
            category: 'USER',
            level: 1
        },
        {
            name: 'View History',
            code: 'history.view',
            description: 'Can view fix history',
            category: 'USER',
            level: 1
        },
        {
            name: 'Use Referral',
            code: 'referral.use',
            description: 'Can use referral system',
            category: 'USER',
            level: 1
        },
        {
            name: 'VIP Access',
            code: 'vip.access',
            description: 'Access VIP features',
            category: 'PREMIUM',
            level: 2
        },
        {
            name: 'VVIP Access',
            code: 'vvip.access',
            description: 'Access VVIP features',
            category: 'PREMIUM',
            level: 3
        },
        {
            name: 'Moderate Users',
            code: 'users.moderate',
            description: 'Can moderate users',
            category: 'ADMIN',
            level: 4
        },
        {
            name: 'Manage SMTP',
            code: 'smtp.manage',
            description: 'Can manage SMTP servers',
            category: 'ADMIN',
            level: 5
        },
        {
            name: 'View Analytics',
            code: 'analytics.view',
            description: 'Can view analytics',
            category: 'ADMIN',
            level: 5
        },
        {
            name: 'Broadcast Message',
            code: 'broadcast.send',
            description: 'Can send broadcast messages',
            category: 'ADMIN',
            level: 5
        },
        {
            name: 'Manage Templates',
            code: 'templates.manage',
            description: 'Can manage templates',
            category: 'ADMIN',
            level: 5
        },
        {
            name: 'Manage Payments',
            code: 'payments.manage',
            description: 'Can manage payments',
            category: 'ADMIN',
            level: 6
        },
        {
            name: 'Manage Settings',
            code: 'settings.manage',
            description: 'Can manage bot settings',
            category: 'ADMIN',
            level: 6
        },
        {
            name: 'Full Access',
            code: 'admin.full',
            description: 'Full admin access',
            category: 'ADMIN',
            level: 7
        }
    ];
};

export const Permission = mongoose.model('Permission', permissionSchema);
export default Permission;