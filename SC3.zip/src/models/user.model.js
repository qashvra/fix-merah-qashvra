/**
 * QASHVRA FIX MERAH PRO - User Model
 * MongoDB user schema with permissions and premium status
 */

import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
    // Telegram User Information
    telegramId: {
        type: Number,
        required: true,
        unique: true,
        index: true
    },
    username: {
        type: String,
        default: ''
    },
    firstName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        default: ''
    },
    
    // User Status
    status: {
        type: String,
        enum: ['FREE_USER', 'VIP', 'VVIP', 'ADMIN', 'MODERATOR', 'DEVELOPER', 'OWNER'],
        default: 'FREE_USER'
    },
    isPremium: {
        type: Boolean,
        default: false
    },
    isBanned: {
        type: Boolean,
        default: false
    },
    isWhitelisted: {
        type: Boolean,
        default: false
    },
    
    // Verification Status
    isVerified: {
        type: Boolean,
        default: false
    },
    joinedChannels: [{
        channelId: String,
        joinedAt: Date
    }],
    
    // Fix Merah Statistics
    fixMerahStats: {
        totalFix: {
            type: Number,
            default: 0
        },
        successFix: {
            type: Number,
            default: 0
        },
        failedFix: {
            type: Number,
            default: 0
        },
        lastFixAt: Date
    },
    
    // Referral System
    referralCode: {
        type: String,
        unique: true,
        sparse: true
    },
    referredBy: {
        type: Number,
        default: null
    },
    referralCount: {
        type: Number,
        default: 0
    },
    referralCoins: {
        type: Number,
        default: 0
    },
    
    // Membership
    membershipExpiry: {
        type: Date,
        default: null
    },
    membershipHistory: [{
        plan: String,
        duration: Number,
        purchasedAt: Date,
        expiredAt: Date,
        orderId: String
    }],
    
    // Limits
    dailyFixCount: {
        type: Number,
        default: 0
    },
    dailyFixLimit: {
        type: Number,
        default: 2
    },
    lastFixReset: {
        type: Date,
        default: Date.now
    },
    
    // Activity Tracking
    lastActive: {
        type: Date,
        default: Date.now
    },
    joinedAt: {
        type: Date,
        default: Date.now
    },
    
    // Session Management
    currentSession: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Session'
    },
    
    // Permissions
    permissions: [{
        type: String
    }],
    
    // Metadata
    metadata: {
        type: mongoose.Schema.Types.Mixed,
        default: {}
    }
}, {
    timestamps: true,
    collection: 'users'
});

// Indexes for performance
userSchema.index({ status: 1 });
userSchema.index({ referralCode: 1 });
userSchema.index({ isVerified: 1, isBanned: 1 });

/**
 * Pre-save middleware
 */
userSchema.pre('save', function(next) {
    // Reset daily fix count if it's a new day
    if (this.lastFixReset) {
        const now = new Date();
        const lastReset = new Date(this.lastFixReset);
        
        if (now.getDate() !== lastReset.getDate() || 
            now.getMonth() !== lastReset.getMonth() || 
            now.getFullYear() !== lastReset.getFullYear()) {
            this.dailyFixCount = 0;
            this.lastFixReset = now;
        }
    }
    
    // Update premium status based on membership expiry
    if (this.membershipExpiry && new Date() > this.membershipExpiry) {
        this.isPremium = false;
        this.status = 'FREE_USER';
        this.membershipExpiry = null;
    }
    
    next();
});

/**
 * Instance methods
 */
userSchema.methods.incrementFixCount = async function() {
    this.fixMerahStats.totalFix += 1;
    this.dailyFixCount += 1;
    this.lastActive = new Date();
    await this.save();
};

userSchema.methods.incrementSuccessFix = async function() {
    this.fixMerahStats.successFix += 1;
    await this.save();
};

userSchema.methods.incrementFailedFix = async function() {
    this.fixMerahStats.failedFix += 1;
    await this.save();
};

userSchema.methods.addReferral = async function() {
    this.referralCount += 1;
    this.referralCoins += 10; // Default coin reward
    await this.save();
};

/**
 * Static methods
 */
userSchema.statics.findByTelegramId = function(telegramId) {
    return this.findOne({ telegramId });
};

userSchema.statics.getLeaderboard = function(limit = 10) {
    return this.find({ isBanned: false })
        .sort({ 'fixMerahStats.successFix': -1 })
        .limit(limit)
        .select('firstName username fixMerahStats referralCoins');
};

// Create and export the model
export const User = mongoose.model('User', userSchema);

export default User;