/**
 * QASHVRA FIX MERAH PRO - SMTP Model
 * SMTP server configuration and management schema
 */

import mongoose from 'mongoose';

const smtpSchema = new mongoose.Schema({
    // Server Information
    host: {
        type: String,
        required: true
    },
    port: {
        type: Number,
        required: true,
        min: 1,
        max: 65535
    },
    secure: {
        type: Boolean,
        default: false
    },
    
    // Authentication
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    isEncrypted: {
        type: Boolean,
        default: false
    },
    
    // Configuration
    displayName: {
        type: String,
        default: 'QASHVRA FIX MERAH'
    },
    priority: {
        type: Number,
        default: 1,
        min: 1,
        max: 10
    },
    
    // Status
    active: {
        type: Boolean,
        default: true,
        index: true
    },
    status: {
        type: String,
        enum: ['active', 'inactive', 'warming', 'cooling', 'banned', 'error'],
        default: 'active'
    },
    
    // Limits
    dailyLimit: {
        type: Number,
        default: 100
    },
    hourlyLimit: {
        type: Number,
        default: 20
    },
    sentToday: {
        type: Number,
        default: 0
    },
    sentThisHour: {
        type: Number,
        default: 0
    },
    
    // Pool Configuration
    maxConnections: {
        type: Number,
        default: 5
    },
    maxMessages: {
        type: Number,
        default: 100
    },
    rateDelta: {
        type: Number,
        default: 1000
    },
    rateLimit: {
        type: Number,
        default: 5
    },
    
    // Warmup
    warmedUp: {
        type: Boolean,
        default: false
    },
    warmupStartedAt: {
        type: Date,
        default: null
    },
    warmupCompletedAt: {
        type: Date,
        default: null
    },
    
    // Health Monitoring
    health: {
        status: {
            type: String,
            enum: ['healthy', 'unhealthy', 'unknown'],
            default: 'unknown'
        },
        lastCheck: {
            type: Date,
            default: null
        },
        failCount: {
            type: Number,
            default: 0
        },
        lastError: {
            type: String,
            default: null
        }
    },
    
    // Statistics
    stats: {
        totalSent: {
            type: Number,
            default: 0
        },
        successCount: {
            type: Number,
            default: 0
        },
        failureCount: {
            type: Number,
            default: 0
        },
        bounceCount: {
            type: Number,
            default: 0
        },
        spamCount: {
            type: Number,
            default: 0
        },
        lastUsed: {
            type: Date,
            default: null
        },
        averageResponseTime: {
            type: Number,
            default: 0
        }
    },
    
    // Type
    type: {
        type: String,
        enum: ['gmail', 'outlook', 'custom', 'sendgrid', 'amazon_ses', 'mailgun'],
        default: 'gmail'
    },
    
    // Tags for categorization
    tags: [{
        type: String
    }],
    
    // Notes
    notes: {
        type: String,
        default: ''
    }
}, {
    timestamps: true,
    collection: 'smtp_servers'
});

// Indexes
smtpSchema.index({ active: 1, 'health.status': 1 });
smtpSchema.index({ priority: -1 });
smtpSchema.index({ type: 1 });

/**
 * Check if SMTP can send more emails
 */
smtpSchema.methods.canSend = function() {
    // Check if active
    if (!this.active || this.status !== 'active') {
        return false;
    }
    
    // Check daily limit
    if (this.sentToday >= this.dailyLimit) {
        return false;
    }
    
    // Check hourly limit
    if (this.sentThisHour >= this.hourlyLimit) {
        return false;
    }
    
    // Check health
    if (this.health.status === 'unhealthy') {
        return false;
    }
    
    return true;
};

/**
 * Reset counters
 */
smtpSchema.methods.resetCounters = async function() {
    this.sentToday = 0;
    this.sentThisHour = 0;
    await this.save();
};

/**
 * Increment sent count
 */
smtpSchema.methods.incrementSent = async function() {
    this.sentToday += 1;
    this.sentThisHour += 1;
    this.stats.totalSent += 1;
    this.stats.lastUsed = new Date();
    await this.save();
};

/**
 * Mark as failed
 */
smtpSchema.methods.markFailed = async function(error) {
    this.stats.failureCount += 1;
    this.health.failCount += 1;
    this.health.lastError = error;
    
    if (this.health.failCount >= 10) {
        this.health.status = 'unhealthy';
        this.active = false;
        this.status = 'error';
    }
    
    await this.save();
};

// Static methods
smtpSchema.statics.getHealthyServers = function() {
    return this.find({
        active: true,
        'health.status': 'healthy',
        status: 'active'
    }).sort({ priority: -1 });
};

smtpSchema.statics.getStats = async function() {
    const stats = await this.aggregate([
        {
            $group: {
                _id: null,
                totalServers: { $sum: 1 },
                activeServers: {
                    $sum: { $cond: [{ $eq: ['$active', true] }, 1, 0] }
                },
                healthyServers: {
                    $sum: { $cond: [{ $eq: ['$health.status', 'healthy'] }, 1, 0] }
                },
                totalSent: { $sum: '$stats.totalSent' },
                totalSuccess: { $sum: '$stats.successCount' },
                totalFailure: { $sum: '$stats.failureCount' }
            }
        }
    ]);
    
    return stats[0] || {
        totalServers: 0,
        activeServers: 0,
        healthyServers: 0,
        totalSent: 0,
        totalSuccess: 0,
        totalFailure: 0
    };
};

export const SMTP = mongoose.model('SMTP', smtpSchema);
export default SMTP;