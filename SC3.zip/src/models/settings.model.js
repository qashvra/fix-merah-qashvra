/**
 * QASHVRA FIX MERAH PRO - Settings Model
 * Central configuration management
 */

import mongoose from 'mongoose';

const settingsSchema = new mongoose.Schema({
    // Bot Information
    botName: {
        type: String,
        default: 'QASHVRA FIX MERAH PRO'
    },
    version: {
        type: String,
        default: '1.0.0'
    },
    
    // Bot Status
    maintenance: {
        type: Boolean,
        default: false
    },
    maintenanceMessage: {
        type: String,
        default: '🔧 Bot sedang dalam maintenance. Silakan coba lagi nanti.'
    },
    
    // Fix Merah Settings
    maxDailyFix: {
        type: Number,
        default: 2
    },
    cooldownMinutes: {
        type: Number,
        default: 5
    },
    maxRetries: {
        type: Number,
        default: 3
    },
    
    // Premium Prices
    premiumPrices: {
        vip: {
            '1': { type: Number, default: 1007 },
            '7': { type: Number, default: 5007 },
            '30': { type: Number, default: 15007 }
        },
        vvip: {
            '1': { type: Number, default: 2007 },
            '30': { type: Number, default: 25007 }
        }
    },
    
    // Referral Settings
    referralReward: {
        type: Number,
        default: 10
    },
    referralCoinToVIP: {
        type: Number,
        default: 100
    },
    
    // Sender Statistics
    activeSenders: {
        type: Number,
        default: 0
    },
    totalSenders: {
        type: Number,
        default: 0
    },
    
    // Rate Limiting
    rateLimit: {
        windowMs: { type: Number, default: 900000 },
        maxRequests: { type: Number, default: 100 }
    },
    
    // Verification
    requireVerification: {
        type: Boolean,
        default: true
    },
    requiredChannels: [{
        channelId: String,
        channelName: String,
        channelLink: String
    }],
    
    // Payment Settings
    paymentTimeout: {
        type: Number,
        default: 3600000 // 1 hour
    },
    autoVerifyPayment: {
        type: Boolean,
        default: true
    },
    
    // SMTP Settings
    smtpDefaultHost: {
        type: String,
        default: 'smtp.gmail.com'
    },
    smtpDefaultPort: {
        type: Number,
        default: 587
    },
    
    // Cache Settings
    cacheTTL: {
        type: Number,
        default: 3600
    },
    sessionTTL: {
        type: Number,
        default: 86400
    },
    
    // Security
    encryptionEnabled: {
        type: Boolean,
        default: true
    },
    maxLoginAttempts: {
        type: Number,
        default: 5
    },
    
    // Logging
    logLevel: {
        type: String,
        enum: ['debug', 'info', 'warn', 'error'],
        default: 'info'
    },
    logRetentionDays: {
        type: Number,
        default: 30
    },
    
    // Feature Flags
    features: {
        fixMerah: { type: Boolean, default: true },
        premium: { type: Boolean, default: true },
        referral: { type: Boolean, default: true },
        leaderboard: { type: Boolean, default: true },
        testimonial: { type: Boolean, default: true },
        broadcast: { type: Boolean, default: true },
        payment: { type: Boolean, default: true }
    },
    
    // UI Settings
    welcomeImage: {
        type: String,
        default: 'https://i.ibb.co/default-banner.jpg'
    },
    premiumImage: {
        type: String,
        default: 'https://i.ibb.co/premium-banner.jpg'
    },
    
    // Updated By
    lastUpdatedBy: {
        type: Number,
        default: null
    },
    lastUpdatedAt: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true,
    collection: 'settings'
});

/**
 * Get singleton settings
 */
settingsSchema.statics.getSettings = async function() {
    let settings = await this.findOne();
    
    if (!settings) {
        settings = await this.create({});
    }
    
    return settings;
};

/**
 * Update settings
 */
settingsSchema.statics.updateSettings = async function(updates, userId) {
    updates.lastUpdatedBy = userId;
    updates.lastUpdatedAt = new Date();
    
    return await this.findOneAndUpdate(
        {},
        { $set: updates },
        { new: true, upsert: true }
    );
};

/**
 * Check if feature is enabled
 */
settingsSchema.methods.isFeatureEnabled = function(feature) {
    return this.features[feature] === true && !this.maintenance;
};

/**
 * Get premium price
 */
settingsSchema.methods.getPremiumPrice = function(plan, duration) {
    const prices = this.premiumPrices[plan.toLowerCase()];
    return prices ? prices[duration.toString()] || 0 : 0;
};

export const Settings = mongoose.model('Settings', settingsSchema);
export default Settings;