/**
 * QASHVRA FIX MERAH PRO - Testimonial Model
 * Success story testimonials schema
 */

import mongoose from 'mongoose';

const testimonialSchema = new mongoose.Schema({
    // User Information
    userId: {
        type: Number,
        required: true,
        index: true
    },
    username: {
        type: String,
        default: 'Anonymous'
    },
    firstName: {
        type: String,
        default: 'User'
    },
    
    // Fix Details
    trackingId: {
        type: String,
        required: true,
        unique: true
    },
    phoneNumber: {
        type: String,
        required: true
    },
    
    // Status
    status: {
        type: String,
        enum: ['SUCCESS', 'PENDING', 'VERIFIED'],
        default: 'SUCCESS'
    },
    
    // Content
    message: {
        type: String,
        default: null
    },
    rating: {
        type: Number,
        min: 1,
        max: 5,
        default: null
    },
    
    // Media
    screenshot: {
        type: String,
        default: null
    },
    
    // Publication
    isPublished: {
        type: Boolean,
        default: true
    },
    publishedAt: {
        type: Date,
        default: Date.now
    },
    publishedInChannel: {
        type: Boolean,
        default: false
    },
    channelMessageId: {
        type: Number,
        default: null
    },
    
    // Engagement
    views: {
        type: Number,
        default: 0
    },
    reactions: {
        type: Number,
        default: 0
    },
    
    // Timestamp
    timestamp: {
        type: Date,
        default: Date.now,
        index: true
    }
}, {
    timestamps: true,
    collection: 'testimonials'
});

// Indexes
testimonialSchema.index({ isPublished: 1, timestamp: -1 });
testimonialSchema.index({ userId: 1, timestamp: -1 });

/**
 * Get formatted testimonial message
 */
testimonialSchema.methods.getFormattedMessage = function() {
    return (
        '🔴 *PROSES FIX MERAH BERHASIL* 🔴\n\n' +
        '```\n' +
        `🆔 ID Banding: ${this.trackingId}\n` +
        `📱 Nomor: ${this.phoneNumber}\n` +
        `📌 Status: ✅ SUKSES\n` +
        `👤 User: ${this.firstName}\n` +
        `📅 Waktu: ${this.timestamp.toLocaleString('id-ID')}\n` +
        '```\n\n' +
        '🤖 _Powered by QASHVRA FIX MERAH BOT_'
    );
};

// Static methods
testimonialSchema.statics.getPublished = function(limit = 10) {
    return this.find({ isPublished: true })
        .sort({ timestamp: -1 })
        .limit(limit)
        .select('-__v -metadata');
};

testimonialSchema.statics.getTodayCount = async function() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return await this.countDocuments({
        timestamp: { $gte: today },
        status: 'SUCCESS'
    });
};

testimonialSchema.statics.getSuccessRate = async function() {
    const total = await this.countDocuments();
    const success = await this.countDocuments({ status: 'SUCCESS' });
    
    if (total === 0) return 0;
    return ((success / total) * 100).toFixed(2);
};

export const Testimonial = mongoose.model('Testimonial', testimonialSchema);
export default Testimonial;