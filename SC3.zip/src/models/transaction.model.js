/**
 * QASHVRA FIX MERAH PRO - Transaction Model
 * Payment transaction schema for tracking all financial operations
 */

import mongoose from 'mongoose';

const transactionSchema = new mongoose.Schema({
    // Order Information
    orderId: {
        type: String,
        required: true,
        unique: true,
        index: true
    },
    userId: {
        type: Number,
        required: true,
        index: true
    },
    
    // Plan Details
    plan: {
        type: String,
        enum: ['VIP', 'VVIP'],
        required: true
    },
    duration: {
        type: Number,
        required: true,
        min: 1
    },
    amount: {
        type: Number,
        required: true,
        min: 0
    },
    
    // Payment Status
    status: {
        type: String,
        enum: ['PENDING', 'SUCCESS', 'FAILED', 'EXPIRED', 'CANCELLED', 'REFUNDED'],
        default: 'PENDING',
        index: true
    },
    paymentMethod: {
        type: String,
        enum: ['QRIS', 'BANK_TRANSFER', 'E_WALLET', 'MANUAL'],
        default: 'QRIS'
    },
    
    // Payment Details
    paymentProof: {
        type: String,
        default: null
    },
    paymentNote: {
        type: String,
        default: null
    },
    
    // Timestamps
    paidAt: {
        type: Date,
        default: null
    },
    expiresAt: {
        type: Date,
        required: true,
        index: true
    },
    
    // Verification
    verifiedBy: {
        type: Number,
        default: null
    },
    verifiedAt: {
        type: Date,
        default: null
    },
    
    // Refund Information
    refundReason: {
        type: String,
        default: null
    },
    refundedAt: {
        type: Date,
        default: null
    },
    
    // Metadata
    metadata: {
        type: mongoose.Schema.Types.Mixed,
        default: {}
    },
    
    // Invoice Details
    invoiceNumber: {
        type: String,
        default: null
    },
    qrisCode: {
        type: String,
        default: null
    }
}, {
    timestamps: true,
    collection: 'transactions'
});

// Compound indexes
transactionSchema.index({ userId: 1, status: 1 });
transactionSchema.index({ status: 1, expiresAt: 1 });
transactionSchema.index({ createdAt: -1 });

/**
 * Check if transaction is expired
 */
transactionSchema.methods.isExpired = function() {
    return this.status === 'PENDING' && new Date() > this.expiresAt;
};

/**
 * Get transaction age in minutes
 */
transactionSchema.methods.getAge = function() {
    return Math.floor((Date.now() - this.createdAt) / 60000);
};

/**
 * Format amount to currency
 */
transactionSchema.methods.getFormattedAmount = function() {
    return `Rp ${this.amount.toLocaleString('id-ID')}`;
};

// Static methods
transactionSchema.statics.getTodayStats = async function() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const stats = await this.aggregate([
        {
            $match: {
                createdAt: { $gte: today }
            }
        },
        {
            $group: {
                _id: '$status',
                count: { $sum: 1 },
                totalAmount: { $sum: '$amount' }
            }
        }
    ]);
    
    return stats;
};

transactionSchema.statics.getUserSpending = async function(userId) {
    const result = await this.aggregate([
        {
            $match: {
                userId: userId,
                status: 'SUCCESS'
            }
        },
        {
            $group: {
                _id: null,
                totalSpent: { $sum: '$amount' },
                totalTransactions: { $sum: 1 },
                averageAmount: { $avg: '$amount' }
            }
        }
    ]);
    
    return result[0] || { totalSpent: 0, totalTransactions: 0, averageAmount: 0 };
};

export const Transaction = mongoose.model('Transaction', transactionSchema);
export default Transaction;