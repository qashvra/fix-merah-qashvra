/**
 * QASHVRA FIX MERAH PRO - Main Menu Keyboard
 * Premium UI keyboards for Telegram bot
 */

/**
 * Main menu inline keyboard
 * @returns {Object} Inline keyboard markup
 */
export function getMainMenuKeyboard() {
    return {
        reply_markup: {
            inline_keyboard: [
                [
                    {
                        text: '🛠️ FIX MERAH',
                        callback_data: 'menu_fix_merah'
                    },
                    {
                        text: '👑 VIP / VVIP',
                        callback_data: 'menu_premium'
                    }
                ],
                [
                    {
                        text: '🧧 REFERRAL',
                        callback_data: 'menu_referral'
                    },
                    {
                        text: '📜 RIWAYAT',
                        callback_data: 'menu_history'
                    }
                ],
                [
                    {
                        text: '🏆 TOP GLOBAL',
                        callback_data: 'menu_leaderboard'
                    },
                    {
                        text: '💬 TESTIMONI',
                        callback_data: 'menu_testimoni'
                    }
                ],
                [
                    {
                        text: 'ℹ️ BANTUAN',
                        callback_data: 'menu_help'
                    }
                ]
            ]
        }
    };
}

/**
 * Reply keyboard for quick access
 * @returns {Object} Reply keyboard markup
 */
export function getReplyKeyboard() {
    return {
        reply_markup: {
            keyboard: [
                ['🛠️ Fix Merah', '👑 VIP/VVIP'],
                ['🧧 Referral', '📜 Riwayat'],
                ['🏆 Top Global', '💬 Testimoni']
            ],
            resize_keyboard: true,
            one_time_keyboard: false
        }
    };
}

/**
 * Admin panel keyboard
 * @returns {Object} Inline keyboard markup
 */
export function getAdminKeyboard() {
    return {
        reply_markup: {
            inline_keyboard: [
                [
                    {
                        text: '📊 STATISTIK',
                        callback_data: 'admin_stats'
                    },
                    {
                        text: '👥 USERS',
                        callback_data: 'admin_users'
                    }
                ],
                [
                    {
                        text: '📧 BROADCAST',
                        callback_data: 'admin_broadcast'
                    },
                    {
                        text: '📝 TEMPLATES',
                        callback_data: 'admin_templates'
                    }
                ],
                [
                    {
                        text: '💰 PAYMENTS',
                        callback_data: 'admin_payments'
                    },
                    {
                        text: '📊 SMTP',
                        callback_data: 'admin_smtp'
                    }
                ],
                [
                    {
                        text: '⚙️ SETTINGS',
                        callback_data: 'admin_settings'
                    },
                    {
                        text: '🔄 RELOAD',
                        callback_data: 'admin_reload'
                    }
                ],
                [
                    {
                        text: '🔙 BACK TO MAIN',
                        callback_data: 'menu_main'
                    }
                ]
            ]
        }
    };
}

export default { getMainMenuKeyboard, getReplyKeyboard, getAdminKeyboard };