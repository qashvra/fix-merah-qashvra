/**
 * QASHVRA FIX MERAH PRO - Permission Middleware
 * Handles user permissions and access control
 */

import { logger } from '../utils/logger.js';
import { User } from '../models/user.model.js';
import { Permission } from '../models/permission.model.js';

/**
 * Permission hierarchy levels
 */
export const PERMISSION_LEVELS = {
    OWNER: 7,
    DEVELOPER: 6,
    ADMIN: 5,
    MODERATOR: 4,
    VVIP: 3,
    VIP: 2,
    FREE_USER: 1
};

/**
 * Permission middleware factory
 * @param {string|string[]} requiredPermission - Required permission level(s)
 * @returns {Function} Middleware function
 */
export function requirePermission(requiredPermission) {
    return async (msg, next) => {
        try {
            const userId = msg.from?.id;
            
            if (!userId) {
                throw new Error('User ID not found');
            }
            
            // Get user from database
            const user = await User.findByTelegramId(userId);
            
            if (!user) {
                throw new Error('User not found in database');
            }
            
            // Check if user is banned
            if (user.isBanned) {
                throw new Error('User is banned');
            }
            
            // Check permission level
            const userLevel = PERMISSION_LEVELS[user.status] || 0;
            const requiredLevel = Array.isArray(requiredPermission) 
                ? Math.max(...requiredPermission.map(p => PERMISSION_LEVELS[p] || 0))
                : PERMISSION_LEVELS[requiredPermission] || 0;
            
            if (userLevel < requiredLevel) {
                throw new Error('Insufficient permissions');
            }
            
            // Anti privilege escalation check
            if (requiredPermission === 'OWNER' && userId !== parseInt(process.env.OWNER_ID)) {
                throw new Error('Only the bot owner can access this feature');
            }
            
            // Permission check passed
            await next();
            
        } catch (error) {
            logger.warn(`Permission denied for user ${msg.from?.id}: ${error.message}`);
            
            // Send permission denied message
            if (msg.reply) {
                await msg.reply(
                    '⛔ *Akses Ditolak*\n\n' +
                    'Maaf, Anda tidak memiliki izin untuk mengakses fitur ini.\n\n' +
                    '_Hubungi owner untuk meningkatkan akses Anda._',
                    { parse_mode: 'Markdown' }
                );
            }
        }
    };
}

/**
 * Check if user is owner
 * @param {number} userId - Telegram user ID
 * @returns {boolean}
 */
export function isOwner(userId) {
    return userId === parseInt(process.env.OWNER_ID);
}

/**
 * Get user permission level
 * @param {string} status - User status
 * @returns {number} Permission level
 */
export function getPermissionLevel(status) {
    return PERMISSION_LEVELS[status] || 0;
}

/**
 * Validate permission for action
 * @param {Object} user - User object
 * @param {string} action - Action to validate
 * @returns {boolean}
 */
export function validatePermission(user, action) {
    // Owner has full access
    if (isOwner(user.telegramId)) {
        return true;
    }
    
    // Check specific permissions array
    if (user.permissions && user.permissions.includes(action)) {
        return true;
    }
    
    // Check based on user status
    const level = getPermissionLevel(user.status);
    
    // Define action requirements
    const actionRequirements = {
        'admin:panel': 5,
        'broadcast': 5,
        'manage_users': 5,
        'manage_smtp': 4,
        'manage_templates': 4,
        'view_analytics': 3,
        'fix_merah': 1,
        'referral': 1
    };
    
    const requiredLevel = actionRequirements[action] || 7;
    return level >= requiredLevel;
}

export default { requirePermission, isOwner, getPermissionLevel, validatePermission };