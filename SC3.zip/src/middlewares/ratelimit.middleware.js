/**
 * QASHVRA FIX MERAH PRO - Rate Limiting Middleware
 * Advanced rate limiting and anti-spam system
 */

import { logger } from '../utils/logger.js';

class RateLimiter {
    constructor() {
        this.requests = new Map();
        this.blacklist = new Map();
        this.warnings = new Map();
        
        // Configuration
        this.config = {
            // Global limits
            global: {
                windowMs: 60000, // 1 minute
                maxRequests: 30
            },
            
            // Command-specific limits
            commands: {
                fix: {
                    windowMs: 300000, // 5 minutes
                    maxRequests: 2
                },
                premium: {
                    windowMs: 10000, // 10 seconds
                    maxRequests: 5
                },
                referral: {
                    windowMs: 60000, // 1 minute
                    maxRequests: 10
                }
            },
            
            // Anti-flood
            flood: {
                threshold: 5, // messages
                windowMs: 5000, // 5 seconds
                muteDuration: 300000 // 5 minutes
            },
            
            // Anti-spam
            spam: {
                similarMessages: 3,
                windowMs: 10000, // 10 seconds
                banDuration: 3600000 // 1 hour
            },
            
            // Warning system
            maxWarnings: 3,
            warningExpiry: 3600000 // 1 hour
        };

        // Cleanup interval
        setInterval(() => this.cleanup(), 60000);
    }

    /**
     * Rate limit middleware
     * @param {Object} msg - Telegram message object
     * @param {Function} next - Next middleware
     */
    async middleware(msg, next) {
        try {
            const userId = msg.from.id;
            const chatId = msg.chat.id;

            // Check blacklist
            if (this.isBlacklisted(userId)) {
                throw new Error('You are temporarily banned from using the bot');
            }

            // Check global rate limit
            if (!this.checkGlobalLimit(userId)) {
                throw new Error('Rate limit exceeded. Please slow down.');
            }

            // Check flood protection
            if (this.isFlooding(userId)) {
                await this.muteUser(userId, chatId, msg);
                throw new Error('Flooding detected. You have been muted.');
            }

            // Check spam protection
            if (msg.text && this.isSpamming(userId, msg.text)) {
                await this.banUser(userId, chatId, msg);
                throw new Error('Spam detected. You have been banned temporarily.');
            }

            // Check command-specific rate limit
            if (msg.text && msg.text.startsWith('/')) {
                const command = msg.text.split(' ')[0].substring(1).split('@')[0];
                if (!this.checkCommandLimit(userId, command)) {
                    throw new Error(`Command rate limit exceeded for /${command}`);
                }
            }

            // Record request
            this.recordRequest(userId, msg);

            // Proceed to next middleware
            await next();

        } catch (error) {
            logger.warn(`Rate limit violation for user ${msg.from.id}: ${error.message}`);
            
            // Send warning message
            if (msg.reply) {
                await msg.reply(
                    `⚠️ *LIMIT TERCAPAI*\n\n${error.message}\n\n_Silakan tunggu beberapa saat sebelum mencoba lagi._`,
                    { parse_mode: 'Markdown' }
                );
            }
        }
    }

    /**
     * Check global rate limit
     * @param {number} userId - User ID
     * @returns {boolean} Allowed status
     */
    checkGlobalLimit(userId) {
        const userRequests = this.requests.get(userId);
        if (!userRequests) return true;

        const now = Date.now();
        const recentRequests = userRequests.global.filter(
            time => now - time < this.config.global.windowMs
        );

        return recentRequests.length < this.config.global.maxRequests;
    }

    /**
     * Check command-specific rate limit
     * @param {number} userId - User ID
     * @param {string} command - Command name
     * @returns {boolean} Allowed status
     */
    checkCommandLimit(userId, command) {
        const limit = this.config.commands[command];
        if (!limit) return true;

        const userRequests = this.requests.get(userId);
        if (!userRequests) return true;

        const now = Date.now();
        const commandRequests = (userRequests.commands.get(command) || []).filter(
            time => now - time < limit.windowMs
        );

        return commandRequests.length < limit.maxRequests;
    }

    /**
     * Check for flooding
     * @param {number} userId - User ID
     * @returns {boolean} Flooding status
     */
    isFlooding(userId) {
        const userRequests = this.requests.get(userId);
        if (!userRequests) return false;

        const now = Date.now();
        const recentMessages = userRequests.messages.filter(
            time => now - time < this.config.flood.windowMs
        );

        return recentMessages.length >= this.config.flood.threshold;
    }

    /**
     * Check for spam
     * @param {number} userId - User ID
     * @param {string} text - Message text
     * @returns {boolean} Spam status
     */
    isSpamming(userId, text) {
        const userRequests = this.requests.get(userId);
        if (!userRequests) return false;

        const now = Date.now();
        const recentTexts = userRequests.texts.filter(
            entry => now - entry.time < this.config.spam.windowMs
        );

        // Count similar messages
        const similarCount = recentTexts.filter(entry => 
            this.calculateSimilarity(entry.text, text) > 0.8
        ).length;

        return similarCount >= this.config.spam.similarMessages;
    }

    /**
     * Calculate text similarity (simple Levenshtein distance based)
     * @param {string} str1 - First string
     * @param {string} str2 - Second string
     * @returns {number} Similarity score (0-1)
     */
    calculateSimilarity(str1, str2) {
        if (str1 === str2) return 1;
        if (!str1 || !str2) return 0;

        const len1 = str1.length;
        const len2 = str2.length;
        const maxLen = Math.max(len1, len2);

        if (maxLen === 0) return 1;

        // Simple character-based similarity
        let matches = 0;
        for (let i = 0; i < Math.min(len1, len2); i++) {
            if (str1[i] === str2[i]) matches++;
        }

        return matches / maxLen;
    }

    /**
     * Record request
     * @param {number} userId - User ID
     * @param {Object} msg - Message object
     */
    recordRequest(userId, msg) {
        if (!this.requests.has(userId)) {
            this.requests.set(userId, {
                global: [],
                commands: new Map(),
                messages: [],
                texts: []
            });
        }

        const userRequests = this.requests.get(userId);
        const now = Date.now();

        // Record global request
        userRequests.global.push(now);

        // Record command request
        if (msg.text && msg.text.startsWith('/')) {
            const command = msg.text.split(' ')[0].substring(1).split('@')[0];
            if (!userRequests.commands.has(command)) {
                userRequests.commands.set(command, []);
            }
            userRequests.commands.get(command).push(now);
        }

        // Record message for flood detection
        userRequests.messages.push(now);

        // Record text for spam detection
        if (msg.text) {
            userRequests.texts.push({
                time: now,
                text: msg.text
            });
        }
    }

    /**
     * Mute user for flooding
     * @param {number} userId - User ID
     * @param {number} chatId - Chat ID
     * @param {Object} msg - Message object
     */
    async muteUser(userId, chatId, msg) {
        logger.warn(`Muting user ${userId} for flooding`);
        
        this.blacklist.set(userId, {
            type: 'mute',
            until: Date.now() + this.config.flood.muteDuration,
            reason: 'Flooding detected'
        });

        // Try to restrict user in group
        if (msg.chat.type !== 'private') {
            try {
                const bot = global.bot;
                if (bot) {
                    await bot.restrictChatMember(chatId, userId, {
                        can_send_messages: false,
                        can_send_media_messages: false,
                        can_send_other_messages: false
                    }, {
                        until_date: Math.floor(Date.now() / 1000) + 300
                    });
                }
            } catch (error) {
                logger.error('Failed to mute user in chat:', error);
            }
        }

        // Add warning
        this.addWarning(userId, 'Flooding');
    }

    /**
     * Ban user for spam
     * @param {number} userId - User ID
     * @param {number} chatId - Chat ID
     * @param {Object} msg - Message object
     */
    async banUser(userId, chatId, msg) {
        logger.warn(`Banning user ${userId} for spam`);
        
        this.blacklist.set(userId, {
            type: 'ban',
            until: Date.now() + this.config.spam.banDuration,
            reason: 'Spam detected'
        });

        // Try to ban user from group
        if (msg.chat.type !== 'private') {
            try {
                const bot = global.bot;
                if (bot) {
                    await bot.banChatMember(chatId, userId);
                    
                    // Unban after duration
                    setTimeout(async () => {
                        try {
                            await bot.unbanChatMember(chatId, userId);
                        } catch (error) {
                            logger.error('Failed to unban user:', error);
                        }
                    }, this.config.spam.banDuration);
                }
            } catch (error) {
                logger.error('Failed to ban user from chat:', error);
            }
        }

        // Update user in database
        try {
            const { User } = await import('../models/user.model.js');
            await User.findOneAndUpdate(
                { telegramId: userId },
                { 
                    isBanned: true,
                    banReason: 'Spam detected',
                    bannedAt: new Date(),
                    banExpiry: new Date(Date.now() + this.config.spam.banDuration)
                }
            );
        } catch (error) {
            logger.error('Failed to update user ban status:', error);
        }
    }

    /**
     * Add warning to user
     * @param {number} userId - User ID
     * @param {string} reason - Warning reason
     */
    addWarning(userId, reason) {
        if (!this.warnings.has(userId)) {
            this.warnings.set(userId, []);
        }

        const userWarnings = this.warnings.get(userId);
        userWarnings.push({
            timestamp: Date.now(),
            reason: reason
        });

        // Check if max warnings reached
        if (userWarnings.length >= this.config.maxWarnings) {
            this.escalatePunishment(userId);
        }
    }

    /**
     * Escalate punishment for repeated violations
     * @param {number} userId - User ID
     */
    async escalatePunishment(userId) {
        logger.warn(`Escalating punishment for user ${userId}`);
        
        // Ban for longer duration
        this.blacklist.set(userId, {
            type: 'ban',
            until: Date.now() + 86400000, // 24 hours
            reason: 'Repeated violations'
        });

        // Update database
        try {
            const { User } = await import('../models/user.model.js');
            await User.findOneAndUpdate(
                { telegramId: userId },
                {
                    isBanned: true,
                    banReason: 'Repeated violations',
                    bannedAt: new Date(),
                    banExpiry: new Date(Date.now() + 86400000)
                }
            );
        } catch (error) {
            logger.error('Failed to escalate punishment:', error);
        }
    }

    /**
     * Check if user is blacklisted
     * @param {number} userId - User ID
     * @returns {boolean} Blacklist status
     */
    isBlacklisted(userId) {
        const blacklist = this.blacklist.get(userId);
        if (!blacklist) return false;

        // Check if ban/mute has expired
        if (Date.now() > blacklist.until) {
            this.blacklist.delete(userId);
            return false;
        }

        return true;
    }

    /**
     * Clean up old records
     */
    cleanup() {
        const now = Date.now();
        const maxAge = 3600000; // 1 hour

        // Clean request records
        for (const [userId, userRequests] of this.requests) {
            // Clean global requests
            userRequests.global = userRequests.global.filter(
                time => now - time < maxAge
            );

            // Clean command requests
            for (const [command, times] of userRequests.commands) {
                userRequests.commands.set(
                    command,
                    times.filter(time => now - time < maxAge)
                );
            }

            // Clean messages
            userRequests.messages = userRequests.messages.filter(
                time => now - time < maxAge
            );

            // Clean texts
            userRequests.texts = userRequests.texts.filter(
                entry => now - entry.time < maxAge
            );

            // Remove empty records
            if (
                userRequests.global.length === 0 &&
                userRequests.commands.size === 0 &&
                userRequests.messages.length === 0 &&
                userRequests.texts.length === 0
            ) {
                this.requests.delete(userId);
            }
        }

        // Clean warnings
        for (const [userId, warnings] of this.warnings) {
            const activeWarnings = warnings.filter(
                w => now - w.timestamp < this.config.warningExpiry
            );

            if (activeWarnings.length === 0) {
                this.warnings.delete(userId);
            } else {
                this.warnings.set(userId, activeWarnings);
            }
        }

        // Clean blacklist
        for (const [userId, blacklist] of this.blacklist) {
            if (now > blacklist.until) {
                this.blacklist.delete(userId);
            }
        }
    }

    /**
     * Get rate limit statistics
     * @returns {Object} Statistics
     */
    getStats() {
        return {
            totalTracked: this.requests.size,
            blacklisted: this.blacklist.size,
            warned: this.warnings.size,
            config: this.config
        };
    }

    /**
     * Reset limits for user
     * @param {number} userId - User ID
     */
    resetUser(userId) {
        this.requests.delete(userId);
        this.blacklist.delete(userId);
        this.warnings.delete(userId);
    }
}

// Export middleware function
const rateLimiter = new RateLimiter();
export const rateLimitMiddleware = (msg, next) => rateLimiter.middleware(msg, next);
export default rateLimiter;