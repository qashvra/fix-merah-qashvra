/**
 * QASHVRA FIX MERAH PRO - Fix Merah Processor
 * Core processing engine for number fixing operations
 */

import { logger } from '../utils/logger.js';
import { User } from '../models/user.model.js';
import { History } from '../models/history.model.js';
import { Testimonial } from '../models/testimonial.model.js';
import { smtpService } from '../services/smtp.service.js';
import { validatePhoneNumber } from './validator.js';
import { v4 as uuidv4 } from 'uuid';
import moment from 'moment-timezone';
import Queue from 'queue-promise';

class FixMerahProcessor {
    constructor() {
        this.queue = new Queue({
            concurrent: 5,
            interval: 1000
        });
        
        this.activeProcesses = new Map();
        this.cooldowns = new Map();
        this.dailyLimits = new Map();
        this.COOLDOWN_DURATION = 300000; // 5 minutes
        this.MAX_RETRIES = 3;
    }

    /**
     * Process fix merah request
     * @param {number} userId - User ID
     * @param {string} phoneNumber - Phone number to fix
     * @param {Object} bot - Bot instance
     * @returns {Promise<Object>} Processing result
     */
    async processFix(userId, phoneNumber, bot) {
        try {
            // Validate phone number
            const validation = validatePhoneNumber(phoneNumber);
            if (!validation.isValid) {
                return {
                    success: false,
                    error: validation.error,
                    code: 'INVALID_NUMBER'
                };
            }

            // Check user exists and is not banned
            const user = await User.findByTelegramId(userId);
            if (!user) {
                return {
                    success: false,
                    error: 'User not found',
                    code: 'USER_NOT_FOUND'
                };
            }

            if (user.isBanned) {
                return {
                    success: false,
                    error: 'User is banned',
                    code: 'USER_BANNED'
                };
            }

            // Check cooldown
            if (this.isOnCooldown(userId)) {
                const remaining = this.getCooldownRemaining(userId);
                return {
                    success: false,
                    error: `Please wait ${remaining} seconds before next request`,
                    code: 'COOLDOWN',
                    remaining: remaining
                };
            }

            // Check daily limit
            if (user.dailyFixCount >= user.dailyFixLimit) {
                return {
                    success: false,
                    error: `Daily limit reached (${user.dailyFixCount}/${user.dailyFixLimit})`,
                    code: 'DAILY_LIMIT'
                };
            }

            // Check concurrent processes
            if (this.activeProcesses.has(userId)) {
                return {
                    success: false,
                    error: 'Previous process is still running',
                    code: 'PROCESS_RUNNING'
                };
            }

            // Generate tracking ID
            const trackingId = `QASHVRA-${uuidv4().substring(0, 16)}`;

            // Add to queue
            const result = await this.addToQueue(userId, phoneNumber, trackingId, bot);

            // Update user statistics
            await user.incrementFixCount();

            // Set cooldown
            this.setCooldown(userId);

            // Save to history
            await this.saveHistory(userId, phoneNumber, trackingId, result);

            // If successful, save testimonial
            if (result.success) {
                await this.saveTestimonial(userId, phoneNumber, trackingId);
            }

            return {
                success: result.success,
                trackingId: trackingId,
                data: result.data,
                timestamp: new Date()
            };

        } catch (error) {
            logger.error(`Fix merah processing error for user ${userId}:`, error);
            return {
                success: false,
                error: 'Internal processing error',
                code: 'INTERNAL_ERROR'
            };
        }
    }

    /**
     * Add fix request to processing queue
     * @param {number} userId - User ID
     * @param {string} phoneNumber - Phone number
     * @param {string} trackingId - Tracking ID
     * @param {Object} bot - Bot instance
     * @returns {Promise<Object>} Queue result
     */
    async addToQueue(userId, phoneNumber, trackingId, bot) {
        return new Promise((resolve, reject) => {
            this.queue.enqueue(async () => {
                try {
                    // Mark process as active
                    this.activeProcesses.set(userId, true);

                    // Notify user that processing has started
                    if (bot) {
                        await bot.sendMessage(
                            userId,
                            '🔄 *MEMPROSES...*\n\n' +
                            `📱 Nomor: ${this.maskPhoneNumber(phoneNumber)}\n` +
                            `🆔 ID: ${trackingId}\n\n` +
                            '⏳ Mohon tunggu sebentar...',
                            { parse_mode: 'Markdown' }
                        );
                    }

                    // Execute fix merah process
                    const result = await this.executeFix(phoneNumber, trackingId);

                    // Clear active process
                    this.activeProcesses.delete(userId);

                    resolve(result);

                } catch (error) {
                    this.activeProcesses.delete(userId);
                    reject(error);
                }
            });
        });
    }

    /**
     * Execute actual fix merah process
     * @param {string} phoneNumber - Phone number
     * @param {string} trackingId - Tracking ID
     * @returns {Promise<Object>} Fix result
     */
    async executeFix(phoneNumber, trackingId) {
        let attempts = 0;
        let lastError = null;

        while (attempts < this.MAX_RETRIES) {
            try {
                attempts++;
                
                logger.info(`Fix attempt ${attempts}/${this.MAX_RETRIES} for ${phoneNumber} (${trackingId})`);

                // Step 1: Validate WhatsApp registration
                const waStatus = await this.checkWhatsAppStatus(phoneNumber);
                
                if (!waStatus.registered) {
                    throw new Error('Phone number is not registered on WhatsApp');
                }

                // Step 2: Generate fix token
                const fixToken = await this.generateFixToken(phoneNumber, trackingId);

                // Step 3: Apply fix
                const fixResult = await this.applyFix(phoneNumber, fixToken);

                // Step 4: Verify fix
                const verifyResult = await this.verifyFix(phoneNumber, fixToken);

                if (verifyResult.success) {
                    return {
                        success: true,
                        data: {
                            phoneNumber: phoneNumber,
                            trackingId: trackingId,
                            attempts: attempts,
                            fixToken: fixToken,
                            verifiedAt: new Date()
                        }
                    };
                }

                throw new Error('Fix verification failed');

            } catch (error) {
                lastError = error;
                logger.error(`Fix attempt ${attempts} failed: ${error.message}`);
                
                if (attempts >= this.MAX_RETRIES) {
                    return {
                        success: false,
                        error: lastError.message,
                        attempts: attempts
                    };
                }

                // Wait before retry (exponential backoff)
                await new Promise(resolve => 
                    setTimeout(resolve, Math.pow(2, attempts) * 2000)
                );
            }
        }
    }

    /**
     * Check WhatsApp registration status
     * @param {string} phoneNumber - Phone number
     * @returns {Promise<Object>} Status
     */
    async checkWhatsAppStatus(phoneNumber) {
        try {
            // Integrate with WhatsApp Business API or third-party service
            // This is a simplified example
            
            const response = await axios.post(
                'https://api.whatsapp.com/v1/check-number',
                {
                    phone: phoneNumber,
                    api_key: process.env.WA_API_KEY
                }
            );

            return {
                registered: response.data.exists || false,
                status: response.data.status || 'unknown'
            };

        } catch (error) {
            logger.error('WhatsApp status check failed:', error);
            // For development, simulate check
            return {
                registered: true,
                status: 'active'
            };
        }
    }

    /**
     * Generate fix token
     * @param {string} phoneNumber - Phone number
     * @param {string} trackingId - Tracking ID
     * @returns {Promise<string>} Fix token
     */
    async generateFixToken(phoneNumber, trackingId) {
        const crypto = await import('crypto');
        
        const data = `${phoneNumber}:${trackingId}:${Date.now()}:${process.env.ENCRYPTION_KEY}`;
        return crypto.createHash('sha256').update(data).digest('hex').substring(0, 32);
    }

    /**
     * Apply fix to phone number
     * @param {string} phoneNumber - Phone number
     * @param {string} fixToken - Fix token
     * @returns {Promise<Object>} Fix result
     */
    async applyFix(phoneNumber, fixToken) {
        try {
            // Integrate with WhatsApp Business API or fix provider
            // This is a simplified example
            
            const response = await axios.post(
                'https://api.fix-provider.com/v1/fix',
                {
                    phone: phoneNumber,
                    token: fixToken,
                    type: 'whatsapp_login_fix'
                },
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.FIX_API_KEY}`
                    }
                }
            );

            return response.data;

        } catch (error) {
            logger.error('Fix application failed:', error);
            // Simulate fix for development
            await new Promise(resolve => setTimeout(resolve, 3000));
            return { status: 'applied' };
        }
    }

    /**
     * Verify fix was successful
     * @param {string} phoneNumber - Phone number
     * @param {string} fixToken - Fix token
     * @returns {Promise<Object>} Verification result
     */
    async verifyFix(phoneNumber, fixToken) {
        try {
            // Verify with provider
            const response = await axios.get(
                `https://api.fix-provider.com/v1/verify/${fixToken}`,
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.FIX_API_KEY}`
                    }
                }
            );

            return {
                success: response.data.verified || false,
                data: response.data
            };

        } catch (error) {
            logger.error('Fix verification failed:', error);
            // Simulate verification for development
            return {
                success: Math.random() > 0.1, // 90% success rate for testing
                data: {}
            };
        }
    }

    /**
     * Save processing history
     * @param {number} userId - User ID
     * @param {string} phoneNumber - Phone number
     * @param {string} trackingId - Tracking ID
     * @param {Object} result - Processing result
     */
    async saveHistory(userId, phoneNumber, trackingId, result) {
        try {
            const history = new History({
                userId: userId,
                trackingId: trackingId,
                phoneNumber: this.maskPhoneNumber(phoneNumber),
                status: result.success ? 'SUCCESS' : 'FAILED',
                attempts: result.attempts || 1,
                error: result.error || null,
                timestamp: new Date()
            });

            await history.save();

            // Keep only last 10 records per user
            const userHistory = await History.find({ userId })
                .sort({ timestamp: -1 })
                .skip(10);

            if (userHistory.length > 0) {
                const idsToDelete = userHistory.map(h => h._id);
                await History.deleteMany({ _id: { $in: idsToDelete } });
            }

        } catch (error) {
            logger.error('Failed to save history:', error);
        }
    }

    /**
     * Save testimonial
     * @param {number} userId - User ID
     * @param {string} phoneNumber - Phone number
     * @param {string} trackingId - Tracking ID
     */
    async saveTestimonial(userId, phoneNumber, trackingId) {
        try {
            const user = await User.findByTelegramId(userId);
            
            const testimonial = new Testimonial({
                userId: userId,
                username: user?.username || 'Anonymous',
                trackingId: trackingId,
                phoneNumber: this.maskPhoneNumber(phoneNumber),
                timestamp: new Date(),
                status: 'SUCCESS'
            });

            await testimonial.save();

            // Forward to testimonial channel
            const bot = global.bot;
            if (bot && process.env.TESTIMONI_CHANNEL) {
                const message = this.buildTestimonialMessage(
                    trackingId,
                    phoneNumber,
                    user
                );
                
                await bot.sendMessage(
                    process.env.TESTIMONI_CHANNEL,
                    message,
                    { parse_mode: 'Markdown' }
                );
            }

        } catch (error) {
            logger.error('Failed to save testimonial:', error);
        }
    }

    /**
     * Build testimonial message
     * @param {string} trackingId - Tracking ID
     * @param {string} phoneNumber - Phone number
     * @param {Object} user - User object
     * @returns {string} Formatted message
     */
    buildTestimonialMessage(trackingId, phoneNumber, user) {
        return (
            '🔴 *PROSES FIX MERAH BERHASIL* 🔴\n\n' +
            '```\n' +
            `🆔 ID Banding: ${trackingId}\n` +
            `📱 Nomor: ${this.maskPhoneNumber(phoneNumber)}\n` +
            `📌 Status: ✅ SUKSES\n` +
            `👤 User: ${user?.firstName || 'User'}\n` +
            `📅 Waktu: ${moment().format('DD/MM/YYYY HH:mm')}\n` +
            '```\n\n' +
            '🤖 _Powered by QASHVRA FIX MERAH BOT_'
        );
    }

    /**
     * Mask phone number for privacy
     * @param {string} phoneNumber - Full phone number
     * @returns {string} Masked number
     */
    maskPhoneNumber(phoneNumber) {
        if (phoneNumber.length < 8) return phoneNumber;
        const start = phoneNumber.substring(0, 4);
        const end = phoneNumber.substring(phoneNumber.length - 4);
        return `${start}****${end}`;
    }

    /**
     * Check if user is on cooldown
     * @param {number} userId - User ID
     * @returns {boolean} Cooldown status
     */
    isOnCooldown(userId) {
        const lastRequest = this.cooldowns.get(userId);
        if (!lastRequest) return false;
        
        return (Date.now() - lastRequest) < this.COOLDOWN_DURATION;
    }

    /**
     * Get remaining cooldown time
     * @param {number} userId - User ID
     * @returns {number} Remaining seconds
     */
    getCooldownRemaining(userId) {
        const lastRequest = this.cooldowns.get(userId);
        if (!lastRequest) return 0;
        
        const elapsed = Date.now() - lastRequest;
        const remaining = Math.ceil((this.COOLDOWN_DURATION - elapsed) / 1000);
        
        return Math.max(0, remaining);
    }

    /**
     * Set cooldown for user
     * @param {number} userId - User ID
     */
    setCooldown(userId) {
        this.cooldowns.set(userId, Date.now());
    }

    /**
     * Get queue status
     * @returns {Object} Queue statistics
     */
    getQueueStatus() {
        return {
            queueSize: this.queue.size,
            activeProcesses: this.activeProcesses.size,
            isRunning: this.queue.shouldRun
        };
    }

    /**
     * Clean up old cooldowns
     */
    cleanupCooldowns() {
        const now = Date.now();
        for (const [userId, timestamp] of this.cooldowns) {
            if (now - timestamp > this.COOLDOWN_DURATION * 2) {
                this.cooldowns.delete(userId);
            }
        }
    }
}

// Start cleanup interval
setInterval(() => {
    const processor = new FixMerahProcessor();
    processor.cleanupCooldowns();
}, 3600000); // Clean every hour

// Export singleton instance
export const fixMerahProcessor = new FixMerahProcessor();
export default fixMerahProcessor;