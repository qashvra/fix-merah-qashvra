/**
 * QASHVRA FIX MERAH PRO - SMTP Service
 * Professional SMTP management system with pooling, rotation, and health checking
 */

import nodemailer from 'nodemailer';
import { SMTP } from '../models/smtp.model.js';
import { logger } from '../utils/logger.js';
import { encryption } from '../utils/encryption.js';
import dns from 'dns';
import { promisify } from 'util';

const resolveMx = promisify(dns.resolveMx);

class SMTPService {
    constructor() {
        this.transporters = new Map();
        this.smtpPool = [];
        this.healthStatus = new Map();
        this.usageCount = new Map();
        this.failureCount = new Map();
        this.blacklistedDomains = new Set();
        this.warmupQueue = new Map();
    }

    /**
     * Initialize SMTP service
     */
    async initialize() {
        try {
            logger.info('Initializing SMTP service...');
            
            // Load SMTP configurations from database
            await this.loadSMTPConfigs();
            
            // Start health checker
            this.startHealthChecker();
            
            // Start auto rotation
            this.startAutoRotation();
            
            logger.info(`SMTP service initialized with ${this.smtpPool.length} servers`);
            
        } catch (error) {
            logger.error('Failed to initialize SMTP service:', error);
            throw error;
        }
    }

    /**
     * Load SMTP configurations from database
     */
    async loadSMTPConfigs() {
        try {
            const smtpConfigs = await SMTP.find({ active: true });
            
            for (const config of smtpConfigs) {
                await this.addSMTPServer(config);
            }
            
        } catch (error) {
            logger.error('Failed to load SMTP configs:', error);
        }
    }

    /**
     * Add SMTP server to pool
     * @param {Object} config - SMTP configuration
     */
    async addSMTPServer(config) {
        try {
            // Decrypt password if encrypted
            const password = config.isEncrypted 
                ? encryption.decrypt(config.password)
                : config.password;

            const transporter = nodemailer.createTransport({
                host: config.host,
                port: config.port,
                secure: config.secure,
                auth: {
                    user: config.email,
                    pass: password
                },
                pool: true,
                maxConnections: config.maxConnections || 5,
                maxMessages: config.maxMessages || 100,
                rateDelta: config.rateDelta || 1000,
                rateLimit: config.rateLimit || 5
            });

            // Verify connection
            await transporter.verify();
            
            const smtpEntry = {
                id: config._id,
                transporter: transporter,
                config: config,
                priority: config.priority || 1,
                addedAt: Date.now()
            };

            this.transporters.set(config._id.toString(), smtpEntry);
            this.smtpPool.push(smtpEntry);
            this.healthStatus.set(config._id.toString(), 'healthy');
            this.usageCount.set(config._id.toString(), 0);
            this.failureCount.set(config._id.toString(), 0);

            logger.info(`SMTP server added: ${config.email} (${config.host})`);
            
        } catch (error) {
            logger.error(`Failed to add SMTP server ${config.email}:`, error.message);
            this.healthStatus.set(config._id.toString(), 'unhealthy');
        }
    }

    /**
     * Remove SMTP server from pool
     * @param {string} id - SMTP server ID
     */
    async removeSMTPServer(id) {
        try {
            this.transporters.delete(id);
            this.smtpPool = this.smtpPool.filter(entry => entry.id !== id);
            this.healthStatus.delete(id);
            this.usageCount.delete(id);
            this.failureCount.delete(id);
            
            logger.info(`SMTP server removed: ${id}`);
        } catch (error) {
            logger.error(`Failed to remove SMTP server ${id}:`, error);
        }
    }

    /**
     * Send email using best available SMTP
     * @param {Object} options - Email options
     * @returns {Promise<Object>} Send result
     */
    async sendEmail(options) {
        try {
            const { to, subject, html, text, from, priority = 1 } = options;
            
            if (!to || !subject || (!html && !text)) {
                throw new Error('Missing required email options');
            }

            // Select best SMTP server
            const smtpEntry = await this.selectSMTPServer(priority);
            
            if (!smtpEntry) {
                throw new Error('No available SMTP servers');
            }

            // Prepare email
            const mailOptions = {
                from: from || smtpEntry.config.email,
                to: to,
                subject: subject,
                html: html,
                text: text,
                priority: 'high'
            };

            // Send email with retry
            const result = await this.sendWithRetry(smtpEntry, mailOptions);
            
            // Update statistics
            await this.updateSMTPStats(smtpEntry.id, true);
            
            return {
                success: true,
                messageId: result.messageId,
                smtpId: smtpEntry.id,
                timestamp: new Date()
            };

        } catch (error) {
            logger.error('Failed to send email:', error);
            return {
                success: false,
                error: error.message,
                timestamp: new Date()
            };
        }
    }

    /**
     * Select best SMTP server based on priority and health
     * @param {number} priority - Message priority
     * @returns {Promise<Object>} Selected SMTP entry
     */
    async selectSMTPServer(priority = 1) {
        // Filter healthy servers
        const healthyServers = this.smtpPool.filter(entry => 
            this.healthStatus.get(entry.id) === 'healthy'
        );

        if (healthyServers.length === 0) {
            logger.error('No healthy SMTP servers available');
            return null;
        }

        // Sort by priority (higher priority first) and usage count (lower first)
        const sortedServers = healthyServers.sort((a, b) => {
            // Priority matching
            const priorityDiff = Math.abs(b.priority - priority) - Math.abs(a.priority - priority);
            if (priorityDiff !== 0) return priorityDiff;
            
            // Usage count (round-robin like behavior)
            const usageA = this.usageCount.get(a.id) || 0;
            const usageB = this.usageCount.get(b.id) || 0;
            return usageA - usageB;
        });

        // Return least used server
        return sortedServers[0];
    }

    /**
     * Send email with retry mechanism
     * @param {Object} smtpEntry - SMTP server entry
     * @param {Object} mailOptions - Email options
     * @param {number} maxRetries - Maximum retry attempts
     * @returns {Promise<Object>} Send result
     */
    async sendWithRetry(smtpEntry, mailOptions, maxRetries = 3) {
        let lastError;
        
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                const result = await smtpEntry.transporter.sendMail(mailOptions);
                return result;
            } catch (error) {
                lastError = error;
                logger.warn(`SMTP send attempt ${attempt}/${maxRetries} failed for ${smtpEntry.config.email}: ${error.message}`);
                
                if (attempt < maxRetries) {
                    // Wait before retry (exponential backoff)
                    await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 1000));
                }
            }
        }
        
        // Mark server as unhealthy after all retries failed
        this.healthStatus.set(smtpEntry.id, 'unhealthy');
        await this.updateSMTPStats(smtpEntry.id, false);
        
        throw lastError;
    }

    /**
     * Start health checker
     */
    startHealthChecker() {
        setInterval(async () => {
            await this.checkAllSMTPHealth();
        }, 300000); // Check every 5 minutes
    }

    /**
     * Check health of all SMTP servers
     */
    async checkAllSMTPHealth() {
        logger.info('Running SMTP health check...');
        
        for (const smtpEntry of this.smtpPool) {
            await this.checkSMTPHealth(smtpEntry);
        }
    }

    /**
     * Check health of specific SMTP server
     * @param {Object} smtpEntry - SMTP server entry
     */
    async checkSMTPHealth(smtpEntry) {
        try {
            const isHealthy = await smtpEntry.transporter.verify();
            
            if (isHealthy) {
                this.healthStatus.set(smtpEntry.id, 'healthy');
                
                // Update database
                await SMTP.findByIdAndUpdate(smtpEntry.id, {
                    'health.lastCheck': new Date(),
                    'health.status': 'healthy',
                    'health.failCount': 0
                });
            }
        } catch (error) {
            logger.warn(`SMTP health check failed for ${smtpEntry.config.email}: ${error.message}`);
            
            this.healthStatus.set(smtpEntry.id, 'unhealthy');
            this.failureCount.set(smtpEntry.id, (this.failureCount.get(smtpEntry.id) || 0) + 1);
            
            // Update database
            await SMTP.findByIdAndUpdate(smtpEntry.id, {
                'health.lastCheck': new Date(),
                'health.status': 'unhealthy',
                'health.lastError': error.message,
                '$inc': { 'health.failCount': 1 }
            });
            
            // Auto-deactivate after too many failures
            const failCount = this.failureCount.get(smtpEntry.id) || 0;
            if (failCount >= 10) {
                await this.deactivateSMTPServer(smtpEntry.id);
            }
        }
    }

    /**
     * Deactivate unhealthy SMTP server
     * @param {string} id - SMTP server ID
     */
    async deactivateSMTPServer(id) {
        try {
            await SMTP.findByIdAndUpdate(id, { active: false });
            await this.removeSMTPServer(id);
            logger.warn(`SMTP server ${id} deactivated due to repeated failures`);
        } catch (error) {
            logger.error(`Failed to deactivate SMTP server ${id}:`, error);
        }
    }

    /**
     * Start auto rotation
     */
    startAutoRotation() {
        // Rotate every hour
        setInterval(() => {
            this.rotateSMTPConnections();
        }, 3600000);
    }

    /**
     * Rotate SMTP connections
     */
    async rotateSMTPConnections() {
        logger.info('Rotating SMTP connections...');
        
        for (const [id, transporter] of this.transporters) {
            try {
                await transporter.close();
                const config = this.getSMTPConfig(id);
                await this.addSMTPServer(config);
            } catch (error) {
                logger.error(`Failed to rotate SMTP ${id}:`, error);
            }
        }
    }

    /**
     * Update SMTP statistics
     * @param {string} id - SMTP server ID
     * @param {boolean} success - Send success status
     */
    async updateSMTPStats(id, success) {
        try {
            const update = success 
                ? {
                    '$inc': { 
                        'stats.successCount': 1,
                        'stats.totalSent': 1
                    },
                    'stats.lastUsed': new Date()
                }
                : {
                    '$inc': { 
                        'stats.failureCount': 1,
                        'stats.totalSent': 1
                    },
                    'stats.lastUsed': new Date()
                };
            
            await SMTP.findByIdAndUpdate(id, update);
            
            this.usageCount.set(id, (this.usageCount.get(id) || 0) + 1);
            
        } catch (error) {
            logger.error(`Failed to update SMTP stats for ${id}:`, error);
        }
    }

    /**
     * Check if email domain is blacklisted
     * @param {string} email - Email address
     * @returns {Promise<boolean>} Blacklist status
     */
    async isBlacklisted(email) {
        const domain = email.split('@')[1];
        
        // Check local blacklist
        if (this.blacklistedDomains.has(domain)) {
            return true;
        }
        
        try {
            // Check DNS MX records
            const mxRecords = await resolveMx(domain);
            
            if (!mxRecords || mxRecords.length === 0) {
                this.blacklistedDomains.add(domain);
                return true;
            }
            
            // Add more blacklist checks here
            // Example: Spamhaus, Barracuda, etc.
            
            return false;
        } catch (error) {
            this.blacklistedDomains.add(domain);
            return true;
        }
    }

    /**
     * Warm up new SMTP server
     * @param {Object} config - SMTP configuration
     */
    async warmupSMTPServer(config) {
        logger.info(`Starting warmup for ${config.email}`);
        
        const warmupSchedule = [1, 5, 10, 20, 50, 100, 200, 500];
        
        for (const count of warmupSchedule) {
            // Gradually increase sending volume
            await new Promise(resolve => setTimeout(resolve, 3600000)); // Wait 1 hour between steps
            logger.info(`Warmup step for ${config.email}: ${count} emails`);
        }
        
        config.warmedUp = true;
        await config.save();
        
        logger.info(`Warmup completed for ${config.email}`);
    }

    /**
     * Get SMTP statistics
     * @returns {Object} Statistics
     */
    getStatistics() {
        const stats = {
            total: this.smtpPool.length,
            healthy: 0,
            unhealthy: 0,
            servers: []
        };

        for (const smtpEntry of this.smtpPool) {
            const health = this.healthStatus.get(smtpEntry.id);
            const usage = this.usageCount.get(smtpEntry.id) || 0;
            
            if (health === 'healthy') {
                stats.healthy++;
            } else {
                stats.unhealthy++;
            }
            
            stats.servers.push({
                id: smtpEntry.id,
                email: smtpEntry.config.email,
                host: smtpEntry.config.host,
                priority: smtpEntry.priority,
                health: health,
                usageCount: usage
            });
        }

        return stats;
    }

    /**
     * Clean up resources
     */
    async cleanup() {
        for (const [id, transporter] of this.transporters) {
            await transporter.close();
        }
        this.transporters.clear();
        this.smtpPool = [];
    }
}

// Export singleton instance
export const smtpService = new SMTPService();
export default smtpService;