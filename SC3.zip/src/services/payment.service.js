/**
 * QASHVRA FIX MERAH PRO - Payment Service
 * Handles all payment processing, QRIS generation, and invoice management
 */

import QRCode from 'qrcode';
import { v4 as uuidv4 } from 'uuid';
import crypto from 'crypto';
import { logger } from '../utils/logger.js';
import { Transaction } from '../models/transaction.model.js';
import { User } from '../models/user.model.js';
import { Settings } from '../models/settings.model.js';
import { formatCurrency } from '../utils/helpers.js';
import moment from 'moment-timezone';

class PaymentService {
    constructor() {
        this.pendingPayments = new Map();
        this.paymentCheckInterval = 30000; // 30 seconds
        this.paymentTimeout = 3600000; // 1 hour
    }

    /**
     * Generate unique order ID
     * @param {string} plan - Membership plan
     * @param {number} userId - User ID
     * @param {number} duration - Duration in days
     * @returns {string} Order ID
     */
    generateOrderId(plan, userId, duration) {
        const timestamp = Date.now();
        const random = Math.floor(Math.random() * 90000) + 10000;
        const hash = crypto.createHash('md5')
            .update(`${userId}-${plan}-${timestamp}-${random}`)
            .digest('hex')
            .substring(0, 5);
        
        return `QASHVRA-${plan.toUpperCase()}-${userId}-${duration}-${random}`;
    }

    /**
     * Get plan price from settings
     * @param {string} plan - Plan type (vip/vvip)
     * @param {number} duration - Duration in days
     * @returns {Promise<number>} Plan price
     */
    async getPlanPrice(plan, duration) {
        try {
            const settings = await Settings.findOne();
            const prices = settings.premiumPrices[plan.toLowerCase()];
            return prices[duration.toString()] || 0;
        } catch (error) {
            logger.error('Failed to get plan price:', error);
            return 0;
        }
    }

    /**
     * Generate QRIS payment code
     * @param {Object} paymentData - Payment information
     * @returns {Promise<string>} QRIS code
     */
    async generateQRISCode(paymentData) {
        try {
            const { amount, orderId, merchantId } = paymentData;
            
            // QRIS standard format (simplified)
            const qrisData = {
                version: '01',
                merchantId: merchantId || process.env.PAYMENT_MERCHANT_ID,
                amount: amount.toString().padStart(10, '0'),
                orderId: orderId,
                timestamp: new Date().toISOString(),
                signature: this.generateSignature(orderId, amount)
            };

            // Generate QRIS string
            const qrisString = this.buildQRISString(qrisData);
            
            return qrisString;
        } catch (error) {
            logger.error('Failed to generate QRIS:', error);
            throw error;
        }
    }

    /**
     * Generate QR code image from QRIS data
     * @param {string} qrisData - QRIS data string
     * @returns {Promise<Buffer>} QR code image buffer
     */
    async generateQRImage(qrisData) {
        try {
            const qrBuffer = await QRCode.toBuffer(qrisData, {
                type: 'png',
                width: 400,
                margin: 2,
                color: {
                    dark: '#000000',
                    light: '#FFFFFF'
                }
            });
            
            return qrBuffer;
        } catch (error) {
            logger.error('Failed to generate QR image:', error);
            throw error;
        }
    }

    /**
     * Build QRIS string from data
     * @param {Object} data - QRIS data
     * @returns {string} QRIS string
     */
    buildQRISString(data) {
        // In production, implement actual QRIS standard
        return `QRIS:${data.merchantId}:${data.amount}:${data.orderId}:${data.signature}`;
    }

    /**
     * Generate signature for payment verification
     * @param {string} orderId - Order ID
     * @param {number} amount - Payment amount
     * @returns {string} Signature
     */
    generateSignature(orderId, amount) {
        const secret = process.env.PAYMENT_API_KEY || 'default-secret-key';
        return crypto.createHmac('sha256', secret)
            .update(`${orderId}:${amount}`)
            .digest('hex');
    }

    /**
     * Create payment invoice
     * @param {Object} params - Invoice parameters
     * @returns {Promise<Object>} Invoice data
     */
    async createInvoice(params) {
        try {
            const { userId, plan, duration, amount } = params;
            
            // Validate parameters
            if (!userId || !plan || !duration || !amount) {
                throw new Error('Missing required invoice parameters');
            }

            // Generate order ID
            const orderId = this.generateOrderId(plan, userId, duration);
            
            // Create transaction record
            const transaction = new Transaction({
                orderId: orderId,
                userId: userId,
                plan: plan.toUpperCase(),
                duration: duration,
                amount: amount,
                status: 'PENDING',
                paymentMethod: 'QRIS',
                expiresAt: new Date(Date.now() + this.paymentTimeout),
                metadata: {
                    ipAddress: params.ipAddress || 'unknown',
                    userAgent: params.userAgent || 'bot'
                }
            });

            await transaction.save();

            // Generate QRIS
            const qrisData = await this.generateQRISCode({
                orderId: orderId,
                amount: amount,
                merchantId: process.env.PAYMENT_MERCHANT_ID
            });

            // Generate QR image
            const qrImage = await this.generateQRImage(qrisData);

            // Store pending payment
            this.pendingPayments.set(orderId, {
                transaction: transaction,
                qrisData: qrisData,
                createdAt: Date.now()
            });

            // Schedule payment expiry check
            this.schedulePaymentExpiry(orderId);

            // Build invoice message
            const invoiceMessage = this.buildInvoiceMessage({
                orderId: orderId,
                plan: plan,
                duration: duration,
                amount: amount,
                userId: userId
            });

            return {
                success: true,
                data: {
                    orderId: orderId,
                    qrImage: qrImage,
                    qrisData: qrisData,
                    invoiceMessage: invoiceMessage,
                    expiresAt: transaction.expiresAt
                }
            };

        } catch (error) {
            logger.error('Failed to create invoice:', error);
            throw error;
        }
    }

    /**
     * Build invoice message text
     * @param {Object} data - Invoice data
     * @returns {string} Formatted invoice message
     */
    buildInvoiceMessage(data) {
        const { orderId, plan, duration, amount, userId } = data;
        const planName = `${plan.toUpperCase()} ${duration} Hari`;
        
        return (
            '💳 *INVOICE PEMBAYARAN*\n\n' +
            '```\n' +
            '🔖 DETAIL ORDER\n' +
            '━━━━━━━━━━━━━━━\n' +
            `📋 Order ID: ${orderId}\n` +
            `📦 Paket: ${planName}\n` +
            `👤 User ID: ${userId}\n` +
            `💰 Total: ${formatCurrency(amount)}\n` +
            `📅 Tanggal: ${moment().format('DD/MM/YYYY HH:mm')}\n` +
            `⏰ Expired: ${moment().add(1, 'hour').format('DD/MM/YYYY HH:mm')}\n` +
            '━━━━━━━━━━━━━━━\n' +
            '```\n\n' +
            '📱 *CARA PEMBAYARAN:*\n' +
            '1️⃣ Scan QRIS di atas\n' +
            '2️⃣ Buka aplikasi e-wallet/banking\n' +
            '3️⃣ Konfirmasi pembayaran\n' +
            '4️⃣ Klik tombol "SUDAH BAYAR"\n\n' +
            '⚠️ *PERHATIAN:*\n' +
            '• Pastikan nominal sesuai\n' +
            '• Pembayaran otomatis terverifikasi\n' +
            '• Invoice expired dalam 1 jam\n\n' +
            '🔐 _Powered by QASHVRA Payment System_'
        );
    }

    /**
     * Build payment confirmation button
     * @param {string} orderId - Order ID
     * @returns {Object} Inline keyboard
     */
    getPaymentKeyboard(orderId) {
        return {
            reply_markup: {
                inline_keyboard: [
                    [
                        {
                            text: '✅ SUDAH BAYAR',
                            callback_data: `payment_confirm_${orderId}`
                        }
                    ],
                    [
                        {
                            text: '❌ BATALKAN',
                            callback_data: `payment_cancel_${orderId}`
                        }
                    ],
                    [
                        {
                            text: '🔙 KEMBALI',
                            callback_data: 'menu_premium'
                        }
                    ]
                ]
            }
        };
    }

    /**
     * Verify payment status
     * @param {string} orderId - Order ID
     * @returns {Promise<Object>} Payment status
     */
    async verifyPayment(orderId) {
        try {
            const transaction = await Transaction.findOne({ orderId });
            
            if (!transaction) {
                throw new Error('Transaction not found');
            }

            // Check if already processed
            if (transaction.status === 'SUCCESS') {
                return {
                    success: true,
                    status: 'SUCCESS',
                    message: 'Pembayaran sudah diverifikasi'
                };
            }

            // Check if expired
            if (transaction.status === 'EXPIRED' || new Date() > transaction.expiresAt) {
                transaction.status = 'EXPIRED';
                await transaction.save();
                
                return {
                    success: false,
                    status: 'EXPIRED',
                    message: 'Pembayaran telah expired'
                };
            }

            // In production, integrate with payment gateway API
            // For now, simulate payment verification
            const isPaid = await this.checkPaymentGateway(orderId);
            
            if (isPaid) {
                // Update transaction
                transaction.status = 'SUCCESS';
                transaction.paidAt = new Date();
                await transaction.save();

                // Upgrade user membership
                await this.upgradeMembership(transaction);

                // Remove from pending payments
                this.pendingPayments.delete(orderId);

                return {
                    success: true,
                    status: 'SUCCESS',
                    message: 'Pembayaran berhasil diverifikasi'
                };
            }

            return {
                success: false,
                status: 'PENDING',
                message: 'Pembayaran belum terdeteksi'
            };

        } catch (error) {
            logger.error('Payment verification error:', error);
            throw error;
        }
    }

    /**
     * Check payment gateway for transaction status
     * @param {string} orderId - Order ID
     * @returns {Promise<boolean>} Payment status
     */
    async checkPaymentGateway(orderId) {
        try {
            // Integrate with actual payment gateway API
            // Example: Xendit, Midtrans, Tripay, etc.
            
            const apiKey = process.env.PAYMENT_API_KEY;
            
            // Simulate API call
            // In production, implement actual payment gateway integration
            const response = await axios.get(
                `https://api.payment-gateway.com/v1/transactions/${orderId}`,
                {
                    headers: {
                        'Authorization': `Bearer ${apiKey}`,
                        'Content-Type': 'application/json'
                    }
                }
            );
            
            return response.data.status === 'PAID';
            
        } catch (error) {
            logger.error('Payment gateway check failed:', error);
            // For development, simulate random payment success
            return Math.random() < 0.3; // 30% chance for testing
        }
    }

    /**
     * Upgrade user membership after successful payment
     * @param {Object} transaction - Transaction object
     * @returns {Promise<void>}
     */
    async upgradeMembership(transaction) {
        try {
            const user = await User.findByTelegramId(transaction.userId);
            
            if (!user) {
                throw new Error('User not found');
            }

            const durationMs = transaction.duration * 24 * 60 * 60 * 1000;
            const now = new Date();
            
            // Calculate new expiry
            let newExpiry;
            if (user.membershipExpiry && user.membershipExpiry > now) {
                // Extend existing membership
                newExpiry = new Date(user.membershipExpiry.getTime() + durationMs);
            } else {
                // New membership
                newExpiry = new Date(now.getTime() + durationMs);
            }

            // Update user
            user.status = transaction.plan;
            user.isPremium = true;
            user.membershipExpiry = newExpiry;
            user.dailyFixLimit = transaction.plan === 'VVIP' ? 10 : 5;
            
            // Add to history
            user.membershipHistory.push({
                plan: transaction.plan,
                duration: transaction.duration,
                purchasedAt: now,
                expiredAt: newExpiry,
                orderId: transaction.orderId
            });

            await user.save();

            logger.info(`Membership upgraded for user ${transaction.userId}: ${transaction.plan} ${transaction.duration} days`);

            // Send notification to user
            const bot = global.bot; // Get bot instance
            if (bot) {
                await bot.sendMessage(
                    transaction.userId,
                    '🎉 *SELAMAT!*\n\n' +
                    `Pembayaran Anda berhasil diverifikasi!\n\n` +
                    `📦 Paket: ${transaction.plan} ${transaction.duration} Hari\n` +
                    `📅 Berlaku hingga: ${moment(newExpiry).format('DD/MM/YYYY HH:mm')}\n\n` +
                    'Selamat menikmati fitur premium! 🚀',
                    { parse_mode: 'Markdown' }
                );
            }

        } catch (error) {
            logger.error('Failed to upgrade membership:', error);
            throw error;
        }
    }

    /**
     * Schedule payment expiry check
     * @param {string} orderId - Order ID
     */
    schedulePaymentExpiry(orderId) {
        setTimeout(async () => {
            try {
                const payment = this.pendingPayments.get(orderId);
                
                if (payment) {
                    const transaction = await Transaction.findOne({ orderId });
                    
                    if (transaction && transaction.status === 'PENDING') {
                        transaction.status = 'EXPIRED';
                        await transaction.save();
                        
                        this.pendingPayments.delete(orderId);
                        
                        logger.info(`Payment expired for order ${orderId}`);
                        
                        // Notify user
                        const bot = global.bot;
                        if (bot) {
                            await bot.sendMessage(
                                transaction.userId,
                                '⏰ *PEMBAYARAN EXPIRED*\n\n' +
                                `Order ID: ${orderId}\n` +
                                'Silakan buat pesanan baru.',
                                { parse_mode: 'Markdown' }
                            );
                        }
                    }
                }
            } catch (error) {
                logger.error('Payment expiry handler error:', error);
            }
        }, this.paymentTimeout);
    }

    /**
     * Cancel payment
     * @param {string} orderId - Order ID
     * @param {number} userId - User ID
     * @returns {Promise<Object>} Cancellation result
     */
    async cancelPayment(orderId, userId) {
        try {
            const transaction = await Transaction.findOne({ 
                orderId, 
                userId,
                status: 'PENDING'
            });
            
            if (!transaction) {
                throw new Error('Transaction not found or already processed');
            }

            transaction.status = 'CANCELLED';
            await transaction.save();
            
            this.pendingPayments.delete(orderId);
            
            return {
                success: true,
                message: 'Pembayaran dibatalkan'
            };
            
        } catch (error) {
            logger.error('Payment cancellation error:', error);
            throw error;
        }
    }

    /**
     * Get payment history for user
     * @param {number} userId - User ID
     * @param {number} limit - Number of records
     * @returns {Promise<Array>} Payment history
     */
    async getPaymentHistory(userId, limit = 10) {
        try {
            return await Transaction.find({ userId })
                .sort({ createdAt: -1 })
                .limit(limit);
        } catch (error) {
            logger.error('Failed to get payment history:', error);
            throw error;
        }
    }

    /**
     * Get transaction statistics
     * @returns {Promise<Object>} Statistics
     */
    async getTransactionStats() {
        try {
            const stats = await Transaction.aggregate([
                {
                    $group: {
                        _id: '$status',
                        count: { $sum: 1 },
                        totalAmount: { $sum: '$amount' }
                    }
                }
            ]);

            const totalTransactions = await Transaction.countDocuments();
            const todayTransactions = await Transaction.countDocuments({
                createdAt: {
                    $gte: new Date(new Date().setHours(0, 0, 0, 0))
                }
            });

            return {
                total: totalTransactions,
                today: todayTransactions,
                byStatus: stats
            };
        } catch (error) {
            logger.error('Failed to get transaction stats:', error);
            throw error;
        }
    }
}

// Export singleton instance
export const paymentService = new PaymentService();
export default paymentService;