/**
 * QASHVRA FIX MERAH PRO - Bot Service
 * Main Telegram bot initialization and management
 */

import TelegramBot from 'node-telegram-bot-api';
import { logger } from '../utils/logger.js';
import { loadCommands } from '../handlers/command.handler.js';
import { loadEvents } from '../events/index.js';
import { loadMiddlewares } from '../middlewares/index.js';
import { getConfig } from '../configs/bot.config.js';
import { User } from '../models/user.model.js';
import { Settings } from '../models/settings.model.js';
import chalk from 'chalk';

let bot = null;

/**
 * Initialize and start the Telegram bot
 */
export async function startBot() {
    try {
        const token = process.env.BOT_TOKEN;
        
        if (!token) {
            throw new Error('BOT_TOKEN is required in environment variables');
        }
        
        const config = getConfig();
        
        // Create bot instance with polling
        bot = new TelegramBot(token, {
            polling: true,
            ...config.options
        });
        
        logger.info(chalk.green('🤖 Bot instance created successfully'));
        
        // Load middleware system
        await loadMiddlewares(bot);
        
        // Load command handlers
        await loadCommands(bot);
        
        // Load event handlers
        await loadEvents(bot);
        
        // Setup error handling
        setupErrorHandling(bot);
        
        // Initialize bot settings in database
        await initializeSettings();
        
        // Log bot information
        const botInfo = await bot.getMe();
        logger.info(chalk.cyan(`Bot @${botInfo.username} is running...`));
        
        return bot;
        
    } catch (error) {
        logger.error(chalk.red('Failed to start bot:'), error);
        throw error;
    }
}

/**
 * Setup error handling for the bot
 */
function setupErrorHandling(bot) {
    bot.on('error', (error) => {
        logger.error('Bot error:', error);
    });
    
    bot.on('polling_error', (error) => {
        logger.error('Polling error:', error);
    });
    
    bot.on('webhook_error', (error) => {
        logger.error('Webhook error:', error);
    });
}

/**
 * Initialize settings in database
 */
async function initializeSettings() {
    try {
        const settingsCount = await Settings.countDocuments();
        
        if (settingsCount === 0) {
            const defaultSettings = new Settings({
                botName: 'QASHVRA FIX MERAH PRO',
                version: '1.0.0',
                maintenance: false,
                maxDailyFix: 2,
                referralReward: 10,
                premiumPrices: {
                    vip: {
                        '1': 1007,
                        '7': 5007,
                        '30': 15007
                    },
                    vvip: {
                        '1': 2007,
                        '30': 25007
                    }
                }
            });
            
            await defaultSettings.save();
            logger.info('Default settings initialized');
        }
    } catch (error) {
        logger.error('Failed to initialize settings:', error);
    }
}

/**
 * Get bot instance
 */
export function getBot() {
    if (!bot) {
        throw new Error('Bot not initialized');
    }
    return bot;
}

/**
 * Restart the bot
 */
export async function restartBot() {
    logger.info('Restarting bot...');
    
    if (bot) {
        await bot.stopPolling();
        bot = null;
    }
    
    await startBot();
}

export default { startBot, getBot, restartBot };