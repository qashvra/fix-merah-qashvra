/**
 * QASHVRA FIX MERAH PRO - Start Command
 * Main welcome message and user registration
 */

import { User } from '../models/user.model.js';
import { Settings } from '../models/settings.model.js';
import { logger } from '../utils/logger.js';
import { getMainMenuKeyboard } from '../keyboards/main.keyboard.js';
import { formatNumber, getRuntime, getCurrentDateTime } from '../utils/helpers.js';
import { v4 as uuidv4 } from 'uuid';
import moment from 'moment-timezone';

/**
 * Handle /start command
 * @param {Object} msg - Telegram message object
 * @param {Object} bot - Bot instance
 */
export async function handleStart(msg, bot) {
    try {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const username = msg.from.username || 'No Username';
        const firstName = msg.from.first_name || 'User';
        const lastName = msg.from.last_name || '';
        
        // Check for referral
        const startPayload = msg.text?.split(' ')[1];
        let referredBy = null;
        
        if (startPayload && startPayload !== userId.toString()) {
            referredBy = parseInt(startPayload);
        }
        
        // Find or create user
        let user = await User.findByTelegramId(userId);
        
        if (!user) {
            // Generate referral code
            const referralCode = `QASHVRA-${uuidv4().substring(0, 8).toUpperCase()}`;
            
            // Create new user
            user = new User({
                telegramId: userId,
                username: username,
                firstName: firstName,
                lastName: lastName,
                referralCode: referralCode,
                referredBy: referredBy,
                status: userId === parseInt(process.env.OWNER_ID) ? 'OWNER' : 'FREE_USER'
            });
            
            await user.save();
            logger.info(`New user registered: ${userId} (${username})`);
            
            // Handle referral
            if (referredBy) {
                await handleReferralRegistration(referredBy, userId, bot);
            }
        } else {
            // Update user info
            user.username = username;
            user.firstName = firstName;
            user.lastName = lastName;
            user.lastActive = new Date();
            await user.save();
        }
        
        // Get global statistics
        const settings = await Settings.findOne();
        const totalUsers = await User.countDocuments();
        const totalFix = await User.aggregate([
            { $group: { _id: null, total: { $sum: '$fixMerahStats.totalFix' } } }
        ]);
        
        // Calculate win rate
        const userWinRate = user.fixMerahStats.totalFix > 0 
            ? ((user.fixMerahStats.successFix / user.fixMerahStats.totalFix) * 100).toFixed(1)
            : '0.0';
        
        const globalWinRate = '100.0'; // You can calculate this dynamically
        
        // Build welcome message
        const welcomeMessage = 
            '🔴 *WELCOME TO QASHVRA FIX MERAH PRO*\n\n' +
            '👤 *INFORMASI AKUN*\n' +
            `├ 👤 Nama: ${maskName(firstName)}\n` +
            `├ 🆔 Akun ID: ${userId}\n` +
            `├ 👑 Status: ${getStatusEmoji(user.status)} ${user.status}\n` +
            `└ 📅 Bergabung: ${moment(user.joinedAt).format('DD/MM/YYYY')}\n\n` +
            '📊 *STATISTIK PRIBADI*\n' +
            `├ 🛠️ Total Fix: ${formatNumber(user.fixMerahStats.totalFix)}\n` +
            `├ 🎯 Berhasil: ${formatNumber(user.fixMerahStats.successFix)}\n` +
            `└ 📈 Win Rate: ${userWinRate}%\n\n` +
            '🌍 *STATISTIK GLOBAL*\n' +
            `├ 📧 Sender Aktif: ${formatNumber(settings?.activeSenders || 0)}/${formatNumber(settings?.totalSenders || 0)}\n` +
            `├ 👥 Pengguna: ${formatNumber(totalUsers)}\n` +
            `├ 🛠️ Total Fix: ${formatNumber(totalFix[0]?.total || 0)}\n` +
            `└ 📈 Win Rate Global: ${globalWinRate}%\n\n` +
            `⏳ *Runtime Bot:* ${getRuntime()}\n` +
            `📅 *Hari/Tanggal:* ${getCurrentDateTime()}\n\n` +
            '💡 _Gunakan tombol di bawah untuk mengakses fitur:_';
        
        // Send welcome message with premium UI
        await bot.sendPhoto(chatId, 'https://i.ibb.co/your-banner-image.jpg', {
            caption: welcomeMessage,
            parse_mode: 'Markdown',
            ...getMainMenuKeyboard()
        });
        
    } catch (error) {
        logger.error('Error in start command:', error);
        throw error;
    }
}

/**
 * Handle referral registration
 * @param {number} referrerId - Referrer's Telegram ID
 * @param {number} newUserId - New user's Telegram ID
 * @param {Object} bot - Bot instance
 */
async function handleReferralRegistration(referrerId, newUserId, bot) {
    try {
        const referrer = await User.findByTelegramId(referrerId);
        
        if (referrer && !referrer.isBanned) {
            await referrer.addReferral();
            
            // Notify referrer
            await bot.sendMessage(referrerId,
                '🎉 *REFERRAL BARU!*\n\n' +
                'Seseorang telah bergabung menggunakan link referral Anda.\n' +
                `💰 Anda mendapatkan 10 koin!\n` +
                `🪙 Total koin: ${referrer.referralCoins}`,
                { parse_mode: 'Markdown' }
            );
        }
    } catch (error) {
        logger.error('Error handling referral:', error);
    }
}

/**
 * Mask username for privacy
 * @param {string} name - Full name
 * @returns {string} Masked name
 */
function maskName(name) {
    if (name.length <= 2) return name;
    return name.substring(0, 2) + '***' + name.substring(name.length - 1);
}

/**
 * Get status emoji
 * @param {string} status - User status
 * @returns {string} Status emoji
 */
function getStatusEmoji(status) {
    const emojis = {
        'OWNER': '👑',
        'DEVELOPER': '💻',
        'ADMIN': '⚡',
        'MODERATOR': '🛡️',
        'VVIP': '💎',
        'VIP': '🌟',
        'FREE_USER': '👤'
    };
    return emojis[status] || '👤';
}

export default { handleStart };