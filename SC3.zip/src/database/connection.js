/**
 * QASHVRA FIX MERAH PRO - Database Connection
 * MongoDB connection manager with fallback support
 */

import mongoose from 'mongoose';
import { logger } from '../utils/logger.js';
import { JSONDatabase } from './fallback.js';
import chalk from 'chalk';

let isConnected = false;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;
const RECONNECT_INTERVAL = 5000; // 5 seconds

/**
 * Connect to MongoDB with auto-reconnect
 */
export async function connectDatabase() {
    try {
        const uri = process.env.MONGODB_URI;
        
        if (!uri) {
            throw new Error('MONGODB_URI is required in environment variables');
        }
        
        // Configure mongoose
        mongoose.set('strictQuery', true);
        
        // Connection options
        const options = {
            maxPoolSize: 10,
            minPoolSize: 2,
            socketTimeoutMS: 45000,
            serverSelectionTimeoutMS: 5000,
            heartbeatFrequencyMS: 10000,
            retryWrites: true,
            w: 'majority'
        };
        
        // Event listeners
        mongoose.connection.on('connected', () => {
            isConnected = true;
            reconnectAttempts = 0;
            logger.info(chalk.green('✅ MongoDB connected successfully'));
        });
        
        mongoose.connection.on('error', (error) => {
            logger.error(chalk.red('MongoDB connection error:'), error);
            isConnected = false;
        });
        
        mongoose.connection.on('disconnected', () => {
            logger.warn(chalk.yellow('MongoDB disconnected'));
            isConnected = false;
            
            if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                setTimeout(() => {
                    reconnectAttempts++;
                    logger.info(`Reconnection attempt ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS}`);
                    connectDatabase();
                }, RECONNECT_INTERVAL);
            } else {
                logger.error('Max reconnection attempts reached. Falling back to JSON database.');
                JSONDatabase.initialize();
            }
        });
        
        // Connect to MongoDB
        await mongoose.connect(uri, options);
        
        return mongoose.connection;
        
    } catch (error) {
        logger.error(chalk.red('Failed to connect to MongoDB:'), error);
        logger.info(chalk.yellow('Falling back to JSON database...'));
        
        // Initialize JSON database fallback
        await JSONDatabase.initialize();
        
        // Attempt reconnection in background
        scheduleReconnection();
        
        return null;
    }
}

/**
 * Schedule reconnection attempts
 */
function scheduleReconnection() {
    setInterval(async () => {
        if (!isConnected && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
            try {
                await mongoose.connect(process.env.MONGODB_URI);
                if (isConnected) {
                    logger.info('Reconnected to MongoDB. Syncing data...');
                    await JSONDatabase.syncToMongoDB();
                }
            } catch (error) {
                // Silently continue reconnection attempts
            }
        }
    }, RECONNECT_INTERVAL);
}

/**
 * Check database connection status
 */
export function isDatabaseConnected() {
    return isConnected && mongoose.connection.readyState === 1;
}

/**
 * Get database connection
 */
export function getConnection() {
    return mongoose.connection;
}

/**
 * Disconnect from database
 */
export async function disconnectDatabase() {
    try {
        await mongoose.disconnect();
        logger.info('Disconnected from MongoDB');
    } catch (error) {
        logger.error('Error disconnecting from MongoDB:', error);
    }
}

export default { connectDatabase, isDatabaseConnected, getConnection, disconnectDatabase };