/**
 * QASHVRA FIX MERAH PRO - Startup Banner
 * Professional startup display with system information
 */

import chalk from 'chalk';
import moment from 'moment-timezone';
import os from 'os';
import { logger } from '../utils/logger.js';

/**
 * Display startup banner
 */
export async function displayBanner() {
    // Clear console
    console.clear();
    
    // System information
    const systemInfo = {
        platform: os.platform(),
        arch: os.arch(),
        cpus: os.cpus().length,
        totalMemory: (os.totalmem() / 1024 / 1024 / 1024).toFixed(2),
        freeMemory: (os.freemem() / 1024 / 1024 / 1024).toFixed(2),
        uptime: (os.uptime() / 3600).toFixed(2),
        nodeVersion: process.version,
        timezone: moment.tz.guess(),
        currentTime: moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss')
    };

    // Display banner
    console.log('');
    console.log(chalk.red.bold('╔══════════════════════════════════════════════════════════════╗'));
    console.log(chalk.red.bold('║                                                              ║'));
    console.log(chalk.red.bold('║          🔴  QASHVRA FIX MERAH PRO  🔴                      ║'));
    console.log(chalk.red.bold('║     Professional Telegram Bot Automation System              ║'));
    console.log(chalk.red.bold('║                                                              ║'));
    console.log(chalk.red.bold('╚══════════════════════════════════════════════════════════════╝'));
    console.log('');
    
    // Version and environment
    console.log(chalk.cyan('  📦 Version: ') + chalk.white('1.0.0'));
    console.log(chalk.cyan('  🌍 Environment: ') + chalk.yellow(process.env.NODE_ENV || 'development'));
    console.log(chalk.cyan('  🕐 Time: ') + chalk.white(systemInfo.currentTime));
    console.log('');
    
    // System information
    console.log(chalk.gray('  ─────── System Information ───────'));
    console.log(chalk.blue('  🖥️  Platform: ') + chalk.white(`${systemInfo.platform} (${systemInfo.arch})`));
    console.log(chalk.blue('  💻 CPU: ') + chalk.white(`${systemInfo.cpus} cores`));
    console.log(chalk.blue('  🧠 Memory: ') + chalk.white(`${systemInfo.freeMemory}GB / ${systemInfo.totalMemory}GB`));
    console.log(chalk.blue('  ⚡ Node.js: ') + chalk.white(systemInfo.nodeVersion));
    console.log(chalk.blue('  ⏰ Uptime: ') + chalk.white(`${systemInfo.uptime} hours`));
    console.log('');
    
    // Services status (will be updated during startup)
    console.log(chalk.gray('  ─────── Services Status ───────'));
    console.log(chalk.yellow('  🔄 Initializing services...'));
    console.log('');
    
    // Divider
    console.log(chalk.gray('═'.repeat(64)));
    console.log('');
    
    // Log startup
    logger.startupBanner();
    logger.system('Bot starting up...', systemInfo);
}

/**
 * Display service status
 * @param {string} service - Service name
 * @param {string} status - Service status
 */
export function displayServiceStatus(service, status) {
    const statusIcon = status === 'connected' ? chalk.green('✅') : 
                       status === 'error' ? chalk.red('❌') : 
                       chalk.yellow('🔄');
    
    const statusText = status === 'connected' ? chalk.green('Connected') :
                       status === 'error' ? chalk.red('Failed') :
                       chalk.yellow('Connecting...');
    
    console.log(`  ${statusIcon} ${chalk.white(service)}: ${statusText}`);
}

/**
 * Display final startup status
 * @param {Object} status - Startup status object
 */
export function displayStartupStatus(status) {
    console.log('');
    console.log(chalk.gray('═'.repeat(64)));
    console.log('');
    
    const allConnected = Object.values(status).every(s => s === 'connected');
    
    if (allConnected) {
        console.log(chalk.green.bold('  ✅ All services connected successfully!'));
        console.log(chalk.green('  Bot is ready to serve requests.'));
    } else {
        console.log(chalk.yellow.bold('  ⚠️  Some services failed to connect'));
        console.log(chalk.yellow('  Bot will run with limited functionality.'));
    }
    
    console.log('');
    console.log(chalk.gray('═'.repeat(64)));
    console.log('');
    
    // Log final status
    logger.system('Startup completed', status);
}

export default { displayBanner, displayServiceStatus, displayStartupStatus };