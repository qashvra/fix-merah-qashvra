/**
 * QASHVRA FIX MERAH PRO - Startup Validator
 * Validates all requirements before bot starts
 */

import { logger } from '../utils/logger.js';
import { displayServiceStatus } from './banner.js';
import mongoose from 'mongoose';
import nodemailer from 'nodemailer';

/**
 * Validate all startup requirements
 */
export async function validateStartup() {
    logger.info('Validating startup requirements...');
    
    const status = {
        env: 'checking',
        mongodb: 'checking',
        telegram: 'checking',
        smtp: 'checking',
        directories: 'checking',
        permissions: 'checking'
    };

    try {
        // Validate environment variables
        await validateEnvironment();
        status.env = 'connected';
        displayServiceStatus('Environment', 'connected');

        // Validate directories
        await validateDirectories();
        status.directories = 'connected';
        displayServiceStatus('Directories', 'connected');

        // Validate MongoDB connection (async, don't block)
        validateMongoDB().then(() => {
            status.mongodb = 'connected';
            displayServiceStatus('MongoDB', 'connected');
        }).catch(() => {
            status.mongodb = 'error';
            displayServiceStatus('MongoDB', 'error');
        });

        // Validate Telegram token
        await validateTelegramToken();
        status.telegram = 'connected';
        displayServiceStatus('Telegram', 'connected');

        // Validate SMTP (async, don't block)
        validateSMTP().then(() => {
            status.smtp = 'connected';
            displayServiceStatus('SMTP', 'connected');
        }).catch(() => {
            status.smtp = 'error';
            displayServiceStatus('SMTP', 'error');
        });

        // Validate permissions
        await validatePermissions();
        status.permissions = 'connected';
        displayServiceStatus('Permissions', 'connected');

        return status;

    } catch (error) {
        logger.error('Startup validation failed:', error);
        throw error;
    }
}

/**
 * Validate environment variables
 */
async function validateEnvironment() {
    const requiredVars = [
        'BOT_TOKEN',
        'OWNER_ID',
        'MONGODB_URI'
    ];

    const missing = [];
    
    for (const varName of requiredVars) {
        if (!process.env[varName]) {
            missing.push(varName);
        }
    }

    if (missing.length > 0) {
        throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
    }

    // Validate specific variables
    if (!process.env.BOT_TOKEN.includes(':')) {
        throw new Error('Invalid BOT_TOKEN format');
    }

    if (isNaN(parseInt(process.env.OWNER_ID))) {
        throw new Error('OWNER_ID must be a number');
    }
}

/**
 * Validate required directories exist
 */
async function validateDirectories() {
    const fs = await import('fs-extra');
    const path = await import('path');
    
    const requiredDirs = [
        'logs',
        'logs/daily',
        'logs/errors',
        'logs/access',
        'assets',
        'assets/images',
        'assets/videos',
        'backups',
        'temp'
    ];

    for (const dir of requiredDirs) {
        const dirPath = path.join(process.cwd(), dir);
        await fs.ensureDir(dirPath);
    }
}

/**
 * Validate MongoDB connection
 */
async function validateMongoDB() {
    try {
        const uri = process.env.MONGODB_URI;
        
        // Test connection
        const testConnection = await mongoose.createConnection(uri).asPromise();
        await testConnection.close();
        
        return true;
    } catch (error) {
        logger.warn('MongoDB validation failed, will use fallback:', error.message);
        return false;
    }
}

/**
 * Validate Telegram bot token
 */
async function validateTelegramToken() {
    try {
        const axios = (await import('axios')).default;
        const token = process.env.BOT_TOKEN;
        
        const response = await axios.get(
            `https://api.telegram.org/bot${token}/getMe`
        );
        
        if (!response.data.ok) {
            throw new Error('Invalid bot token');
        }
        
        logger.info(`Bot validated: @${response.data.result.username}`);
        return true;
        
    } catch (error) {
        throw new Error(`Telegram token validation failed: ${error.message}`);
    }
}

/**
 * Validate SMTP configuration
 */
async function validateSMTP() {
    try {
        if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
            logger.warn('SMTP not configured, email features will be disabled');
            return false;
        }

        // Test SMTP connection
        const transporter = nodemailer.createTransport({
            host: process.env.SMTP_HOST,
            port: parseInt(process.env.SMTP_PORT) || 587,
            secure: process.env.SMTP_SECURE === 'true',
            auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS
            }
        });

        await transporter.verify();
        await transporter.close();
        
        return true;
        
    } catch (error) {
        logger.warn('SMTP validation failed:', error.message);
        return false;
    }
}

/**
 * Validate file permissions
 */
async function validatePermissions() {
    const fs = await import('fs-extra');
    const path = await import('path');
    
    const writableDirs = [
        'logs',
        'backups',
        'temp'
    ];

    for (const dir of writableDirs) {
        const dirPath = path.join(process.cwd(), dir);
        
        try {
            // Test write permission
            const testFile = path.join(dirPath, '.test');
            await fs.writeFile(testFile, 'test');
            await fs.remove(testFile);
        } catch (error) {
            logger.warn(`Directory ${dir} is not writable:`, error.message);
        }
    }
}

export default { validateStartup };