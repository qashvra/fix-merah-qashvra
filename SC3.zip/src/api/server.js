/**
 * QASHVRA FIX MERAH PRO - API Server
 * Express server for webhooks, payment callbacks, and external API
 */

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import { logger } from '../utils/logger.js';
import { paymentService } from '../services/payment.service.js';
import { User } from '../models/user.model.js';
import jwt from 'jsonwebtoken';

class APIServer {
    constructor() {
        this.app = express();
        this.port = process.env.API_PORT || 3000;
        this.setupMiddleware();
        this.setupRoutes();
    }

    /**
     * Setup Express middleware
     */
    setupMiddleware() {
        // Security middleware
        this.app.use(helmet());
        this.app.use(cors({
            origin: process.env.ALLOWED_ORIGINS?.split(',') || '*',
            methods: ['GET', 'POST', 'PUT', 'DELETE'],
            allowedHeaders: ['Content-Type', 'Authorization']
        }));

        // Compression
        this.app.use(compression());

        // Body parsing
        this.app.use(express.json({ limit: '10mb' }));
        this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));

        // Rate limiting
        const limiter = rateLimit({
            windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
            max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
            message: {
                success: false,
                error: 'Too many requests, please try again later'
            }
        });
        this.app.use('/api/', limiter);

        // Request logging
        this.app.use((req, res, next) => {
            logger.info(`${req.method} ${req.path} - ${req.ip}`);
            next();
        });
    }

    /**
     * Setup API routes
     */
    setupRoutes() {
        // Health check endpoint
        this.app.get('/health', (req, res) => {
            res.json({
                success: true,
                service: 'QASHVRA FIX MERAH PRO API',
                version: '1.0.0',
                timestamp: new Date(),
                uptime: process.uptime()
            });
        });

        // Payment webhook endpoint
        this.app.post('/webhook/payment', async (req, res) => {
            try {
                const { orderId, status, signature } = req.body;

                // Verify webhook signature
                if (!this.verifyWebhookSignature(req.body, signature)) {
                    return res.status(401).json({
                        success: false,
                        error: 'Invalid signature'
                    });
                }

                // Process payment notification
                if (status === 'PAID') {
                    await paymentService.verifyPayment(orderId);
                }

                res.json({
                    success: true,
                    message: 'Webhook processed'
                });

            } catch (error) {
                logger.error('Payment webhook error:', error);
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // API routes with authentication
        this.app.use('/api', this.authenticateAPI);

        // Get bot statistics
        this.app.get('/api/stats', async (req, res) => {
            try {
                const totalUsers = await User.countDocuments();
                const premiumUsers = await User.countDocuments({ isPremium: true });
                const activeToday = await User.countDocuments({
                    lastActive: {
                        $gte: new Date(new Date().setHours(0, 0, 0, 0))
                    }
                });

                const stats = {
                    totalUsers,
                    premiumUsers,
                    activeToday,
                    registrationRate: ((premiumUsers / totalUsers) * 100).toFixed(2) + '%'
                };

                res.json({
                    success: true,
                    data: stats
                });

            } catch (error) {
                logger.error('Stats API error:', error);
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Get user information
        this.app.get('/api/users/:userId', async (req, res) => {
            try {
                const user = await User.findByTelegramId(req.params.userId);
                
                if (!user) {
                    return res.status(404).json({
                        success: false,
                        error: 'User not found'
                    });
                }

                res.json({
                    success: true,
                    data: {
                        telegramId: user.telegramId,
                        username: user.username,
                        status: user.status,
                        isPremium: user.isPremium,
                        referralCount: user.referralCount,
                        fixStats: user.fixMerahStats
                    }
                });

            } catch (error) {
                logger.error('User API error:', error);
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Broadcast message endpoint
        this.app.post('/api/broadcast', async (req, res) => {
            try {
                const { message, target } = req.body;
                const bot = global.bot;

                if (!bot) {
                    return res.status(500).json({
                        success: false,
                        error: 'Bot not initialized'
                    });
                }

                let users;
                if (target === 'all') {
                    users = await User.find({ isBanned: false });
                } else if (target === 'premium') {
                    users = await User.find({ isPremium: true, isBanned: false });
                } else {
                    return res.status(400).json({
                        success: false,
                        error: 'Invalid target'
                    });
                }

                let sent = 0;
                let failed = 0;

                for (const user of users) {
                    try {
                        await bot.sendMessage(user.telegramId, message, {
                            parse_mode: 'Markdown'
                        });
                        sent++;
                        await new Promise(resolve => setTimeout(resolve, 50)); // Rate limit
                    } catch (error) {
                        failed++;
                    }
                }

                res.json({
                    success: true,
                    data: {
                        total: users.length,
                        sent,
                        failed
                    }
                });

            } catch (error) {
                logger.error('Broadcast API error:', error);
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // SMTP management endpoints
        this.app.get('/api/smtp/status', async (req, res) => {
            try {
                const { smtpService } = await import('../services/smtp.service.js');
                const stats = smtpService.getStatistics();
                
                res.json({
                    success: true,
                    data: stats
                });
            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Queue status endpoint
        this.app.get('/api/queue/status', async (req, res) => {
            try {
                const { fixMerahProcessor } = await import('../fixmerah/processor.js');
                const status = fixMerahProcessor.getQueueStatus();
                
                res.json({
                    success: true,
                    data: status
                });
            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // 404 handler
        this.app.use('*', (req, res) => {
            res.status(404).json({
                success: false,
                error: 'Endpoint not found'
            });
        });

        // Error handler
        this.app.use((error, req, res, next) => {
            logger.error('API Error:', error);
            res.status(500).json({
                success: false,
                error: process.env.NODE_ENV === 'production' 
                    ? 'Internal server error' 
                    : error.message
            });
        });
    }

    /**
     * API authentication middleware
     * @param {Object} req - Express request
     * @param {Object} res - Express response
     * @param {Function} next - Next middleware
     */
    authenticateAPI(req, res, next) {
        const apiKey = req.headers['x-api-key'] || req.query.api_key;

        if (!apiKey || apiKey !== process.env.API_KEY) {
            return res.status(401).json({
                success: false,
                error: 'Invalid API key'
            });
        }

        next();
    }

    /**
     * Verify webhook signature
     * @param {Object} payload - Webhook payload
     * @param {string} signature - Provided signature
     * @returns {boolean} Valid signature
     */
    verifyWebhookSignature(payload, signature) {
        try {
            const crypto = require('crypto');
            const expected = crypto
                .createHmac('sha256', process.env.PAYMENT_API_KEY)
                .update(JSON.stringify(payload))
                .digest('hex');

            return signature === expected;
        } catch (error) {
            logger.error('Signature verification error:', error);
            return false;
        }
    }

    /**
     * Start API server
     */
    async start() {
        return new Promise((resolve, reject) => {
            this.server = this.app.listen(this.port, () => {
                logger.info(`🌐 API Server running on port ${this.port}`);
                resolve(this.server);
            });

            this.server.on('error', (error) => {
                logger.error('API Server error:', error);
                reject(error);
            });
        });
    }

    /**
     * Stop API server
     */
    async stop() {
        if (this.server) {
            return new Promise((resolve) => {
                this.server.close(() => {
                    logger.info('API Server stopped');
                    resolve();
                });
            });
        }
    }
}

// Export start function
export const startAPIServer = async () => {
    const server = new APIServer();
    await server.start();
    return server;
};

export default APIServer;