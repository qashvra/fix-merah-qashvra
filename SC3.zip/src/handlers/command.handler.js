/**
 * QASHVRA FIX MERAH PRO - Command Handler
 * Central command registration and routing system
 */

import fs from 'fs-extra';
import path from 'path';
import { logger } from '../utils/logger.js';
import { User } from '../models/user.model.js';
import { Settings } from '../models/settings.model.js';
import { requirePermission, PERMISSION_LEVELS } from '../middlewares/permission.middleware.js';
import { verificationMiddleware } from '../middlewares/verification.middleware.js';
import { rateLimitMiddleware } from '../middlewares/ratelimit.middleware.js';

class CommandHandler {
    constructor() {
        this.commands = new Map();
        this.aliases = new Map();
        this.categories = new Map();
        this.prefixes = ['/', '!', '.'];
    }

    /**
     * Load all commands
     * @param {Object} bot - Bot instance
     */
    async loadCommands(bot) {
        try {
            logger.info('Loading commands...');
            
            // Register built-in commands
            await this.registerBuiltInCommands(bot);
            
            // Load commands from directory
            const commandsDir = path.join(process.cwd(), 'src', 'commands');
            
            if (await fs.pathExists(commandsDir)) {
                const files = await fs.readdir(commandsDir);
                
                for (const file of files) {
                    if (file.endsWith('.command.js')) {
                        try {
                            const commandModule = await import(`../commands/${file}`);
                            const command = commandModule.default || commandModule;
                            
                            if (command.name && command.execute) {
                                this.registerCommand(command);
                            }
                        } catch (error) {
                            logger.error(`Failed to load command ${file}:`, error);
                        }
                    }
                }
            }
            
            logger.info(`Loaded ${this.commands.size} commands`);
            
            // Setup message listener
            this.setupMessageListener(bot);
            
        } catch (error) {
            logger.error('Failed to load commands:', error);
            throw error;
        }
    }

    /**
     * Register built-in commands
     * @param {Object} bot - Bot instance
     */
    async registerBuiltInCommands(bot) {
        // Start command
        this.registerCommand({
            name: 'start',
            description: 'Mulai bot dan tampilkan menu utama',
            category: 'general',
            level: PERMISSION_LEVELS.FREE_USER,
            execute: async (msg, args) => {
                const { handleStart } = await import('../commands/start.command.js');
                await handleStart(msg, bot);
            }
        });

        // Help command
        this.registerCommand({
            name: 'help',
            description: 'Tampilkan bantuan',
            category: 'general',
            level: PERMISSION_LEVELS.FREE_USER,
            execute: async (msg) => {
                await this.showHelp(msg, bot);
            }
        });

        // Status command
        this.registerCommand({
            name: 'status',
            description: 'Cek status akun',
            category: 'general',
            level: PERMISSION_LEVELS.FREE_USER,
            execute: async (msg) => {
                await this.showStatus(msg, bot);
            }
        });

        // Admin command
        this.registerCommand({
            name: 'admin',
            description: 'Panel admin',
            category: 'admin',
            level: PERMISSION_LEVELS.ADMIN,
            execute: async (msg) => {
                const { handleAdmin } = await import('../commands/admin.command.js');
                await handleAdmin(msg, bot);
            }
        });

        // Owner command
        this.registerCommand({
            name: 'owner',
            description: 'Panel owner',
            category: 'owner',
            level: PERMISSION_LEVELS.OWNER,
            execute: async (msg) => {
                const { handleOwner } = await import('../commands/owner.command.js');
                await handleOwner(msg, bot);
            }
        });

        // Fix command
        this.registerCommand({
            name: 'fix',
            description: 'Fix nomor WhatsApp',
            category: 'fixmerah',
            level: PERMISSION_LEVELS.FREE_USER,
            execute: async (msg) => {
                const { handleFix } = await import('../commands/fixmerah.command.js');
                await handleFix(msg, bot);
            }
        });

        // Referral command
        this.registerCommand({
            name: 'referral',
            description: 'Menu referral',
            aliases: ['ref', 'undang'],
            category: 'referral',
            level: PERMISSION_LEVELS.FREE_USER,
            execute: async (msg) => {
                const { handleReferral } = await import('../commands/referral.command.js');
                await handleReferral(msg, bot);
            }
        });

        // History command
        this.registerCommand({
            name: 'history',
            description: 'Riwayat fix',
            aliases: ['riwayat'],
            category: 'general',
            level: PERMISSION_LEVELS.FREE_USER,
            execute: async (msg) => {
                const { handleHistory } = await import('../commands/history.command.js');
                await handleHistory(msg, bot);
            }
        });

        // Premium command
        this.registerCommand({
            name: 'premium',
            description: 'Menu premium',
            aliases: ['vip', 'vvip'],
            category: 'premium',
            level: PERMISSION_LEVELS.FREE_USER,
            execute: async (msg) => {
                const { handlePremium } = await import('../commands/premium.command.js');
                await handlePremium(msg, bot);
            }
        });

        // Leaderboard command
        this.registerCommand({
            name: 'leaderboard',
            description: 'Top global',
            aliases: ['top', 'rank'],
            category: 'general',
            level: PERMISSION_LEVELS.FREE_USER,
            execute: async (msg) => {
                const { handleLeaderboard } = await import('../commands/leaderboard.command.js');
                await handleLeaderboard(msg, bot);
            }
        });
    }

    /**
     * Register a command
     * @param {Object} command - Command object
     */
    registerCommand(command) {
        if (!command.name) {
            throw new Error('Command must have a name');
        }

        // Register main command
        this.commands.set(command.name.toLowerCase(), command);

        // Register aliases
        if (command.aliases) {
            for (const alias of command.aliases) {
                this.aliases.set(alias.toLowerCase(), command.name.toLowerCase());
            }
        }

        // Register category
        if (command.category) {
            if (!this.categories.has(command.category)) {
                this.categories.set(command.category, []);
            }
            this.categories.get(command.category).push(command.name);
        }

        logger.debug(`Registered command: ${command.name}`);
    }

    /**
     * Setup message listener for commands
     * @param {Object} bot - Bot instance
     */
    setupMessageListener(bot) {
        bot.on('message', async (msg) => {
            try {
                // Skip if no text
                if (!msg.text) return;

                // Check for command prefix
                const prefix = this.detectPrefix(msg.text);
                if (!prefix) return;

                // Parse command and arguments
                const args = msg.text.slice(prefix.length).trim().split(/ +/);
                const commandName = args.shift().toLowerCase();

                // Find command
                const command = this.findCommand(commandName);
                if (!command) return;

                // Log command usage
                logger.userAction(msg.from.id, `Command: ${command.name}`, {
                    args: args,
                    chatId: msg.chat.id
                });

                // Apply middleware chain
                await this.executeMiddlewareChain(msg, command, async () => {
                    await command.execute(msg, args, bot);
                });

            } catch (error) {
                logger.error('Command execution error:', error);
                await this.handleCommandError(msg, error, bot);
            }
        });
    }

    /**
     * Detect command prefix
     * @param {string} text - Message text
     * @returns {string|null} Detected prefix
     */
    detectPrefix(text) {
        for (const prefix of this.prefixes) {
            if (text.startsWith(prefix)) {
                return prefix;
            }
        }
        return null;
    }

    /**
     * Find command by name or alias
     * @param {string} name - Command name
     * @returns {Object|null} Command object
     */
    findCommand(name) {
        // Direct command lookup
        if (this.commands.has(name)) {
            return this.commands.get(name);
        }

        // Alias lookup
        if (this.aliases.has(name)) {
            const commandName = this.aliases.get(name);
            return this.commands.get(commandName);
        }

        return null;
    }

    /**
     * Execute middleware chain
     * @param {Object} msg - Message object
     * @param {Object} command - Command object
     * @param {Function} next - Next function
     */
    async executeMiddlewareChain(msg, command, next) {
        const middlewares = [
            rateLimitMiddleware,
            verificationMiddleware
        ];

        // Add permission middleware if command has level requirement
        if (command.level) {
            middlewares.push(requirePermission(command.level));
        }

        // Execute middleware chain
        let index = 0;
        
        const execute = async () => {
            if (index < middlewares.length) {
                const middleware = middlewares[index];
                index++;
                
                try {
                    await middleware(msg, execute);
                } catch (error) {
                    throw error;
                }
            } else {
                await next();
            }
        };

        await execute();
    }

    /**
     * Handle command execution error
     * @param {Object} msg - Message object
     * @param {Error} error - Error object
     * @param {Object} bot - Bot instance
     */
    async handleCommandError(msg, error, bot) {
        const errorMessage = error.message || 'Terjadi kesalahan internal';
        
        await bot.sendMessage(
            msg.chat.id,
            `❌ *ERROR*\n\n${errorMessage}\n\n_Silakan coba lagi atau hubungi admin._`,
            { parse_mode: 'Markdown' }
        );
    }

    /**
     * Show help message
     * @param {Object} msg - Message object
     * @param {Object} bot - Bot instance
     */
    async showHelp(msg, bot) {
        const user = await User.findByTelegramId(msg.from.id);
        const userLevel = PERMISSION_LEVELS[user?.status] || 1;

        let helpMessage = '📚 *BANTUAN QASHVRA FIX MERAH PRO*\n\n';
        helpMessage += 'Berikut adalah perintah yang tersedia:\n\n';

        // Group commands by category
        for (const [category, commands] of this.categories) {
            const categoryCommands = commands
                .map(cmd => this.commands.get(cmd))
                .filter(cmd => cmd && (!cmd.level || cmd.level <= userLevel));

            if (categoryCommands.length > 0) {
                helpMessage += `*${category.toUpperCase()}*\n`;
                
                for (const cmd of categoryCommands) {
                    helpMessage += `/${cmd.name}`;
                    if (cmd.aliases) {
                        helpMessage += ` (${cmd.aliases.map(a => `/${a}`).join(', ')})`;
                    }
                    helpMessage += ` - ${cmd.description}\n`;
                }
                
                helpMessage += '\n';
            }
        }

        helpMessage += '💡 _Gunakan tombol menu untuk navigasi yang lebih mudah._';

        await bot.sendMessage(msg.chat.id, helpMessage, {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [[
                    { text: '🔙 KEMBALI KE MENU', callback_data: 'menu_main' }
                ]]
            }
        });
    }

    /**
     * Show user status
     * @param {Object} msg - Message object
     * @param {Object} bot - Bot instance
     */
    async showStatus(msg, bot) {
        const user = await User.findByTelegramId(msg.from.id);
        
        if (!user) {
            return bot.sendMessage(msg.chat.id, '❌ User tidak ditemukan');
        }

        const settings = await Settings.getSettings();
        const cooldownRemaining = fixMerahProcessor?.getCooldownRemaining(msg.from.id) || 0;

        const statusMessage = 
            '📊 *STATUS AKUN*\n\n' +
            '👤 *INFORMASI*\n' +
            `├ Nama: ${user.firstName}\n` +
            `├ Username: @${user.username || 'N/A'}\n` +
            `├ Status: ${user.status}\n` +
            `└ Premium: ${user.isPremium ? '✅' : '❌'}\n\n` +
            '📊 *STATISTIK*\n' +
            `├ Total Fix: ${user.fixMerahStats.totalFix}\n` +
            `├ Berhasil: ${user.fixMerahStats.successFix}\n` +
            `├ Gagal: ${user.fixMerahStats.failedFix}\n` +
            `└ Win Rate: ${user.fixMerahStats.totalFix > 0 ? ((user.fixMerahStats.successFix / user.fixMerahStats.totalFix) * 100).toFixed(1) : 0}%\n\n` +
            '🔄 *LIMIT*\n' +
            `├ Harian: ${user.dailyFixCount}/${user.dailyFixLimit}\n` +
            `├ Cooldown: ${cooldownRemaining > 0 ? `${cooldownRemaining}s` : 'Siap'}\n` +
            `├ Koin: ${user.referralCoins}\n` +
            `└ Referral: ${user.referralCount}\n\n` +
            (user.membershipExpiry ? 
                `📅 *PREMIUM*\n└ Expired: ${user.membershipExpiry.toLocaleString('id-ID')}\n\n` : 
                '') +
            `⏰ *TERAKHIR AKTIF*\n└ ${user.lastActive.toLocaleString('id-ID')}`;

        await bot.sendMessage(msg.chat.id, statusMessage, {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [[
                    { text: '🔙 KEMBALI', callback_data: 'menu_main' }
                ]]
            }
        });
    }

    /**
     * Reload commands (hot reload)
     */
    async reloadCommands(bot) {
        logger.info('Reloading commands...');
        this.commands.clear();
        this.aliases.clear();
        this.categories.clear();
        await this.loadCommands(bot);
        logger.info('Commands reloaded successfully');
    }
}

// Export singleton instance
export const commandHandler = new CommandHandler();
export const loadCommands = (bot) => commandHandler.loadCommands(bot);
export default commandHandler;