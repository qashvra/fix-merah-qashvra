/**
 * QASHVRA FIX MERAH PRO - PM2 Ecosystem Configuration
 * Production process manager configuration
 */

module.exports = {
    apps: [
        {
            // Main bot process
            name: 'qashvra-fix-merah',
            script: 'index.js',
            instances: 1,
            exec_mode: 'fork',
            watch: false,
            max_memory_restart: '2G',
            env: {
                NODE_ENV: 'production',
                PORT: 3000
            },
            error_file: './logs/pm2/error.log',
            out_file: './logs/pm2/output.log',
            log_file: './logs/pm2/combined.log',
            time: true,
            kill_timeout: 5000,
            listen_timeout: 3000,
            restart_delay: 4000,
            max_restarts: 10,
            autorestart: true,
            cron_restart: '0 3 * * *', // Restart at 3 AM daily
            merge_logs: true,
            log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
            env_production: {
                NODE_ENV: 'production'
            },
            env_development: {
                NODE_ENV: 'development'
            }
        },
        {
            // API server (optional, separate process)
            name: 'qashvra-api',
            script: 'src/api/server.js',
            instances: 2,
            exec_mode: 'cluster',
            watch: false,
            max_memory_restart: '1G',
            env: {
                NODE_ENV: 'production',
                PORT: 3000
            },
            error_file: './logs/pm2/api-error.log',
            out_file: './logs/pm2/api-output.log',
            merge_logs: true,
            log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
            autorestart: true,
            max_restarts: 10,
            env_production: {
                NODE_ENV: 'production'
            }
        },
        {
            // Queue worker (for heavy tasks)
            name: 'qashvra-worker',
            script: 'src/services/queue.service.js',
            instances: 4,
            exec_mode: 'cluster',
            watch: false,
            max_memory_restart: '1G',
            env: {
                NODE_ENV: 'production'
            },
            error_file: './logs/pm2/worker-error.log',
            out_file: './logs/pm2/worker-output.log',
            merge_logs: true,
            log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
            autorestart: true,
            max_restarts: 5,
            env_production: {
                NODE_ENV: 'production'
            }
        },
        {
            // Scheduled tasks
            name: 'qashvra-scheduler',
            script: 'src/scheduler/tasks.js',
            instances: 1,
            exec_mode: 'fork',
            watch: false,
            max_memory_restart: '500M',
            env: {
                NODE_ENV: 'production'
            },
            error_file: './logs/pm2/scheduler-error.log',
            out_file: './logs/pm2/scheduler-output.log',
            merge_logs: true,
            log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
            autorestart: true,
            max_restarts: 5,
            cron_restart: '0 4 * * *', // Restart at 4 AM daily
            env_production: {
                NODE_ENV: 'production'
            }
        }
    ],
    
    deploy: {
        production: {
            user: 'deploy',
            host: process.env.DEPLOY_HOST || 'your-server.com',
            ref: 'origin/main',
            repo: 'git@github.com:qashvra/qashvra-fix-merah-pro.git',
            path: '/var/www/qashvra-fix-merah',
            'post-deploy': 'npm install && pm2 reload ecosystem.config.js --env production',
            'pre-setup': 'apt update && apt install git nodejs npm -y'
        }
    }
};