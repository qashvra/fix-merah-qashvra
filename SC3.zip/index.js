/**
 * QASHVRA FIX MERAH PRO - Main Entry Point
 * Professional Telegram Bot Automation System
 * Version: 1.0.0
 */

import 'dotenv/config';
import { startBot } from './src/services/bot.service.js';
import { connectDatabase } from './src/database/connection.js';
import { validateStartup } from './src/startup/validator.js';
import { displayBanner } from './src/startup/banner.js';
import { logger } from './src/utils/logger.js';

/**
 * Main application initialization
 * Handles startup sequence with proper error handling
 */
async function initializeApp() {
    try {
        // Display startup banner
        await displayBanner();
        
        logger.info('🚀 Initializing QASHVRA FIX MERAH PRO...');
        
        // Validate startup requirements
        await validateStartup();
        
        // Connect to MongoDB
        await connectDatabase();
        
        // Start Telegram Bot
        await startBot();
        
        // Start API Server (optional)
        if (process.env.API_PORT) {
            const { startAPIServer } = await import('./src/api/server.js');
            await startAPIServer();
        }
        
        logger.info('✅ QASHVRA FIX MERAH PRO is fully operational!');
        
        // Graceful shutdown handlers
        setupGracefulShutdown();
        
    } catch (error) {
        logger.error('❌ Failed to initialize application:', error);
        process.exit(1);
    }
}

/**
 * Setup graceful shutdown handlers
 */
function setupGracefulShutdown() {
    const shutdown = async (signal) => {
        logger.info(`\n${signal} received. Shutting down gracefully...`);
        
        try {
            // Close MongoDB connection
            const mongoose = await import('mongoose');
            await mongoose.disconnect();
            logger.info('MongoDB connection closed.');
            
            // Add other cleanup tasks here
            
            process.exit(0);
        } catch (error) {
            logger.error('Error during shutdown:', error);
            process.exit(1);
        }
    };
    
    // Listen for shutdown signals
    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('uncaughtException', (error) => {
        logger.error('Uncaught Exception:', error);
        shutdown('uncaughtException');
    });
    process.on('unhandledRejection', (reason, promise) => {
        logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
        shutdown('unhandledRejection');
    });
}

// Start the application
initializeApp();