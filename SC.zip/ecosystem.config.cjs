module.exports = {
  apps: [{
    name: 'qashvra-bot',
    script: 'src/app.js',
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
    },
    error_file: 'logs/pm2-error.log',
    out_file: 'logs/pm2-out.log',
    log_file: 'logs/pm2-combined.log',
    time: true,
    kill_timeout: 5000,
    restart_delay: 4000,
    max_restarts: 10,
    min_uptime: '10s',
    listen_timeout: 3000,
    shutdown_with_message: true,
    cron_restart: '0 0 * * *', // Restart every midnight
    instance_var: 'INSTANCE_ID',
    merge_logs: true,
    autorestart: true,
    vizion: false
  }]
};