import nodemailer from 'nodemailer';
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import { Logger } from '../utils/logger.js';
import { EventEmitter } from 'events';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const logger = new Logger();

class SmtpPoolManager extends EventEmitter {
  constructor() {
    super();
    this.accounts = [];
    this.transporters = new Map();
    this.currentIndex = 0;
    this.smtpDbPath = path.join(__dirname, '../../data/smtp.json');
    this.locks = new Map();
    this.healthCheckInterval = null;
    this.settings = {
      rollingMethod: 'round_robin',
      maxRetryPerEmail: 3,
      retryDelayMs: 5000,
      autoResetHour: 0,
      healthCheckIntervalMs: 300000,
      maxConcurrentPerAccount: 5,
      cooldownAfterFailMs: 60000,
      notificationEmail: process.env.SMTP_USER || ''
    };
  }

  async initialize() {
    try {
      await this.loadSmtpAccounts();
      await this.initializeTransporters();
      this.startHealthCheck();
      this.startAutoReset();
      
      const activeAccounts = this.accounts.filter(a => a.status === 'active');
      logger.success(`SMTP Pool initialized with ${activeAccounts.length}/${this.accounts.length} active accounts`);
      
      return true;
    } catch (error) {
      logger.error('Failed to initialize SMTP Pool:', error);
      throw error;
    }
  }

  async loadSmtpAccounts() {
    try {
      const exists = await fs.pathExists(this.smtpDbPath);
      
      if (!exists) {
        // Buat default dari .env
        const defaultSmtp = {
          smtp_accounts: [{
            id: 'smtp_default',
            email: process.env.SMTP_USER || 'default@gmail.com',
            password: process.env.SMTP_PASS || '',
            dailyLimit: 500,
            dailyUsed: 0,
            status: process.env.SMTP_USER ? 'active' : 'inactive',
            lastUsed: null,
            lastReset: new Date().toISOString(),
            successCount: 0,
            failedCount: 0,
            priority: 1,
            addedAt: new Date().toISOString()
          }],
          settings: this.settings
        };
        
        await fs.ensureDir(path.dirname(this.smtpDbPath));
        await fs.writeJson(this.smtpDbPath, defaultSmtp, { spaces: 2 });
        logger.info('Created default SMTP database from .env configuration');
      }
      
      const data = await fs.readJson(this.smtpDbPath);
      this.accounts = data.smtp_accounts || [];
      
      // Merge settings
      if (data.settings) {
        this.settings = { ...this.settings, ...data.settings };
      }
      
      logger.info(`Loaded ${this.accounts.length} SMTP accounts`);
      
    } catch (error) {
      logger.error('Failed to load SMTP accounts:', error);
      
      // Fallback: gunakan .env saja
      if (process.env.SMTP_USER && process.env.SMTP_PASS) {
        this.accounts = [{
          id: 'smtp_fallback',
          email: process.env.SMTP_USER,
          password: process.env.SMTP_PASS,
          dailyLimit: 500,
          dailyUsed: 0,
          status: 'active',
          lastUsed: null,
          lastReset: new Date().toISOString(),
          successCount: 0,
          failedCount: 0,
          priority: 1,
          addedAt: new Date().toISOString()
        }];
        logger.info('Using fallback SMTP from .env');
      } else {
        throw new Error('No SMTP configuration available');
      }
    }
  }

  async saveSmtpDatabase() {
    try {
      const data = {
        smtp_accounts: this.accounts,
        settings: this.settings
      };
      
      await fs.ensureDir(path.dirname(this.smtpDbPath));
      await fs.writeJson(this.smtpDbPath, data, { spaces: 2 });
    } catch (error) {
      logger.error('Failed to save SMTP database:', error);
    }
  }

  async initializeTransporters() {
    this.transporters.clear();
    
    for (const account of this.accounts) {
      if (account.status === 'active') {
        await this.createTransporter(account);
      }
    }
    
    logger.info(`Initialized ${this.transporters.size} transporters`);
  }

  async createTransporter(account) {
    try {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST || 'smtp.gmail.com',
        port: parseInt(process.env.SMTP_PORT) || 587,
        secure: false,
        auth: {
          user: account.email,
          pass: account.password
        },
        pool: true,
        maxConnections: this.settings.maxConcurrentPerAccount || 5,
        maxMessages: Infinity,
        rateDelta: 1000,
        rateLimit: 20,
        tls: {
          rejectUnauthorized: false
        }
      });

      // Verifikasi koneksi
      await transporter.verify();
      
      this.transporters.set(account.id, {
        transporter,
        account
      });
      
      logger.success(`Transporter created for ${account.email}`);
      return transporter;
      
    } catch (error) {
      logger.error(`Failed to create transporter for ${account.email}:`, error.message);
      
      // Tandai akun error
      account.status = 'error';
      account.lastError = error.message;
      account.lastErrorAt = new Date().toISOString();
      await this.saveSmtpDatabase();
      
      return null;
    }
  }

  // 🔄 METODE ROLLING

  async getNextAccount(method = null) {
    const rollingMethod = method || this.settings.rollingMethod;
    
    // Filter akun yang tersedia
    const availableAccounts = this.accounts.filter(a => 
      a.status === 'active' && 
      a.dailyUsed < a.dailyLimit &&
      !this.isAccountLocked(a.id)
    );

    if (availableAccounts.length === 0) {
      // Cek apakah ada akun yang mendekati limit
      const nearLimitAccounts = this.accounts.filter(a => 
        a.status === 'active' && 
        a.dailyUsed >= a.dailyLimit * 0.9
      );
      
      if (nearLimitAccounts.length > 0) {
        logger.warning(`All accounts near limit! Using account closest to reset`);
        return this.getLeastUsedAccount(this.accounts.filter(a => a.status === 'active'));
      }
      
      // Coba reset jika sudah waktunya
      await this.checkAndResetLimits();
      
      throw new Error('No SMTP accounts available - all limits reached');
    }

    let selectedAccount = null;

    switch (rollingMethod) {
      case 'round_robin':
        selectedAccount = this.getRoundRobinAccount(availableAccounts);
        break;
        
      case 'least_used':
        selectedAccount = this.getLeastUsedAccount(availableAccounts);
        break;
        
      case 'random':
        selectedAccount = this.getRandomAccount(availableAccounts);
        break;
        
      case 'priority':
        selectedAccount = this.getPriorityAccount(availableAccounts);
        break;
        
      default:
        selectedAccount = this.getRoundRobinAccount(availableAccounts);
    }

    // Lock account untuk mencegah overuse
    this.lockAccount(selectedAccount.id);
    
    return selectedAccount;
  }

  getRoundRobinAccount(accounts) {
    accounts.sort((a, b) => a.id.localeCompare(b.id));
    const index = this.currentIndex % accounts.length;
    const account = accounts[index];
    this.currentIndex++;
    
    logger.info(`🔄 Round Robin: ${account.email} (${account.dailyUsed}/${account.dailyLimit})`);
    return account;
  }

  getLeastUsedAccount(accounts) {
    const sorted = accounts.sort((a, b) => a.dailyUsed - b.dailyUsed);
    logger.info(`📊 Least Used: ${sorted[0].email} (${sorted[0].dailyUsed}/${sorted[0].dailyLimit})`);
    return sorted[0];
  }

  getRandomAccount(accounts) {
    const randomIndex = Math.floor(Math.random() * accounts.length);
    logger.info(`🎲 Random: ${accounts[randomIndex].email}`);
    return accounts[randomIndex];
  }

  getPriorityAccount(accounts) {
    const sorted = accounts.sort((a, b) => a.priority - b.priority);
    logger.info(`⭐ Priority: ${sorted[0].email} (priority: ${sorted[0].priority})`);
    return sorted[0];
  }

  // 🔒 CONCURRENCY CONTROL

  lockAccount(accountId) {
    const currentLocks = this.locks.get(accountId) || 0;
    this.locks.set(accountId, currentLocks + 1);
  }

  unlockAccount(accountId) {
    const currentLocks = this.locks.get(accountId) || 0;
    if (currentLocks > 0) {
      this.locks.set(accountId, currentLocks - 1);
    }
  }

  isAccountLocked(accountId) {
    const currentLocks = this.locks.get(accountId) || 0;
    return currentLocks >= (this.settings.maxConcurrentPerAccount || 5);
  }

  // 📧 KIRIM EMAIL DENGAN AUTO-ROLLING

  async sendEmail(mailOptions, attemptNumber = 0) {
    const maxRetries = this.settings.maxRetryPerEmail || 3;
    let lastError = null;
    let usedAccount = null;
    
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        // Dapatkan akun yang tersedia
        const account = await this.getNextAccount();
        usedAccount = account;
        
        // Dapatkan atau buat transporter
        let transporterData = this.transporters.get(account.id);
        
        if (!transporterData || !transporterData.transporter) {
          logger.info(`Creating new transporter for ${account.email}...`);
          const newTransporter = await this.createTransporter(account);
          
          if (!newTransporter) {
            this.unlockAccount(account.id);
            continue; // Coba akun lain
          }
          
          transporterData = { transporter: newTransporter, account };
        }
        
        // Kirim email
        const info = await transporterData.transporter.sendMail({
          ...mailOptions,
          from: mailOptions.from || `"Qashvra Support" <${account.email}>`,
        });
        
        // Update statistik
        await this.updateAccountStats(account, true);
        this.unlockAccount(account.id);
        
        logger.success(`✅ Email sent via ${account.email}: ${mailOptions.subject} (ID: ${info.messageId})`);
        
        this.emit('emailSent', {
          account: account.email,
          messageId: info.messageId,
          subject: mailOptions.subject,
          to: mailOptions.to,
          timestamp: new Date().toISOString()
        });
        
        return {
          success: true,
          messageId: info.messageId,
          account: account.email,
          attempt: attempt + 1
        };
        
      } catch (error) {
        lastError = error;
        
        if (usedAccount) {
          await this.updateAccountStats(usedAccount, false);
          this.unlockAccount(usedAccount.id);
          
          // Tandai error jika perlu
          if (error.code === 'EAUTH' || error.responseCode === 535) {
            usedAccount.status = 'error';
            usedAccount.lastError = 'Authentication failed';
            usedAccount.lastErrorAt = new Date().toISOString();
            await this.saveSmtpDatabase();
            logger.error(`Auth failed for ${usedAccount.email} - marked as error`);
          }
        }
        
        logger.error(`Send attempt ${attempt + 1}/${maxRetries + 1} failed: ${error.message}`);
        
        if (attempt < maxRetries) {
          const delay = this.settings.retryDelayMs * Math.pow(2, attempt);
          logger.info(`Retrying in ${delay}ms...`);
          await this.delay(delay);
        }
      }
    }
    
    // Semua percobaan gagal
    this.emit('emailFailed', {
      error: lastError?.message || 'Unknown error',
      subject: mailOptions.subject,
      to: mailOptions.to,
      attempts: maxRetries + 1,
      timestamp: new Date().toISOString()
    });
    
    throw new Error(`Failed to send email after ${maxRetries + 1} attempts: ${lastError?.message}`);
  }

  async updateAccountStats(account, success) {
    const acc = this.accounts.find(a => a.id === account.id);
    if (!acc) return;
    
    acc.dailyUsed = (acc.dailyUsed || 0) + 1;
    acc.lastUsed = new Date().toISOString();
    
    if (success) {
      acc.successCount = (acc.successCount || 0) + 1;
    } else {
      acc.failedCount = (acc.failedCount || 0) + 1;
      
      // Turunkan prioritas jika terlalu banyak gagal
      if (acc.failedCount > 10) {
        acc.priority = (acc.priority || 1) + 1;
        logger.warning(`Account ${acc.email} priority decreased to ${acc.priority}`);
      }
    }
    
    await this.saveSmtpDatabase();
  }

  // 🩺 HEALTH CHECK

  startHealthCheck() {
    const interval = this.settings.healthCheckIntervalMs || 300000;
    
    this.healthCheckInterval = setInterval(async () => {
      await this.checkAllAccountsHealth();
    }, interval);
    
    logger.info(`Health check started (interval: ${interval / 1000}s)`);
  }

  async checkAllAccountsHealth() {
    let recoveredCount = 0;
    
    for (const account of this.accounts) {
      try {
        let transporterData = this.transporters.get(account.id);
        
        if (!transporterData || !transporterData.transporter) {
          // Coba buat ulang
          const newTransporter = await this.createTransporter(account);
          
          if (newTransporter && account.status === 'error') {
            account.status = 'active';
            account.lastError = null;
            recoveredCount++;
            logger.success(`Recovered SMTP: ${account.email}`);
          }
        } else {
          // Verify existing
          await transporterData.transporter.verify();
          
          if (account.status === 'error') {
            account.status = 'active';
            account.lastError = null;
            recoveredCount++;
            logger.success(`Recovered SMTP: ${account.email}`);
          }
        }
      } catch (error) {
        if (account.status === 'active') {
          account.status = 'error';
          account.lastError = error.message;
          account.lastErrorAt = new Date().toISOString();
          logger.warning(`SMTP ${account.email} health check failed: ${error.message}`);
        }
      }
    }
    
    if (recoveredCount > 0) {
      logger.success(`Health check: ${recoveredCount} account(s) recovered`);
      await this.saveSmtpDatabase();
    }
  }

  // 🔄 AUTO RESET DAILY LIMIT

  startAutoReset() {
    setInterval(async () => {
      await this.checkAndResetLimits();
    }, 60000); // Cek setiap menit
    
    logger.info('Auto-reset daily limit started');
  }

  async checkAndResetLimits() {
    const now = new Date();
    const resetHour = this.settings.autoResetHour || 0;
    
    if (now.getHours() === resetHour && now.getMinutes() === 0) {
      await this.resetDailyLimits();
    }
  }

  async resetDailyLimits() {
    let resetCount = 0;
    
    for (const account of this.accounts) {
      if (account.dailyUsed > 0) {
        account.dailyUsed = 0;
        account.lastReset = new Date().toISOString();
        resetCount++;
      }
    }
    
    if (resetCount > 0) {
      logger.success(`Reset ${resetCount} SMTP account daily limits`);
      await this.saveSmtpDatabase();
    }
  }

  // 👥 ADMIN FUNCTIONS

  async addSmtpAccount(email, password, dailyLimit = 500, priority = 1) {
    // Cek duplikat
    const exists = this.accounts.find(a => a.email === email);
    if (exists) {
      throw new Error(`SMTP account ${email} already exists`);
    }
    
    const newAccount = {
      id: `smtp_${Date.now()}`,
      email,
      password,
      dailyLimit,
      dailyUsed: 0,
      status: 'active',
      lastUsed: null,
      lastReset: new Date().toISOString(),
      successCount: 0,
      failedCount: 0,
      priority,
      addedAt: new Date().toISOString()
    };
    
    this.accounts.push(newAccount);
    
    // Buat transporter
    await this.createTransporter(newAccount);
    
    await this.saveSmtpDatabase();
    logger.success(`SMTP account added: ${email} (limit: ${dailyLimit}/day)`);
    
    return newAccount;
  }

  async removeSmtpAccount(accountId) {
    const index = this.accounts.findIndex(a => a.id === accountId);
    
    if (index === -1) {
      throw new Error(`SMTP account ${accountId} not found`);
    }
    
    const removed = this.accounts.splice(index, 1)[0];
    
    // Tutup transporter
    const transporterData = this.transporters.get(accountId);
    if (transporterData?.transporter) {
      transporterData.transporter.close();
    }
    this.transporters.delete(accountId);
    
    await this.saveSmtpDatabase();
    logger.success(`SMTP account removed: ${removed.email}`);
    
    return removed;
  }

  async toggleAccountStatus(accountId) {
    const account = this.accounts.find(a => a.id === accountId);
    
    if (!account) {
      throw new Error(`SMTP account ${accountId} not found`);
    }
    
    const newStatus = account.status === 'active' ? 'inactive' : 'active';
    account.status = newStatus;
    
    if (newStatus === 'active') {
      await this.createTransporter(account);
    } else {
      const transporterData = this.transporters.get(accountId);
      if (transporterData?.transporter) {
        transporterData.transporter.close();
      }
      this.transporters.delete(accountId);
    }
    
    await this.saveSmtpDatabase();
    logger.info(`SMTP ${account.email} status: ${newStatus}`);
    
    return account;
  }

  async updateAccountPriority(accountId, priority) {
    const account = this.accounts.find(a => a.id === accountId);
    
    if (!account) {
      throw new Error(`SMTP account ${accountId} not found`);
    }
    
    account.priority = priority;
    await this.saveSmtpDatabase();
    logger.info(`SMTP ${account.email} priority set to ${priority}`);
    
    return account;
  }

  async updateAccountLimit(accountId, dailyLimit) {
    const account = this.accounts.find(a => a.id === accountId);
    
    if (!account) {
      throw new Error(`SMTP account ${accountId} not found`);
    }
    
    account.dailyLimit = dailyLimit;
    await this.saveSmtpDatabase();
    logger.info(`SMTP ${account.email} daily limit set to ${dailyLimit}`);
    
    return account;
  }

  async updateRollingMethod(method) {
    const validMethods = ['round_robin', 'least_used', 'random', 'priority'];
    
    if (!validMethods.includes(method)) {
      throw new Error(`Invalid rolling method: ${method}. Valid: ${validMethods.join(', ')}`);
    }
    
    this.settings.rollingMethod = method;
    await this.saveSmtpDatabase();
    logger.info(`Rolling method changed to: ${method}`);
    
    return method;
  }

  // 📊 STATUS & MONITORING

  getStatus() {
    const totalSent = this.accounts.reduce((sum, a) => sum + (a.successCount || 0), 0);
    const totalFailed = this.accounts.reduce((sum, a) => sum + (a.failedCount || 0), 0);
    const totalProcessed = totalSent + totalFailed;
    const activeAccounts = this.accounts.filter(a => a.status === 'active');
    
    return {
      totalAccounts: this.accounts.length,
      activeAccounts: activeAccounts.length,
      inactiveAccounts: this.accounts.filter(a => a.status === 'inactive').length,
      errorAccounts: this.accounts.filter(a => a.status === 'error').length,
      totalSent,
      totalFailed,
      totalProcessed,
      successRate: totalProcessed > 0 ? ((totalSent / totalProcessed) * 100).toFixed(2) : 0,
      rollingMethod: this.settings.rollingMethod,
      maxConcurrent: this.settings.maxConcurrentPerAccount,
      accounts: this.accounts.map(a => ({
        id: a.id,
        email: a.email,
        status: a.status,
        dailyUsed: a.dailyUsed || 0,
        dailyLimit: a.dailyLimit || 500,
        usagePercent: a.dailyLimit > 0 ? (((a.dailyUsed || 0) / a.dailyLimit) * 100).toFixed(1) : 0,
        successCount: a.successCount || 0,
        failedCount: a.failedCount || 0,
        priority: a.priority || 1,
        locked: this.isAccountLocked(a.id),
        lastUsed: a.lastUsed,
        lastError: a.lastError || null
      }))
    };
  }

  getActiveTransporterCount() {
    return this.transporters.size;
  }

  getLockCount() {
    let totalLocks = 0;
    for (const locks of this.locks.values()) {
      totalLocks += locks;
    }
    return totalLocks;
  }

  // 🛠 UTILITY

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async shutdown() {
    logger.info('Shutting down SMTP Pool Manager...');
    
    // Stop health check
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
    
    // Save current state
    await this.saveSmtpDatabase();
    
    // Close all transporters
    for (const [id, data] of this.transporters) {
      if (data.transporter) {
        try {
          data.transporter.close();
          logger.info(`Closed transporter: ${data.account.email}`);
        } catch (error) {
          logger.warning(`Error closing transporter ${data.account.email}: ${error.message}`);
        }
      }
    }
    
    this.transporters.clear();
    this.locks.clear();
    
    logger.success('SMTP Pool Manager shutdown complete');
  }
}

// Create and export singleton instance
const smtpPool = new SmtpPoolManager();

export { SmtpPoolManager, smtpPool };
export default smtpPool;