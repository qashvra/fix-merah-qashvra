import QRCode from 'qrcode';
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from '../utils/logger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const logger = new Logger();

class QRISGenerator {
  constructor() {
    this.qrisDir = path.join(__dirname, '../../assets/qris');
    this.staticQRIS = process.env.QRIS_STATIC || '';
    fs.ensureDirSync(this.qrisDir);
  }

  async generateDynamicQRIS(amount, orderId) {
    try {
      // Create dynamic QRIS with amount
      const dynamicQRIS = this.createDynamicQRISString(amount, orderId);
      
      // Generate QR code image
      const fileName = `qris_${orderId}_${Date.now()}.png`;
      const filePath = path.join(this.qrisDir, fileName);
      
      await QRCode.toFile(filePath, dynamicQRIS, {
        color: {
          dark: '#000000',
          light: '#ffffff'
        },
        width: 500,
        margin: 2
      });
      
      logger.success(`QRIS generated for order ${orderId}: Rp ${amount}`);
      
      return {
        filePath,
        fileName,
        qrisString: dynamicQRIS
      };
    } catch (error) {
      logger.error('Failed to generate QRIS:', error);
      throw error;
    }
  }

  createDynamicQRISString(amount, orderId) {
    // Use static QRIS and modify with dynamic amount
    let qrisString = this.staticQRIS;
    
    try {
      // QRIS format: Amount is usually at position after "54" tag
      // Format: 54 + 2-digit length + amount
      const amountStr = amount.toString();
      const amountLength = amountStr.length.toString().padStart(2, '0');
      const amountTag = `54${amountLength}${amountStr}`;
      
      // Try to insert/replace amount tag
      if (qrisString.includes('54')) {
        qrisString = qrisString.replace(/54\d{2}\d+/, amountTag);
      }
      
      // Add unique order ID for tracking
      const orderTag = `62${orderId.length.toString().padStart(2, '0')}${orderId}`;
      qrisString += orderTag;
      
    } catch (error) {
      logger.warning('Could not modify QRIS string, using static');
    }
    
    return qrisString;
  }

  async cleanupOldQRIS(maxAgeHours = 24) {
    try {
      const files = await fs.readdir(this.qrisDir);
      const cutoffTime = Date.now() - (maxAgeHours * 3600000);
      
      for (const file of files) {
        const filePath = path.join(this.qrisDir, file);
        const stats = await fs.stat(filePath);
        
        if (stats.mtimeMs < cutoffTime) {
          await fs.remove(filePath);
          logger.info(`Cleaned up old QRIS: ${file}`);
        }
      }
    } catch (error) {
      logger.error('Failed to cleanup QRIS files:', error);
    }
  }
}

export const qrisGenerator = new QRISGenerator();