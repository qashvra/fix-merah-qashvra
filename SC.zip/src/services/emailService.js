import nodemailer from 'nodemailer';
import { DatabaseManager } from '../database/init.js';
import { Logger } from '../utils/logger.js';

const logger = new Logger();
const templatesDB = new DatabaseManager('templates');

class EmailService {
  constructor() {
    this.transporter = null;
    this.retryAttempts = 3;
    this.retryDelay = 5000;
    this.successCount = 0;
    this.failedCount = 0;
    this.initialized = false;
  }

  async initialize() {
    try {
      this.transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT),
        secure: false,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS
        },
        tls: {
          rejectUnauthorized: false
        }
      });

      // Verify connection
      await this.transporter.verify();
      this.initialized = true;
      logger.success('Email service initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize email service:', error);
      throw error;
    }
  }

  async sendEmail({ to, subject, body, templateName = null, replyTo = null }) {
    if (!this.initialized) {
      throw new Error('Email service not initialized');
    }

    try {
      let emailBody = body;
      
      // Use template if specified
      if (templateName) {
        const template = await templatesDB.findOne(t => 
          t.name === templateName && t.type === 'email'
        );
        
        if (template) {
          subject = template.subject || subject;
          emailBody = template.body.replace(/\{\{content\}\}/g, body);
        }
      }

      const mailOptions = {
        from: `"Qashvra Support" <${process.env.SMTP_USER}>`,
        to: to,
        subject: subject,
        html: emailBody,
        replyTo: replyTo || process.env.SMTP_USER
      };

      // Send with retry
      const result = await this.sendWithRetry(mailOptions);
      
      this.successCount++;
      logger.success(`Email sent to ${to}: ${subject}`);
      
      return result;
    } catch (error) {
      this.failedCount++;
      logger.error(`Failed to send email to ${to}:`, error);
      throw error;
    }
  }

  async sendWithRetry(mailOptions, attempt = 0) {
    try {
      return await this.transporter.sendMail(mailOptions);
    } catch (error) {
      if (attempt < this.retryAttempts) {
        logger.warning(`Email retry attempt ${attempt + 1}/${this.retryAttempts}`);
        await this.delay(this.retryDelay * (attempt + 1));
        return this.sendWithRetry(mailOptions, attempt + 1);
      }
      throw error;
    }
  }

  async sendWelcomeEmail(userEmail, userName) {
    const template = await templatesDB.findOne(t => t.name === 'welcome');
    
    return this.sendEmail({
      to: userEmail,
      subject: 'Selamat Datang di Qashvra! 🎉',
      body: template ? template.body : this.getDefaultWelcomeTemplate(userName),
      templateName: 'welcome'
    });
  }

  async sendPaymentConfirmation(userEmail, orderDetails) {
    return this.sendEmail({
      to: userEmail,
      subject: 'Pembayaran Berhasil - Qashvra',
      body: this.getPaymentTemplate(orderDetails),
      templateName: 'payment_success'
    });
  }

  async sendSubscriptionActivated(userEmail, planDetails) {
    return this.sendEmail({
      to: userEmail,
      subject: `Langganan ${planDetails.plan} Aktif! 🎉`,
      body: this.getSubscriptionTemplate(planDetails),
      templateName: 'subscription_activated'
    });
  }

  getDefaultWelcomeTemplate(userName) {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #FF0000;">Qashvra Bot</h1>
        <h2>Selamat Datang, ${userName}! 🎉</h2>
        <p>Terima kasih telah bergabung dengan Qashvra Bot.</p>
        <p>Nikmati berbagai fitur premium kami:</p>
        <ul>
          <li>🔴 Fix Merah</li>
          <li>👑 Program VIP/VVIP</li>
          <li>🧧 Sistem Referral</li>
          <li>Dan masih banyak lagi!</li>
        </ul>
        <p>Jika ada pertanyaan, silakan hubungi support kami.</p>
        <br>
        <p>Best regards,<br>Qashvra Team</p>
      </div>
    `;
  }

  getPaymentTemplate(orderDetails) {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #FF0000;">Qashvra</h1>
        <h2>Pembayaran Berhasil ✅</h2>
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td>Order ID</td>
            <td>: ${orderDetails.orderId}</td>
          </tr>
          <tr>
            <td>Plan</td>
            <td>: ${orderDetails.plan}</td>
          </tr>
          <tr>
            <td>Amount</td>
            <td>: Rp ${orderDetails.amount}</td>
          </tr>
          <tr>
            <td>Status</td>
            <td>: Aktif</td>
          </tr>
        </table>
        <p>Langganan Anda telah aktif. Selamat menikmati!</p>
        <br>
        <p>Qashvra Team</p>
      </div>
    `;
  }

  getSubscriptionTemplate(planDetails) {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #FF0000;">Qashvra</h1>
        <h2>Langganan Aktif! 🎉</h2>
        <p>Selamat! Langganan ${planDetails.plan} Anda telah aktif.</p>
        <p>Berlaku hingga: ${planDetails.expiryDate}</p>
        <p>Nikmati semua fitur premium Qashvra!</p>
        <br>
        <p>Qashvra Team</p>
      </div>
    `;
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  getStats() {
    return {
      successCount: this.successCount,
      failedCount: this.failedCount,
      initialized: this.initialized
    };
  }
}

export const emailService = new EmailService();