import os from 'os';
import { Logger } from './logger.js';
import { DatabaseManager } from '../database/init.js';

const logger = new Logger();
const statsDB = new DatabaseManager('statistics');

class HealthMonitor {
  constructor() {
    this.startTime = Date.now();
    this.metrics = {
      cpu: [],
      memory: [],
      users: 0,
      activeUsers: 0
    };
    this.monitorInterval = null;
    this.backupInterval = null;
  }

  startMonitoring() {
    // Update metrics every 30 seconds
    this.monitorInterval = setInterval(() => {
      this.collectMetrics();
    }, 30000);

    // Backup database every hour
    this.backupInterval = setInterval(() => {
      this.performBackup();
    }, 3600000);

    logger.success('Health monitoring started');
  }

  async stop() {
    if (this.monitorInterval) clearInterval(this.monitorInterval);
    if (this.backupInterval) clearInterval(this.backupInterval);
    
    await this.performBackup(); // Final backup
    logger.success('Health monitoring stopped');
  }

  async collectMetrics() {
    try {
      const cpuUsage = this.getCPUUsage();
      const memoryUsage = this.getMemoryUsage();
      const uptime = this.getUptime();
      
      this.metrics.cpu.push(cpuUsage);
      this.metrics.memory.push(memoryUsage);
      
      // Keep only last 100 metrics
      if (this.metrics.cpu.length > 100) {
        this.metrics.cpu = this.metrics.cpu.slice(-100);
        this.metrics.memory = this.metrics.memory.slice(-100);
      }
      
      // Update statistics database
      await statsDB.update(data => {
        data.global.uptime = uptime;
        return data;
      });
      
    } catch (error) {
      logger.error('Failed to collect metrics:', error);
    }
  }

  getCPUUsage() {
    const cpus = os.cpus();
    const totalIdle = cpus.reduce((acc, cpu) => acc + cpu.times.idle, 0);
    const totalTick = cpus.reduce((acc, cpu) => {
      return acc + Object.values(cpu.times).reduce((a, b) => a + b, 0);
    }, 0);
    
    const idlePercentage = (totalIdle / totalTick) * 100;
    return 100 - idlePercentage;
  }

  getMemoryUsage() {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    
    return {
      total: this.formatBytes(totalMem),
      used: this.formatBytes(usedMem),
      free: this.formatBytes(freeMem),
      usagePercent: ((usedMem / totalMem) * 100).toFixed(2)
    };
  }

  getUptime() {
    const uptime = process.uptime();
    const days = Math.floor(uptime / 86400);
    const hours = Math.floor((uptime % 86400) / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    
    return {
      seconds: uptime,
      formatted: `${days}d ${hours}h ${minutes}m ${seconds}s`,
      days,
      hours,
      minutes,
      seconds
    };
  }

  getStatus() {
    return {
      uptime: this.getUptime(),
      cpu: this.getCPUUsage(),
      memory: this.getMemoryUsage(),
      platform: os.platform(),
      nodeVersion: process.version,
      timestamp: new Date().toISOString()
    };
  }

  formatBytes(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  async performBackup() {
    try {
      logger.info('Performing database backup...');
      
      // Implementation depends on database type
      // For JSON, just copy the data directory
      
      logger.success('Database backup completed');
    } catch (error) {
      logger.error('Backup failed:', error);
    }
  }
}

export { HealthMonitor };