// src/utils/generateAssets.js
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import { createCanvas } from 'canvas'; // Need to install: npm install canvas
import chalk from 'chalk';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function generateAssets() {
  console.log(chalk.blue('🎨 Generating placeholder assets...\n'));

  // Create canvas for banner
  const width = 800;
  const height = 400;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  // Background gradient
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, '#FF0000');
  gradient.addColorStop(1, '#8B0000');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  // Text
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 48px Arial';
  ctx.textAlign = 'center';
  ctx.fillText('QASHVRA BOT', width / 2, height / 2 - 20);

  ctx.font = '24px Arial';
  ctx.fillText('Premium Digital Solutions', width / 2, height / 2 + 40);

  // Save main banner
  const bannerBuffer = canvas.toBuffer('image/jpeg');
  await fs.writeFile(path.join(__dirname, '../../assets/images/banner.jpg'), bannerBuffer);
  console.log(chalk.green('✅ Banner generated: assets/images/banner.jpg'));

  // Generate Fix Merah banner
  ctx.fillStyle = '#DC143C';
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 36px Arial';
  ctx.fillText('🔴 FIX MERAH', width / 2, height / 2);
  ctx.font = '20px Arial';
  ctx.fillText('Solusi Digital Profesional', width / 2, height / 2 + 40);

  const fixMerahBuffer = canvas.toBuffer('image/jpeg');
  await fs.writeFile(path.join(__dirname, '../../assets/images/fixmerah.jpg'), fixMerahBuffer);
  console.log(chalk.green('✅ Fix Merah banner generated'));

  // Generate default QRIS placeholder
  const qrisCanvas = createCanvas(400, 400);
  const qrisCtx = qrisCanvas.getContext('2d');
  
  qrisCtx.fillStyle = '#FFFFFF';
  qrisCtx.fillRect(0, 0, 400, 400);
  
  qrisCtx.fillStyle = '#000000';
  qrisCtx.font = '20px Arial';
  qrisCtx.textAlign = 'center';
  qrisCtx.fillText('QRIS Payment', 200, 180);
  qrisCtx.fillText('QASHVRA', 200, 220);

  const qrisBuffer = qrisCanvas.toBuffer('image/png');
  await fs.writeFile(path.join(__dirname, '../../assets/qris/default.png'), qrisBuffer);
  console.log(chalk.green('✅ Default QRIS generated'));

  // Generate VIP badge
  const badgeCanvas = createCanvas(200, 200);
  const badgeCtx = badgeCanvas.getContext('2d');
  
  badgeCtx.fillStyle = '#FFD700';
  badgeCtx.beginPath();
  badgeCtx.arc(100, 100, 90, 0, Math.PI * 2);
  badgeCtx.fill();
  
  badgeCtx.fillStyle = '#000000';
  badgeCtx.font = 'bold 36px Arial';
  badgeCtx.textAlign = 'center';
  badgeCtx.fillText('VIP', 100, 115);

  const badgeBuffer = badgeCanvas.toBuffer('image/png');
  await fs.writeFile(path.join(__dirname, '../../assets/images/vip_badge.png'), badgeBuffer);
  console.log(chalk.green('✅ VIP badge generated'));

  console.log(chalk.green('\n🎉 All assets generated successfully!'));
}

// Run if executed directly
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  generateAssets().catch(console.error);
}

export { generateAssets };