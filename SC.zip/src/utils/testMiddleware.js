// src/utils/testMiddleware.js (NEW)
import { Telegraf } from 'telegraf';
import dotenv from 'dotenv';
import chalk from 'chalk';
import { setupMiddleware } from '../middleware/index.js';

dotenv.config();

async function testMiddleware() {
  console.log(chalk.blue('🧪 Testing Middleware System...\n'));
  
  try {
    // Buat bot instance untuk testing
    const bot = new Telegraf(process.env.BOT_TOKEN);
    
    // Setup semua middleware
    setupMiddleware(bot);
    
    // Test session middleware
    console.log(chalk.green('✅ Session middleware loaded'));
    
    // Test rate limiter
    console.log(chalk.green('✅ Rate limiter loaded'));
    
    // Test verification
    console.log(chalk.green('✅ Verification middleware loaded'));
    
    // Test admin auth
    console.log(chalk.green('✅ Admin auth middleware loaded'));
    
    console.log(chalk.blue('\n📊 Middleware Order:'));
    console.log(chalk.cyan('1. Session (User state management)'));
    console.log(chalk.cyan('2. Rate Limiter (Anti-spam protection)'));
    console.log(chalk.cyan('3. Verification (Channel membership check)'));
    console.log(chalk.cyan('4. Admin Auth (Access control)'));
    
    console.log(chalk.green('\n✅ All middleware loaded successfully!'));
    console.log(chalk.yellow('ℹ️  Middleware akan aktif saat bot dijalankan.'));
    
    // Cleanup
    bot.stop();
    
  } catch (error) {
    console.log(chalk.red('❌ Middleware test failed:'), error.message);
    
    if (error.message.includes('Cannot find module')) {
      console.log(chalk.yellow('\n💡 Missing files detected:'));
      console.log(chalk.yellow('- Check if all middleware files exist in src/middleware/'));
    }
  }
}

testMiddleware();