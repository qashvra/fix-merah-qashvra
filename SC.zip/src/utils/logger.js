import chalk from 'chalk';
import moment from 'moment-timezone';
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export class Logger {
  constructor() {
    this.logDir = path.join(__dirname, '../../logs');
    this.ensureLogDirectory();
  }

  ensureLogDirectory() {
    fs.ensureDirSync(this.logDir);
    
    // Create daily log files
    const today = moment().format('YYYY-MM-DD');
    this.successLog = path.join(this.logDir, `success-${today}.log`);
    this.errorLog = path.join(this.logDir, `error-${today}.log`);
    this.activityLog = path.join(this.logDir, `activity-${today}.log`);
  }

  timestamp() {
    return moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss.SSS');
  }

  formatMessage(level, message) {
    return `[${this.timestamp()}] [${level}] ${message}`;
  }

  success(message, data = null) {
    const formattedMsg = this.formatMessage('SUCCESS', message);
    console.log(chalk.green(formattedMsg));
    this.writeLog(this.successLog, formattedMsg);
    
    if (data) {
      const dataStr = JSON.stringify(data, null, 2);
      console.log(chalk.green(`  ↳ ${dataStr}`));
      this.writeLog(this.successLog, `  ↳ ${dataStr}`);
    }
  }

  error(message, error = null) {
    const formattedMsg = this.formatMessage('ERROR', message);
    console.log(chalk.red(formattedMsg));
    this.writeLog(this.errorLog, formattedMsg);
    
    if (error) {
      console.log(chalk.red(`  ↳ ${error.stack || error}`));
      this.writeLog(this.errorLog, `  ↳ ${error.stack || error}`);
    }
  }

  warning(message) {
    const formattedMsg = this.formatMessage('WARNING', message);
    console.log(chalk.yellow(formattedMsg));
    this.writeLog(this.errorLog, formattedMsg);
  }

  info(message) {
    const formattedMsg = this.formatMessage('INFO', message);
    console.log(chalk.blue(formattedMsg));
  }

  activity(userId, action, details = {}) {
    const logData = {
      timestamp: this.timestamp(),
      userId,
      action,
      details
    };
    
    const formattedMsg = this.formatMessage('ACTIVITY', JSON.stringify(logData));
    console.log(chalk.cyan(formattedMsg));
    this.writeLog(this.activityLog, formattedMsg);
  }

  payment(userId, amount, status, details = {}) {
    const logData = {
      timestamp: this.timestamp(),
      userId,
      amount,
      status,
      details
    };
    
    const formattedMsg = this.formatMessage('PAYMENT', JSON.stringify(logData));
    console.log(chalk.magenta(formattedMsg));
    this.writeLog(this.activityLog, formattedMsg);
  }

  admin(adminId, action, targetId = null, details = {}) {
    const logData = {
      timestamp: this.timestamp(),
      adminId,
      action,
      targetId,
      details
    };
    
    const formattedMsg = this.formatMessage('ADMIN', JSON.stringify(logData));
    console.log(chalk.yellow.bold(formattedMsg));
    this.writeLog(this.activityLog, formattedMsg);
  }

  async writeLog(filePath, message) {
    try {
      await fs.appendFile(filePath, message + '\n');
    } catch (error) {
      console.error('Failed to write log:', error);
    }
  }

  async getLogs(type = 'activity', date = null) {
    try {
      const targetDate = date || moment().format('YYYY-MM-DD');
      const logFile = path.join(this.logDir, `${type}-${targetDate}.log`);
      
      if (await fs.pathExists(logFile)) {
        return await fs.readFile(logFile, 'utf8');
      }
      return 'No logs found for this date';
    } catch (error) {
      return `Error reading logs: ${error.message}`;
    }
  }

  async clearOldLogs(daysToKeep = 7) {
    try {
      const files = await fs.readdir(this.logDir);
      const cutoffDate = moment().subtract(daysToKeep, 'days');
      
      for (const file of files) {
        const filePath = path.join(this.logDir, file);
        const stats = await fs.stat(filePath);
        
        if (moment(stats.mtime).isBefore(cutoffDate)) {
          await fs.remove(filePath);
          this.info(`Removed old log file: ${file}`);
        }
      }
    } catch (error) {
      this.error('Failed to clear old logs:', error);
    }
  }
}