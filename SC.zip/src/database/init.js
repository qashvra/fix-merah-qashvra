import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import { Logger } from '../utils/logger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const logger = new Logger();

const DATABASE_PATH = path.join(__dirname, '../../data');

const databaseFiles = {
  users: 'users.json',
  config: 'config.json',
  statistics: 'statistics.json',
  history: 'history.json',
  referrals: 'referrals.json',
  subscriptions: 'subscriptions.json',
  templates: 'templates.json',
  invoices: 'invoices.json',
  leaderboard: 'leaderboard.json',
  sessions: 'sessions.json' // ✅ Ditambahkan agar sinkron dengan defaultData & proses inisialisasi
};

const defaultData = {
  users: {
    data: [],
    metadata: {
      total: 0,
      lastUpdated: new Date().toISOString()
    }
  },
  config: { // ✅ TAMBAHAN: Fallback konfigurasi sistem
    requiredChannels: [],
    botSettings: {},
    adminIds: []
  },
  statistics: {
    global: {
      totalUsers: 0,
      activeUsers: 0,
      totalActivities: 0,
      totalSuccess: 0,
      totalFailed: 0,
      uptime: 0,
      lastReset: new Date().toISOString()
    },
    daily: {}
  },
  history: {
    records: [],
    metadata: {
      totalRecords: 0,
      lastCleanup: new Date().toISOString()
    }
  },
  referrals: {
    data: [],
    metadata: {
      totalReferrals: 0,
      totalCoinsDistributed: 0
    }
  },
  subscriptions: {
    active: [],
    expired: [],
    metadata: {
      totalActive: 0,
      totalExpired: 0
    }
  },
  templates: {
    email: [],
    testimoni: [],
    broadcast: []
  },
  invoices: {
    data: [],
    metadata: {
      totalInvoices: 0,
      totalRevenue: 0
    }
  },
  leaderboard: {
    global: [],
    byCountry: {},
    lastUpdated: new Date().toISOString()
  },
  sessions: { // ✅ TAMBAHAN: Manajemen session tracking
    data: [],
    metadata: {
      totalSessions: 0,
      lastCleanup: new Date().toISOString()
    }
  }
};

async function initializeDatabase() {
  try {
    // Ensure data directory exists
    await fs.ensureDir(DATABASE_PATH);
    
    // Initialize each database file
    for (const [key, filename] of Object.entries(databaseFiles)) {
      const filePath = path.join(DATABASE_PATH, filename);
      
      if (!await fs.pathExists(filePath)) {
        await fs.writeJson(filePath, defaultData[key], { spaces: 2 });
        logger.info(`Created database file: ${filename}`);
      } else {
        // Validate existing file
        try {
          const data = await fs.readJson(filePath);
          if (!data) {
            await fs.writeJson(filePath, defaultData[key], { spaces: 2 });
            logger.warning(`Reset corrupted database file: ${filename}`);
          }
        } catch (error) {
          await fs.writeJson(filePath, defaultData[key], { spaces: 2 });
          logger.warning(`Recreated invalid database file: ${filename}`);
        }
      }
    }
    
    logger.success('All database files initialized successfully');
    return true;
  } catch (error) {
    logger.error('Failed to initialize database:', error);
    throw error;
  }
}

class DatabaseManager {
  constructor(databaseName) {
    this.databaseName = databaseName;
    this.filePath = path.join(DATABASE_PATH, databaseFiles[databaseName]);
    this.cache = null;
    this.lastRead = 0;
    this.cacheTimeout = 5000; // 5 seconds cache
  }

  async read() {
    try {
      const now = Date.now();
      
      // Return cached data if within timeout
      if (this.cache && (now - this.lastRead) < this.cacheTimeout) {
        return this.cache;
      }
      
      const data = await fs.readJson(this.filePath);
      this.cache = data;
      this.lastRead = now;
      return data;
    } catch (error) {
      logger.error(`Failed to read ${this.databaseName} database:`, error);
      return defaultData[this.databaseName];
    }
  }

  async write(data) {
    try {
      // Update metadata
      if (data.metadata) {
        data.metadata.lastUpdated = new Date().toISOString();
      }
      
      await fs.writeJson(this.filePath, data, { spaces: 2 });
      this.cache = data;
      this.lastRead = Date.now();
      return true;
    } catch (error) {
      logger.error(`Failed to write ${this.databaseName} database:`, error);
      throw error;
    }
  }

  async update(updateFn) {
    try {
      const data = await this.read();
      const updatedData = await updateFn(data);
      await this.write(updatedData);
      return updatedData;
    } catch (error) {
      logger.error(`Failed to update ${this.databaseName} database:`, error);
      throw error;
    }
  }

  async query(predicate) {
    const data = await this.read();
    return data.data.filter(predicate);
  }

  async findOne(predicate) {
    const data = await this.read();
    return data.data.find(predicate);
  }

  async findById(id) {
    return this.findOne(item => item.id === id);
  }

  async insert(newItem) {
    return this.update(data => {
      data.data.push(newItem);
      if (data.metadata) {
        data.metadata.total = data.data.length;
      }
      return data;
    });
  }

  async updateById(id, updates) {
    return this.update(data => {
      const index = data.data.findIndex(item => item.id === id);
      if (index !== -1) {
        data.data[index] = { ...data.data[index], ...updates };
      }
      return data;
    });
  }

  async deleteById(id) {
    return this.update(data => {
      data.data = data.data.filter(item => item.id !== id);
      if (data.metadata) {
        data.metadata.total = data.data.length;
      }
      return data;
    });
  }

  clearCache() {
    this.cache = null;
    this.lastRead = 0;
  }
}

export { initializeDatabase, DatabaseManager, DATABASE_PATH };
