import { Telegraf } from 'telegraf';
import express from 'express';
import dotenv from 'dotenv';
import chalk from 'chalk';
import { initializeDatabase } from './database/init.js';
import { setupMiddleware } from './middleware/index.js';
import { setupHandlers } from './handlers/index.js';
import { Logger } from './utils/logger.js';
import { HealthMonitor } from './utils/healthMonitor.js';
import { QueueManager } from './queue/queueManager.js';

dotenv.config();

const logger = new Logger();

class QashvraBot {
  constructor() {
    this.bot = null;
    this.app = express();
    this.healthMonitor = new HealthMonitor();
    this.queueManager = new QueueManager();
  }

  async initialize() {
    try {
      console.log(chalk.blue('🚀 Initializing Qashvra Bot System...'));
      
      // Check environment variables
      this.validateEnvironment();
      
      // Initialize database
      await initializeDatabase();
      console.log(chalk.green('✅ Database initialized'));
      
      // Initialize bot
      this.bot = new Telegraf(process.env.BOT_TOKEN);
      
      // Setup middleware
      setupMiddleware(this.bot);
      console.log(chalk.green('✅ Middleware configured'));
      
      // Setup handlers
      setupHandlers(this.bot, this.queueManager);
      console.log(chalk.green('✅ Handlers configured'));
      
      // Setup Express server
      this.setupExpress();
      
      // Start health monitoring
      this.healthMonitor.startMonitoring();
      console.log(chalk.green('✅ Health monitoring active'));
      
      // Start queue manager
      this.queueManager.start();
      console.log(chalk.green('✅ Queue manager started'));
      
      // Launch bot
      await this.bot.launch();
      console.log(chalk.green('✅ Bot launched successfully'));
      
      logger.success('Qashvra Bot System Initialized Successfully');
      
    } catch (error) {
      logger.error('Failed to initialize bot:', error);
      process.exit(1);
    }
  }

  validateEnvironment() {
    const requiredEnv = [
      'BOT_TOKEN', 
      'OWNER_ID', 
      'SMTP_USER', 
      'SMTP_PASS',
      'TIMEZONE'
    ];
    
    requiredEnv.forEach(env => {
      if (!process.env[env]) {
        throw new Error(`Missing required environment variable: ${env}`);
      }
    });
  }

  setupExpress() {
    this.app.use(express.json());
    
    // Health check endpoint
    this.app.get('/health', (req, res) => {
      res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        bot: this.healthMonitor.getStatus()
      });
    });
    
    // Webhook endpoint
    if (process.env.NODE_ENV === 'production' && process.env.WEBHOOK_URL) {
      this.app.post('/webhook', (req, res) => {
        this.bot.handleUpdate(req.body);
        res.sendStatus(200);
      });
    }
    
    const port = process.env.PORT || 3000;
    this.app.listen(port, () => {
      console.log(chalk.cyan(`🌐 Express server running on port ${port}`));
    });
  }

  // Graceful shutdown
  async shutdown() {
    console.log(chalk.yellow('⚠️ Shutting down gracefully...'));
    
    await this.queueManager.stop();
    await this.healthMonitor.stop();
    
    if (this.bot) {
      await this.bot.stop();
    }
    
    console.log(chalk.green('✅ Shutdown complete'));
    process.exit(0);
  }
}

// Create and start bot
const bot = new QashvraBot();

// Handle process termination
process.on('SIGTERM', () => bot.shutdown());
process.on('SIGINT', () => bot.shutdown());
process.on('unhandledRejection', (error) => {
  logger.error('Unhandled Rejection:', error);
});
process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  bot.shutdown();
});

// Start the bot
bot.initialize();

export { bot as default };