import { Markup } from 'telegraf';
import { Logger } from '../utils/logger.js';
import { DatabaseManager } from '../database/init.js';
import { configManager } from '../config/configManager.js';
import { smtpPool } from '../services/smtpPoolManager.js';
import { getRateLimitStats, unbanUser, resetUserLimits } from '../middleware/rateLimiter.js';
import { getAllSessions, getActiveSessionCount } from '../middleware/session.js';
import { updateLeaderboardData } from './leaderboardHandler.js';
import os from 'os';
import moment from 'moment-timezone';

const logger = new Logger();
const userDB = new DatabaseManager('users');
const statsDB = new DatabaseManager('statistics');
const historyDB = new DatabaseManager('history');
const invoiceDB = new DatabaseManager('invoices');
const subscriptionDB = new DatabaseManager('subscriptions');
const templatesDB = new DatabaseManager('templates');

export async function adminHandler(ctx) {
  try {
    const userId = ctx.from.id;
    
    // Cek akses admin
    if (!configManager.isAdmin(userId)) {
      return ctx.reply('⛔ Akses ditolak. Admin only command.');
    }
    
    logger.admin(userId, 'open_admin_panel');
    
    await showAdminPanel(ctx);
    
  } catch (error) {
    logger.error('Admin handler error:', error);
    await ctx.reply('❌ Gagal membuka admin panel').catch(() => {});
  }
}

export function setupAdminActions(bot) {
  
  // Admin panel from callback
  bot.action('menu_admin', async (ctx) => {
    await ctx.answerCbQuery();
    
    const userId = ctx.from.id;
    
    if (!configManager.isAdmin(userId)) {
      return ctx.answerCbQuery('⛔ Admin only!');
    }
    
    await showAdminPanel(ctx);
  });

  // Admin menu actions
  bot.action('admin_stats', async (ctx) => await showStatistics(ctx));
  bot.action('admin_users', async (ctx) => await showUserManagement(ctx));
  bot.action('admin_broadcast', async (ctx) => await showBroadcastMenu(ctx));
  bot.action('admin_templates', async (ctx) => await showTemplateMenu(ctx));
  bot.action('admin_queue', async (ctx) => await showQueueMonitor(ctx));
  bot.action('admin_smtp', async (ctx) => await showSmtpPanel(ctx));
  bot.action('admin_security', async (ctx) => await showSecurityPanel(ctx));
  bot.action('admin_backup', async (ctx) => await performBackup(ctx));
  bot.action('admin_maintenance', async (ctx) => await toggleMaintenance(ctx));
  
  // User management actions
  bot.action(/admin_user_detail_(\d+)/, async (ctx) => {
    const targetId = parseInt(ctx.match[1]);
    await showUserDetail(ctx, targetId);
  });
  
  bot.action(/admin_ban_user_(\d+)/, async (ctx) => {
    const targetId = parseInt(ctx.match[1]);
    await banUserAction(ctx, targetId);
  });
  
  bot.action(/admin_unban_user_(\d+)/, async (ctx) => {
    const targetId = parseInt(ctx.match[1]);
    await unbanUserAction(ctx, targetId);
  });
  
  bot.action(/admin_add_vip_(\d+)/, async (ctx) => {
    const targetId = parseInt(ctx.match[1]);
    await addVipUser(ctx, targetId);
  });
  
  bot.action(/admin_remove_vip_(\d+)/, async (ctx) => {
    const targetId = parseInt(ctx.match[1]);
    await removeVipUser(ctx, targetId);
  });
  
  bot.action(/admin_reset_limit_(\d+)/, async (ctx) => {
    const targetId = parseInt(ctx.match[1]);
    await resetUserLimit(ctx, targetId);
  });
  
  // Broadcast actions
  bot.action('admin_broadcast_all', async (ctx) => {
    await ctx.answerCbQuery();
    await startBroadcast(ctx, 'all');
  });
  
  bot.action('admin_broadcast_vip', async (ctx) => {
    await ctx.answerCbQuery();
    await startBroadcast(ctx, 'vip');
  });
  
  bot.action('admin_broadcast_free', async (ctx) => {
    await ctx.answerCbQuery();
    await startBroadcast(ctx, 'free');
  });
  
  // Template actions
  bot.action('admin_template_list', async (ctx) => await listTemplates(ctx));
  bot.action('admin_template_add', async (ctx) => await addTemplatePrompt(ctx));
  
  // Pagination
  bot.action(/admin_users_page_(\d+)/, async (ctx) => {
    const page = parseInt(ctx.match[1]);
    await showUserManagement(ctx, page);
  });
  
  // Back to admin panel
  bot.action('admin_back', async (ctx) => {
    await ctx.answerCbQuery();
    await showAdminPanel(ctx);
  });
}

// ========== ADMIN PANEL ==========

async function showAdminPanel(ctx) {
  const stats = await getSystemStats();
  const uptime = formatUptime(process.uptime());
  
  const message = 
    `⚙️ *ADMIN PANEL*\n` +
    `──────────────────\n\n` +
    `🖥 *System Info*\n` +
    `⏱ Uptime: ${uptime}\n` +
    `💾 Memory: ${stats.memory}\n` +
    `🔄 CPU: ${stats.cpu}%\n\n` +
    `📊 *Quick Stats*\n` +
    `👥 Users: ${stats.totalUsers}\n` +
    `🟢 Active: ${stats.activeUsers}\n` +
    `📨 Activities: ${stats.totalActivities}\n` +
    `💰 Revenue: Rp ${stats.revenue}\n` +
    `🔒 Bans: ${stats.activeBans}\n\n` +
    `Pilih menu pengelolaan:`;
  
  const keyboard = [
    [
      Markup.button.callback('📊 Statistik', 'admin_stats'),
      Markup.button.callback('👥 Users', 'admin_users')
    ],
    [
      Markup.button.callback('📢 Broadcast', 'admin_broadcast'),
      Markup.button.callback('📧 Template', 'admin_templates')
    ],
    [
      Markup.button.callback('🔄 Queue', 'admin_queue'),
      Markup.button.callback('📨 SMTP', 'admin_smtp')
    ],
    [
      Markup.button.callback('🛡 Security', 'admin_security'),
      Markup.button.callback('💾 Backup', 'admin_backup')
    ],
    [
      Markup.button.callback('🔧 Maintenance', 'admin_maintenance'),
      Markup.button.callback('🔄 Refresh', 'menu_admin')
    ],
    [Markup.button.callback('🔙 Menu Utama', 'menu_back')]
  ];
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

// ========== STATISTICS ==========

async function showStatistics(ctx) {
  await ctx.answerCbQuery();
  
  const stats = await getSystemStats();
  const uptime = formatUptime(process.uptime());
  
  // Get today's stats
  const today = moment().tz('Asia/Jakarta').format('YYYY-MM-DD');
  const dailyStats = await getDailyStats(today);
  
  const message = 
    `📊 *STATISTIK SISTEM*\n` +
    `──────────────────\n\n` +
    `🖥 *System*\n` +
    `⏱ Uptime: ${uptime}\n` +
    `💾 RAM: ${stats.memory}\n` +
    `🔄 CPU: ${stats.cpu}%\n` +
    `📡 Platform: ${os.platform()}\n\n` +
    `👥 *Users*\n` +
    `📝 Total: ${stats.totalUsers}\n` +
    `🟢 Active: ${stats.activeUsers}\n` +
    `👑 VIP: ${stats.vipUsers}\n` +
    `💎 VVIP: ${stats.vvipUsers}\n` +
    `🆓 Free: ${stats.freeUsers}\n\n` +
    `📊 *Activities*\n` +
    `📨 Total: ${stats.totalActivities}\n` +
    `✅ Success: ${stats.totalSuccess}\n` +
    `❌ Failed: ${stats.totalFailed}\n` +
    `📈 Rate: ${stats.successRate}%\n\n` +
    `💰 *Finance*\n` +
    `💵 Revenue: Rp ${stats.revenue}\n` +
    `🧾 Invoices: ${stats.totalInvoices}\n\n` +
    `📅 *Hari Ini (${today})*\n` +
    `📝 Aktivitas: ${dailyStats.activities}\n` +
    `👥 User Baru: ${dailyStats.newUsers}\n` +
    `💰 Pemasukan: Rp ${dailyStats.revenue}`;
  
  const keyboard = [
    [
      Markup.button.callback('🔄 Refresh', 'admin_stats'),
      Markup.button.callback('📊 Leaderboard', 'menu_leaderboard')
    ],
    [Markup.button.callback('🔙 Admin Panel', 'admin_back')]
  ];
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

// ========== USER MANAGEMENT ==========

async function showUserManagement(ctx, page = 1) {
  await ctx.answerCbQuery();
  
  const limit = 10;
  const allUsers = await userDB.read();
  const totalUsers = allUsers.data.length;
  const totalPages = Math.ceil(totalUsers / limit) || 1;
  const offset = (page - 1) * limit;
  const users = allUsers.data
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(offset, offset + limit);
  
  let message = 
    `👥 *USER MANAGEMENT*\n` +
    `──────────────────\n` +
    `📝 Total: ${totalUsers} users\n` +
    `📄 Halaman ${page}/${totalPages}\n\n` +
    `Daftar user terbaru:\n\n`;
  
  users.forEach((user, index) => {
    const roleEmoji = getRoleEmoji(user.role);
    const banStatus = user.banned ? ' 🚫' : '';
    
    message += 
      `${offset + index + 1}. ${roleEmoji} *${user.firstName || 'Unknown'}*${banStatus}\n` +
      `   ID: \`${user.id}\`\n` +
      `   @${user.username || 'N/A'}\n` +
      `   Role: ${user.role}\n` +
      `   Activities: ${user.totalActivities || 0}\n\n`;
  });
  
  // Buat tombol untuk setiap user
  const keyboard = [];
  
  users.forEach((user) => {
    keyboard.push([
      Markup.button.callback(
        `👤 ${user.firstName || 'User'} (${user.role})`,
        `admin_user_detail_${user.id}`
      )
    ]);
  });
  
  // Navigation
  const navButtons = [];
  
  if (page > 1) {
    navButtons.push(Markup.button.callback('◀️', `admin_users_page_${page - 1}`));
  }
  
  navButtons.push(Markup.button.callback(`📄 ${page}/${totalPages}`, 'admin_users_nop'));
  
  if (page < totalPages) {
    navButtons.push(Markup.button.callback('▶️', `admin_users_page_${page + 1}`));
  }
  
  keyboard.push(navButtons);
  keyboard.push([
    Markup.button.callback('🔍 Cari User', 'admin_user_search'),
    Markup.button.callback('🔙 Admin Panel', 'admin_back')
  ]);
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

async function showUserDetail(ctx, userId) {
  await ctx.answerCbQuery();
  
  const user = await userDB.findOne(u => u.id === userId);
  
  if (!user) {
    return ctx.reply('❌ User tidak ditemukan');
  }
  
  // Get user history
  const userHistory = await historyDB.query(h => h.userId === userId);
  const subscriptions = await subscriptionDB.query(s => s.userId === userId);
  const invoices = await invoiceDB.query(i => i.userId === userId);
  
  const message = 
    `👤 *USER DETAIL*\n` +
    `──────────────────\n\n` +
    `🆔 ID: \`${user.id}\`\n` +
    `👤 Nama: ${user.firstName || 'N/A'}\n` +
    `📛 Username: @${user.username || 'N/A'}\n` +
    `💎 Role: ${getRoleEmoji(user.role)} ${user.role}\n` +
    `🪙 Coins: ${user.coins || 0}\n` +
    `🚫 Banned: ${user.banned ? 'Ya' : 'Tidak'}\n\n` +
    `📊 *Statistics*\n` +
    `📝 Activities: ${user.totalActivities || 0}\n` +
    `✅ Success: ${user.totalSuccess || 0}\n` +
    `📅 Bergabung: ${formatDate(user.createdAt)}\n` +
    `🕐 Last Active: ${formatDate(user.lastActivity)}\n\n` +
    `📜 *History*\n` +
    `📨 Total Records: ${userHistory.length}\n` +
    `👑 Subscriptions: ${subscriptions.length}\n` +
    `💰 Invoices: ${invoices.length}\n\n` +
    (user.subscriptionExpiry ? 
      `📅 Langganan: ${formatDate(user.subscriptionExpiry)}\n` : '');
  
  const keyboard = [
    [
      Markup.button.callback(
        user.banned ? '✅ Unban' : '🚫 Ban',
        user.banned ? `admin_unban_user_${userId}` : `admin_ban_user_${userId}`
      ),
      Markup.button.callback(
        user.role === 'VIP' || user.role === 'VVIP' ? '⬇️ Remove VIP' : '⬆️ Add VIP',
        user.role === 'VIP' || user.role === 'VVIP' ? `admin_remove_vip_${userId}` : `admin_add_vip_${userId}`
      )
    ],
    [
      Markup.button.callback('🔄 Reset Limit', `admin_reset_limit_${userId}`),
      Markup.button.callback('📊 Lihat History', `history_user_${userId}`)
    ],
    [Markup.button.callback('🔙 User List', 'admin_users')]
  ];
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

async function banUserAction(ctx, userId) {
  await userDB.updateById(userId, { banned: true });
  unbanUser(userId); // Clear session
  
  await ctx.answerCbQuery('✅ User dibanned');
  logger.admin(ctx.from.id, 'ban_user', userId);
  
  await showUserDetail(ctx, userId);
}

async function unbanUserAction(ctx, userId) {
  await userDB.updateById(userId, { banned: false });
  unbanUser(userId);
  
  await ctx.answerCbQuery('✅ User di-unbanned');
  logger.admin(ctx.from.id, 'unban_user', userId);
  
  await showUserDetail(ctx, userId);
}

async function addVipUser(ctx, userId) {
  await userDB.updateById(userId, {
    role: 'VIP',
    dailyLimit: 999999,
    subscriptionExpiry: new Date(Date.now() + 30 * 86400000).toISOString()
  });
  
  await ctx.answerCbQuery('✅ User jadi VIP 30 hari');
  logger.admin(ctx.from.id, 'add_vip', userId);
  
  await showUserDetail(ctx, userId);
}

async function removeVipUser(ctx, userId) {
  await userDB.updateById(userId, {
    role: 'FREE',
    dailyLimit: 2,
    subscriptionExpiry: null
  });
  
  await ctx.answerCbQuery('✅ VIP dihapus');
  logger.admin(ctx.from.id, 'remove_vip', userId);
  
  await showUserDetail(ctx, userId);
}

async function resetUserLimit(ctx, userId) {
  await userDB.updateById(userId, { dailyUsed: 0 });
  resetUserLimits(userId);
  
  await ctx.answerCbQuery('✅ Limit direset');
  logger.admin(ctx.from.id, 'reset_limit', userId);
  
  await showUserDetail(ctx, userId);
}

// ========== BROADCAST ==========

async function showBroadcastMenu(ctx) {
  await ctx.answerCbQuery();
  
  const message = 
    `📢 *BROADCAST MESSAGE*\n` +
    `──────────────────\n\n` +
    `Kirim pesan ke semua user.\n\n` +
    `Pilih target broadcast:`;
  
  const keyboard = [
    [Markup.button.callback('👥 Semua User', 'admin_broadcast_all')],
    [Markup.button.callback('👑 VIP/VVIP Only', 'admin_broadcast_vip')],
    [Markup.button.callback('🆓 Free User Only', 'admin_broadcast_free')],
    [Markup.button.callback('🔙 Admin Panel', 'admin_back')]
  ];
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

async function startBroadcast(ctx, target) {
  const message = 
    `📢 *BROADCAST*\n\n` +
    `Silakan kirim pesan yang akan dibroadcast.\n` +
    `Format: Text, Photo, atau Video\n\n` +
    `Ketik /cancel untuk membatalkan.`;
  
  await ctx.reply(message, { parse_mode: 'Markdown' });
  
  // Set session untuk menunggu input broadcast
  // Akan dihandle di callbackHandler
}

// ========== TEMPLATE MANAGEMENT ==========

async function showTemplateMenu(ctx) {
  await ctx.answerCbQuery();
  
  const templates = await templatesDB.read();
  const emailTemplates = templates.email || [];
  const testimoniTemplates = templates.testimoni || [];
  const broadcastTemplates = templates.broadcast || [];
  
  const message = 
    `📧 *TEMPLATE MANAGEMENT*\n` +
    `──────────────────\n\n` +
    `📨 Email Templates: ${emailTemplates.length}\n` +
    `💬 Testimoni: ${testimoniTemplates.length}\n` +
    `📢 Broadcast: ${broadcastTemplates.length}\n\n` +
    `Pilih aksi:`;
  
  const keyboard = [
    [Markup.button.callback('📋 List Templates', 'admin_template_list')],
    [Markup.button.callback('➕ Add Template', 'admin_template_add')],
    [Markup.button.callback('🔙 Admin Panel', 'admin_back')]
  ];
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

async function listTemplates(ctx) {
  await ctx.answerCbQuery();
  
  const templates = await templatesDB.read();
  const allTemplates = [
    ...(templates.email || []).map(t => ({ ...t, type: '📧 Email' })),
    ...(templates.testimoni || []).map(t => ({ ...t, type: '💬 Testimoni' })),
    ...(templates.broadcast || []).map(t => ({ ...t, type: '📢 Broadcast' }))
  ];
  
  if (allTemplates.length === 0) {
    await ctx.reply(
      '📭 Belum ada template.\n\nGunakan "Add Template" untuk membuat.',
      Markup.inlineKeyboard([
        [Markup.button.callback('➕ Add Template', 'admin_template_add')],
        [Markup.button.callback('🔙 Kembali', 'admin_templates')]
      ])
    );
    return;
  }
  
  let message = `📋 *TEMPLATE LIST*\n\n`;
  
  allTemplates.slice(0, 20).forEach((t, i) => {
    message += 
      `${i + 1}. ${t.type} - *${t.name}*\n` +
      `   Subject: ${t.subject || 'N/A'}\n\n`;
  });
  
  const keyboard = [
    [Markup.button.callback('➕ Add Template', 'admin_template_add')],
    [Markup.button.callback('🔙 Kembali', 'admin_templates')]
  ];
  
  await ctx.reply(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  });
}

async function addTemplatePrompt(ctx) {
  await ctx.answerCbQuery();
  
  await ctx.reply(
    '📧 *TAMBAH TEMPLATE*\n\n' +
    'Kirim template dengan format:\n\n' +
    '`/template [type] [name] [subject]`\n' +
    '`[body]`\n\n' +
    'Type: email, testimoni, broadcast\n' +
    'Contoh:\n' +
    '`/template email welcome "Welcome!"`\n' +
    '`<h1>Selamat datang!</h1>`',
    { parse_mode: 'Markdown' }
  );
}

// ========== QUEUE MONITOR ==========

async function showQueueMonitor(ctx) {
  await ctx.answerCbQuery();
  
  // Get queue status from global queue manager
  // This assumes queueManager is accessible
  const queueStatus = global.queueManager?.getQueueStatus() || {
    stats: { total: 0, completed: 0, failed: 0, pending: 0 },
    queues: { normal: 0, priority: 0, highPriority: 0 },
    processing: 0
  };
  
  const message = 
    `🔄 *QUEUE MONITOR*\n` +
    `──────────────────\n\n` +
    `📊 *Statistics*\n` +
    `📨 Total: ${queueStatus.stats.total}\n` +
    `✅ Completed: ${queueStatus.stats.completed}\n` +
    `❌ Failed: ${queueStatus.stats.failed}\n` +
    `⏳ Pending: ${queueStatus.stats.pending}\n\n` +
    `📋 *Queues*\n` +
    `🟢 Normal: ${queueStatus.queues.normal}\n` +
    `🟡 Priority: ${queueStatus.queues.priority}\n` +
    `🔴 High Priority: ${queueStatus.queues.highPriority}\n\n` +
    `⚙️ *Processing*\n` +
    `🔄 Active: ${queueStatus.processing}\n` +
    `📊 Max Concurrent: ${queueStatus.maxConcurrent || 10}`;
  
  const keyboard = [
    [Markup.button.callback('🔄 Refresh', 'admin_queue')],
    [Markup.button.callback('🗑 Clear Queue', 'admin_queue_clear')],
    [Markup.button.callback('🔙 Admin Panel', 'admin_back')]
  ];
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

// ========== SMTP PANEL ==========

async function showSmtpPanel(ctx) {
  await ctx.answerCbQuery();
  
  const status = smtpPool.getStatus();
  
  let message = 
    `📧 *SMTP POOL*\n` +
    `──────────────────\n\n` +
    `📊 Total: ${status.totalAccounts}\n` +
    `✅ Active: ${status.activeAccounts}\n` +
    `📨 Sent: ${status.totalSent}\n` +
    `❌ Failed: ${status.totalFailed}\n` +
    `📈 Rate: ${status.successRate}%\n` +
    `🔄 Method: ${status.rollingMethod}\n\n` +
    `📋 *Accounts:*\n`;
  
  status.accounts.slice(0, 10).forEach((acc, i) => {
    const statusEmoji = acc.status === 'active' ? '✅' : '❌';
    message += 
      `${i + 1}. ${statusEmoji} ${acc.email}\n` +
      `   📊 ${acc.dailyUsed}/${acc.dailyLimit}\n\n`;
  });
  
  const keyboard = [
    [Markup.button.callback('🔄 Refresh', 'admin_smtp')],
    [Markup.button.callback('🔙 Admin Panel', 'admin_back')]
  ];
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

// ========== SECURITY PANEL ==========

async function showSecurityPanel(ctx) {
  await ctx.answerCbQuery();
  
  const rateStats = getRateLimitStats();
  const activeSessions = getActiveSessionCount();
  
  const message = 
    `🛡 *SECURITY PANEL*\n` +
    `──────────────────\n\n` +
    `🚫 *Bans*\n` +
    `🔒 Active: ${rateStats.activeBans}\n` +
    `⏳ Cooldowns: ${rateStats.activeCooldowns}\n\n` +
    `👥 *Sessions*\n` +
    `🟢 Active: ${activeSessions}\n` +
    `📊 Rate Limits: ${rateStats.activeLimits}\n\n` +
    `📋 *Banned Users:*\n`;
  
  if (rateStats.bans.length === 0) {
    message += `✅ Tidak ada user dibanned\n`;
  } else {
    rateStats.bans.slice(0, 5).forEach(ban => {
      message += 
        `🚫 \`${ban.userId}\` - ${ban.reason}\n` +
        `   Until: ${ban.bannedUntil}\n`;
    });
  }
  
  const keyboard = [
    [Markup.button.callback('🔄 Refresh', 'admin_security')],
    [Markup.button.callback('🗑 Clear All Bans', 'admin_clear_bans')],
    [Markup.button.callback('🔙 Admin Panel', 'admin_back')]
  ];
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

// ========== BACKUP ==========

async function performBackup(ctx) {
  await ctx.answerCbQuery('💾 Memulai backup...');
  
  try {
    // Backup database files
    const timestamp = moment().format('YYYYMMDD_HHmmss');
    const backupDir = `backups/backup_${timestamp}`;
    
    await fs.ensureDir(backupDir);
    await fs.copy('data', backupDir);
    
    // Update leaderboard
    await updateLeaderboardData();
    
    const message = 
      `✅ *BACKUP BERHASIL*\n\n` +
      `📁 Folder: \`${backupDir}\`\n` +
      `⏰ Waktu: ${moment().format('DD/MM/YYYY HH:mm:ss')}`;
    
    await ctx.reply(message, { parse_mode: 'Markdown' });
    
    logger.admin(ctx.from.id, 'backup_database');
    
  } catch (error) {
    logger.error('Backup failed:', error);
    await ctx.reply('❌ Backup gagal!');
  }
}

// ========== MAINTENANCE ==========

async function toggleMaintenance(ctx) {
  const currentMode = configManager.get('botSettings.maintenanceMode', false);
  const newMode = !currentMode;
  
  await configManager.set('botSettings.maintenanceMode', newMode);
  
  await ctx.answerCbQuery(
    newMode ? '🔧 Maintenance ON' : '✅ Maintenance OFF'
  );
  
  logger.admin(ctx.from.id, 'toggle_maintenance', null, { mode: newMode });
  
  await showAdminPanel(ctx);
}

// ========== HELPER FUNCTIONS ==========

async function getSystemStats() {
  try {
    const users = await userDB.read();
    const stats = await statsDB.read();
    const invoices = await invoiceDB.read();
    const rateStats = getRateLimitStats();
    
    const totalUsers = users.data.length;
    const activeUsers = users.data.filter(u => {
      const lastActive = new Date(u.lastActivity);
      const thirtyDaysAgo = Date.now() - 30 * 86400000;
      return lastActive.getTime() > thirtyDaysAgo;
    }).length;
    
    const vipUsers = users.data.filter(u => u.role === 'VIP').length;
    const vvipUsers = users.data.filter(u => u.role === 'VVIP').length;
    const freeUsers = users.data.filter(u => u.role === 'FREE').length;
    
    const paidInvoices = invoices.data.filter(i => i.status === 'paid');
    const revenue = paidInvoices.reduce((sum, i) => sum + (i.amount || 0), 0);
    
    const memoryUsage = process.memoryUsage();
    const memoryPercent = ((memoryUsage.heapUsed / memoryUsage.heapTotal) * 100).toFixed(1);
    
    return {
      totalUsers,
      activeUsers,
      vipUsers,
      vvipUsers,
      freeUsers,
      totalActivities: stats.global.totalActivities || 0,
      totalSuccess: stats.global.totalSuccess || 0,
      totalFailed: stats.global.totalFailed || 0,
      successRate: stats.global.totalActivities > 0 
        ? ((stats.global.totalSuccess / stats.global.totalActivities) * 100).toFixed(1)
        : 0,
      revenue: revenue.toLocaleString('id-ID'),
      totalInvoices: invoices.data.length,
      activeBans: rateStats.activeBans,
      memory: memoryPercent + '%',
      cpu: os.loadavg()[0].toFixed(1)
    };
  } catch (error) {
    logger.error('Get system stats error:', error);
    return {};
  }
}

async function getDailyStats(date) {
  try {
    const stats = await statsDB.read();
    const dailyData = stats.daily[date] || {};
    const users = await userDB.read();
    
    const newUsers = users.data.filter(u => {
      const createdAt = new Date(u.createdAt).toISOString().split('T')[0];
      return createdAt === date;
    }).length;
    
    const invoices = await invoiceDB.read();
    const dailyRevenue = invoices.data
      .filter(i => {
        const paidDate = (i.paidAt || i.createdAt).split('T')[0];
        return paidDate === date && i.status === 'paid';
      })
      .reduce((sum, i) => sum + (i.amount || 0), 0);
    
    return {
      activities: dailyData.total || 0,
      newUsers,
      revenue: dailyRevenue.toLocaleString('id-ID')
    };
  } catch (error) {
    return { activities: 0, newUsers: 0, revenue: '0' };
  }
}

function getRoleEmoji(role) {
  const emojis = {
    'FREE': '🆓',
    'VIP': '👑',
    'VVIP': '💎',
    'ADMIN': '🛡️',
    'OWNER': '👨‍💻'
  };
  return emojis[role] || '👤';
}

function formatUptime(seconds) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  const parts = [];
  if (days > 0) parts.push(`${days}h`);
  if (hours > 0) parts.push(`${hours}j`);
  if (minutes > 0) parts.push(`${minutes}m`);
  
  return parts.join(' ') || 'baru saja';
}

function formatDate(dateString) {
  if (!dateString) return 'N/A';
  
  const date = new Date(dateString);
  return date.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}