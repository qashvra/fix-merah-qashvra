import { Markup } from 'telegraf';
import { Logger } from '../utils/logger.js';
import { DatabaseManager } from '../database/init.js';
import { configManager } from '../config/configManager.js';
import { applyCommandCooldown } from '../middleware/rateLimiter.js';
import { getSession, setSessionState, clearSessionState } from '../middleware/session.js';

const logger = new Logger();
const historyDB = new DatabaseManager('history');
const userDB = new DatabaseManager('users');
const statsDB = new DatabaseManager('statistics');

export function fixMerahHandler(bot, queueManager) {
  
  // Menu Fix Merah
  bot.action('menu_fixmerah', async (ctx) => {
    await ctx.answerCbQuery();
    
    const userId = ctx.from.id;
    const user = await userDB.findOne(u => u.id === userId);
    
    if (!user) {
      return ctx.reply('❌ User tidak ditemukan. Gunakan /start terlebih dahulu.');
    }
    
    // Cek cooldown
    if (!applyCommandCooldown(userId, 'fixmerah', 3000)) {
      return ctx.answerCbQuery('⏳ Terlalu cepat! Tunggu sebentar...');
    }
    
    // Cek limit harian
    const dailyLimit = configManager.get(`maxDailyLimit.${user.role}`, 2);
    const dailyUsed = user.dailyUsed || 0;
    
    if (dailyUsed >= dailyLimit) {
      const keyboard = [
        [Markup.button.callback('👑 Upgrade ke VIP', 'menu_subscription')],
        [Markup.button.callback('🔙 Kembali', 'menu_back')]
      ];
      
      return ctx.editMessageCaption(
        `⚠️ *LIMIT HARIAN TERCAPAI*\n\n` +
        `📊 Penggunaan: ${dailyUsed}/${dailyLimit}\n` +
        `💎 Role: ${user.role}\n\n` +
        `Upgrade ke *VIP/VVIP* untuk akses unlimited!\n` +
        `Klik tombol di bawah 👇`,
        {
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard(keyboard)
        }
      ).catch(() => {
        ctx.reply(
          `⚠️ *LIMIT HARIAN TERCAPAI*\n\n` +
          `📊 Penggunaan: ${dailyUsed}/${dailyLimit}\n` +
          `💎 Role: ${user.role}\n\n` +
          `Upgrade ke *VIP/VVIP* untuk akses unlimited!`,
          {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(keyboard)
          }
        );
      });
      return;
    }
    
    // Tampilkan menu Fix Merah
    const queueStatus = queueManager.getQueueStatus();
    
    const message = 
      `🔴 *FIX MERAH*\n` +
      `──────────────────\n\n` +
      `💎 *Role:* ${user.role}\n` +
      `📊 *Limit:* ${dailyUsed}/${dailyLimit}\n` +
      `🔄 *Slot Queue:* ${queueStatus.queues.normal}\n` +
      `⚡ *Prioritas:* ${user.role === 'VVIP' ? 'Tertinggi' : user.role === 'VIP' ? 'Tinggi' : 'Normal'}\n\n` +
      `📝 *Format Nomor:*\n` +
      `Internasional (+62xxx / 08xxx)\n\n` +
      `⚠️ *Maksimal nomor:* ${
        user.role === 'VVIP' ? 25 : user.role === 'VIP' ? 5 : 1
      }\n\n` +
      `_Kirimkan nomor tujuan sekarang..._`;
    
    const keyboard = [
      [Markup.button.callback('❌ Batal', 'fixmerah_cancel')],
      [Markup.button.callback('🔙 Kembali ke Menu', 'menu_back')]
    ];
    
    // Set session state untuk menunggu input nomor
    setSessionState(userId, 'waiting_fixmerah_number', {
      role: user.role,
      maxNumbers: user.role === 'VVIP' ? 25 : user.role === 'VIP' ? 5 : 1
    });
    
    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    }).catch(async () => {
      await ctx.replyWithPhoto(
        { source: './assets/images/fixmerah.jpg' },
        {
          caption: message,
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard(keyboard)
        }
      ).catch(async () => {
        await ctx.reply(message, {
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard(keyboard)
        });
      });
    });
    
    logger.activity(userId, 'open_fixmerah_menu');
  });

  // Cancel Fix Merah
  bot.action('fixmerah_cancel', async (ctx) => {
    await ctx.answerCbQuery('❌ Dibatalkan');
    clearSessionState(ctx.from.id);
    
    await ctx.editMessageCaption(
      '❌ *Fix Merah Dibatalkan*\n\nSilakan pilih menu lain.',
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('🔙 Kembali ke Menu', 'menu_back')]
        ])
      }
    ).catch(() => {
      ctx.reply('❌ Fix Merah dibatalkan.');
    });
  });

  // Handle text input untuk nomor Fix Merah
  bot.on('text', async (ctx, next) => {
    const userId = ctx.from.id;
    const session = getSession(userId);
    
    // Cek apakah sedang menunggu input nomor
    if (session && session.currentState === 'waiting_fixmerah_number') {
      
      const input = ctx.message.text.trim();
      
      // Validasi nomor telepon
      const numbers = input.split(/[\n,;]+/).map(n => n.trim()).filter(n => n);
      
      // Cek maksimal nomor
      if (numbers.length > session.stateData.maxNumbers) {
        return ctx.reply(
          `⚠️ Maksimal ${session.stateData.maxNumbers} nomor untuk role ${session.stateData.role}`
        );
      }
      
      // Validasi setiap nomor
      const validNumbers = [];
      const invalidNumbers = [];
      
      for (const number of numbers) {
        if (validatePhoneNumber(number)) {
          validNumbers.push(formatPhoneNumber(number));
        } else {
          invalidNumbers.push(number);
        }
      }
      
      if (invalidNumbers.length > 0) {
        return ctx.reply(
          `❌ Nomor tidak valid:\n${invalidNumbers.join('\n')}\n\n` +
          `Format: Internasional (+62xxx) atau 08xxx`
        );
      }
      
      // Cek duplikat
      const userHistory = await historyDB.query(h => 
        h.userId === userId && 
        h.type === 'fixmerah'
      );
      
      const recentNumbers = userHistory
        .slice(-50)
        .flatMap(h => h.numbers || []);
      
      const duplicateNumbers = validNumbers.filter(n => 
        recentNumbers.includes(n)
      );
      
      if (duplicateNumbers.length > 0) {
        return ctx.reply(
          `⚠️ Nomor sudah pernah dikirim:\n${duplicateNumbers.join('\n')}\n\n` +
          `Silakan gunakan nomor yang berbeda.`
        );
      }
      
      // Anti spam check
      const now = Date.now();
      const recentRequests = userHistory.filter(h => 
        now - new Date(h.createdAt).getTime() < 60000
      );
      
      if (recentRequests.length >= 3) {
        return ctx.reply('⚠️ Terlalu banyak permintaan. Silakan tunggu 1 menit.');
      }
      
      // Proses Fix Merah
      await processFixMerah(ctx, userId, validNumbers, queueManager);
      
      // Clear session state
      clearSessionState(userId);
      
    } else {
      return next();
    }
  });
}

async function processFixMerah(ctx, userId, numbers, queueManager) {
  try {
    // Update daily used
    await userDB.updateById(userId, {
      dailyUsed: (await userDB.findOne(u => u.id === userId)).dailyUsed + 1,
      lastActivity: new Date().toISOString()
    });
    
    // Add to queue
    const taskId = await queueManager.addToQueue(
      async () => {
        // Simulasi proses Fix Merah
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        return {
          success: true,
          numbers: numbers,
          processedAt: new Date().toISOString()
        };
      },
      ctx.session.role === 'VVIP' ? 'vvip' : ctx.session.role === 'VIP' ? 'vip' : 'normal'
    );
    
    // Save to history
    const historyRecord = {
      id: `FM_${Date.now()}_${userId}`,
      userId: userId,
      type: 'fixmerah',
      numbers: numbers,
      status: 'processing',
      taskId: taskId,
      createdAt: new Date().toISOString(),
      username: ctx.from.username || 'unknown'
    };
    
    await historyDB.insert(historyRecord);
    
    // Update statistics
    await statsDB.update(data => {
      data.global.totalActivities++;
      return data;
    });
    
    // Kirim pesan sukses
    const message = 
      `✅ *FIX MERAH DIPROSES*\n\n` +
      `📝 *Nomor:* ${numbers.length} nomor\n` +
      `📋 *ID Task:* \`${taskId}\`\n` +
      `⚡ *Prioritas:* ${ctx.session.role}\n` +
      `⏳ *Status:* Sedang diproses...\n\n` +
      `Hasil akan dikirim setelah selesai.\n` +
      `Cek /history untuk melihat riwayat.`;
    
    const keyboard = [
      [Markup.button.callback('📜 Lihat Riwayat', 'menu_history')],
      [Markup.button.callback('🔙 Menu Utama', 'menu_back')]
    ];
    
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
    
    // Kirim ke channel testimoni
    await sendTestimoni(ctx, numbers, taskId);
    
    logger.success(`Fix Merah processed for user ${userId}: ${numbers.length} numbers`);
    
  } catch (error) {
    logger.error(`Fix Merah processing error for user ${userId}:`, error);
    
    await ctx.reply(
      '❌ Terjadi kesalahan saat memproses.\nSilakan coba lagi atau hubungi support.'
    );
  }
}

async function sendTestimoni(ctx, numbers, taskId) {
  try {
    const testimoniChannel = configManager.get('testimoniChannel', '@qashvrachannel');
    
    const message = 
      `🎉 *FIX MERAH BERHASIL*\n\n` +
      `👤 *User:* @${ctx.from.username || ctx.from.id}\n` +
      `📝 *Jumlah:* ${numbers.length} nomor\n` +
      `📋 *ID:* \`${taskId}\`\n` +
      `⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}\n\n` +
      `#FixMerah #QashvraBot`;
    
    await ctx.telegram.sendMessage(testimoniChannel, message, {
      parse_mode: 'Markdown'
    });
    
  } catch (error) {
    logger.warning('Failed to send testimoni:', error.message);
  }
}

function validatePhoneNumber(number) {
  // Format internasional: +62xxx atau 08xxx
  const regex = /^(\+62|62|0)8[1-9][0-9]{6,10}$/;
  return regex.test(number.replace(/[\s\-\(\)]/g, ''));
}

function formatPhoneNumber(number) {
  // Format ke internasional
  let cleaned = number.replace(/[\s\-\(\)]/g, '');
  
  if (cleaned.startsWith('0')) {
    return '+62' + cleaned.substring(1);
  } else if (cleaned.startsWith('62')) {
    return '+' + cleaned;
  }
  
  return cleaned;
}

export { validatePhoneNumber, formatPhoneNumber };