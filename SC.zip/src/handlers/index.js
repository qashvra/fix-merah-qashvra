import { startHandler } from './startHandler.js';
import { menuHandler } from './menuHandler.js';
import { fixMerahHandler } from './fixMerahHandler.js';
import { referralHandler, setupReferralActions } from './referralHandler.js';
import { subscriptionHandler } from './subscriptionHandler.js';
import { historyHandler, setupHistoryActions } from './historyHandler.js';
import { leaderboardHandler, setupLeaderboardActions } from './leaderboardHandler.js';
import { adminHandler, setupAdminActions } from './adminHandler.js';
import { callbackHandler } from './callbackHandler.js';
import { Logger } from '../utils/logger.js';

const logger = new Logger();

export function setupHandlers(bot, queueManager) {
  
  // Command handlers
  bot.command('start', startHandler);
  bot.command('menu', menuHandler);
  bot.command('help', menuHandler);
  bot.command('referral', referralHandler);
  bot.command('history', historyHandler);
  bot.command('leaderboard', leaderboardHandler);
  bot.command('admin', adminHandler);
  
  // Action-based handlers
  fixMerahHandler(bot, queueManager);
  subscriptionHandler(bot);
  
  // Setup all inline keyboard actions
  setupReferralActions(bot);
  setupHistoryActions(bot);
  setupLeaderboardActions(bot);
  setupAdminActions(bot);
  
  // Global callback handler (must be last)
  callbackHandler(bot, queueManager);
  
  // Error handler
  bot.catch((err, ctx) => {
    logger.error(`Bot error for ${ctx?.updateType}:`, err);
    
    // Try to notify user
    ctx.reply(
      '❌ Maaf, terjadi kesalahan sistem.\nSilakan coba lagi nanti atau hubungi support @qashvra'
    ).catch(() => {});
  });
  
  logger.success('✅ All handlers configured successfully');
  
  // Log registered commands
  const commands = [
    '/start - Mulai bot',
    '/menu - Tampilkan menu utama',
    '/referral - Menu referral',
    '/history - Lihat riwayat',
    '/leaderboard - Top global',
    '/admin - Admin panel (admin only)'
  ];
  
  logger.info('Registered commands:\n' + commands.join('\n'));
}

export { 
  startHandler, 
  menuHandler, 
  fixMerahHandler,
  referralHandler,
  subscriptionHandler,
  historyHandler,
  leaderboardHandler,
  adminHandler,
  callbackHandler
};