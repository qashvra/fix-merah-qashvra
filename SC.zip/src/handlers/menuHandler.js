import { Markup } from 'telegraf';
import { Logger } from '../utils/logger.js';
import { showMainMenu } from './startHandler.js';

const logger = new Logger();

export async function menuHandler(ctx) {
  try {
    const userId = ctx.from.id;
    logger.activity(userId, 'command_menu');
    
    // Panggil kembali main menu
    await showMainMenu(ctx, ctx.session);
    
  } catch (error) {
    logger.error('Menu handler error:', error);
    await ctx.reply('❌ Gagal menampilkan menu. Silakan coba /start').catch(() => {});
  }
}

// Handler untuk tombol-tombol menu utama
export async function handleMenuActions(bot) {
  
  // Menu: Info Bot
  bot.action('menu_info', async (ctx) => {
    await ctx.answerCbQuery();
    
    const infoMessage = 
      `ℹ️ *INFO QASHVRA BOT*\n\n` +
      `🤖 *Nama Bot:* @qashvrabot\n` +
      `👨‍💻 *Owner:* @qashvra\n` +
      `📅 *Dibuat:* 2026\n\n` +
      `🔴 *Fix Merah*\n` +
      `Solusi digital profesional\n\n` +
      `👑 *VIP / VVIP*\n` +
      `Akses premium tanpa batas\n\n` +
      `🧧 *Referral*\n` +
      `Dapatkan koin gratis\n\n` +
      `📞 *Support:* @qashvra\n` +
      `📧 *Email:* support@qashvra.com`;
    
    const keyboard = [
      [Markup.button.url('📞 Hubungi Support', 'https://t.me/qashvra')],
      [Markup.button.callback('🔙 Kembali ke Menu', 'menu_back')]
    ];
    
    await ctx.editMessageCaption(infoMessage, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    }).catch(async () => {
      await ctx.reply(infoMessage, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard(keyboard)
      });
    });
  });

  // Menu: Testimoni
  bot.action('menu_testimoni', async (ctx) => {
    await ctx.answerCbQuery();
    
    const testimoniMessage = 
      `💬 *TESTIMONI PENGGUNA*\n\n` +
      `_"Bot paling stabil yang pernah saya pakai!"_\n` +
      `⭐️⭐️⭐️⭐️⭐️ - @user1\n\n` +
      `_"VIP worth it banget, unlimited!"_\n` +
      `⭐️⭐️⭐️⭐️⭐️ - @user2\n\n` +
      `_"QRIS payment cepat dan aman"_\n` +
      `⭐️⭐️⭐️⭐️⭐️ - @user3\n\n` +
      `Ingin testimoni kamu muncul?\n` +
      `Gunakan bot secara aktif! 🚀`;
    
    const keyboard = [
      [Markup.button.url('📢 Channel Testimoni', 'https://t.me/qashvrachannel')],
      [Markup.button.callback('🔙 Kembali ke Menu', 'menu_back')]
    ];
    
    await ctx.editMessageCaption(testimoniMessage, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    }).catch(async () => {
      await ctx.reply(testimoniMessage, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard(keyboard)
      });
    });
  });

  // Back to main menu
  bot.action('menu_back', async (ctx) => {
    await ctx.answerCbQuery('🔙 Kembali ke menu utama');
    await showMainMenu(ctx, ctx.session);
  });
}