import { Markup } from 'telegraf';
import { Logger } from '../utils/logger.js';
import { DatabaseManager } from '../database/init.js';
import { configManager } from '../config/configManager.js';

const logger = new Logger();
const userDB = new DatabaseManager('users');
const referralDB = new DatabaseManager('referrals');

export async function referralHandler(ctx) {
  try {
    const userId = ctx.from.id;
    const user = await userDB.findOne(u => u.id === userId);
    
    if (!user) {
      return ctx.reply('❌ Silakan gunakan /start terlebih dahulu');
    }
    
    logger.activity(userId, 'view_referral');
    
    await showReferralMenu(ctx, user);
    
  } catch (error) {
    logger.error('Referral handler error:', error);
    await ctx.reply('❌ Gagal memuat menu referral').catch(() => {});
  }
}

export function setupReferralActions(bot) {
  
  // Menu Referral
  bot.action('menu_referral', async (ctx) => {
    await ctx.answerCbQuery();
    
    const userId = ctx.from.id;
    const user = await userDB.findOne(u => u.id === userId);
    
    await showReferralMenu(ctx, user);
  });

  // Redeem VIP
  bot.action('referral_redeem', async (ctx) => {
    await ctx.answerCbQuery();
    
    const userId = ctx.from.id;
    const user = await userDB.findOne(u => u.id === userId);
    
    const prices = configManager.get('referralRewards');
    
    const keyboard = [
      [
        Markup.button.callback(`💎 VIP 1 Hari (${prices.vip1DayCost} koin)`, 'redeem_vip_1'),
        Markup.button.callback(`👑 VIP 7 Hari (${prices.vip7DaysCost} koin)`, 'redeem_vip_7')
      ],
      [Markup.button.callback('🔙 Kembali', 'menu_referral')]
    ];
    
    const message = 
      `🎁 *REDEEM KOIN*\n\n` +
      `💰 Koin kamu: *${user.coins}* 🪙\n\n` +
      `Pilih paket yang ingin di-redeem:`;
    
    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    }).catch(() => {
      ctx.reply(message, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard(keyboard)
      });
    });
  });

  // Redeem actions
  bot.action(/redeem_vip_(.+)/, async (ctx) => {
    const days = parseInt(ctx.match[1]);
    const userId = ctx.from.id;
    const user = await userDB.findOne(u => u.id === userId);
    
    const prices = configManager.get('referralRewards');
    const cost = days === 1 ? prices.vip1DayCost : 
                 days === 7 ? prices.vip7DaysCost : 
                 prices.vip30DaysCost;
    
    if (user.coins < cost) {
      await ctx.answerCbQuery(`❌ Koin tidak cukup! Butuh ${cost} koin`);
      return;
    }
    
    // Kurangi koin
    await userDB.updateById(userId, {
      coins: user.coins - cost,
      role: 'VIP',
      subscriptionExpiry: new Date(Date.now() + days * 86400000).toISOString()
    });
    
    await ctx.answerCbQuery('✅ Berhasil redeem!');
    
    const message = 
      `🎉 *REDEEM BERHASIL*\n\n` +
      `👑 VIP *${days} Hari* telah aktif!\n` +
      `💰 Koin terpakai: ${cost} 🪙\n` +
      `💎 Sisa koin: ${user.coins - cost} 🪙`;
    
    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Menu Referral', 'menu_referral')]
      ])
    }).catch(() => {
      ctx.reply(message, { parse_mode: 'Markdown' });
    });
    
    logger.success(`User ${userId} redeemed VIP ${days} days`);
  });
}

async function showReferralMenu(ctx, user) {
  // Get referral stats
  const referrals = await referralDB.query(r => r.referrerId === user.id);
  const activeReferrals = referrals.filter(r => r.status === 'active');
  const totalCoinsEarned = referrals.reduce((sum, r) => sum + (r.coinsEarned || 0), 0);
  
  const referralLink = `https://t.me/${process.env.BOT_USERNAME}?start=${user.referralCode}`;
  
  const message = 
    `🧧 *REFERRAL SYSTEM*\n` +
    `──────────────────\n\n` +
    `🔗 *Link Referral:*\n` +
    `\`${referralLink}\`\n\n` +
    `📊 *Statistik:*\n` +
    `👥 Total Invite: ${referrals.length}\n` +
    `✅ Active: ${activeReferrals.length}\n` +
    `🪙 Koin Earned: ${totalCoinsEarned}\n` +
    `💰 Current Koin: ${user.coins}\n\n` +
    `🎁 *Reward:*\n` +
    `+10 🪙 per referral aktif\n\n` +
    `💎 *Redeem Koin:*\n` +
    `100 🪙 = VIP 1 Hari\n` +
    `300 🪙 = VIP 7 Hari\n` +
    `1000 🪙 = VIP 30 Hari`;
  
  const keyboard = [
    [Markup.button.switchToChat('📤 Bagikan Link', referralLink)],
    [Markup.button.callback('🎁 Redeem Koin', 'referral_redeem')],
    [Markup.button.callback('📊 List Referral', 'referral_list')],
    [Markup.button.callback('🔙 Kembali ke Menu', 'menu_back')]
  ];
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

export async function processReferral(ctx, user, refCode) {
  try {
    // Decode referral code
    const referrerId = decodeReferralCode(refCode);
    
    if (!referrerId || referrerId === user.id) {
      return; // Invalid or self-referral
    }
    
    const referrer = await userDB.findOne(u => u.id === referrerId);
    
    if (!referrer) {
      return; // Referrer not found
    }
    
    // Cek apakah sudah pernah direferral
    const existingReferral = await referralDB.findOne(r => 
      r.userId === user.id && r.referrerId === referrerId
    );
    
    if (existingReferral) {
      return; // Already referred
    }
    
    // Create referral record
    const referralRecord = {
      id: `REF_${Date.now()}`,
      referrerId: referrerId,
      userId: user.id,
      username: user.username,
      status: 'active',
      coinsEarned: 10,
      createdAt: new Date().toISOString()
    };
    
    await referralDB.insert(referralRecord);
    
    // Update referrer coins
    await userDB.updateById(referrerId, {
      coins: (referrer.coins || 0) + 10
    });
    
    // Update user
    await userDB.updateById(user.id, {
      referredBy: referrerId
    });
    
    // Notify referrer
    try {
      await ctx.telegram.sendMessage(
        referrerId,
        `🎉 *REFERRAL BARU!*\n\n` +
        `@${user.username || user.id} telah join menggunakan link referral kamu!\n` +
        `+10 🪙 telah ditambahkan ke akun kamu.\n\n` +
        `Cek /referral untuk detail.`,
        { parse_mode: 'Markdown' }
      );
    } catch (error) {
      // User might have blocked bot
    }
    
    logger.success(`Referral processed: ${user.id} referred by ${referrerId}`);
    
  } catch (error) {
    logger.error('Process referral error:', error);
  }
}

function decodeReferralCode(code) {
  try {
    const decoded = Buffer.from(code.replace('ref_', ''), 'base64').toString('utf8');
    const parts = decoded.split('_');
    return parseInt(parts[1]);
  } catch (error) {
    return null;
  }
}