import { Markup } from 'telegraf';
import { Logger } from '../utils/logger.js';
import { DatabaseManager } from '../database/init.js';

const logger = new Logger();
const historyDB = new DatabaseManager('history');

export async function historyHandler(ctx) {
  try {
    const userId = ctx.from.id;
    logger.activity(userId, 'view_history');
    
    const page = parseInt(ctx.message?.text?.split(' ')[1]) || 1;
    await showHistory(ctx, userId, page);
    
  } catch (error) {
    logger.error('History handler error:', error);
    await ctx.reply('❌ Gagal memuat riwayat').catch(() => {});
  }
}

export function setupHistoryActions(bot) {
  
  bot.action('menu_history', async (ctx) => {
    await ctx.answerCbQuery();
    await showHistory(ctx, ctx.from.id, 1);
  });

  bot.action(/history_page_(\d+)/, async (ctx) => {
    await ctx.answerCbQuery();
    const page = parseInt(ctx.match[1]);
    await showHistory(ctx, ctx.from.id, page);
  });

  bot.action('history_clear', async (ctx) => {
    await ctx.answerCbQuery();
    
    const keyboard = [
      [
        Markup.button.callback('✅ Ya, Hapus Semua', 'history_clear_confirm'),
        Markup.button.callback('❌ Batal', 'menu_history')
      ]
    ];
    
    await ctx.editMessageCaption(
      '⚠️ *HAPUS RIWAYAT*\n\n' +
      'Apakah kamu yakin ingin menghapus semua riwayat?\n' +
      'Tindakan ini tidak dapat dibatalkan!',
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard(keyboard)
      }
    ).catch(() => {
      ctx.reply(
        '⚠️ *HAPUS RIWAYAT*\n\nApakah kamu yakin?',
        {
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard(keyboard)
        }
      );
    });
  });

  bot.action('history_clear_confirm', async (ctx) => {
    const userId = ctx.from.id;
    
    // Hapus semua history user
    const userHistory = await historyDB.query(h => h.userId === userId);
    
    for (const record of userHistory) {
      await historyDB.deleteById(record.id);
    }
    
    await ctx.answerCbQuery('✅ Riwayat dihapus');
    
    await ctx.editMessageCaption(
      '✅ *RIWAYAT DIHAPUS*\n\nSemua riwayat kamu telah dihapus.',
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('🔙 Kembali ke Menu', 'menu_back')]
        ])
      }
    ).catch(() => {
      ctx.reply('✅ Semua riwayat telah dihapus.');
    });
    
    logger.activity(userId, 'clear_history');
  });
}

async function showHistory(ctx, userId, page = 1) {
  const limit = 10;
  const offset = (page - 1) * limit;
  
  // Get user history
  const allHistory = await historyDB.query(h => h.userId === userId);
  
  // Sort by newest first
  allHistory.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  
  const totalRecords = allHistory.length;
  const totalPages = Math.ceil(totalRecords / limit);
  const records = allHistory.slice(offset, offset + limit);
  
  if (records.length === 0) {
    const message = 
      `📜 *RIWAYAT*\n` +
      `──────────────────\n\n` +
      `📭 Belum ada riwayat aktivitas.\n\n` +
      `Gunakan fitur *Fix Merah* untuk memulai!`;
    
    const keyboard = [
      [Markup.button.callback('🔴 Mulai Fix Merah', 'menu_fixmerah')],
      [Markup.button.callback('🔙 Kembali ke Menu', 'menu_back')]
    ];
    
    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    }).catch(async () => {
      await ctx.reply(message, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard(keyboard)
      });
    });
    return;
  }
  
  // Build history message
  let message = 
    `📜 *RIWAYAT AKTIVITAS*\n` +
    `──────────────────\n` +
    `📊 Total: ${totalRecords} records\n` +
    `📄 Halaman ${page}/${totalPages}\n\n`;
  
  records.forEach((record, index) => {
    const statusEmoji = getStatusEmoji(record.status);
    const date = formatDate(record.createdAt);
    const id = record.id.substring(0, 10);
    
    message += 
      `${offset + index + 1}. ${statusEmoji} *${record.type?.toUpperCase() || 'FIX MERAH'}*\n` +
      `   📋 ID: \`${id}...\`\n` +
      `   📅 ${date}\n` +
      `   📝 ${record.numbers?.length || 1} nomor\n` +
      `   Status: ${record.status || 'completed'}\n\n`;
  });
  
  // Build pagination buttons
  const keyboard = [];
  const navButtons = [];
  
  if (page > 1) {
    navButtons.push(Markup.button.callback('◀️ Sebelumnya', `history_page_${page - 1}`));
  }
  
  navButtons.push(Markup.button.callback(`📄 ${page}/${totalPages}`, 'history_nop'));
  
  if (page < totalPages) {
    navButtons.push(Markup.button.callback('Selanjutnya ▶️', `history_page_${page + 1}`));
  }
  
  keyboard.push(navButtons);
  keyboard.push([
    Markup.button.callback('🗑️ Hapus Riwayat', 'history_clear'),
    Markup.button.callback('🔄 Refresh', 'menu_history')
  ]);
  keyboard.push([Markup.button.callback('🔙 Kembali ke Menu', 'menu_back')]);
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

function getStatusEmoji(status) {
  const emojis = {
    'success': '✅',
    'completed': '✅',
    'processing': '⏳',
    'pending': '🕐',
    'failed': '❌',
    'cancelled': '🚫'
  };
  return emojis[status] || '📌';
}

function formatDate(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const diff = now - date;
  
  // Less than 1 hour
  if (diff < 3600000) {
    const minutes = Math.floor(diff / 60000);
    return `${minutes} menit yang lalu`;
  }
  
  // Less than 24 hours
  if (diff < 86400000) {
    const hours = Math.floor(diff / 3600000);
    return `${hours} jam yang lalu`;
  }
  
  // Less than 7 days
  if (diff < 604800000) {
    const days = Math.floor(diff / 86400000);
    return `${days} hari yang lalu`;
  }
  
  // Full date
  return date.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

export { showHistory, formatDate };