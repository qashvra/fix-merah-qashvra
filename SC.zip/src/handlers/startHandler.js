import { DatabaseManager } from '../database/init.js';
import { configManager } from '../config/configManager.js';
import { checkUserVerification } from '../middleware/verification.js';
import { Logger } from '../utils/logger.js';
import { Markup } from 'telegraf';
import moment from 'moment-timezone';
import os from 'os';

const logger = new Logger();
const userDB = new DatabaseManager('users');
const statsDB = new DatabaseManager('statistics');

// PERBAIKAN: Menghapus 'export' dan menambahkan 'function'
async function startHandler(ctx) {
  try {
    const userId = ctx.from.id;
    const username = ctx.from.username || 'unknown';
    const firstName = ctx.from.first_name || 'User';
    
    // Check if user exists
    let user = await userDB.findOne(u => u.id === userId);
    
    if (!user) {
      // Register new user
      user = {
        id: userId,
        username: username,
        firstName: firstName,
        role: 'FREE',
        verified: false,
        coins: 0,
        dailyLimit: 2,
        dailyUsed: 0,
        totalActivities: 0,
        totalSuccess: 0,
        referralCode: generateReferralCode(userId),
        referredBy: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        banned: false,
        lastActivity: null
      };
      
      await userDB.insert(user);
      logger.success(`New user registered: ${userId} (${username})`);
      
      // Check for referral
      const refCode = ctx.message.text.split(' ')[1];
      if (refCode && refCode.startsWith('ref_')) {
        await processReferral(ctx, user, refCode);
      }
    } else {
      // Update user info
      await userDB.updateById(userId, {
        username: username,
        firstName: firstName,
        updatedAt: new Date().toISOString()
      });
    }
    
    // Check verification
    const isVerified = await checkUserVerification(ctx);
    
    if (isVerified) {
      await userDB.updateById(userId, { verified: true });
      await showMainMenu(ctx, user);
    } else {
      await showVerificationScreen(ctx);
    }
    
  } catch (error) {
    logger.error('Start handler error:', error);
    await ctx.reply('❌ Terjadi kesalahan. Silakan coba /start lagi').catch(() => {});
  }
}

async function showMainMenu(ctx, user) {
  const stats = await getBotStatistics();
  const runtime = getRuntime();
  
  const message = `🏠 *QASHVRA BOT*\n` +
    `──────────────────\n\n` +
    `👋 Selamat datang, *${ctx.from.first_name}*!\n\n` +
    `📅 *Tanggal:* ${moment().tz('Asia/Jakarta').format('DD MMMM YYYY')}\n` +
    `🕐 *Hari:* ${moment().tz('Asia/Jakarta').format('dddd')}\n` +
    `⏱ *Runtime:* ${runtime}\n\n` +
    `📊 *STATISTIK GLOBAL*\n` +
    `👥 Total Users: ${stats.totalUsers}\n` +
    `✅ Success Rate: ${stats.successRate}%\n` +
    `📨 Total Activities: ${stats.totalActivities}\n\n` +
    `👤 *STATUS AKUN*\n` +
    `💎 Role: ${getRoleEmoji(user.role)} ${user.role}\n` +
    `🪙 Coins: ${user.coins}\n` +
    `📊 Limit: ${user.dailyUsed}/${user.dailyLimit}\n` +
    `──────────────────\n\n` +
    `Silakan pilih menu di bawah ini:`;

  const keyboard = [
    [Markup.button.callback('🔴 Fix Merah', 'menu_fixmerah')],
    [Markup.button.callback('👑 VIP / VVIP', 'menu_subscription')],
    [Markup.button.callback('🧧 Referral', 'menu_referral')],
    [Markup.button.callback('📜 Riwayat', 'menu_history')],
    [Markup.button.callback('🏆 Top Global', 'menu_leaderboard')],
    [Markup.button.callback('💬 Testimoni', 'menu_testimoni')],
    [Markup.button.callback('ℹ️ Info Bot', 'menu_info')]
  ];

  if (user.role === 'ADMIN' || user.role === 'OWNER') {
    keyboard.push([Markup.button.callback('⚙️ Admin Panel', 'menu_admin')]);
  }

  await ctx.replyWithPhoto(
    { source: './assets/images/banner.jpg' },
    {
      caption: message,
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    }
  ).catch(async () => {
    // Fallback if image not available
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });

  logger.activity(ctx.from.id, 'view_main_menu');
}

function generateReferralCode(userId) {
  const encoded = Buffer.from(`qashvra_${userId}`).toString('base64');
  return `ref_${encoded.substring(0, 12)}`;
}

function getRoleEmoji(role) {
  const emojis = {
    'FREE': '🆓',
    'VIP': '👑',
    'VVIP': '💎',
    'ADMIN': '🛡️',
    'OWNER': '👨‍💻'
  };
  return emojis[role] || '👤';
}

function getRuntime() {
  const uptime = process.uptime();
  const days = Math.floor(uptime / 86400);
  const hours = Math.floor((uptime % 86400) / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  const seconds = Math.floor(uptime % 60);
  
  const parts = [];
  if (days > 0) parts.push(`${days}h`);
  if (hours > 0) parts.push(`${hours}j`);
  if (minutes > 0) parts.push(`${minutes}m`);
  parts.push(`${seconds}d`);
  
  return parts.join(' ');
}

async function getBotStatistics() {
  try {
    const stats = await statsDB.read();
    const users = await userDB.read();
    
    const totalUsers = users.data.length;
    const totalActivities = stats.global.totalActivities || 0;
    const totalSuccess = stats.global.totalSuccess || 0;
    const successRate = totalActivities > 0 
      ? ((totalSuccess / totalActivities) * 100).toFixed(1)
      : 0;
    
    return {
      totalUsers,
      totalActivities,
      successRate,
      activeUsers: stats.global.activeUsers || 0
    };
  } catch (error) {
    logger.error('Error getting statistics:', error);
    return {
      totalUsers: 0,
      totalActivities: 0,
      successRate: 0,
      activeUsers: 0
    };
  }
}

// Tetap menggunakan satu ekspor di akhir file
export { startHandler, showMainMenu };
