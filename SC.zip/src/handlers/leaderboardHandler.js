import { Markup } from 'telegraf';
import { Logger } from '../utils/logger.js';
import { DatabaseManager } from '../database/init.js';
import { configManager } from '../config/configManager.js';

const logger = new Logger();
const leaderboardDB = new DatabaseManager('leaderboard');
const userDB = new DatabaseManager('users');
const statsDB = new DatabaseManager('statistics');

export async function leaderboardHandler(ctx) {
  try {
    const userId = ctx.from.id;
    logger.activity(userId, 'view_leaderboard');
    
    const category = ctx.message?.text?.split(' ')[1] || 'global';
    await showLeaderboard(ctx, userId, category, 1);
    
  } catch (error) {
    logger.error('Leaderboard handler error:', error);
    await ctx.reply('❌ Gagal memuat leaderboard').catch(() => {});
  }
}

export function setupLeaderboardActions(bot) {
  
  bot.action('menu_leaderboard', async (ctx) => {
    await ctx.answerCbQuery();
    await showLeaderboard(ctx, ctx.from.id, 'global', 1);
  });

  bot.action(/leaderboard_(.+)_page_(\d+)/, async (ctx) => {
    await ctx.answerCbQuery();
    const category = ctx.match[1];
    const page = parseInt(ctx.match[2]);
    await showLeaderboard(ctx, ctx.from.id, category, page);
  });

  bot.action('leaderboard_global', async (ctx) => {
    await ctx.answerCbQuery('🌍 Global');
    await showLeaderboard(ctx, ctx.from.id, 'global', 1);
  });

  bot.action('leaderboard_daily', async (ctx) => {
    await ctx.answerCbQuery('📅 Harian');
    await showLeaderboard(ctx, ctx.from.id, 'daily', 1);
  });

  bot.action('leaderboard_weekly', async (ctx) => {
    await ctx.answerCbQuery('📊 Mingguan');
    await showLeaderboard(ctx, ctx.from.id, 'weekly', 1);
  });

  bot.action('leaderboard_country', async (ctx) => {
    await ctx.answerCbQuery('🌏 Negara');
    await showLeaderboard(ctx, ctx.from.id, 'country', 1);
  });
}

async function showLeaderboard(ctx, userId, category = 'global', page = 1) {
  try {
    const limit = 10;
    
    // Update leaderboard data
    await updateLeaderboardData();
    
    // Get leaderboard data
    const lbData = await leaderboardDB.read();
    let rankings = [];
    let title = '';
    
    switch (category) {
      case 'global':
        rankings = lbData.global || [];
        title = '🌍 GLOBAL';
        break;
      case 'daily':
        rankings = lbData.daily || [];
        title = '📅 HARIAN';
        break;
      case 'weekly':
        rankings = lbData.weekly || [];
        title = '📊 MINGGUAN';
        break;
      case 'country':
        title = '🌏 NEGARA';
        // Country rankings handled differently
        return showCountryLeaderboard(ctx, userId, page);
      default:
        rankings = lbData.global || [];
        title = '🌍 GLOBAL';
    }
    
    const totalRanked = rankings.length;
    const totalPages = Math.ceil(totalRanked / limit) || 1;
    const offset = (page - 1) * limit;
    const pageRankings = rankings.slice(offset, offset + limit);
    
    // Get user's rank
    const userRank = rankings.findIndex(r => r.userId === userId) + 1;
    
    let message = 
      `🏆 *TOP ${title}*\n` +
      `──────────────────\n`;
    
    if (userRank > 0) {
      message += `👤 *Peringkat Kamu:* #${userRank}\n\n`;
    } else {
      message += `👤 *Peringkat Kamu:* Belum terdaftar\n\n`;
    }
    
    if (pageRankings.length === 0) {
      message += `📭 Belum ada data leaderboard.\n\n` +
                 `Gunakan bot secara aktif untuk masuk peringkat! 🚀`;
    } else {
      pageRankings.forEach((rank, index) => {
        const position = offset + index + 1;
        const medal = getMedalEmoji(position);
        const username = rank.username || `User ${rank.userId}`;
        
        message += 
          `${medal} *${position}.* @${username}\n` +
          `   📊 Aktivitas: ${rank.totalActivities || 0}\n` +
          `   ✅ Sukses: ${rank.successCount || 0}\n` +
          `   ⭐ Rate: ${rank.successRate || 0}%\n\n`;
      });
    }
    
    message += `──────────────────\n` +
               `📄 Halaman ${page}/${totalPages}`;
    
    // Build keyboard
    const keyboard = [];
    
    // Category selector
    keyboard.push([
      Markup.button.callback(
        `${category === 'global' ? '✅ ' : ''}Global`,
        'leaderboard_global'
      ),
      Markup.button.callback(
        `${category === 'daily' ? '✅ ' : ''}Harian`,
        'leaderboard_daily'
      )
    ]);
    
    keyboard.push([
      Markup.button.callback(
        `${category === 'weekly' ? '✅ ' : ''}Mingguan`,
        'leaderboard_weekly'
      ),
      Markup.button.callback(
        `${category === 'country' ? '✅ ' : ''}Negara`,
        'leaderboard_country'
      )
    ]);
    
    // Navigation buttons
    if (totalPages > 1) {
      const navButtons = [];
      
      if (page > 1) {
        navButtons.push(
          Markup.button.callback('◀️', `leaderboard_${category}_page_${page - 1}`)
        );
      }
      
      navButtons.push(
        Markup.button.callback(`${page}/${totalPages}`, 'leaderboard_nop')
      );
      
      if (page < totalPages) {
        navButtons.push(
          Markup.button.callback('▶️', `leaderboard_${category}_page_${page + 1}`)
        );
      }
      
      keyboard.push(navButtons);
    }
    
    keyboard.push([
      Markup.button.callback('🔄 Refresh', 'menu_leaderboard'),
      Markup.button.callback('🔙 Menu', 'menu_back')
    ]);
    
    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    }).catch(async () => {
      await ctx.reply(message, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard(keyboard)
      });
    });
    
  } catch (error) {
    logger.error('Show leaderboard error:', error);
    await ctx.reply('❌ Gagal memuat leaderboard');
  }
}

async function showCountryLeaderboard(ctx, userId, page) {
  const lbData = await leaderboardDB.read();
  const countryData = lbData.byCountry || {};
  
  const countries = Object.entries(countryData)
    .sort((a, b) => b[1].totalActivities - a[1].totalActivities);
  
  let message = 
    `🌏 *LEADERBOARD NEGARA*\n` +
    `──────────────────\n\n`;
  
  if (countries.length === 0) {
    message += `📭 Belum ada data negara.`;
  } else {
    countries.slice(0, 10).forEach(([country, data], index) => {
      const medal = getMedalEmoji(index + 1);
      message += 
        `${medal} *${index + 1}.* ${getCountryFlag(country)} ${country}\n` +
        `   👥 Users: ${data.users || 0}\n` +
        `   📊 Activities: ${data.totalActivities || 0}\n\n`;
    });
  }
  
  const keyboard = [
    [
      Markup.button.callback('🌍 Global', 'leaderboard_global'),
      Markup.button.callback('📅 Harian', 'leaderboard_daily')
    ],
    [Markup.button.callback('🔙 Kembali', 'menu_leaderboard')]
  ];
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

async function updateLeaderboardData() {
  try {
    const users = await userDB.read();
    const stats = await statsDB.read();
    
    // Build global rankings
    const globalRankings = users.data
      .map(user => ({
        userId: user.id,
        username: user.username,
        firstName: user.firstName,
        totalActivities: user.totalActivities || 0,
        successCount: user.totalSuccess || 0,
        successRate: user.totalActivities > 0 
          ? ((user.totalSuccess / user.totalActivities) * 100).toFixed(1)
          : 0,
        role: user.role
      }))
      .filter(user => user.totalActivities > 0)
      .sort((a, b) => b.totalActivities - a.totalActivities);
    
    // Get today's date
    const today = new Date().toISOString().split('T')[0];
    
    // Build daily rankings (from today's stats)
    const dailyStats = stats.daily[today] || {};
    const dailyRankings = globalRankings
      .slice(0, 50)
      .sort((a, b) => (dailyStats[a.userId] || 0) - (dailyStats[b.userId] || 0))
      .reverse();
    
    // Build weekly rankings (last 7 days)
    const weeklyRankings = globalRankings.slice(0, 50);
    
    // Build country rankings
    const countryStats = {};
    users.data.forEach(user => {
      const country = user.country || 'Unknown';
      if (!countryStats[country]) {
        countryStats[country] = { users: 0, totalActivities: 0 };
      }
      countryStats[country].users++;
      countryStats[country].totalActivities += user.totalActivities || 0;
    });
    
    // Update leaderboard database
    await leaderboardDB.write({
      global: globalRankings.slice(0, 100),
      daily: dailyRankings,
      weekly: weeklyRankings,
      byCountry: countryStats,
      lastUpdated: new Date().toISOString()
    });
    
  } catch (error) {
    logger.error('Update leaderboard error:', error);
  }
}

function getMedalEmoji(position) {
  if (position === 1) return '🥇';
  if (position === 2) return '🥈';
  if (position === 3) return '🥉';
  if (position <= 10) return '⭐';
  return '📌';
}

function getCountryFlag(country) {
  const flags = {
    'Indonesia': '🇮🇩',
    'Malaysia': '🇲🇾',
    'Singapore': '🇸🇬',
    'Thailand': '🇹🇭',
    'Vietnam': '🇻🇳',
    'Philippines': '🇵🇭',
    'Unknown': '🌍'
  };
  return flags[country] || '🌍';
}

export { updateLeaderboardData };