import { Markup } from 'telegraf';
import { Logger } from '../utils/logger.js';
import { DatabaseManager } from '../database/init.js';
import { configManager } from '../config/configManager.js';
import { qrisGenerator } from '../services/qrisGenerator.js';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs-extra';

const logger = new Logger();
const userDB = new DatabaseManager('users');
const subscriptionDB = new DatabaseManager('subscriptions');
const invoiceDB = new DatabaseManager('invoices');

export function subscriptionHandler(bot) {
  
  // Menu Subscription
  bot.action('menu_subscription', async (ctx) => {
    await ctx.answerCbQuery();
    await showSubscriptionMenu(ctx);
  });

  // Select plan
  bot.action(/sub_plan_(.+)/, async (ctx) => {
    await ctx.answerCbQuery();
    const plan = ctx.match[1];
    await showPlanDetail(ctx, plan);
  });

  // Confirm order
  bot.action(/sub_confirm_(.+)/, async (ctx) => {
    await ctx.answerCbQuery();
    const plan = ctx.match[1];
    await createOrder(ctx, plan);
  });

  // Cancel order
  bot.action('sub_cancel', async (ctx) => {
    await ctx.answerCbQuery('❌ Dibatalkan');
    
    await ctx.editMessageCaption(
      '❌ *Pemesanan Dibatalkan*\n\nSilakan pilih menu lain.',
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('🔙 Menu Subscription', 'menu_subscription')],
          [Markup.button.callback('🏠 Menu Utama', 'menu_back')]
        ])
      }
    ).catch(() => {
      ctx.reply('❌ Pemesanan dibatalkan.');
    });
  });

  // Check payment
  bot.action(/check_payment_(.+)/, async (ctx) => {
    await ctx.answerCbQuery('🔄 Memeriksa pembayaran...');
    const orderId = ctx.match[1];
    await checkPaymentStatus(ctx, orderId);
  });
}

async function showSubscriptionMenu(ctx) {
  const userId = ctx.from.id;
  const user = await userDB.findOne(u => u.id === userId);
  
  if (!user) return;
  
  const message = 
    `👑 *SUBSCRIPTION VIP/VVIP*\n` +
    `──────────────────\n\n` +
    `💎 *Status Saat Ini:* ${user.role}\n` +
    (user.subscriptionExpiry ? 
      `📅 *Berlaku hingga:* ${new Date(user.subscriptionExpiry).toLocaleDateString('id-ID')}\n` : 
      `📅 *Berlaku hingga:* Tidak ada\n`) +
    `\n` +
    `🎯 *Pilih Paket:*\n\n` +
    `*VIP*\n` +
    `✅ Unlimited Fix Merah\n` +
    `✅ 5 Nomor Sekaligus\n` +
    `✅ Prioritas Queue\n\n` +
    `*VVIP*\n` +
    `✅ Semua fitur VIP\n` +
    `✅ 25 Nomor Sekaligus\n` +
    `✅ Prioritas Tertinggi\n` +
    `✅ Support 24/7\n\n` +
    `Pilih paket di bawah ini:`;
  
  const prices = configManager.get('subscriptionPrices');
  
  const keyboard = [
    [
      Markup.button.callback(`👑 VIP 1 Hari - Rp ${prices.vip1Day}`, 'sub_plan_vip1Day'),
      Markup.button.callback(`👑 VIP 7 Hari - Rp ${prices.vip7Days}`, 'sub_plan_vip7Days')
    ],
    [
      Markup.button.callback(`👑 VIP 30 Hari - Rp ${prices.vip30Days}`, 'sub_plan_vip30Days')
    ],
    [
      Markup.button.callback(`💎 VVIP 1 Hari - Rp ${prices.vvip1Day}`, 'sub_plan_vvip1Day'),
      Markup.button.callback(`💎 VVIP 7 Hari - Rp ${prices.vvip7Days}`, 'sub_plan_vvip7Days')
    ],
    [
      Markup.button.callback(`💎 VVIP 30 Hari - Rp ${prices.vvip30Days}`, 'sub_plan_vvip30Days')
    ],
    [Markup.button.callback('🔙 Kembali ke Menu', 'menu_back')]
  ];
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
  
  logger.activity(userId, 'view_subscription_menu');
}

async function showPlanDetail(ctx, plan) {
  const prices = configManager.get('subscriptionPrices');
  const price = prices[plan] || 0;
  
  const planNames = {
    'vip1Day': 'VIP 1 Hari',
    'vip7Days': 'VIP 7 Hari',
    'vip30Days': 'VIP 30 Hari',
    'vvip1Day': 'VVIP 1 Hari',
    'vvip7Days': 'VVIP 7 Hari',
    'vvip30Days': 'VVIP 30 Hari'
  };
  
  const days = {
    'vip1Day': 1, 'vip7Days': 7, 'vip30Days': 30,
    'vvip1Day': 1, 'vvip7Days': 7, 'vvip30Days': 30
  };
  
  const features = plan.startsWith('vvip') 
    ? '✅ Semua fitur VIP\n✅ 25 Nomor\n✅ Prioritas Tertinggi\n✅ Support 24/7'
    : '✅ Unlimited\n✅ 5 Nomor\n✅ Prioritas Queue';
  
  const message = 
    `📋 *DETAIL PAKET*\n` +
    `──────────────────\n\n` +
    `📦 *Paket:* ${planNames[plan]}\n` +
    `💰 *Harga:* Rp ${price.toLocaleString('id-ID')}\n` +
    `📅 *Durasi:* ${days[plan]} Hari\n\n` +
    `✨ *Fitur:*\n${features}\n\n` +
    `🔒 Pembayaran aman via QRIS\n` +
    `⚡ Aktivasi instan setelah bayar`;
  
  const keyboard = [
    [Markup.button.callback(`✅ Pesan Sekarang - Rp ${price.toLocaleString('id-ID')}`, `sub_confirm_${plan}`)],
    [Markup.button.callback('❌ Batal', 'menu_subscription')]
  ];
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(keyboard)
  }).catch(async () => {
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  });
}

async function createOrder(ctx, plan) {
  const userId = ctx.from.id;
  const user = await userDB.findOne(u => u.id === userId);
  const prices = configManager.get('subscriptionPrices');
  const amount = prices[plan];
  
  // Generate order ID
  const orderId = `QASHVRA-${plan.toUpperCase()}-${userId}-${Date.now().toString(36).toUpperCase()}`;
  
  // Generate QRIS
  const qrisResult = await qrisGenerator.generateDynamicQRIS(amount, orderId);
  
  // Create invoice record
  const invoice = {
    id: orderId,
    userId: userId,
    plan: plan,
    amount: amount,
    status: 'pending',
    qrisImage: qrisResult.fileName,
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 3600000).toISOString(), // 1 jam
    paymentMethod: 'QRIS'
  };
  
  await invoiceDB.insert(invoice);
  
  // Kirim invoice ke user
  const message = 
    `🧾 *INVOICE PEMBAYARAN*\n` +
    `──────────────────\n\n` +
    `📋 *Order ID:* \`${orderId}\`\n` +
    `📦 *Paket:* ${getPlanName(plan)}\n` +
    `💰 *Jumlah:* Rp ${amount.toLocaleString('id-ID')}\n` +
    `⏰ *Expired:* ${new Date(invoice.expiresAt).toLocaleString('id-ID')}\n\n` +
    `📱 *Cara Bayar:*\n` +
    `1. Buka aplikasi e-wallet/ banking\n` +
    `2. Scan QRIS di bawah ini\n` +
    `3. Konfirmasi pembayaran\n` +
    `4. Klik "Cek Pembayaran"\n\n` +
    `⚠️ Pembayaran otomatis terdeteksi!`;
  
  const keyboard = [
    [Markup.button.callback('🔄 Cek Pembayaran', `check_payment_${orderId}`)],
    [Markup.button.callback('❌ Batalkan', 'sub_cancel')],
    [Markup.button.callback('🔙 Menu Subscription', 'menu_subscription')]
  ];
  
  try {
    // Kirim foto QRIS
    await ctx.replyWithPhoto(
      { source: qrisResult.filePath },
      {
        caption: message,
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard(keyboard)
      }
    );
  } catch (error) {
    // Fallback tanpa foto
    await ctx.reply(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard(keyboard)
    });
  }
  
  // Set timer untuk auto-expire
  setTimeout(async () => {
    await checkAndExpireOrder(orderId);
  }, 3600000);
  
  logger.payment(userId, amount, 'pending', { orderId, plan });
}

async function checkPaymentStatus(ctx, orderId) {
  const invoice = await invoiceDB.findOne(i => i.id === orderId);
  
  if (!invoice) {
    return ctx.answerCbQuery('❌ Invoice tidak ditemukan');
  }
  
  if (invoice.status === 'paid') {
    await ctx.answerCbQuery('✅ Sudah dibayar!');
    
    const message = 
      `✅ *PEMBAYARAN BERHASIL*\n` +
      `──────────────────\n\n` +
      `📋 *Order ID:* \`${orderId}\`\n` +
      `📦 *Paket:* ${getPlanName(invoice.plan)}\n` +
      `💰 *Jumlah:* Rp ${invoice.amount.toLocaleString('id-ID')}\n` +
      `⏰ *Dibayar:* ${new Date(invoice.paidAt).toLocaleString('id-ID')}\n\n` +
      `🎉 Selamat! Langganan kamu sudah aktif!\n` +
      `Nikmati semua fitur premium.`;
    
    await ctx.editMessageCaption(message, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🏠 Menu Utama', 'menu_back')]
      ])
    }).catch(async () => {
      await ctx.reply(message, { parse_mode: 'Markdown' });
    });
    
    return;
  }
  
  // Simulasi cek pembayaran (di production, integrasi dengan payment gateway)
  const isPaid = await simulatePaymentCheck(invoice);
  
  if (isPaid) {
    await processSuccessfulPayment(ctx, invoice);
  } else {
    const timeLeft = Math.max(0, Math.floor((new Date(invoice.expiresAt) - Date.now()) / 60000));
    
    await ctx.answerCbQuery(
      timeLeft > 0 
        ? `⏳ Belum dibayar. Sisa waktu: ${timeLeft} menit`
        : '❌ Invoice expired'
    );
  }
}

async function processSuccessfulPayment(ctx, invoice) {
  const userId = invoice.userId;
  const plan = invoice.plan;
  
  // Update invoice status
  await invoiceDB.updateById(invoice.id, {
    status: 'paid',
    paidAt: new Date().toISOString()
  });
  
  // Calculate days
  const days = {
    'vip1Day': 1, 'vip7Days': 7, 'vip30Days': 30,
    'vvip1Day': 1, 'vvip7Days': 7, 'vvip30Days': 30
  };
  
  const duration = days[plan] || 1;
  const role = plan.startsWith('vvip') ? 'VVIP' : 'VIP';
  
  // Update user subscription
  const currentExpiry = await userDB.findOne(u => u.id === userId)
    .then(u => u?.subscriptionExpiry);
  
  const startDate = currentExpiry && new Date(currentExpiry) > new Date()
    ? new Date(currentExpiry)
    : new Date();
  
  const expiryDate = new Date(startDate.getTime() + duration * 86400000);
  
  await userDB.updateById(userId, {
    role: role,
    subscriptionExpiry: expiryDate.toISOString(),
    dailyLimit: role === 'VVIP' ? 999999 : 999999,
    updatedAt: new Date().toISOString()
  });
  
  // Add to subscription records
  await subscriptionDB.insert({
    id: `SUB_${Date.now()}`,
    userId: userId,
    plan: plan,
    role: role,
    startDate: startDate.toISOString(),
    expiryDate: expiryDate.toISOString(),
    orderId: invoice.id,
    status: 'active',
    createdAt: new Date().toISOString()
  });
  
  logger.success(`Payment successful for user ${userId}: ${plan}`);
  
  // Notify user
  const message = 
    `🎉 *PEMBAYARAN BERHASIL!*\n` +
    `──────────────────\n\n` +
    `✅ Pembayaran Rp ${invoice.amount.toLocaleString('id-ID')} diterima\n\n` +
    `👑 *${role}* telah diaktifkan!\n` +
    `📅 Berlaku hingga: ${expiryDate.toLocaleDateString('id-ID')}\n\n` +
    `Nikmati semua fitur premium Qashvra! 🚀`;
  
  await ctx.editMessageCaption(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🔴 Mulai Fix Merah', 'menu_fixmerah')],
      [Markup.button.callback('🏠 Menu Utama', 'menu_back')]
    ])
  }).catch(async () => {
    await ctx.reply(message, { parse_mode: 'Markdown' });
  });
}

async function checkAndExpireOrder(orderId) {
  const invoice = await invoiceDB.findOne(i => i.id === orderId);
  
  if (invoice && invoice.status === 'pending') {
    await invoiceDB.updateById(orderId, {
      status: 'expired'
    });
    
    logger.info(`Order ${orderId} expired`);
  }
}

async function simulatePaymentCheck(invoice) {
  // Di production, ini akan mengecek ke payment gateway
  // Untuk demo, kita asumsikan selalu berhasil setelah 5 detik
  const elapsed = Date.now() - new Date(invoice.createdAt).getTime();
  return elapsed > 5000; // Auto-success after 5 seconds for demo
}

function getPlanName(plan) {
  const names = {
    'vip1Day': 'VIP 1 Hari',
    'vip7Days': 'VIP 7 Hari',
    'vip30Days': 'VIP 30 Hari',
    'vvip1Day': 'VVIP 1 Hari',
    'vvip7Days': 'VVIP 7 Hari',
    'vvip30Days': 'VVIP 30 Hari'
  };
  return names[plan] || plan;
}