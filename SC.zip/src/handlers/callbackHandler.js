import { Markup } from 'telegraf';
import { Logger } from '../utils/logger.js';
import { showMainMenu } from './startHandler.js';
import { handleMenuActions } from './menuHandler.js';
import { setupHistoryActions } from './historyHandler.js';
import { setupLeaderboardActions } from './leaderboardHandler.js';
import { setupReferralActions } from './referralHandler.js';
import { setupAdminActions } from './adminHandler.js';

const logger = new Logger();

export function callbackHandler(bot, queueManager) {
  
  // Setup all action handlers
  handleMenuActions(bot);
  setupHistoryActions(bot);
  setupLeaderboardActions(bot);
  setupReferralActions(bot);
  setupAdminActions(bot);
  
  // Global callback query handler
  bot.on('callback_query', async (ctx, next) => {
    try {
      const data = ctx.callbackQuery?.data;
      
      if (!data) {
        return next();
      }
      
      logger.info(`Callback received: ${data} from user ${ctx.from?.id}`);
      
      // Handle unknown callbacks
      // Most callbacks are handled by specific action handlers above
      
      return next();
      
    } catch (error) {
      logger.error('Callback handler error:', error);
      
      try {
        await ctx.answerCbQuery('❌ Terjadi kesalahan').catch(() => {});
      } catch (e) {
        // Ignore callback answer errors
      }
    }
  });

  // Handle verification check
  bot.action('check_verification', async (ctx) => {
    await ctx.answerCbQuery('🔄 Memeriksa verifikasi...');
    
    try {
      const { checkUserVerification } = await import('../middleware/verification.js');
      const isVerified = await checkUserVerification(ctx);
      
      if (isVerified) {
        const userDB = new (await import('../database/init.js')).DatabaseManager('users');
        await userDB.updateById(ctx.from.id, { verified: true });
        
        await ctx.editMessageText('✅ Verifikasi berhasil! Gunakan /start untuk memulai.');
        
        // Trigger start command
        setTimeout(() => {
          ctx.reply('/start');
        }, 1000);
        
      } else {
        await ctx.answerCbQuery('❌ Belum join semua channel!', { show_alert: true });
      }
    } catch (error) {
      logger.error('Verification check error:', error);
      await ctx.answerCbQuery('❌ Gagal memeriksa', { show_alert: true });
    }
  });

  // Handle fixing callback query timeouts
  bot.on('callback_query', async (ctx, next) => {
    // Auto-answer any callback that hasn't been answered within 10 seconds
    const timeout = setTimeout(() => {
      ctx.answerCbQuery().catch(() => {});
    }, 10000);
    
    try {
      await next();
    } finally {
      clearTimeout(timeout);
    }
  });

  logger.success('Callback handler configured');
}

// Helper function untuk membuat keyboard konfirmasi
export function createConfirmKeyboard(yesData, noData = 'menu_back') {
  return Markup.inlineKeyboard([
    [
      Markup.button.callback('✅ Ya', yesData),
      Markup.button.callback('❌ Tidak', noData)
    ]
  ]);
}

// Helper function untuk membuat pagination keyboard
export function createPaginationKeyboard(
  currentPage, 
  totalPages, 
  baseCallback, 
  extraButtons = []
) {
  const keyboard = [];
  
  // Navigation row
  const navRow = [];
  
  if (currentPage > 1) {
    navRow.push(
      Markup.button.callback('◀️ Sebelumnya', `${baseCallback}_page_${currentPage - 1}`)
    );
  }
  
  navRow.push(
    Markup.button.callback(`📄 ${currentPage}/${totalPages}`, `${baseCallback}_nop`)
  );
  
  if (currentPage < totalPages) {
    navRow.push(
      Markup.button.callback('Selanjutnya ▶️', `${baseCallback}_page_${currentPage + 1}`)
    );
  }
  
  keyboard.push(navRow);
  
  // Extra buttons
  extraButtons.forEach(button => {
    keyboard.push([button]);
  });
  
  // Back button
  keyboard.push([
    Markup.button.callback('🔙 Kembali', 'menu_back')
  ]);
  
  return Markup.inlineKeyboard(keyboard);
}

// Helper function untuk loading state
export function createLoadingKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('⏳ Loading...', 'loading_nop')]
  ]);
}

// Helper function untuk error state
export function createErrorKeyboard(retryData = 'menu_back') {
  return Markup.inlineKeyboard([
    [Markup.button.callback('🔄 Coba Lagi', retryData)],
    [Markup.button.callback('🔙 Menu Utama', 'menu_back')]
  ]);
}