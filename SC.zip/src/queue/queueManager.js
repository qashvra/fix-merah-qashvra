import { Logger } from '../utils/logger.js';
import { DatabaseManager } from '../database/init.js';
import { configManager } from '../config/configManager.js';

const logger = new Logger();
const historyDB = new DatabaseManager('history');

class QueueManager {
  constructor() {
    this.queues = {
      normal: [],
      priority: [],
      highPriority: []
    };
    this.processing = new Set();
    this.maxConcurrent = 10;
    this.isRunning = false;
    this.processInterval = null;
    this.stats = {
      total: 0,
      completed: 0,
      failed: 0,
      pending: 0
    };
  }

  async start() {
    this.isRunning = true;
    this.maxConcurrent = configManager.get('queueSettings.maxConcurrent', 10);
    
    // Process queue every second
    this.processInterval = setInterval(() => {
      this.processQueue();
    }, 1000);
    
    logger.success('Queue Manager started');
  }

  async stop() {
    this.isRunning = false;
    if (this.processInterval) {
      clearInterval(this.processInterval);
    }
    
    // Wait for all processing tasks to complete
    await this.waitForProcessing();
    logger.success('Queue Manager stopped');
  }

  async addToQueue(task, priority = 'normal') {
    const queueItem = {
      id: `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      task,
      priority,
      addedAt: new Date().toISOString(),
      attempts: 0,
      status: 'pending'
    };

    switch (priority) {
      case 'vvip':
        this.queues.highPriority.push(queueItem);
        break;
      case 'vip':
        this.queues.priority.push(queueItem);
        break;
      default:
        this.queues.normal.push(queueItem);
    }

    this.stats.total++;
    this.stats.pending++;
    
    logger.info(`Task added to queue: ${queueItem.id} (${priority})`);
    
    return queueItem.id;
  }

  async processQueue() {
    if (!this.isRunning) return;
    
    const availableSlots = this.maxConcurrent - this.processing.size;
    if (availableSlots <= 0) return;

    // Get next tasks (prioritize by queue type)
    const tasks = this.getNextTasks(availableSlots);
    
    for (const task of tasks) {
      this.processing.add(task.id);
      this.stats.pending--;
      
      // Process task asynchronously
      this.processTask(task).finally(() => {
        this.processing.delete(task.id);
      });
    }
  }

  getNextTasks(count) {
    const tasks = [];
    
    // Get from high priority queue first
    while (tasks.length < count && this.queues.highPriority.length > 0) {
      tasks.push(this.queues.highPriority.shift());
    }
    
    // Then from priority queue
    while (tasks.length < count && this.queues.priority.length > 0) {
      tasks.push(this.queues.priority.shift());
    }
    
    // Finally from normal queue
    while (tasks.length < count && this.queues.normal.length > 0) {
      tasks.push(this.queues.normal.shift());
    }
    
    return tasks;
  }

  async processTask(queueItem) {
    try {
      queueItem.status = 'processing';
      queueItem.startedAt = new Date().toISOString();
      
      logger.info(`Processing task: ${queueItem.id}`);
      
      // Execute the task
      const result = await queueItem.task();
      
      queueItem.status = 'success';
      queueItem.completedAt = new Date().toISOString();
      queueItem.result = result;
      
      this.stats.completed++;
      
      // Save to history
      await this.saveToHistory(queueItem);
      
      logger.success(`Task completed: ${queueItem.id}`);
      
    } catch (error) {
      queueItem.attempts++;
      queueItem.lastError = error.message;
      
      const maxRetries = configManager.get('queueSettings.retryAttempts', 3);
      
      if (queueItem.attempts < maxRetries) {
        // Retry the task
        queueItem.status = 'pending';
        
        switch (queueItem.priority) {
          case 'vvip':
            this.queues.highPriority.unshift(queueItem);
            break;
          case 'vip':
            this.queues.priority.unshift(queueItem);
            break;
          default:
            this.queues.normal.unshift(queueItem);
        }
        
        this.stats.pending++;
        logger.warning(`Task ${queueItem.id} failed, retrying (${queueItem.attempts}/${maxRetries})`);
      } else {
        queueItem.status = 'failed';
        this.stats.failed++;
        
        await this.saveToHistory(queueItem);
        logger.error(`Task ${queueItem.id} failed permanently:`, error);
      }
    }
  }

  async saveToHistory(queueItem) {
    try {
      await historyDB.insert({
        id: queueItem.id,
        type: 'queue_task',
        status: queueItem.status,
        priority: queueItem.priority,
        addedAt: queueItem.addedAt,
        completedAt: queueItem.completedAt,
        attempts: queueItem.attempts,
        result: queueItem.result,
        error: queueItem.lastError
      });
    } catch (error) {
      logger.error('Failed to save queue history:', error);
    }
  }

  getQueueStatus() {
    return {
      stats: { ...this.stats },
      queues: {
        normal: this.queues.normal.length,
        priority: this.queues.priority.length,
        highPriority: this.queues.highPriority.length
      },
      processing: this.processing.size,
      maxConcurrent: this.maxConcurrent
    };
  }

  async waitForProcessing() {
    const timeout = 30000; // 30 seconds max wait
    const startTime = Date.now();
    
    while (this.processing.size > 0) {
      if (Date.now() - startTime > timeout) {
        logger.warning('Timeout waiting for queue processing');
        break;
      }
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }
}

export { QueueManager };