import { Logger } from '../utils/logger.js';
import { configManager } from '../config/configManager.js';

const logger = new Logger();

// Rate limit tracking
const rateLimits = new Map();
const banList = new Map();
const cooldowns = new Map();

// Cleanup interval
const CLEANUP_INTERVAL = 5 * 60 * 1000; // 5 menit

setInterval(() => {
  cleanupRateLimits();
}, CLEANUP_INTERVAL);

export function rateLimiter() {
  return async (ctx, next) => {
    try {
      // Skip untuk admin/owner
      if (ctx.from && configManager.isAdmin(ctx.from.id)) {
        return next();
      }
      
      const userId = ctx.from?.id;
      
      if (!userId) {
        return next();
      }
      
      // Check ban
      if (isUserBanned(userId)) {
        // Silent ignore - jangan reply untuk banned users
        return;
      }
      
      // Check cooldown
      if (isInCooldown(userId)) {
        const remaining = getCooldownRemaining(userId);
        
        await ctx.reply(
          `⏳ *COOLDOWN*\n\n` +
          `Kamu terlalu cepat!\n` +
          `Silakan tunggu *${remaining} detik* lagi.`,
          { parse_mode: 'Markdown' }
        ).catch(() => {});
        
        return;
      }
      
      // Track request
      trackRequest(userId, ctx);
      
      // Check rate limit
      if (isRateLimited(userId)) {
        // Apply cooldown
        applyCooldown(userId);
        
        logger.warning(`Rate limit exceeded for user ${userId}`);
        
        await ctx.reply(
          `⚠️ *RATE LIMIT TERCAPAI*\n\n` +
          `Kamu mengirim terlalu banyak permintaan!\n` +
          `Silakan tunggu beberapa saat sebelum mencoba lagi.`,
          { parse_mode: 'Markdown' }
        ).catch(() => {});
        
        return;
      }
      
      // Check global rate limit
      if (isGlobalRateLimited()) {
        await ctx.reply(
          `🔄 *SERVER SIBUK*\n\n` +
          `Bot sedang menangani banyak permintaan.\n` +
          `Silakan coba lagi dalam beberapa detik.`,
          { parse_mode: 'Markdown' }
        ).catch(() => {});
        
        return;
      }
      
      return next();
      
    } catch (error) {
      logger.error('Rate limiter error:', error);
      return next(); // Jangan block user jika error
    }
  };
}

// Rate limit tracking functions

function trackRequest(userId, ctx) {
  let userLimit = rateLimits.get(userId);
  const now = Date.now();
  
  if (!userLimit) {
    userLimit = {
      requests: [],
      totalRequests: 0,
      lastReset: now,
      warnings: 0
    };
    rateLimits.set(userId, userLimit);
  }
  
  // Reset counter setiap menit
  if (now - userLimit.lastReset > 60000) {
    userLimit.requests = [];
    userLimit.lastReset = now;
  }
  
  userLimit.requests.push(now);
  userLimit.totalRequests++;
  
  // Simpan command history
  if (ctx.message?.text) {
    if (!userLimit.commandHistory) {
      userLimit.commandHistory = [];
    }
    userLimit.commandHistory.push({
      command: ctx.message.text,
      timestamp: now
    });
    
    // Keep only last 20
    if (userLimit.commandHistory.length > 20) {
      userLimit.commandHistory = userLimit.commandHistory.slice(-20);
    }
  }
}

function isRateLimited(userId) {
  const userLimit = rateLimits.get(userId);
  
  if (!userLimit) {
    return false;
  }
  
  const now = Date.now();
  const maxRequests = configManager.get('securitySettings.maxRequestsPerMinute', 30);
  
  // Hitung requests dalam 1 menit terakhir
  const recentRequests = userLimit.requests.filter(
    time => now - time < 60000
  );
  
  // Update requests list
  userLimit.requests = recentRequests;
  
  return recentRequests.length > maxRequests;
}

function isGlobalRateLimited() {
  // Track total requests across all users
  const now = Date.now();
  let totalRecentRequests = 0;
  
  for (const [userId, userLimit] of rateLimits.entries()) {
    totalRecentRequests += userLimit.requests.filter(
      time => now - time < 1000 // dalam 1 detik
    ).length;
  }
  
  // Max 100 requests per second globally
  return totalRecentRequests > 100;
}

function applyCooldown(userId) {
  const cooldownSeconds = configManager.get('securitySettings.cooldownSeconds', 60);
  
  cooldowns.set(userId, {
    until: Date.now() + (cooldownSeconds * 1000),
    reason: 'rate_limit',
    appliedAt: Date.now()
  });
  
  // Track warnings
  const userLimit = rateLimits.get(userId);
  if (userLimit) {
    userLimit.warnings++;
    
    // Ban jika terlalu banyak warning
    const maxWarnings = configManager.get('securitySettings.maxFailedAttempts', 5);
    
    if (userLimit.warnings >= maxWarnings) {
      banUser(userId, 'Exceeded maximum warnings');
    }
  }
  
  logger.warning(`Cooldown applied to user ${userId} for ${cooldownSeconds}s`);
}

function isInCooldown(userId) {
  const cooldown = cooldowns.get(userId);
  
  if (!cooldown) {
    return false;
  }
  
  if (Date.now() > cooldown.until) {
    cooldowns.delete(userId);
    return false;
  }
  
  return true;
}

function getCooldownRemaining(userId) {
  const cooldown = cooldowns.get(userId);
  
  if (!cooldown) {
    return 0;
  }
  
  const remaining = Math.ceil((cooldown.until - Date.now()) / 1000);
  return Math.max(0, remaining);
}

function banUser(userId, reason) {
  const banDuration = configManager.get('securitySettings.banDurationHours', 24);
  
  banList.set(userId, {
    bannedAt: Date.now(),
    bannedUntil: Date.now() + (banDuration * 3600000),
    reason: reason
  });
  
  logger.warning(`User ${userId} banned for ${banDuration} hours. Reason: ${reason}`);
}

function isUserBanned(userId) {
  const ban = banList.get(userId);
  
  if (!ban) {
    return false;
  }
  
  // Auto unban setelah durasi selesai
  if (Date.now() > ban.bannedUntil) {
    banList.delete(userId);
    logger.info(`User ${userId} auto-unbanned`);
    return false;
  }
  
  return true;
}

function cleanupRateLimits() {
  const now = Date.now();
  let cleanedCount = 0;
  
  // Cleanup rate limits
  for (const [userId, userLimit] of rateLimits.entries()) {
    if (now - userLimit.lastReset > 300000) { // 5 menit idle
      rateLimits.delete(userId);
      cleanedCount++;
    }
  }
  
  // Cleanup cooldowns
  for (const [userId, cooldown] of cooldowns.entries()) {
    if (now > cooldown.until) {
      cooldowns.delete(userId);
    }
  }
  
  // Cleanup bans
  for (const [userId, ban] of banList.entries()) {
    if (now > ban.bannedUntil) {
      banList.delete(userId);
    }
  }
  
  if (cleanedCount > 0) {
    logger.info(`Cleaned up ${cleanedCount} rate limit records`);
  }
}

// Admin functions

export function unbanUser(userId) {
  banList.delete(userId);
  cooldowns.delete(userId);
  
  // Reset warnings
  const userLimit = rateLimits.get(userId);
  if (userLimit) {
    userLimit.warnings = 0;
  }
  
  logger.admin('system', 'unban', userId);
}

export function resetUserLimits(userId) {
  rateLimits.delete(userId);
  cooldowns.delete(userId);
  logger.admin('system', 'reset_limits', userId);
}

export function getRateLimitStats() {
  return {
    activeLimits: rateLimits.size,
    activeCooldowns: cooldowns.size,
    activeBans: banList.size,
    bans: Array.from(banList.entries()).map(([userId, ban]) => ({
      userId,
      reason: ban.reason,
      bannedAt: new Date(ban.bannedAt).toISOString(),
      bannedUntil: new Date(ban.bannedUntil).toISOString()
    }))
  };
}

export function applyCommandCooldown(userId, commandName, cooldownMs = 5000) {
  const key = `${userId}_${commandName}`;
  const cooldown = cooldowns.get(key);
  
  if (cooldown && Date.now() < cooldown.until) {
    return false; // Still in cooldown
  }
  
  cooldowns.set(key, {
    until: Date.now() + cooldownMs,
    reason: `command_${commandName}`
  });
  
  return true;
}