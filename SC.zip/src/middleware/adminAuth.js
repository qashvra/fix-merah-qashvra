import { configManager } from '../config/configManager.js';
import { Logger } from '../utils/logger.js';
import { DatabaseManager } from '../database/init.js';

const logger = new Logger();
const userDB = new DatabaseManager('users');

// Daftar command yang memerlukan akses admin
const ADMIN_COMMANDS = [
  '/admin',
  '/broadcast',
  '/ban',
  '/unban',
  '/addvip',
  '/removevip',
  '/addadmin',
  '/removeadmin',
  '/stats',
  '/reset',
  '/smtp',
  '/maintenance',
  '/config'
];

const OWNER_ONLY_COMMANDS = [
  '/addadmin',
  '/removeadmin',
  '/resetall',
  '/config'
];

export function adminMiddleware() {
  return async (ctx, next) => {
    try {
      // Skip jika bukan command
      if (!ctx.message || !ctx.message.text) {
        return next();
      }
      
      const command = ctx.message.text.split(' ')[0].toLowerCase();
      const userId = ctx.from?.id;
      
      if (!userId) {
        return next();
      }
      
      // Check jika command memerlukan akses admin
      if (ADMIN_COMMANDS.includes(command)) {
        
        // Check apakah user adalah admin atau owner
        const isAdmin = configManager.isAdmin(userId);
        const isOwner = configManager.isOwner(userId);
        
        if (!isAdmin && !isOwner) {
          // User bukan admin
          logger.warning(`Unauthorized admin access attempt by user ${userId}: ${command}`);
          
          await ctx.reply(
            '⛔ *AKSES DITOLAK*\n\n' +
            'Maaf, command ini hanya untuk admin.\n' +
            'Hubungi @qashvra untuk informasi lebih lanjut.',
            { parse_mode: 'Markdown' }
          );
          
          return; // Stop processing
        }
        
        // Check owner-only commands
        if (OWNER_ONLY_COMMANDS.includes(command) && !isOwner) {
          logger.warning(`Unauthorized owner command attempt by admin ${userId}: ${command}`);
          
          await ctx.reply(
            '⛔ *AKSES DITOLAK*\n\n' +
            'Command ini hanya untuk owner bot.',
            { parse_mode: 'Markdown' }
          );
          
          return;
        }
        
        // Update last admin activity
        await userDB.updateById(userId, {
          lastAdminActivity: new Date().toISOString()
        });
        
        logger.admin(userId, command);
        
        // Tambahkan admin flag ke context
        ctx.isAdmin = true;
        ctx.isOwner = isOwner;
      }
      
      return next();
      
    } catch (error) {
      logger.error('Admin middleware error:', error);
      return next();
    }
  };
}

// Helper untuk mengecek akses admin di handler
export function requireAdmin(ctx) {
  if (!ctx.isAdmin) {
    ctx.reply('⛔ Akses ditolak. Admin only command.').catch(() => {});
    return false;
  }
  return true;
}

export function requireOwner(ctx) {
  if (!ctx.isOwner) {
    ctx.reply('⛔ Akses ditolak. Owner only command.').catch(() => {});
    return false;
  }
  return true;
}