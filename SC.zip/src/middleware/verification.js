import { configManager } from '../config/configManager.js';
import { DatabaseManager } from '../database/init.js';
import { Logger } from '../utils/logger.js';
import { Markup } from 'telegraf';

const logger = new Logger();
const userDB = new DatabaseManager('users');

// Perbaikan: Menghapus kata 'export' di depan function karena sudah di-export di baris paling bawah
function verificationMiddleware() {
  return async (ctx, next) => {
    try {
      // Skip verification for some commands
      const skipCommands = ['/start', '/help', '/verify'];
      if (ctx.message && ctx.message.text && 
          skipCommands.includes(ctx.message.text.split(' ')[0])) {
        return next();
      }

      // If no user ID (callback queries, etc), proceed
      if (!ctx.from) {
        return next();
      }

      const userId = ctx.from.id;
      const user = await userDB.findOne(u => u.id === userId);

      // If user not registered yet
      if (!user) {
        if (ctx.message && ctx.message.text === '/start') {
          return next();
        }
        await ctx.reply('⚠️ Silakan gunakan /start terlebih dahulu');
        return;
      }

      // If already verified
      if (user.verified) {
        return next();
      }

      // Check verification status
      const isVerified = await checkUserVerification(ctx);
      
      if (isVerified) {
        // Update user verification status
        await userDB.updateById(userId, { verified: true });
        logger.success(`User ${userId} verified successfully`);
        
        // Send welcome message
        await sendWelcomeMessage(ctx, user);
      } else {
        // Show verification required message
        await showVerificationRequired(ctx);
      }

    } catch (error) {
      logger.error('Verification middleware error:', error);
      await next();
    }
  };
}

async function checkUserVerification(ctx) {
  try {
    const requiredChannels = configManager.getRequiredChannels();
    
    if (requiredChannels.length === 0) {
      return true; // No channels required
    }

    const userId = ctx.from.id;
    let allJoined = true;

    for (const channel of requiredChannels) {
      try {
        const member = await ctx.telegram.getChatMember(channel, userId);
        
        const allowedStatuses = ['member', 'administrator', 'creator'];
        if (!allowedStatuses.includes(member.status)) {
          allJoined = false;
          break;
        }
      } catch (error) {
        logger.warning(`Failed to check membership for channel ${channel}: ${error.message}`);
        // If channel doesn't exist or bot is not admin, skip it
        if (error.description && error.description.includes('chat not found')) {
          logger.error(`Channel ${channel} not found, removing from required list`);
          await configManager.removeRequiredChannel(channel);
        }
        allJoined = false;
        break;
      }
    }

    return allJoined;
  } catch (error) {
    logger.error('Error checking verification:', error);
    return false;
  }
}

async function showVerificationRequired(ctx) {
  const requiredChannels = configManager.getRequiredChannels();
  
  const buttons = [];
  
  // Add join buttons for each channel
  requiredChannels.forEach((channel, index) => {
    const channelName = channel.replace('@', '');
    buttons.push([
      Markup.button.url(`🔗 Join ${channel}`, `https://t.me/${channelName}`)
    ]);
  });
  
  // Add verification check button
  buttons.push([
    Markup.button.callback('✅ Cek Verifikasi', 'check_verification')
  ]);

  const message = `⚠️ *VERIFIKASI DIPERLUKAN*\n\n` +
    `Hai ${ctx.from.first_name}! 👋\n\n` +
    `Untuk menggunakan bot ini, kamu harus bergabung ke channel resmi kami terlebih dahulu:\n\n` +
    requiredChannels.map((ch, i) => `${i + 1}. ${ch}`).join('\n') + 
    `\n\nSetelah bergabung, klik tombol *Cek Verifikasi* di bawah ini ✅`;

  await ctx.reply(message, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard(buttons)
  });
}

async function sendWelcomeMessage(ctx, user) {
  const message = `✅ *VERIFIKASI BERHASIL*\n\n` +
    `Selamat datang ${ctx.from.first_name}! 🎉\n\n` +
    `Kamu sekarang bisa menggunakan semua fitur bot Qashvra.\n\n` +
    `Gunakan /menu untuk melihat menu utama`;

  await ctx.reply(message, {
    parse_mode: 'Markdown'
  });
  
  logger.activity(ctx.from.id, 'verification_success');
}

// Tetap menggunakan ekspor di akhir file agar rapi dan tidak duplikat
export { checkUserVerification, verificationMiddleware };
