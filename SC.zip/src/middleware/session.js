import { DatabaseManager } from '../database/init.js';
import { Logger } from '../utils/logger.js';

const logger = new Logger();
const userDB = new DatabaseManager('users');

// Session store untuk melacak state user
const sessions = new Map();

// Cleanup session setiap 30 menit
const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 menit
const CLEANUP_INTERVAL = 10 * 60 * 1000; // 10 menit

// Jalankan cleanup berkala
setInterval(() => {
  cleanupSessions();
}, CLEANUP_INTERVAL);

export function sessionMiddleware() {
  return async (ctx, next) => {
    try {
      // Skip jika tidak ada user
      if (!ctx.from) {
        return next();
      }

      const userId = ctx.from.id;
      
      // Load atau buat session
      let session = sessions.get(userId);
      
      if (!session) {
        // Coba load dari database atau buat baru
        const user = await userDB.findOne(u => u.id === userId);
        
        session = {
          userId: userId,
          username: ctx.from.username || 'unknown',
          firstName: ctx.from.first_name || 'User',
          lastActivity: new Date().toISOString(),
          createdAt: new Date().toISOString(),
          
          // State management
          currentState: 'idle', // idle | waiting_input | processing
          stateData: {}, // Data temporary untuk state tertentu
          
          // Anti-spam tracking
          lastMessageTime: 0,
          messageCount: 0,
          commandHistory: [],
          
          // Rate limiting local
          requestCount: 0,
          lastRequestTime: Date.now(),
          
          // Session flags
          isBanned: user?.banned || false,
          isVerified: user?.verified || false,
          role: user?.role || 'FREE',
          
          // Timeout tracking
          lastUpdate: Date.now(),
          
          // Metadata
          ipAddress: null,
          userAgent: null
        };
        
        sessions.set(userId, session);
        logger.info(`Session created for user ${userId}`);
      } else {
        // Update existing session
        session.lastActivity = new Date().toISOString();
        session.lastUpdate = Date.now();
        session.username = ctx.from.username || session.username;
        session.firstName = ctx.from.first_name || session.firstName;
      }
      
      // Attach session ke context
      ctx.session = session;
      
      // Update user activity di database (throttled)
      await updateUserActivity(userId);
      
      return next();
      
    } catch (error) {
      logger.error('Session middleware error:', error);
      return next();
    }
  };
}

// Helper functions

async function updateUserActivity(userId) {
  try {
    // Update setiap 5 menit untuk mengurangi I/O
    const session = sessions.get(userId);
    
    if (session && (Date.now() - session.lastUpdate > 300000)) {
      await userDB.updateById(userId, {
        lastActivity: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      
      session.lastUpdate = Date.now();
    }
  } catch (error) {
    // Silent fail - jangan ganggu user experience
  }
}

function cleanupSessions() {
  const now = Date.now();
  let cleanedCount = 0;
  
  for (const [userId, session] of sessions.entries()) {
    if (now - session.lastUpdate > SESSION_TIMEOUT) {
      // Save session data ke database sebelum dihapus
      saveSessionToDatabase(userId, session);
      sessions.delete(userId);
      cleanedCount++;
    }
  }
  
  if (cleanedCount > 0) {
    logger.info(`Cleaned up ${cleanedCount} expired sessions`);
  }
}

async function saveSessionToDatabase(userId, session) {
  try {
    await userDB.updateById(userId, {
      lastSession: {
        state: session.currentState,
        lastActivity: session.lastActivity,
        messageCount: session.messageCount
      }
    });
  } catch (error) {
    // Silent fail
  }
}

// Session management functions

export function getSession(userId) {
  return sessions.get(userId);
}

export function setSessionState(userId, state, data = {}) {
  const session = sessions.get(userId);
  
  if (session) {
    session.currentState = state;
    session.stateData = data;
    session.lastUpdate = Date.now();
    return true;
  }
  
  return false;
}

export function clearSessionState(userId) {
  const session = sessions.get(userId);
  
  if (session) {
    session.currentState = 'idle';
    session.stateData = {};
    session.lastUpdate = Date.now();
    return true;
  }
  
  return false;
}

export function updateSessionData(userId, data) {
  const session = sessions.get(userId);
  
  if (session) {
    session.stateData = { ...session.stateData, ...data };
    session.lastUpdate = Date.now();
    return true;
  }
  
  return false;
}

export function getActiveSessionCount() {
  return sessions.size;
}

export function getSessionInfo(userId) {
  const session = sessions.get(userId);
  
  if (session) {
    return {
      userId: session.userId,
      username: session.username,
      currentState: session.currentState,
      messageCount: session.messageCount,
      lastActivity: session.lastActivity,
      role: session.role,
      isVerified: session.isVerified
    };
  }
  
  return null;
}

export function getAllSessions() {
  const sessionList = [];
  
  for (const [userId, session] of sessions.entries()) {
    sessionList.push({
      userId,
      username: session.username,
      currentState: session.currentState,
      messageCount: session.messageCount,
      lastActivity: session.lastActivity,
      role: session.role
    });
  }
  
  return sessionList;
}

export function deleteSession(userId) {
  return sessions.delete(userId);
}

export function clearAllSessions() {
  const count = sessions.size;
  sessions.clear();
  logger.info(`Cleared all ${count} sessions`);
  return count;
}