import { verificationMiddleware } from './verification.js';
import { sessionMiddleware } from './session.js';        // ✅ SEKARANG ADA
import { rateLimiter } from './rateLimiter.js';          // ✅ SEKARANG ADA
import { adminMiddleware } from './adminAuth.js';        // ✅ SEKARANG ADA
import { Logger } from '../utils/logger.js';

const logger = new Logger();

export function setupMiddleware(bot) {
  // 1. Session middleware - runs first (harus paling awal)
  bot.use(sessionMiddleware());
  logger.success('✅ Session middleware configured');
  
  // 2. Rate limiter - runs second
  bot.use(rateLimiter());
  logger.success('✅ Rate limiter configured');
  
  // 3. Verification middleware - runs third
  bot.use(verificationMiddleware());
  logger.success('✅ Verification middleware configured');
  
  // 4. Admin middleware - runs only on admin commands
  bot.use(adminMiddleware());
  logger.success('✅ Admin auth middleware configured');
  
  logger.success('🎯 All middleware configured successfully');
}

export { 
  verificationMiddleware, 
  sessionMiddleware,     // ✅ EXPORTED
  rateLimiter,          // ✅ EXPORTED
  adminMiddleware       // ✅ EXPORTED
};