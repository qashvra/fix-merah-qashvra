import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import { Logger } from '../utils/logger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const logger = new Logger();

class ConfigManager {
  constructor() {
    this.configPath = path.join(__dirname, '../../data/config.json');
    this.config = null;
    this.defaultConfig = {
      requiredChannels: [
        "@qashvrachannel",
        "@qashvragroup",
        "@qashvraupdate"
      ],
      botSettings: {
        maintenanceMode: false,
        maxDailyLimit: {
          FREE: 2,
          VIP: 999999,
          VVIP: 999999
        },
        maxNumbersPerRequest: {
          FREE: 1,
          VIP: 5,
          VVIP: 25
        },
        cooldownSeconds: {
          FREE: 300,
          VIP: 60,
          VVIP: 10
        }
      },
      referralRewards: {
        coinsPerReferral: 10,
        vip1DayCost: 100,
        vip7DaysCost: 300,
        vip30DaysCost: 1000
      },
      subscriptionPrices: {
        vip1Day: 5000,
        vip7Days: 25000,
        vip30Days: 100000,
        vvip1Day: 15000,
        vvip7Days: 75000,
        vvip30Days: 250000
      },
      queueSettings: {
        maxConcurrent: 10,
        retryAttempts: 3,
        retryDelayMs: 5000,
        timeoutMs: 60000
      },
      securitySettings: {
        maxRequestsPerMinute: 30,
        maxFailedAttempts: 5,
        banDurationHours: 24,
        antiSpamEnabled: true
      },
      adminIds: [8396965752],
      paymentTimeout: 3600 // 1 hour in seconds
    };
  }

  async initialize() {
    try {
      await this.loadConfig();
      logger.success('ConfigManager initialized');
    } catch (error) {
      logger.error('Failed to initialize ConfigManager:', error);
      throw error;
    }
  }

  async loadConfig() {
    try {
      const exists = await fs.pathExists(this.configPath);
      
      if (!exists) {
        await fs.writeJson(this.configPath, this.defaultConfig, { spaces: 2 });
        this.config = { ...this.defaultConfig };
        logger.info('Created default configuration file');
      } else {
        this.config = await fs.readJson(this.configPath);
        // Merge with defaults to ensure new fields exist
        this.config = this.mergeDeep(this.defaultConfig, this.config);
        await this.saveConfig();
      }
    } catch (error) {
      logger.error('Error loading config:', error);
      this.config = { ...this.defaultConfig };
    }
  }

  async saveConfig() {
    try {
      await fs.writeJson(this.configPath, this.config, { spaces: 2 });
      logger.success('Configuration saved successfully');
    } catch (error) {
      logger.error('Failed to save configuration:', error);
      throw error;
    }
  }

  mergeDeep(target, source) {
    const output = { ...target };
    
    if (this.isObject(target) && this.isObject(source)) {
      Object.keys(source).forEach(key => {
        if (this.isObject(source[key])) {
          if (!(key in target)) {
            output[key] = source[key];
          } else {
            output[key] = this.mergeDeep(target[key], source[key]);
          }
        } else {
          output[key] = source[key];
        }
      });
    }
    
    return output;
  }

  isObject(item) {
    return item && typeof item === 'object' && !Array.isArray(item);
  }

  get(key, defaultValue = null) {
    const keys = key.split('.');
    let value = this.config;
    
    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        return defaultValue;
      }
    }
    
    return value;
  }

  async set(key, value) {
    const keys = key.split('.');
    let obj = this.config;
    
    for (let i = 0; i < keys.length - 1; i++) {
      if (!(keys[i] in obj)) {
        obj[keys[i]] = {};
      }
      obj = obj[keys[i]];
    }
    
    obj[keys[keys.length - 1]] = value;
    await this.saveConfig();
  }

  async addRequiredChannel(channelUsername) {
    if (!this.config.requiredChannels.includes(channelUsername)) {
      this.config.requiredChannels.push(channelUsername);
      await this.saveConfig();
      logger.success(`Added required channel: ${channelUsername}`);
    }
  }

  async removeRequiredChannel(channelUsername) {
    this.config.requiredChannels = this.config.requiredChannels.filter(
      ch => ch !== channelUsername
    );
    await this.saveConfig();
    logger.success(`Removed required channel: ${channelUsername}`);
  }

  getRequiredChannels() {
    return this.config.requiredChannels || [];
  }

  isAdmin(userId) {
    return this.config.adminIds.includes(userId) || 
           userId === parseInt(process.env.OWNER_ID);
  }

  isOwner(userId) {
    return userId === parseInt(process.env.OWNER_ID);
  }

  getSubscriptionPrice(plan) {
    return this.config.subscriptionPrices[plan] || 0;
  }

  async addAdmin(userId) {
    if (!this.config.adminIds.includes(userId)) {
      this.config.adminIds.push(userId);
      await this.saveConfig();
      logger.admin('system', 'addAdmin', userId);
    }
  }

  async removeAdmin(userId) {
    this.config.adminIds = this.config.adminIds.filter(id => id !== userId);
    await this.saveConfig();
    logger.admin('system', 'removeAdmin', userId);
  }
}

// Create singleton instance
const configManager = new ConfigManager();
await configManager.initialize();

export { configManager, ConfigManager };